
  # Launch OS

  This is a code bundle for Launch OS. The original project is available at https://www.figma.com/design/5sgXJnv4cRmpcZeiE3UTN3/Launch-OS.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  