import { Suspense } from "react";
import { RouterProvider } from "react-router";
import { router } from "./routes";
import { I18nProvider } from "./components/i18n";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { ThemeProvider } from "./components/ThemeProvider";
import { ThemeAwareToaster } from "./components/ThemeAwareToaster";
import { PageSkeleton } from "./components/PageSkeleton";

// App root
export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider>
        <I18nProvider>
          <Suspense fallback={<PageSkeleton />}>
            <RouterProvider router={router} />
          </Suspense>
          <ThemeAwareToaster />
        </I18nProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}