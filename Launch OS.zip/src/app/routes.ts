import { createBrowserRouter, redirect } from "react-router";
import { lazy } from "react";
import { isAuthenticated } from "./components/user-progress";

/* ─── Eager loads: Landing + Layout shell ─── */
import { LandingPage } from "./components/LandingPage";
import { Layout } from "./components/Layout";
import { NotFound } from "./components/NotFound";

/* ─── Lazy loads: Auth pages (not needed until navigation) ─── */
const AuthPage = lazy(() => import("./components/AuthPage").then((m) => ({ default: m.AuthPage })));
const ForgotPassword = lazy(() => import("./components/ForgotPassword").then((m) => ({ default: m.ForgotPassword })));
const Onboarding = lazy(() => import("./components/Onboarding").then((m) => ({ default: m.Onboarding })));

/* ─── Lazy loads: Dashboard pages ─── */
const Dashboard = lazy(() => import("./components/Dashboard").then((m) => ({ default: m.Dashboard })));
const ProjectWizard = lazy(() => import("./components/ProjectWizard").then((m) => ({ default: m.ProjectWizard })));
const PackageBuilder = lazy(() => import("./components/PackageBuilder").then((m) => ({ default: m.PackageBuilder })));
const LaunchEngine = lazy(() => import("./components/LaunchEngine").then((m) => ({ default: m.LaunchEngine })));
const LaunchTracker = lazy(() => import("./components/LaunchTracker").then((m) => ({ default: m.LaunchTracker })));
const AnalyticsDashboard = lazy(() => import("./components/AnalyticsDashboard").then((m) => ({ default: m.AnalyticsDashboard })));
const TokenStore = lazy(() => import("./components/TokenStore").then((m) => ({ default: m.TokenStore })));
const CommunityBoost = lazy(() => import("./components/CommunityBoost").then((m) => ({ default: m.CommunityBoost })));
const SettingsPage = lazy(() => import("./components/SettingsPage").then((m) => ({ default: m.SettingsPage })));
const Growth = lazy(() => import("./components/Growth").then((m) => ({ default: m.Growth })));
const Messages = lazy(() => import("./components/Messages").then((m) => ({ default: m.Messages })));
const ABTestDashboard = lazy(() => import("./components/ABTestDashboard").then((m) => ({ default: m.ABTestDashboard })));
const ProjectDetail = lazy(() => import("./components/ProjectDetail").then((m) => ({ default: m.ProjectDetail })));
const ProjectsPage = lazy(() => import("./components/ProjectsPage").then((m) => ({ default: m.ProjectsPage })));
const DistributionLive = lazy(() => import("./components/DistributionLive").then((m) => ({ default: m.DistributionLive })));
const LaunchFeed = lazy(() => import("./components/LaunchFeed").then((m) => ({ default: m.LaunchFeed })));
const ROIDashboard = lazy(() => import("./components/ROIDashboard").then((m) => ({ default: m.ROIDashboard })));
const TalentHub = lazy(() => import("./components/TalentHub").then((m) => ({ default: m.TalentHub })));
const ContentPlan = lazy(() => import("./components/ContentPlan").then((m) => ({ default: m.ContentPlan })));
const Roadmap = lazy(() => import("./components/Roadmap").then((m) => ({ default: m.Roadmap })));
const FAQPage = lazy(() => import("./components/FAQPage").then((m) => ({ default: m.FAQPage })));
const WelcomeSplash = lazy(() => import("./components/WelcomeSplash").then((m) => ({ default: m.WelcomeSplash })));

/* ─── Auth guard loader ─── */
function requireAuth() {
  if (!isAuthenticated()) {
    return redirect("/onboarding");
  }
  return null;
}

export const router = createBrowserRouter([
  {
    path: "/",
    Component: LandingPage,
  },
  {
    path: "/login",
    Component: AuthPage,
  },
  {
    path: "/forgot-password",
    Component: ForgotPassword,
  },
  {
    path: "/onboarding",
    Component: Onboarding,
  },
  {
    path: "/welcome",
    Component: WelcomeSplash,
  },
  {
    path: "/dashboard",
    Component: Layout,
    loader: requireAuth,
    children: [
      { index: true, Component: Dashboard },
      { path: "projects", Component: ProjectsPage },
      { path: "new-project", Component: ProjectWizard },
      { path: "project/:projectId", Component: ProjectDetail },
      { path: "package", Component: PackageBuilder },
      { path: "launch", Component: LaunchEngine },
      { path: "tracker", Component: LaunchTracker },
      { path: "analytics", Component: AnalyticsDashboard },
      { path: "tokens", Component: TokenStore },
      { path: "community", Component: CommunityBoost },
      { path: "messages", Component: Messages },
      { path: "growth", Component: Growth },
      { path: "settings", Component: SettingsPage },
      { path: "ab-test", Component: ABTestDashboard },
      { path: "distribution-live", Component: DistributionLive },
      { path: "launch-feed", Component: LaunchFeed },
      { path: "roi-dashboard", Component: ROIDashboard },
      { path: "talent-hub", Component: TalentHub },
      { path: "content-plan", Component: ContentPlan },
      { path: "roadmap", Component: Roadmap },
      { path: "faq", Component: FAQPage },
      { path: "*", Component: NotFound },
    ],
  },
  {
    path: "*",
    Component: NotFound,
  },
]);