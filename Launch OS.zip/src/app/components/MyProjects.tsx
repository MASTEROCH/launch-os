import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import {
  Plus, Rocket, Package, Globe, FileText, CheckCircle, Pause, Trash2,
  MoreHorizontal, Star, ExternalLink, Clock, Search, LayoutGrid, List,
  ArrowDownAZ, ArrowDown01, Filter, ChevronDown, X, Crown, Lock,
} from "lucide-react";
import { useI18n } from "./i18n";
import {
  loadProjects, deleteProject, setActiveProjectId, getActiveProjectId,
  type Project, saveProjects, createProject, loadProgress, addProject,
} from "./user-progress";
import { getProjectLimit } from "./subscription";
import { toast } from "sonner";

/* ─── Status config ─── */
const STATUS_CONFIG: Record<string, { icon: typeof Rocket; color: string; bg: string; border: string; dot: string }> = {
  draft:    { icon: FileText,    color: "text-zinc-400",    bg: "bg-zinc-500/10",    border: "border-zinc-500/20",    dot: "bg-zinc-400"    },
  ready:    { icon: CheckCircle, color: "text-emerald-400", bg: "bg-emerald-500/10", border: "border-emerald-500/20", dot: "bg-emerald-400" },
  launched: { icon: Rocket,      color: "text-purple-400",  bg: "bg-purple-500/10",  border: "border-purple-500/20",  dot: "bg-purple-400"  },
  paused:   { icon: Pause,       color: "text-amber-400",   bg: "bg-amber-500/10",   border: "border-amber-500/20",   dot: "bg-amber-400"   },
};

const COLOR_MAP: Record<string, string> = {
  purple:  "from-purple-500 to-violet-600",
  blue:    "from-blue-500 to-cyan-600",
  emerald: "from-emerald-500 to-teal-600",
  rose:    "from-rose-500 to-pink-600",
  amber:   "from-amber-500 to-orange-600",
  cyan:    "from-cyan-500 to-sky-600",
  violet:  "from-violet-500 to-purple-600",
  orange:  "from-orange-500 to-red-600",
};

const STATUS_ORDER: Record<string, number> = { launched: 0, ready: 1, draft: 2, paused: 3 };
const COLORS = Object.keys(COLOR_MAP);
const STATUSES: Project["status"][] = ["draft", "ready", "launched", "paused"];
const PAGE_SIZE = 12;

/* ─── 25 diverse demo projects ─── */
const DEMO_PROJECTS: Partial<Project>[] = [
  { name: "AI Task Manager",       category: "SaaS / Productivity",  status: "launched", launchDay: 5, channelsConnected: 4, contentGenerated: 100, color: "purple",  description: "AI-powered task prioritization for small teams", audience: "Small dev teams 2-15 people" },
  { name: "NomadPay",              category: "FinTech",              status: "launched", launchDay: 3, channelsConnected: 3, contentGenerated: 85,  color: "blue",    description: "Cross-border payments for digital nomads", audience: "Remote workers & freelancers" },
  { name: "FitCoach AI",           category: "Health & Fitness",     status: "launched", launchDay: 7, channelsConnected: 5, contentGenerated: 100, color: "emerald", description: "Personalized workout plans with computer vision", audience: "Fitness enthusiasts 25-40" },
  { name: "ShopStream",            category: "E-commerce",           status: "ready",    launchDay: 0, channelsConnected: 3, contentGenerated: 90,  color: "rose",    description: "Live shopping platform for indie brands", audience: "DTC brands & small retailers" },
  { name: "CodeReview Bot",        category: "DevTools",             status: "ready",    launchDay: 0, channelsConnected: 2, contentGenerated: 75,  color: "cyan",    description: "AI code reviewer that catches bugs before PR merge", audience: "Engineering teams using GitHub" },
  { name: "PetMatch",              category: "Marketplace",          status: "launched", launchDay: 2, channelsConnected: 4, contentGenerated: 95,  color: "amber",   description: "Tinder for pet adoption — swipe to find your match", audience: "Pet lovers in urban areas" },
  { name: "LearnLang",             category: "EdTech",               status: "ready",    launchDay: 0, channelsConnected: 1, contentGenerated: 60,  color: "violet",  description: "Language learning through AI-generated stories", audience: "Language learners 18-35" },
  { name: "GreenRoute",            category: "CleanTech",            status: "draft",    launchDay: 0, channelsConnected: 0, contentGenerated: 30,  color: "emerald", description: "Carbon-optimized delivery routing for logistics", audience: "Logistics companies & couriers" },
  { name: "MealPrep AI",           category: "FoodTech",             status: "draft",    launchDay: 0, channelsConnected: 0, contentGenerated: 15,  color: "orange",  description: "Weekly meal planning with smart grocery lists", audience: "Busy professionals & families" },
  { name: "DesignSync",            category: "Design Tools",         status: "ready",    launchDay: 0, channelsConnected: 2, contentGenerated: 80,  color: "purple",  description: "Real-time design collaboration for distributed teams", audience: "Design teams & agencies" },
  { name: "TaxBot",                category: "FinTech",              status: "paused",   launchDay: 4, channelsConnected: 2, contentGenerated: 70,  color: "blue",    description: "Automated tax filing for freelancers", audience: "Freelancers & solo entrepreneurs" },
  { name: "EventForge",            category: "Events / SaaS",        status: "launched", launchDay: 6, channelsConnected: 5, contentGenerated: 100, color: "rose",    description: "AI event planning from concept to execution", audience: "Event organizers & companies" },
  { name: "StudyBuddy",            category: "EdTech",               status: "draft",    launchDay: 0, channelsConnected: 0, contentGenerated: 10,  color: "cyan",    description: "AI tutoring assistant for university students", audience: "College students 18-25" },
  { name: "HomeSwap",              category: "Travel / Marketplace", status: "ready",    launchDay: 0, channelsConnected: 3, contentGenerated: 65,  color: "amber",   description: "Home exchange platform for remote workers", audience: "Digital nomads & remote workers" },
  { name: "BrandKit AI",           category: "Marketing / SaaS",     status: "launched", launchDay: 1, channelsConnected: 4, contentGenerated: 100, color: "violet",  description: "Generate complete brand identity with AI in minutes", audience: "Startups & solopreneurs" },
  { name: "Voiceflow Clone",       category: "No-Code / AI",         status: "draft",    launchDay: 0, channelsConnected: 0, contentGenerated: 5,   color: "purple",  description: "Build conversational AI agents without code", audience: "Product managers & marketers" },
  { name: "CryptoAlert",           category: "Crypto / FinTech",     status: "paused",   launchDay: 3, channelsConnected: 2, contentGenerated: 55,  color: "orange",  description: "Smart price alerts with sentiment analysis", audience: "Crypto traders & investors" },
  { name: "FreelanceOS",           category: "Productivity / SaaS",  status: "ready",    launchDay: 0, channelsConnected: 1, contentGenerated: 45,  color: "blue",    description: "All-in-one freelancer management — invoices, contracts, time", audience: "Freelancers & consultants" },
  { name: "ParkSpot",              category: "Mobility / IoT",       status: "draft",    launchDay: 0, channelsConnected: 0, contentGenerated: 20,  color: "emerald", description: "Real-time parking availability with ML prediction", audience: "Urban drivers & parking operators" },
  { name: "RecipeAI",              category: "FoodTech / Consumer",  status: "launched", launchDay: 4, channelsConnected: 3, contentGenerated: 90,  color: "rose",    description: "Generate recipes from fridge photos", audience: "Home cooks & food enthusiasts" },
  { name: "MeetingMind",           category: "Productivity / AI",    status: "ready",    launchDay: 0, channelsConnected: 2, contentGenerated: 70,  color: "cyan",    description: "AI meeting notes, action items & follow-ups", audience: "Remote teams & managers" },
  { name: "PlantDoc",              category: "AgriTech / Consumer",  status: "draft",    launchDay: 0, channelsConnected: 0, contentGenerated: 0,   color: "emerald", description: "Diagnose plant diseases from a photo", audience: "Gardeners & small farmers" },
  { name: "Legalese",              category: "LegalTech",            status: "paused",   launchDay: 2, channelsConnected: 1, contentGenerated: 40,  color: "violet",  description: "Plain-English contract summaries powered by AI", audience: "Small businesses & freelancers" },
  { name: "SkillSwap",             category: "Community / EdTech",   status: "draft",    launchDay: 0, channelsConnected: 0, contentGenerated: 25,  color: "amber",   description: "Peer-to-peer skill exchange marketplace", audience: "Lifelong learners & professionals" },
  { name: "StreamDeck Cloud",      category: "Creator Tools",        status: "ready",    launchDay: 0, channelsConnected: 2, contentGenerated: 50,  color: "orange",  description: "Browser-based stream control panel for creators", audience: "Streamers & content creators" },
];

function seedDemoProjects(): Project[] {
  const now = Date.now();
  const projects = DEMO_PROJECTS.map((d, i) => {
    const daysAgo = Math.floor(Math.random() * 45) + 1;
    const updatedDaysAgo = Math.max(0, daysAgo - Math.floor(Math.random() * 10));
    return createProject({
      ...d,
      createdAt: now - daysAgo * 86_400_000,
      updatedAt: now - updatedDaysAgo * 86_400_000,
      tokensUsed: Math.floor(Math.random() * 500),
    });
  });
  saveProjects(projects);
  setActiveProjectId(projects[0].id);
  return projects;
}

type ViewMode = "grid" | "list";
type SortMode = "newest" | "name" | "status";
type StatusFilter = "all" | Project["status"];

export function MyProjects() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [menuOpen, setMenuOpen] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  /* ─── UX state ─── */
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [sort, setSort] = useState<SortMode>("newest");
  const [view, setView] = useState<ViewMode>("grid");
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);

  /* ─── Plan limits ─── */
  const { limit: projectLimit, planId } = getProjectLimit();
  const isAtLimit = projectLimit !== Infinity && projects.length >= projectLimit;
  const planLabel = planId.charAt(0).toUpperCase() + planId.slice(1);

  useEffect(() => {
    let list = loadProjects();
    if (list.length === 0) {
      // Migrate legacy single-project
      const progress = loadProgress();
      if (progress.projectCreated && progress.projectName) {
        const p = addProject({
          name: progress.projectName,
          category: progress.projectCategory,
          url: progress.projectUrl,
          description: progress.projectDescription,
          audience: progress.audience,
          status: progress.launched ? "launched" : "ready",
          launchDay: progress.launchDay,
          channelsConnected: progress.channelsConnected,
        });
        list = [p];
      } else {
        // Seed demo data for UX testing
        list = seedDemoProjects();
      }
    }
    setProjects(list);
    setActiveId(getActiveProjectId());
  }, []);

  /* ─── Derived data ─── */
  const statusCounts = useMemo(() => {
    const c: Record<string, number> = { all: projects.length, draft: 0, ready: 0, launched: 0, paused: 0 };
    projects.forEach((p) => { c[p.status] = (c[p.status] || 0) + 1; });
    return c;
  }, [projects]);

  const filtered = useMemo(() => {
    let result = [...projects];

    // Status filter
    if (statusFilter !== "all") {
      result = result.filter((p) => p.status === statusFilter);
    }

    // Search
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter((p) =>
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
      );
    }

    // Sort
    if (sort === "newest") {
      result.sort((a, b) => b.updatedAt - a.updatedAt);
    } else if (sort === "name") {
      result.sort((a, b) => a.name.localeCompare(b.name));
    } else {
      result.sort((a, b) => (STATUS_ORDER[a.status] ?? 9) - (STATUS_ORDER[b.status] ?? 9));
    }

    return result;
  }, [projects, statusFilter, search, sort]);

  const visible = filtered.slice(0, visibleCount);
  const hasMore = visibleCount < filtered.length;

  // Reset visible count when filter changes
  useEffect(() => { setVisibleCount(PAGE_SIZE); }, [statusFilter, search, sort]);

  /* ─── Actions ─── */
  const handleSetActive = (id: string) => {
    setActiveProjectId(id);
    setActiveId(id);
    setMenuOpen(null);
    toast.success(t("projects.active"));
  };

  const handleDelete = (id: string) => {
    deleteProject(id);
    const updated = loadProjects();
    setProjects(updated);
    setActiveId(getActiveProjectId());
    setDeleteConfirm(null);
    setMenuOpen(null);
    toast.success(t("projects.deleted"));
  };

  /* ─── Empty state ─── */
  if (projects.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-6 rounded-2xl border border-dashed border-white/[0.06] bg-white/[0.01]"
      >
        <div className="flex flex-col items-center text-center py-6">
          <div className="w-14 h-14 rounded-2xl bg-purple-500/10 border border-purple-500/10 flex items-center justify-center mb-4">
            <Rocket className="w-6 h-6 text-purple-500/40" />
          </div>
          <h3 className="text-zinc-400 text-sm mb-1" style={{ fontWeight: 600 }}>{t("projects.empty")}</h3>
          <p className="text-xs text-zinc-600 mb-5 max-w-xs">{t("projects.emptyDesc")}</p>
          <button
            onClick={() => navigate("/dashboard/new-project")}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white px-5 py-2.5 rounded-xl text-sm transition-all shadow-lg shadow-purple-500/20"
            style={{ fontWeight: 600 }}
          >
            <Plus className="w-4 h-4" />
            {t("projects.createFirst")}
          </button>
        </div>
      </motion.div>
    );
  }

  /* ─── Format relative date ─── */
  const relativeDate = (ts: number) => {
    const diff = Date.now() - ts;
    const mins = Math.floor(diff / 60_000);
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    const days = Math.floor(hrs / 24);
    if (days < 30) return `${days}d ago`;
    return new Date(ts).toLocaleDateString();
  };

  /* ─── Render ─── */
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      {/* ═══ Header: title + new project ═══ */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <h2 className="text-white text-sm" style={{ fontWeight: 700 }}>{t("projects.title")}</h2>
          <span className="text-[11px] text-zinc-500 bg-white/[0.04] px-2 py-0.5 rounded-md" style={{ fontWeight: 600 }}>
            {projects.length}{projectLimit !== Infinity ? ` / ${projectLimit}` : ""}
          </span>
        </div>
        {isAtLimit ? (
          <button
            onClick={() => navigate("/dashboard/settings")}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white text-xs transition-all shrink-0"
            style={{ fontWeight: 600 }}
          >
            <Crown className="w-3.5 h-3.5" />
            {t("projects.upgrade")}
          </button>
        ) : (
          <button
            onClick={() => navigate("/dashboard/new-project")}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs transition-all shrink-0"
            style={{ fontWeight: 600 }}
          >
            <Plus className="w-3.5 h-3.5" />
            {t("projects.new")}
          </button>
        )}
      </div>

      {/* ═══ Plan limit bar ═══ */}
      {projectLimit !== Infinity && (
        <div className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
          isAtLimit
            ? "border-amber-500/20 bg-amber-500/[0.04]"
            : "border-white/[0.04] bg-white/[0.02]"
        }`}>
          <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
            isAtLimit ? "bg-amber-500/10" : "bg-purple-500/10"
          }`}>
            {isAtLimit ? <Lock className="w-4 h-4 text-amber-400" /> : <Rocket className="w-4 h-4 text-purple-400" />}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[11px] text-zinc-400" style={{ fontWeight: 500 }}>
                {planLabel} plan
              </span>
              <span className={`text-[11px] ${isAtLimit ? "text-amber-400" : "text-zinc-500"}`} style={{ fontWeight: 600 }}>
                {projects.length} {t("projects.usedOf")} {projectLimit}
              </span>
            </div>
            <div className="h-1.5 rounded-full bg-white/[0.04] overflow-hidden">
              <motion.div
                className={`h-full rounded-full ${
                  isAtLimit
                    ? "bg-gradient-to-r from-amber-500 to-orange-500"
                    : "bg-gradient-to-r from-purple-500 to-violet-500"
                }`}
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(100, (projects.length / projectLimit) * 100)}%` }}
                transition={{ type: "spring", stiffness: 200, damping: 25 }}
              />
            </div>
          </div>
          {isAtLimit && (
            <button
              onClick={() => navigate("/dashboard/settings")}
              className="text-[11px] text-amber-400 hover:text-amber-300 transition-colors shrink-0 flex items-center gap-1"
              style={{ fontWeight: 600 }}
            >
              <Crown className="w-3 h-3" />
              {t("projects.upgrade")}
            </button>
          )}
        </div>
      )}

      {/* ═══ Toolbar: search + filters + view toggle ═══ */}
      <div className="space-y-3">
        {/* Search bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t("projects.search")}
            className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.06] text-sm text-white placeholder:text-zinc-600 outline-none focus:border-purple-500/30 focus:bg-white/[0.06] transition-all"
          />
          {search && (
            <button
              onClick={() => setSearch("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 rounded-full bg-white/[0.08] flex items-center justify-center hover:bg-white/[0.12] transition-all"
            >
              <X className="w-3 h-3 text-zinc-400" />
            </button>
          )}
        </div>

        {/* Filter row */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Status pills */}
          <div className="flex items-center gap-1 flex-1 overflow-x-auto pb-0.5 scrollbar-hide">
            {(["all", ...STATUSES] as StatusFilter[]).map((s) => {
              const isActive = statusFilter === s;
              const cfg = s === "all" ? null : STATUS_CONFIG[s];
              return (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs whitespace-nowrap transition-all ${
                    isActive
                      ? "bg-white/[0.1] text-white"
                      : "bg-white/[0.02] text-zinc-500 hover:bg-white/[0.06] hover:text-zinc-300"
                  }`}
                  style={{ fontWeight: isActive ? 600 : 400 }}
                >
                  {cfg && <div className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />}
                  {s === "all" ? t("projects.all") : t(`projects.${s}`)}
                  <span className={`text-[10px] ${isActive ? "text-zinc-300" : "text-zinc-600"}`}>
                    {statusCounts[s] || 0}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Sort + View */}
          <div className="flex items-center gap-1.5 shrink-0">
            {/* Sort dropdown */}
            <div className="relative group/sort">
              <button className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white/[0.03] text-xs text-zinc-500 hover:bg-white/[0.06] hover:text-zinc-300 transition-all border border-white/[0.04]">
                {sort === "newest" ? <ArrowDown01 className="w-3.5 h-3.5" /> : sort === "name" ? <ArrowDownAZ className="w-3.5 h-3.5" /> : <Filter className="w-3.5 h-3.5" />}
                <ChevronDown className="w-3 h-3" />
              </button>
              <div className="absolute right-0 top-full mt-1 w-36 rounded-xl bg-zinc-900 border border-white/10 py-1 opacity-0 invisible group-hover/sort:opacity-100 group-hover/sort:visible transition-all z-50 shadow-2xl">
                {(["newest", "name", "status"] as SortMode[]).map((s) => (
                  <button
                    key={s}
                    onClick={() => setSort(s)}
                    className={`w-full flex items-center gap-2 px-3 py-2 text-xs transition-colors ${
                      sort === s ? "text-purple-400" : "text-zinc-400 hover:text-white hover:bg-white/5"
                    }`}
                  >
                    {s === "newest" && <ArrowDown01 className="w-3.5 h-3.5" />}
                    {s === "name" && <ArrowDownAZ className="w-3.5 h-3.5" />}
                    {s === "status" && <Filter className="w-3.5 h-3.5" />}
                    {t(`projects.sort${s.charAt(0).toUpperCase() + s.slice(1)}`)}
                  </button>
                ))}
              </div>
            </div>

            {/* View toggle */}
            <div className="flex items-center rounded-lg bg-white/[0.03] border border-white/[0.04] overflow-hidden">
              <button
                onClick={() => setView("grid")}
                className={`p-1.5 transition-all ${view === "grid" ? "bg-white/[0.1] text-white" : "text-zinc-600 hover:text-zinc-400"}`}
                title={t("projects.gridView")}
              >
                <LayoutGrid className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setView("list")}
                className={`p-1.5 transition-all ${view === "list" ? "bg-white/[0.1] text-white" : "text-zinc-600 hover:text-zinc-400"}`}
                title={t("projects.listView")}
              >
                <List className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ═══ Showing X of Y ═══ */}
      {(search || statusFilter !== "all") && (
        <div className="text-[11px] text-zinc-600">
          {t("projects.showing")} {filtered.length} {t("projects.of")} {projects.length}
        </div>
      )}

      {/* ═══ No results ═══ */}
      {filtered.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="py-12 flex flex-col items-center text-center"
        >
          <Search className="w-8 h-8 text-zinc-700 mb-3" />
          <p className="text-sm text-zinc-500" style={{ fontWeight: 500 }}>{t("projects.noMatch")}</p>
          <button
            onClick={() => { setSearch(""); setStatusFilter("all"); }}
            className="mt-3 text-xs text-purple-400 hover:text-purple-300 transition-colors"
          >
            {t("projects.clearSearch")}
          </button>
        </motion.div>
      )}

      {/* ═══ Grid View ═══ */}
      {view === "grid" && filtered.length > 0 && (
        <div className="grid gap-3 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence>
            {visible.map((project, i) => (
              <GridCard
                key={project.id}
                project={project}
                index={i}
                isActive={activeId === project.id}
                menuOpen={menuOpen === project.id}
                onMenuToggle={() => setMenuOpen(menuOpen === project.id ? null : project.id)}
                onOpen={() => navigate(`/dashboard/project/${project.id}`)}
                onSetActive={() => handleSetActive(project.id)}
                onDeleteRequest={() => { setDeleteConfirm(project.id); setMenuOpen(null); }}
                relativeDate={relativeDate}
                t={t}
              />
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* ═══ List View ═══ */}
      {view === "list" && filtered.length > 0 && (
        <div className="space-y-1.5">
          <AnimatePresence>
            {visible.map((project, i) => (
              <ListRow
                key={project.id}
                project={project}
                index={i}
                isActive={activeId === project.id}
                menuOpen={menuOpen === project.id}
                onMenuToggle={() => setMenuOpen(menuOpen === project.id ? null : project.id)}
                onOpen={() => navigate(`/dashboard/project/${project.id}`)}
                onSetActive={() => handleSetActive(project.id)}
                onDeleteRequest={() => { setDeleteConfirm(project.id); setMenuOpen(null); }}
                relativeDate={relativeDate}
                t={t}
              />
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* ═══ Load more ═══ */}
      {hasMore && (
        <div className="flex justify-center pt-2">
          <button
            onClick={() => setVisibleCount((c) => c + PAGE_SIZE)}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.06] text-sm text-zinc-400 hover:text-white hover:bg-white/[0.08] transition-all"
          >
            {t("projects.loadMore")}
            <span className="text-[11px] text-zinc-600">
              ({Math.min(PAGE_SIZE, filtered.length - visibleCount)} {t("projects.of")} {filtered.length - visibleCount})
            </span>
          </button>
        </div>
      )}

      {/* Close menu on outside click */}
      {menuOpen && (
        <div className="fixed inset-0 z-[110]" onClick={() => setMenuOpen(null)} />
      )}

      {/* ═══ Delete confirmation modal ═══ */}
      <AnimatePresence>
        {deleteConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60"
            onClick={() => setDeleteConfirm(null)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="liquid-glass-modal w-full max-w-sm rounded-2xl p-6 text-center"
              role="dialog"
              aria-modal="true"
              aria-label={t("projects.delete")}
            >
              <div className="w-12 h-12 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-5 h-5 text-red-400" />
              </div>
              <h3 className="text-white mb-2" style={{ fontWeight: 700 }}>{t("projects.delete")}</h3>
              <p className="text-sm text-zinc-400 mb-6">{t("projects.deleteConfirm")}</p>
              <div className="flex gap-3 justify-center">
                <button
                  onClick={() => setDeleteConfirm(null)}
                  className="px-5 py-2 rounded-xl border border-white/10 text-sm text-zinc-400 hover:text-white transition-all"
                >
                  {t("projDetail.cancel")}
                </button>
                <button
                  onClick={() => handleDelete(deleteConfirm)}
                  className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-sm transition-all"
                >
                  {t("projects.delete")}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════════
   Grid Card — compact project card
   ═══════════════════════════════════════════════════ */
interface CardProps {
  project: Project;
  index: number;
  isActive: boolean;
  menuOpen: boolean;
  onMenuToggle: () => void;
  onOpen: () => void;
  onSetActive: () => void;
  onDeleteRequest: () => void;
  relativeDate: (ts: number) => string;
  t: (key: string) => string;
}

function GridCard({ project, index, isActive, menuOpen, onMenuToggle, onOpen, onSetActive, onDeleteRequest, relativeDate, t }: CardProps) {
  const statusCfg = STATUS_CONFIG[project.status] || STATUS_CONFIG.draft;
  const StatusIcon = statusCfg.icon;
  const gradientClass = COLOR_MAP[project.color] || COLOR_MAP.purple;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ delay: Math.min(index * 0.03, 0.3) }}
      className={`relative group rounded-xl border bg-white/[0.02] hover:bg-white/[0.04] transition-all cursor-pointer ios-press ${
        isActive
          ? "border-purple-500/30 shadow-lg shadow-purple-500/5"
          : "border-white/5 hover:border-white/10"
      }`}
      onClick={onOpen}
    >
      {/* Active badge */}
      {isActive && (
        <div className="absolute -top-1.5 -right-1.5 z-10">
          <div className="w-5 h-5 rounded-full bg-purple-500 flex items-center justify-center shadow-lg shadow-purple-500/30">
            <Star className="w-3 h-3 text-white" />
          </div>
        </div>
      )}

      {/* Gradient stripe */}
      <div className={`h-1 rounded-t-xl bg-gradient-to-r ${gradientClass}`} />

      <div className="p-3.5">
        {/* Top row */}
        <div className="flex items-start justify-between gap-2 mb-1.5">
          <h3 className="text-white text-[13px] truncate flex-1" style={{ fontWeight: 600 }}>
            {project.name}
          </h3>
          <div className="relative shrink-0">
            <button
              onClick={(e) => { e.stopPropagation(); onMenuToggle(); }}
              className="w-6 h-6 rounded-md flex items-center justify-center text-zinc-600 hover:text-zinc-400 hover:bg-white/5 transition-all opacity-0 group-hover:opacity-100"
            >
              <MoreHorizontal className="w-4 h-4" />
            </button>
            <AnimatePresence>
              {menuOpen && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: -4 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -4 }}
                  className="absolute right-0 top-full mt-1 w-44 rounded-xl bg-zinc-900 border border-white/10 py-1 z-[120] shadow-2xl"
                  onClick={(e) => e.stopPropagation()}
                >
                  <button onClick={onOpen}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-zinc-300 hover:text-white hover:bg-white/5 transition-colors">
                    <ExternalLink className="w-3.5 h-3.5" />{t("projects.open")}
                  </button>
                  {!isActive && (
                    <button onClick={onSetActive}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs text-zinc-300 hover:text-white hover:bg-white/5 transition-colors">
                      <Star className="w-3.5 h-3.5" />{t("projects.setActive")}
                    </button>
                  )}
                  <div className="my-1 h-px bg-white/5" />
                  <button onClick={onDeleteRequest}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-red-400 hover:text-red-300 hover:bg-red-500/5 transition-colors">
                    <Trash2 className="w-3.5 h-3.5" />{t("projects.delete")}
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Category */}
        <p className="text-[11px] text-zinc-600 truncate mb-2">{project.category}</p>

        {/* Status badge */}
        <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] ${statusCfg.bg} ${statusCfg.color} mb-2.5`} style={{ fontWeight: 600 }}>
          <StatusIcon className="w-3 h-3" />
          {t(`projects.${project.status}`)}
        </div>

        {/* Progress bar for contentGenerated */}
        {project.contentGenerated > 0 && (
          <div className="mb-2.5">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] text-zinc-600">{t("projects.content")}</span>
              <span className="text-[10px] text-zinc-500" style={{ fontWeight: 600 }}>{project.contentGenerated}%</span>
            </div>
            <div className="h-1 rounded-full bg-white/[0.04] overflow-hidden">
              <div
                className={`h-full rounded-full bg-gradient-to-r ${gradientClass} transition-all`}
                style={{ width: `${project.contentGenerated}%` }}
              />
            </div>
          </div>
        )}

        {/* Mini stats row */}
        <div className="flex items-center gap-3 text-[10px] text-zinc-600">
          {project.channelsConnected > 0 && (
            <span className="flex items-center gap-0.5"><Globe className="w-3 h-3" />{project.channelsConnected}</span>
          )}
          {project.launchDay > 0 && (
            <span className="flex items-center gap-0.5"><Rocket className="w-3 h-3" />{t("projects.day")} {project.launchDay}</span>
          )}
          <span className="flex items-center gap-0.5 ml-auto"><Clock className="w-3 h-3" />{relativeDate(project.updatedAt)}</span>
        </div>
      </div>
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════════
   List Row — compact horizontal row
   ═══════════════════════════════════════════════════ */
function ListRow({ project, index, isActive, menuOpen, onMenuToggle, onOpen, onSetActive, onDeleteRequest, relativeDate, t }: CardProps) {
  const statusCfg = STATUS_CONFIG[project.status] || STATUS_CONFIG.draft;
  const StatusIcon = statusCfg.icon;
  const gradientClass = COLOR_MAP[project.color] || COLOR_MAP.purple;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, x: -8 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -8 }}
      transition={{ delay: Math.min(index * 0.02, 0.25) }}
      className={`group flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all hover:bg-white/[0.04] ${
        isActive
          ? "border-purple-500/30 bg-purple-500/[0.03]"
          : "border-white/[0.03] bg-white/[0.01] hover:border-white/[0.08]"
      }`}
      onClick={onOpen}
    >
      {/* Color indicator */}
      <div className={`w-1 h-8 rounded-full bg-gradient-to-b ${gradientClass} shrink-0`} />

      {/* Active star */}
      {isActive && (
        <div className="w-5 h-5 rounded-full bg-purple-500 flex items-center justify-center shrink-0 shadow shadow-purple-500/30">
          <Star className="w-3 h-3 text-white" />
        </div>
      )}

      {/* Name + category */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-[13px] text-white truncate" style={{ fontWeight: 600 }}>{project.name}</span>
        </div>
        <span className="text-[11px] text-zinc-600 truncate block">{project.category}</span>
      </div>

      {/* Content progress - hidden on small screens */}
      {project.contentGenerated > 0 && (
        <div className="hidden sm:flex items-center gap-2 w-24 shrink-0">
          <div className="h-1 flex-1 rounded-full bg-white/[0.04] overflow-hidden">
            <div
              className={`h-full rounded-full bg-gradient-to-r ${gradientClass}`}
              style={{ width: `${project.contentGenerated}%` }}
            />
          </div>
          <span className="text-[10px] text-zinc-500 w-7 text-right" style={{ fontWeight: 500 }}>{project.contentGenerated}%</span>
        </div>
      )}

      {/* Stats */}
      <div className="hidden md:flex items-center gap-3 text-[10px] text-zinc-600 shrink-0">
        {project.channelsConnected > 0 && (
          <span className="flex items-center gap-0.5"><Globe className="w-3 h-3" />{project.channelsConnected}</span>
        )}
        {project.launchDay > 0 && (
          <span className="flex items-center gap-0.5"><Rocket className="w-3 h-3" />{t("projects.day")} {project.launchDay}</span>
        )}
      </div>

      {/* Status */}
      <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] shrink-0 ${statusCfg.bg} ${statusCfg.color}`} style={{ fontWeight: 600 }}>
        <StatusIcon className="w-3 h-3" />
        <span className="hidden sm:inline">{t(`projects.${project.status}`)}</span>
      </div>

      {/* Date */}
      <span className="hidden lg:flex items-center gap-0.5 text-[10px] text-zinc-600 shrink-0 w-14 justify-end">
        <Clock className="w-3 h-3" />{relativeDate(project.updatedAt)}
      </span>

      {/* Menu */}
      <div className="relative shrink-0">
        <button
          onClick={(e) => { e.stopPropagation(); onMenuToggle(); }}
          className="w-6 h-6 rounded-md flex items-center justify-center text-zinc-600 hover:text-zinc-400 hover:bg-white/5 transition-all opacity-0 group-hover:opacity-100"
        >
          <MoreHorizontal className="w-4 h-4" />
        </button>
        <AnimatePresence>
          {menuOpen && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -4 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -4 }}
              className="absolute right-0 top-full mt-1 w-44 rounded-xl bg-zinc-900 border border-white/10 py-1 z-[120] shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <button onClick={onOpen}
                className="w-full flex items-center gap-2 px-3 py-2 text-xs text-zinc-300 hover:text-white hover:bg-white/5 transition-colors">
                <ExternalLink className="w-3.5 h-3.5" />{t("projects.open")}
              </button>
              {!isActive && (
                <button onClick={onSetActive}
                  className="w-full flex items-center gap-2 px-3 py-2 text-xs text-zinc-300 hover:text-white hover:bg-white/5 transition-colors">
                  <Star className="w-3.5 h-3.5" />{t("projects.setActive")}
                </button>
              )}
              <div className="my-1 h-px bg-white/5" />
              <button onClick={onDeleteRequest}
                className="w-full flex items-center gap-2 px-3 py-2 text-xs text-red-400 hover:text-red-300 hover:bg-red-500/5 transition-colors">
                <Trash2 className="w-3.5 h-3.5" />{t("projects.delete")}
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}