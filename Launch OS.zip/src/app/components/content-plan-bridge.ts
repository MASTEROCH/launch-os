/**
 * Content Plan Bridge — syncs LaunchEngine cards → Content Plan items.
 * LaunchEngine calls `syncToContentPlan()`, ContentPlan listens via event.
 */

export interface ContentPlanItem {
  id: string;
  title: string;
  body: string;
  platform: string;
  status: "idea" | "draft" | "scheduled" | "published";
  date: string;
  time: string;
  tags: string[];
  aiGenerated: boolean;
  sourceEngine?: boolean;
}

const LS_KEY = "launchapp_content_plan";
const EVENT_NAME = "launchapp:content-plan-sync";

/** Platform name → content plan platform key mapping */
const PLATFORM_MAP: Record<string, string> = {
  "Product Hunt": "producthunt",
  "Twitter / X": "twitter",
  "Twitter/X": "twitter",
  "LinkedIn": "linkedin",
  "Reddit": "reddit",
  "Hacker News": "forum",
  "Indie Hackers": "forum",
  "Dev.to": "blog",
  "Telegram": "newsletter",
  "YouTube": "blog",
  "Facebook": "twitter",
  "Instagram": "twitter",
  "Email PR": "newsletter",
  "Catalogs": "blog",
  "SEO": "blog",
  "Newsletters": "newsletter",
  "Forums": "forum",
};

export function syncToContentPlan(cards: {
  id: string;
  platform: string;
  title: string;
  content: string;
  status: "generated" | "scheduled" | "published";
  scheduledDate?: string;
  estReach: number;
}[]) {
  try {
    const existing: ContentPlanItem[] = JSON.parse(localStorage.getItem(LS_KEY) || "[]");
    const existingEngineIds = new Set(existing.filter(e => e.sourceEngine).map(e => e.id));
    
    const newItems: ContentPlanItem[] = [];
    const now = new Date();

    for (const card of cards) {
      const engineId = `engine-${card.id}`;
      if (existingEngineIds.has(engineId)) {
        // Update existing
        const idx = existing.findIndex(e => e.id === engineId);
        if (idx >= 0) {
          existing[idx].status = card.status === "generated" ? "draft" : card.status;
          existing[idx].body = card.content;
          if (card.scheduledDate) {
            const parts = card.scheduledDate.split(" ");
            existing[idx].date = parts[0] || existing[idx].date;
            existing[idx].time = parts[1] || existing[idx].time;
          }
        }
        continue;
      }

      const platformKey = PLATFORM_MAP[card.platform] || "blog";
      const date = card.scheduledDate?.split(" ")[0] || now.toISOString().split("T")[0];
      const time = card.scheduledDate?.split(" ")[1] || "10:00";

      newItems.push({
        id: engineId,
        title: card.title,
        body: card.content,
        platform: platformKey,
        status: card.status === "generated" ? "draft" : card.status,
        date,
        time,
        tags: [platformKey, "engine-sync"],
        aiGenerated: true,
        sourceEngine: true,
      });
    }

    const merged = [...existing, ...newItems];
    localStorage.setItem(LS_KEY, JSON.stringify(merged));

    // Dispatch event so ContentPlan re-reads
    document.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: { count: newItems.length, updated: cards.length - newItems.length } }));

    return { added: newItems.length, updated: cards.length - newItems.length };
  } catch {
    return { added: 0, updated: 0 };
  }
}

export { LS_KEY, EVENT_NAME };
