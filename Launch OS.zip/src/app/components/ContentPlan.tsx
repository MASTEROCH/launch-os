import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  CalendarDays, Plus, ChevronLeft, ChevronRight, Check,
  Clock, Edit3, Trash2, Copy, Sparkles, Send,
  Twitter, Linkedin, Globe, MessageSquare, Rss,
  Hash, Eye, ArrowRight, Zap, Filter,
  LayoutGrid, List, GripVertical, AlertCircle,
  Download, FileText, FileSpreadsheet, Link2, X,
  Repeat, BarChart3, Target, TrendingUp, Wand2,
  Pause, Play, MoveRight,
  Bell, BellOff, CheckSquare, Square,
  Columns3, Coins,
} from "lucide-react";
import { useNavigate } from "react-router";
import { useI18n } from "./i18n";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { loadProgress } from "./user-progress";
import { toast } from "sonner";
import { DndProvider, useDrag, useDrop } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { TouchBackend } from "react-dnd-touch-backend";
import jsPDF from "jspdf";
import { EVENT_NAME } from "./content-plan-bridge";

/* ─── Types ─── */
export type PostStatus = "idea" | "draft" | "scheduled" | "published" | "paused";
export type Platform = "twitter" | "linkedin" | "reddit" | "producthunt" | "blog" | "newsletter" | "forum";

export interface ContentItem {
  id: string;
  title: string;
  body: string;
  platform: Platform;
  status: PostStatus;
  date: string;
  time: string;
  tags: string[];
  aiGenerated: boolean;
  sourceEngine?: boolean;
}

const PLATFORM_META: Record<Platform, { icon: typeof Twitter; label: string; color: string; bgColor: string; hex: string }> = {
  twitter: { icon: Twitter, label: "Twitter / X", color: "text-sky-400", bgColor: "bg-sky-500/10", hex: "#38bdf8" },
  linkedin: { icon: Linkedin, label: "LinkedIn", color: "text-blue-400", bgColor: "bg-blue-500/10", hex: "#60a5fa" },
  reddit: { icon: MessageSquare, label: "Reddit", color: "text-orange-400", bgColor: "bg-orange-500/10", hex: "#fb923c" },
  producthunt: { icon: Zap, label: "Product Hunt", color: "text-orange-500", bgColor: "bg-orange-500/10", hex: "#f97316" },
  blog: { icon: Globe, label: "Blog / SEO", color: "text-emerald-400", bgColor: "bg-emerald-500/10", hex: "#34d399" },
  newsletter: { icon: Rss, label: "Newsletter", color: "text-violet-400", bgColor: "bg-violet-500/10", hex: "#a78bfa" },
  forum: { icon: Hash, label: "Forums", color: "text-amber-400", bgColor: "bg-amber-500/10", hex: "#fbbf24" },
};

const STATUS_META: Record<PostStatus, { label: string; labelRu: string; color: string; dotColor: string; i18nKey: string }> = {
  idea: { label: "Idea", labelRu: "Идея", color: "text-zinc-400 bg-zinc-500/10 border-zinc-500/20", dotColor: "bg-zinc-500", i18nKey: "contentPlan.statusIdea" },
  draft: { label: "Draft", labelRu: "Черновик", color: "text-amber-400 bg-amber-500/10 border-amber-500/20", dotColor: "bg-amber-500", i18nKey: "contentPlan.statusDraft" },
  scheduled: { label: "Scheduled", labelRu: "Запланирован", color: "text-cyan-400 bg-cyan-500/10 border-cyan-500/20", dotColor: "bg-cyan-500", i18nKey: "contentPlan.statusScheduled" },
  published: { label: "Published", labelRu: "Опубликован", color: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20", dotColor: "bg-emerald-500", i18nKey: "contentPlan.statusPublished" },
  paused: { label: "Paused", labelRu: "На паузе", color: "text-orange-400 bg-orange-500/10 border-orange-500/20", dotColor: "bg-orange-500", i18nKey: "contentPlan.statusPaused" },
};

const DND_TYPE = "CONTENT_ITEM";

/* ─── Mock AI content generation ─── */
function generateMockContent(projectName: string, platform: Platform, dayOffset: number): ContentItem {
  const now = new Date();
  now.setDate(now.getDate() + dayOffset);
  const date = now.toISOString().split("T")[0];

  const templates: Record<Platform, { titles: string[]; bodies: string[] }> = {
    twitter: {
      titles: ["Launch thread", "Feature highlight", "User testimonial", "Behind the scenes", "Milestone update"],
      bodies: [
        `Launching ${projectName} today!\n\nWe built it because existing solutions are slow & expensive.\n\nHere's what makes us different:\n- 10x faster\n- AI-powered\n- Free tier\n\nThread below:`,
        `Feature spotlight: Smart automation in ${projectName}\n\nWhat used to take 2 hours now takes 2 minutes.\n\nHere's how it works:`,
        `"${projectName} saved us 15 hours/week" — @earlyuser\n\nHearing feedback like this is why we build.\n\nWhat would you do with 15 extra hours?`,
      ],
    },
    linkedin: {
      titles: ["Launch announcement", "Founder story", "Industry insight", "Team milestone"],
      bodies: [
        `Excited to announce the launch of ${projectName}!\n\nAfter 6 months of building, testing, and iterating with 200+ beta users, we're ready.\n\nThe problem we solve:\nTeams waste 30% of their time on repetitive tasks that should be automated.\n\n${projectName} uses AI to identify and automate these workflows — no coding required.\n\n#startup #launch #productivity`,
        `The story behind ${projectName}:\n\n3 years ago, I was frustrated with how much time our team spent on manual processes. Every tool promised automation but delivered complexity.\n\nSo we built something different.\n\nKey insight: The best automation is invisible.`,
      ],
    },
    reddit: {
      titles: ["r/startups launch post", "r/SaaS case study", "r/Entrepreneur AMA"],
      bodies: [
        `[Launch] ${projectName} — AI-powered workflow automation\n\nHey r/startups! Just launched our product after 6 months of development.\n\nQuick stats:\n- 200+ beta users\n- 40% avg time savings\n- Free tier available\n\nWould love your honest feedback. AMA!`,
      ],
    },
    producthunt: {
      titles: ["PH launch day", "PH maker update", "PH collection feature"],
      bodies: [
        `${projectName} — AI that automates your workflow\n\nProblem: Teams waste hours on repetitive tasks\nSolution: AI identifies patterns and automates them\nResult: 40% time savings for beta users\n\nWe're live on Product Hunt today! Your support means everything.`,
      ],
    },
    blog: {
      titles: ["SEO pillar article", "How-to guide", "Comparison post", "Case study"],
      bodies: [
        `Title: "How ${projectName} Saves Teams 15 Hours Per Week"\n\nTarget keyword: "${projectName.toLowerCase()} automation"\nWord count: 2,500\nCTA: Free trial signup\n\nOutline:\n1. The hidden cost of manual work\n2. How AI automation works\n3. Real results from beta users\n4. Getting started (3 steps)`,
      ],
    },
    newsletter: {
      titles: ["Launch announcement email", "Weekly update", "Feature deep-dive"],
      bodies: [
        `Subject: ${projectName} is live!\n\nHi {name},\n\nAfter months of building, ${projectName} is officially live.\n\nWhat you get:\n+ AI-powered automation\n+ 5-minute setup\n+ Free tier to start\n\nAs an early subscriber, you get 30% off for life.\n\n[CTA: Start Free ->]`,
      ],
    },
    forum: {
      titles: ["Indie Hackers update", "HN Show post", "Niche forum intro"],
      bodies: [
        `Show HN/IH: ${projectName} – AI workflow automation\n\nBuilt this over the last 6 months. The core idea: instead of building complex automation rules, let AI learn from how you work.\n\nStack: React, Node.js, OpenAI\nUsers: 200+ in beta\n\nFeedback welcome!`,
      ],
    },
  };

  const t = templates[platform];
  const titleIdx = Math.abs(dayOffset) % t.titles.length;
  const bodyIdx = Math.abs(dayOffset) % t.bodies.length;

  const statuses: PostStatus[] = dayOffset < 0 ? ["published"] : dayOffset === 0 ? ["scheduled", "draft"] : dayOffset < 3 ? ["draft", "scheduled"] : ["idea", "draft"];
  const status = statuses[Math.abs(dayOffset) % statuses.length];

  const hours = [9, 10, 12, 14, 16, 18];
  const time = `${String(hours[Math.abs(dayOffset) % hours.length]).padStart(2, "0")}:00`;

  return {
    id: `cp-${platform}-${dayOffset}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    title: t.titles[titleIdx],
    body: t.bodies[bodyIdx],
    platform,
    status,
    date,
    time,
    tags: [projectName.toLowerCase(), platform, status === "published" ? "posted" : "upcoming"],
    aiGenerated: true,
  };
}

/* ─── LS key ─── */
const LS_KEY = "launchapp_content_plan";

function loadPlan(): ContentItem[] {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return [];
}

function savePlan(items: ContentItem[]) {
  try { localStorage.setItem(LS_KEY, JSON.stringify(items)); } catch {}
}

/* ─── Detect touch device ─── */
const isTouchDevice = typeof window !== "undefined" && ("ontouchstart" in window || navigator.maxTouchPoints > 0);

/* ════════════════════════════════════════════════
   Draggable Content Card (calendar mini-card)
   ════════════════════════════════════════════════ */
function DraggableCalendarItem({ item }: { item: ContentItem }) {
  const pm = PLATFORM_META[item.platform];
  const sm = STATUS_META[item.status];

  const [{ isDragging }, dragRef] = useDrag({
    type: DND_TYPE,
    item: { id: item.id, sourceDate: item.date },
    collect: (monitor) => ({ isDragging: monitor.isDragging() }),
  });

  return (
    <div
      ref={dragRef as unknown as React.Ref<HTMLDivElement>}
      className={`flex items-center gap-1 px-1.5 py-[3px] rounded-md text-[9px] sm:text-[10px] truncate cursor-grab active:cursor-grabbing transition-all ${pm.bgColor} hover:ring-1 hover:ring-white/10 ${isDragging ? "opacity-30 scale-95" : "opacity-100"}`}
      title={`${item.title} -- ${sm.label}`}
    >
      <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${sm.dotColor}`} />
      <pm.icon className={`w-2.5 h-2.5 shrink-0 ${pm.color} opacity-70`} />
      <span className={`truncate ${pm.color}`}>{item.title}</span>
    </div>
  );
}

/* ════════════════════════════════════════════════
   Droppable Calendar Day Cell
   ════════════════════════════════════════════════ */
function DroppableDayCell({
  day,
  dateStr,
  isToday,
  isSelected,
  dayItems,
  onSelect,
  onDrop,
  isPast,
}: {
  day: number;
  dateStr: string;
  isToday: boolean;
  isSelected: boolean;
  dayItems: ContentItem[];
  onSelect: () => void;
  onDrop: (itemId: string, targetDate: string) => void;
  isPast: boolean;
}) {
  const [{ isOver, canDrop }, dropRef] = useDrop({
    accept: DND_TYPE,
    drop: (dragItem: { id: string; sourceDate: string }) => {
      if (dragItem.sourceDate !== dateStr) {
        onDrop(dragItem.id, dateStr);
      }
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
      canDrop: monitor.canDrop(),
    }),
  });

  const statusCounts = useMemo(() => {
    const counts: Partial<Record<PostStatus, number>> = {};
    dayItems.forEach((i) => { counts[i.status] = (counts[i.status] || 0) + 1; });
    return counts;
  }, [dayItems]);

  return (
    <div
      ref={dropRef as unknown as React.Ref<HTMLDivElement>}
      onClick={onSelect}
      className={`min-h-[72px] sm:min-h-[90px] p-1 sm:p-1.5 rounded-lg text-left transition-all flex flex-col cursor-pointer group/cell ${
        isOver && canDrop
          ? "bg-purple-500/15 border-2 border-purple-500/40 border-dashed scale-[1.02]"
          : isSelected
          ? "bg-purple-500/10 border border-purple-500/30 shadow-sm shadow-purple-500/10"
          : isToday
          ? "bg-white/[0.05] border border-purple-500/20"
          : isPast
          ? "bg-white/[0.01] border border-transparent opacity-60 hover:opacity-100"
          : "hover:bg-white/[0.03] border border-transparent hover:border-white/5"
      }`}
    >
      <div className="flex items-center justify-between">
        <span className={`text-[11px] px-1 ${isToday ? "text-purple-400" : isPast ? "text-zinc-600" : "text-zinc-500"}`} style={{ fontWeight: isToday ? 700 : 400 }}>
          {day}
        </span>
        {dayItems.length > 0 && (
          <span className="text-[9px] text-zinc-600 px-1">{dayItems.length}</span>
        )}
      </div>
      <div className="flex-1 flex flex-col gap-0.5 mt-0.5 overflow-hidden">
        {dayItems.slice(0, 3).map((item) => (
          <DraggableCalendarItem key={item.id} item={item} />
        ))}
        {dayItems.length > 3 && (
          <span className="text-[9px] text-zinc-600 px-1">+{dayItems.length - 3}</span>
        )}
      </div>
      {/* Status dots summary */}
      {dayItems.length > 0 && (
        <div className="flex items-center gap-0.5 mt-auto pt-0.5 px-0.5">
          {Object.entries(statusCounts).map(([status, count]) => (
            <div key={status} className={`w-1.5 h-1.5 rounded-full ${STATUS_META[status as PostStatus]?.dotColor}`} title={`${count} ${status}`} />
          ))}
        </div>
      )}
    </div>
  );
}

/* ════════════════════════════════════════════════
   Draggable List Row
   ════════════════════════════════════════════════ */
function DraggableListRow({
  item,
  t,
  updateStatus,
  duplicateItem,
  deleteItem,
  onEdit,
  onPreview,
  onAbTest,
  abTest,
  bulkMode,
  isSelected,
  onToggleSelect,
}: {
  item: ContentItem;
  t: (k: string) => string;
  updateStatus: (id: string, s: PostStatus) => void;
  duplicateItem: (item: ContentItem) => void;
  deleteItem: (id: string) => void;
  onEdit: (item: ContentItem) => void;
  onPreview: (item: ContentItem) => void;
  onAbTest: (item: ContentItem) => void;
  abTest?: { a: string; b: string; aClicks: number; bClicks: number };
  bulkMode?: boolean;
  isSelected?: boolean;
  onToggleSelect?: () => void;
}) {
  const pm = PLATFORM_META[item.platform];
  const sm = STATUS_META[item.status];

  const [{ isDragging }, dragRef, previewRef] = useDrag({
    type: DND_TYPE,
    item: { id: item.id, sourceDate: item.date },
    collect: (monitor) => ({ isDragging: monitor.isDragging() }),
  });

  return (
    <motion.div
      ref={previewRef as unknown as React.Ref<HTMLDivElement>}
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: isDragging ? 0.3 : 1, x: 0 }}
      className={`flex items-start gap-3 p-3 sm:p-4 rounded-xl border transition-all group ${isSelected ? "border-purple-500/30 bg-purple-500/[0.04]" : "border-white/5 bg-white/[0.02] hover:border-white/10"}`}
    >
      {/* Bulk checkbox */}
      {bulkMode && (
        <button onClick={(e) => { e.stopPropagation(); onToggleSelect?.(); }} className="mt-1 shrink-0">
          {isSelected
            ? <CheckSquare className="w-4 h-4 text-purple-400" />
            : <Square className="w-4 h-4 text-zinc-600 hover:text-zinc-400 transition-colors" />}
        </button>
      )}
      {/* Drag handle */}
      <div
        ref={dragRef as unknown as React.Ref<HTMLDivElement>}
        className="mt-1 cursor-grab active:cursor-grabbing text-zinc-700 hover:text-zinc-500 transition-colors shrink-0 hidden sm:flex"
        title="Drag to reorder"
      >
        <GripVertical className="w-4 h-4" />
      </div>
      <div className={`w-9 h-9 rounded-lg ${pm.bgColor} flex items-center justify-center shrink-0`}>
        <pm.icon className={`w-4 h-4 ${pm.color}`} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          <span className="text-sm text-white truncate" style={{ fontWeight: 500 }}>{item.title}</span>
          {item.aiGenerated && <Sparkles className="w-3 h-3 text-purple-400 shrink-0" />}
          {item.sourceEngine && <Link2 className="w-3 h-3 text-cyan-400 shrink-0" title="From Launch Engine" />}
        </div>
        <p className="text-xs text-zinc-500 line-clamp-1">{item.body.split("\n")[0]}</p>
        <div className="flex items-center gap-2 mt-1.5 flex-wrap">
          <span className={`text-[10px] px-1.5 py-0.5 rounded-full border ${sm.color}`}>{t(sm.i18nKey)}</span>
          <span className="text-[10px] text-zinc-600 flex items-center gap-1">
            <Clock className="w-2.5 h-2.5" />{item.date} · {item.time}
          </span>
          <span className="text-[10px] text-zinc-600">{pm.label}</span>
        </div>
      </div>
      <div className="flex flex-col items-end gap-1 shrink-0">
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button onClick={() => onPreview(item)} className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-purple-500/10 text-zinc-600 hover:text-purple-400 transition-all" title="Preview">
            <Eye className="w-3.5 h-3.5" />
          </button>
          <button onClick={() => onAbTest(item)} className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-orange-500/10 text-zinc-600 hover:text-orange-400 transition-all" title="A/B Test">
            <Repeat className="w-3.5 h-3.5" />
          </button>
          <button onClick={() => onEdit(item)} className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-600 hover:text-zinc-300 transition-all" title="Edit">
            <Edit3 className="w-3.5 h-3.5" />
          </button>
          {item.status === "draft" && (
            <button onClick={() => updateStatus(item.id, "scheduled")} className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-cyan-500/10 text-zinc-600 hover:text-cyan-400 transition-all" title="Schedule">
              <Send className="w-3.5 h-3.5" />
            </button>
          )}
          {item.status === "scheduled" && (
            <button onClick={() => updateStatus(item.id, "published")} className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-emerald-500/10 text-zinc-600 hover:text-emerald-400 transition-all" title="Publish">
              <Check className="w-3.5 h-3.5" />
            </button>
          )}
          {item.status !== "paused" && item.status !== "published" && (
            <button onClick={() => updateStatus(item.id, "paused")} className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-orange-500/10 text-zinc-600 hover:text-orange-400 transition-all" title="Pause">
              <Pause className="w-3.5 h-3.5" />
            </button>
          )}
          {item.status === "paused" && (
            <button onClick={() => updateStatus(item.id, "draft")} className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-emerald-500/10 text-zinc-600 hover:text-emerald-400 transition-all" title="Resume">
              <Play className="w-3.5 h-3.5" />
            </button>
          )}
          <button onClick={() => duplicateItem(item)} className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-600 hover:text-zinc-300 transition-all" title="Duplicate">
            <Copy className="w-3.5 h-3.5" />
          </button>
          <button onClick={() => deleteItem(item.id)} className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-red-500/10 text-zinc-600 hover:text-red-400 transition-all" title="Delete">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
        {abTest && (
          <div className="flex items-center gap-1.5 text-[9px]">
            <span className={abTest.aClicks >= abTest.bClicks ? "text-emerald-400" : "text-zinc-500"}>A: {abTest.aClicks}</span>
            <span className="text-zinc-700">vs</span>
            <span className={abTest.bClicks > abTest.aClicks ? "text-emerald-400" : "text-zinc-500"}>B: {abTest.bClicks}</span>
          </div>
        )}
      </div>
    </motion.div>
  );
}

/* ════════════════════════════════════════════════
   Export Utilities
   ════════════════════════════════════════════════ */
function exportCSV(items: ContentItem[], projectName: string) {
  const header = "Date,Time,Platform,Status,Title,Content,AI Generated,Source";
  const rows = items
    .sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`))
    .map((item) => {
      const escape = (s: string) => `"${s.replace(/"/g, '""').replace(/\n/g, " ")}"`;
      return [
        item.date,
        item.time,
        PLATFORM_META[item.platform]?.label || item.platform,
        STATUS_META[item.status]?.label || item.status,
        escape(item.title),
        escape(item.body),
        item.aiGenerated ? "Yes" : "No",
        item.sourceEngine ? "Launch Engine" : "Manual",
      ].join(",");
    });

  const csv = [header, ...rows].join("\n");
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${projectName.replace(/\s+/g, "-")}_content-plan_${new Date().toISOString().split("T")[0]}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

function exportPDF(items: ContentItem[], projectName: string) {
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const pageW = doc.internal.pageSize.getWidth();
  let y = 20;

  // Title
  doc.setFontSize(20);
  doc.setTextColor(100, 50, 200);
  doc.text(`${projectName} — Content Plan`, pageW / 2, y, { align: "center" });
  y += 10;
  doc.setFontSize(10);
  doc.setTextColor(120, 120, 120);
  doc.text(`Generated: ${new Date().toLocaleDateString()} | ${items.length} posts`, pageW / 2, y, { align: "center" });
  y += 12;

  // Stats summary
  const stats = {
    ideas: items.filter(i => i.status === "idea").length,
    drafts: items.filter(i => i.status === "draft").length,
    scheduled: items.filter(i => i.status === "scheduled").length,
    published: items.filter(i => i.status === "published").length,
  };

  doc.setFontSize(9);
  doc.setTextColor(80, 80, 80);
  doc.text(`Ideas: ${stats.ideas}  |  Drafts: ${stats.drafts}  |  Scheduled: ${stats.scheduled}  |  Published: ${stats.published}`, pageW / 2, y, { align: "center" });
  y += 10;

  // Separator line
  doc.setDrawColor(200, 200, 200);
  doc.line(15, y, pageW - 15, y);
  y += 8;

  // Group by date
  const sorted = [...items].sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`));
  let currentDate = "";

  for (const item of sorted) {
    if (y > 270) {
      doc.addPage();
      y = 20;
    }

    // Date header
    if (item.date !== currentDate) {
      currentDate = item.date;
      doc.setFontSize(11);
      doc.setTextColor(100, 50, 200);
      const dateLabel = new Date(item.date + "T00:00").toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
      doc.text(dateLabel, 15, y);
      y += 6;
    }

    // Item
    const platLabel = PLATFORM_META[item.platform as Platform]?.label || item.platform;
    const statusLabel = STATUS_META[item.status]?.label || item.status;

    doc.setFontSize(9);
    doc.setTextColor(40, 40, 40);
    doc.text(`${item.time}  [${platLabel}]  ${statusLabel}`, 20, y);
    y += 4.5;

    doc.setFontSize(10);
    doc.setTextColor(20, 20, 20);
    const titleLines = doc.splitTextToSize(item.title, pageW - 40);
    doc.text(titleLines, 20, y);
    y += titleLines.length * 4.5;

    doc.setFontSize(8);
    doc.setTextColor(100, 100, 100);
    const bodyPreview = item.body.split("\n").slice(0, 3).join(" ").substring(0, 200);
    const bodyLines = doc.splitTextToSize(bodyPreview + (item.body.length > 200 ? "..." : ""), pageW - 40);
    doc.text(bodyLines, 20, y);
    y += bodyLines.length * 3.5 + 5;

    // Light separator
    doc.setDrawColor(230, 230, 230);
    doc.line(20, y - 2, pageW - 20, y - 2);
  }

  // Footer on last page
  doc.setFontSize(8);
  doc.setTextColor(150, 150, 150);
  doc.text("Generated by Launch OS — Content Plan", pageW / 2, 290, { align: "center" });

  doc.save(`${projectName.replace(/\s+/g, "-")}_content-plan_${new Date().toISOString().split("T")[0]}.pdf`);
}

/* ════════════════════════════════════════════════
   MAIN COMPONENT
   ════════════════════════════════════════════════ */
function ContentPlanInner() {
  const navigate = useNavigate();
  const { t, lang } = useI18n();
  useDocumentTitle(t("contentPlan.title"));

  const progress = loadProgress();
  const projectName = progress.projectName || "My Project";

  const [items, setItems] = useState<ContentItem[]>(() => {
    const saved = loadPlan();
    if (saved.length > 0) return saved;
    const platforms: Platform[] = ["twitter", "linkedin", "reddit", "producthunt", "blog", "newsletter", "forum"];
    const initial: ContentItem[] = [];
    for (let day = -3; day <= 21; day++) {
      const count = day <= 0 ? 3 : day <= 7 ? 2 : 1;
      for (let j = 0; j < count; j++) {
        const platform = platforms[(day + j + 3) % platforms.length];
        initial.push(generateMockContent(projectName, platform, day));
      }
    }
    return initial;
  });

  useEffect(() => { savePlan(items); }, [items]);

  // ─── Listen for LaunchEngine sync events ───
  useEffect(() => {
    const handler = () => {
      const fresh = loadPlan();
      if (fresh.length > 0) setItems(fresh);
    };
    document.addEventListener(EVENT_NAME, handler);
    return () => document.removeEventListener(EVENT_NAME, handler);
  }, []);

  // ─── Content mode: Simple (beginners) vs Advanced ───
  const [contentMode, setContentMode] = useState<"simple" | "advanced">(() => {
    try { return (localStorage.getItem("launchapp_content_mode") as "simple" | "advanced") || "simple"; } catch { return "simple"; }
  });
  useEffect(() => { try { localStorage.setItem("launchapp_content_mode", contentMode); } catch {} }, [contentMode]);

  // ─── View mode ───
  const [viewMode, setViewMode] = useState<"calendar" | "list">("calendar");
  const [calendarScale, setCalendarScale] = useState<"month" | "week" | "day">("month");
  const [filterPlatform, setFilterPlatform] = useState<Platform | "all">("all");
  const [filterStatus, setFilterStatus] = useState<PostStatus | "all">("all");
  const [showExportMenu, setShowExportMenu] = useState(false);
  const exportRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (exportRef.current && !exportRef.current.contains(e.target as Node)) setShowExportMenu(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  // ─── Calendar navigation ───
  const [currentMonth, setCurrentMonth] = useState(() => {
    const now = new Date();
    return { year: now.getFullYear(), month: now.getMonth() };
  });
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [showNewModal, setShowNewModal] = useState(false);
  const [editItem, setEditItem] = useState<ContentItem | null>(null);

  // ─── Filtered items ───
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      if (filterPlatform !== "all" && item.platform !== filterPlatform) return false;
      if (filterStatus !== "all" && item.status !== filterStatus) return false;
      return true;
    });
  }, [items, filterPlatform, filterStatus]);

  // ─── Calendar helpers ───
  const daysInMonth = new Date(currentMonth.year, currentMonth.month + 1, 0).getDate();
  const firstDayOfWeek = new Date(currentMonth.year, currentMonth.month, 1).getDay();
  const monthName = new Date(currentMonth.year, currentMonth.month).toLocaleDateString(lang === "ru" ? "ru-RU" : "en-US", { month: "long", year: "numeric" });

  const prevMonth = () => setCurrentMonth((p) => p.month === 0 ? { year: p.year - 1, month: 11 } : { ...p, month: p.month - 1 });
  const nextMonth = () => setCurrentMonth((p) => p.month === 11 ? { year: p.year + 1, month: 0 } : { ...p, month: p.month + 1 });
  const goToday = () => {
    const now = new Date();
    setCurrentMonth({ year: now.getFullYear(), month: now.getMonth() });
  };

  const getDateStr = (day: number) => `${currentMonth.year}-${String(currentMonth.month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
  const todayStr = new Date().toISOString().split("T")[0];

  const itemsByDate = useMemo(() => {
    const map: Record<string, ContentItem[]> = {};
    filteredItems.forEach((item) => {
      if (!map[item.date]) map[item.date] = [];
      map[item.date].push(item);
    });
    return map;
  }, [filteredItems]);

  // ─── Stats ───
  const stats = useMemo(() => {
    const byPlatform: Record<string, number> = {};
    items.forEach((i) => { byPlatform[i.platform] = (byPlatform[i.platform] || 0) + 1; });
    const topPlatform = Object.entries(byPlatform).sort(([,a],[,b]) => b - a)[0];
    const scheduledNext7 = items.filter((i) => {
      if (i.status !== "scheduled") return false;
      const d = new Date(i.date);
      const now = new Date();
      const diff = (d.getTime() - now.getTime()) / (1000 * 60 * 60 * 24);
      return diff >= 0 && diff <= 7;
    }).length;

    return {
      total: items.length,
      ideas: items.filter((i) => i.status === "idea").length,
      drafts: items.filter((i) => i.status === "draft").length,
      scheduled: items.filter((i) => i.status === "scheduled").length,
      published: items.filter((i) => i.status === "published").length,
      paused: items.filter((i) => i.status === "paused").length,
      topPlatform: topPlatform ? { name: PLATFORM_META[topPlatform[0] as Platform]?.label || topPlatform[0], count: topPlatform[1] } : null,
      scheduledNext7,
      engineSynced: items.filter((i) => i.sourceEngine).length,
    };
  }, [items]);

  // ─── Actions ───
  const updateStatus = useCallback((id: string, status: PostStatus) => {
    setItems((prev) => prev.map((item) => item.id === id ? { ...item, status } : item));
    toast.success(t("contentPlan.statusUpdated"));
  }, [t]);

  const deleteItem = useCallback((id: string) => {
    setItems((prev) => prev.filter((item) => item.id !== id));
    toast.success(t("contentPlan.deleted"));
  }, [t]);

  const duplicateItem = useCallback((item: ContentItem) => {
    const newItem: ContentItem = {
      ...item,
      id: `cp-dup-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      status: "draft",
      title: `${item.title} (copy)`,
      sourceEngine: false,
    };
    setItems((prev) => [...prev, newItem]);
    toast.success(t("contentPlan.duplicated"));
  }, [t]);

  // ─── DnD: move item to new date ───
  const moveItemToDate = useCallback((itemId: string, newDate: string) => {
    setItems((prev) => prev.map((item) => item.id === itemId ? { ...item, date: newDate } : item));
    toast.success(t("contentPlan.moved"));
  }, [t]);

  // ─── AI generation ───
  const generateAI = useCallback(() => {
    const platforms: Platform[] = ["twitter", "linkedin", "reddit", "blog", "newsletter", "producthunt", "forum"];
    const newItems: ContentItem[] = [];
    for (let i = 0; i < 10; i++) {
      const platform = platforms[i % platforms.length];
      newItems.push(generateMockContent(projectName, platform, i + 1));
    }
    setItems((prev) => [...prev, ...newItems]);
    toast.success(t("contentPlan.aiGenerated"), { description: `+10 ${t("contentPlan.posts")}` });
  }, [projectName, t]);

  // ─── AI strategy generation (marketers killer) ───
  const [generatingStrategy, setGeneratingStrategy] = useState(false);
  const [strategyTemplate, setStrategyTemplate] = useState<"saas" | "b2b" | "consumer">("saas");

  const STRATEGY_TEMPLATES: Record<string, { label: string; desc: string; platforms: Platform[]; phases: { pre: number; post: number; growth: number } }> = {
    saas: { label: "SaaS Launch", desc: "PH + Twitter + Reddit + HN", platforms: ["twitter", "linkedin", "reddit", "producthunt", "blog", "newsletter", "forum"], phases: { pre: 5, post: 14, growth: 15 } },
    b2b: { label: "B2B Enterprise", desc: "LinkedIn + SEO + Email", platforms: ["linkedin", "blog", "newsletter", "twitter", "forum"], phases: { pre: 7, post: 21, growth: 30 } },
    consumer: { label: "Consumer App", desc: "Twitter + Reddit + PH", platforms: ["twitter", "reddit", "producthunt", "newsletter", "blog"], phases: { pre: 3, post: 7, growth: 14 } },
  };

  const generateFullStrategy = useCallback(() => {
    setGeneratingStrategy(true);
    const tpl = STRATEGY_TEMPLATES[strategyTemplate];
    setTimeout(() => {
      const strategyItems: ContentItem[] = [];
      const platforms = tpl.platforms;
      for (let day = -tpl.phases.pre; day < 0; day++) {
        platforms.slice(0, 3).forEach((p) => {
          strategyItems.push({ ...generateMockContent(projectName, p, day), tags: [projectName.toLowerCase(), "pre-launch", "buzz"] });
        });
      }
      platforms.forEach((p) => {
        strategyItems.push({ ...generateMockContent(projectName, p, 0), status: "scheduled", tags: [projectName.toLowerCase(), "launch-day", "critical"] });
      });
      for (let day = 1; day <= tpl.phases.post; day++) {
        const count = day <= 3 ? 3 : day <= 7 ? 2 : 1;
        for (let j = 0; j < count; j++) {
          strategyItems.push({ ...generateMockContent(projectName, platforms[(day + j) % platforms.length], day), tags: [projectName.toLowerCase(), day <= 3 ? "momentum" : "nurture"] });
        }
      }
      for (let day = tpl.phases.post + 1; day <= tpl.phases.post + tpl.phases.growth; day += 2) {
        strategyItems.push({ ...generateMockContent(projectName, platforms[day % platforms.length], day), tags: [projectName.toLowerCase(), "growth"] });
      }
      setItems(strategyItems);
      setGeneratingStrategy(false);
      toast.success(t("contentPlan.strategyGenerated"), { description: `${strategyItems.length} ${t("contentPlan.posts")}` });
    }, 2000);
  }, [projectName, t, strategyTemplate]);

  // ─── Post preview ───
  const [previewItem, setPreviewItem] = useState<ContentItem | null>(null);

  // ─── A/B testing ───
  const [abTestItem, setAbTestItem] = useState<ContentItem | null>(null);
  const [abVariantB, setAbVariantB] = useState("");
  const [abTests, setAbTests] = useState<Record<string, { a: string; b: string; aClicks: number; bClicks: number }>>(() => {
    try { const raw = localStorage.getItem("launchapp_ab_tests"); if (raw) return JSON.parse(raw); } catch {} return {};
  });
  useEffect(() => { try { localStorage.setItem("launchapp_ab_tests", JSON.stringify(abTests)); } catch {} }, [abTests]);
  const startAbTest = (item: ContentItem) => { setAbTestItem(item); setAbVariantB(item.title + " — v2"); };
  const saveAbTest = () => {
    if (!abTestItem) return;
    setAbTests((prev) => ({ ...prev, [abTestItem.id]: { a: abTestItem.title, b: abVariantB, aClicks: 50 + Math.floor(Math.random() * 200), bClicks: 50 + Math.floor(Math.random() * 200) } }));
    setAbTestItem(null);
    toast.success(t("contentPlan.abTestCreated"));
  };

  // ─── New post form ───
  const [newPlatform, setNewPlatform] = useState<Platform>("twitter");
  const [newTitle, setNewTitle] = useState("");
  const [newBody, setNewBody] = useState("");
  const [newDate, setNewDate] = useState(todayStr);
  const [newTime, setNewTime] = useState("10:00");

  const createPost = () => {
    if (!newTitle.trim()) return;
    const item: ContentItem = {
      id: `cp-new-${Date.now()}`,
      title: newTitle,
      body: newBody,
      platform: newPlatform,
      status: "draft",
      date: newDate,
      time: newTime,
      tags: [projectName.toLowerCase(), newPlatform],
      aiGenerated: false,
    };
    setItems((prev) => [...prev, item]);
    setShowNewModal(false);
    setNewTitle("");
    setNewBody("");
    toast.success(t("contentPlan.created"));
  };

  // ─── Edit post form ───
  const openEdit = (item: ContentItem) => {
    setEditItem({ ...item });
  };
  const saveEdit = () => {
    if (!editItem) return;
    setItems((prev) => prev.map((i) => i.id === editItem.id ? editItem : i));
    setEditItem(null);
    toast.success(t("contentPlan.saved"));
  };

  // ─── Sort list view by date ───
  const sortedItems = useMemo(() => {
    return [...filteredItems].sort((a, b) => {
      const da = `${a.date}T${a.time}`;
      const db = `${b.date}T${b.time}`;
      return da.localeCompare(db);
    });
  }, [filteredItems]);

  const weekDays = [
    t("contentPlan.sun"), t("contentPlan.mon"), t("contentPlan.tue"),
    t("contentPlan.wed"), t("contentPlan.thu"), t("contentPlan.fri"), t("contentPlan.sat"),
  ];

  // ─── Day detail drawer state ───
  const [dayDrawerDate, setDayDrawerDate] = useState<string | null>(null);
  const [inlineEditId, setInlineEditId] = useState<string | null>(null);
  const [inlineEditData, setInlineEditData] = useState<ContentItem | null>(null);
  const [movePostId, setMovePostId] = useState<string | null>(null);
  const [moveTargetDate, setMoveTargetDate] = useState("");
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // ─── Token cost system ───
  const TOKEN_COSTS = { edit: 5, move: 3, changePlatform: 5, pause: 2, resume: 2, relaunch: 10, duplicate: 3 } as const;
  const [tokenBalance, setTokenBalance] = useState(() => loadProgress().tokensAvailable || 1250);
  const [showTokenUpsell, setShowTokenUpsell] = useState(false);
  const [pendingTokenCost, setPendingTokenCost] = useState(0);

  const checkTokens = useCallback((cost: number, action: () => void) => {
    if (tokenBalance < cost) {
      setPendingTokenCost(cost);
      setShowTokenUpsell(true);
      return;
    }
    setTokenBalance((prev) => prev - cost);
    action();
  }, [tokenBalance]);

  const isOverdue = useCallback((item: ContentItem) => {
    if (item.status !== "scheduled" && item.status !== "paused") return false;
    const postTime = new Date(`${item.date}T${item.time}`);
    return postTime.getTime() < Date.now();
  }, []);

  const dayDrawerItems = useMemo(() => {
    if (!dayDrawerDate) return [];
    return (itemsByDate[dayDrawerDate] || []).sort((a, b) => a.time.localeCompare(b.time));
  }, [dayDrawerDate, itemsByDate]);

  const openDayDrawer = useCallback((dateStr: string) => {
    setDayDrawerDate(dateStr);
    setSelectedDate(dateStr);
    setInlineEditId(null);
    setInlineEditData(null);
    setMovePostId(null);
    setConfirmDeleteId(null);
  }, []);

  const closeDayDrawer = useCallback(() => {
    setDayDrawerDate(null);
    setSelectedDate(null);
    setInlineEditId(null);
    setInlineEditData(null);
  }, []);

  const startInlineEdit = useCallback((item: ContentItem) => {
    setInlineEditId(item.id);
    setInlineEditData({ ...item });
  }, []);

  const saveInlineEdit = useCallback(() => {
    if (!inlineEditData) return;
    setItems((prev) => prev.map((i) => i.id === inlineEditData.id ? inlineEditData : i));
    setInlineEditId(null);
    setInlineEditData(null);
    toast.success(t("contentPlan.postSaved"));
  }, [inlineEditData, t]);

  const discardInlineEdit = useCallback(() => {
    setInlineEditId(null);
    setInlineEditData(null);
  }, []);

  const confirmMovePost = useCallback(() => {
    if (!movePostId || !moveTargetDate) return;
    moveItemToDate(movePostId, moveTargetDate);
    setMovePostId(null);
    setMoveTargetDate("");
  }, [movePostId, moveTargetDate, moveItemToDate]);

  const confirmDeletePost = useCallback(() => {
    if (!confirmDeleteId) return;
    deleteItem(confirmDeleteId);
    setConfirmDeleteId(null);
  }, [confirmDeleteId, deleteItem]);

  // ─── Calendar scale: week helpers ───
  const [weekStart, setWeekStart] = useState<Date>(() => {
    const now = new Date();
    const d = new Date(now);
    d.setDate(d.getDate() - d.getDay());
    d.setHours(0, 0, 0, 0);
    return d;
  });

  const weekDates = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(weekStart);
      d.setDate(d.getDate() + i);
      return d;
    });
  }, [weekStart]);

  const prevWeek = () => setWeekStart((p) => { const d = new Date(p); d.setDate(d.getDate() - 7); return d; });
  const nextWeek = () => setWeekStart((p) => { const d = new Date(p); d.setDate(d.getDate() + 7); return d; });
  const goTodayWeek = () => {
    const now = new Date();
    const d = new Date(now);
    d.setDate(d.getDate() - d.getDay());
    d.setHours(0, 0, 0, 0);
    setWeekStart(d);
  };

  const weekLabel = useMemo(() => {
    const first = weekDates[0];
    const last = weekDates[6];
    const opts: Intl.DateTimeFormatOptions = { month: "short", day: "numeric" };
    const loc = lang === "ru" ? "ru-RU" : "en-US";
    return `${t("contentPlan.weekOf")} ${first.toLocaleDateString(loc, opts)} - ${last.toLocaleDateString(loc, opts)}`;
  }, [weekDates, lang, t]);

  // ─── Calendar scale: day helpers ───
  const [dayViewDate, setDayViewDate] = useState<Date>(() => new Date());
  const dayViewStr = useMemo(() => dayViewDate.toISOString().split("T")[0], [dayViewDate]);
  const dayViewItems = useMemo(() => (itemsByDate[dayViewStr] || []).sort((a, b) => a.time.localeCompare(b.time)), [dayViewStr, itemsByDate]);
  const prevDay = () => setDayViewDate((p) => { const d = new Date(p); d.setDate(d.getDate() - 1); return d; });
  const nextDay = () => setDayViewDate((p) => { const d = new Date(p); d.setDate(d.getDate() + 1); return d; });
  const goTodayDay = () => setDayViewDate(new Date());
  const dayViewLabel = useMemo(() => {
    const loc = lang === "ru" ? "ru-RU" : "en-US";
    return dayViewDate.toLocaleDateString(loc, { weekday: "long", month: "long", day: "numeric", year: "numeric" });
  }, [dayViewDate, lang]);

  const TIME_SLOTS = useMemo(() => Array.from({ length: 24 }, (_, i) => `${String(i).padStart(2, "0")}:00`), []);

  // ─── Bulk actions ───
  const [bulkMode, setBulkMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkMoveDate, setBulkMoveDate] = useState("");
  const [showBulkMoveInput, setShowBulkMoveInput] = useState(false);
  const [showBulkDeleteConfirm, setShowBulkDeleteConfirm] = useState(false);
  const [showBulkStatusMenu, setShowBulkStatusMenu] = useState(false);

  const toggleSelectId = useCallback((id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }, []);

  const selectAll = useCallback(() => {
    setSelectedIds(new Set(filteredItems.map((i) => i.id)));
  }, [filteredItems]);

  const deselectAll = useCallback(() => {
    setSelectedIds(new Set());
  }, []);

  const bulkDelete = useCallback(() => {
    setItems((prev) => prev.filter((i) => !selectedIds.has(i.id)));
    toast.success(t("contentPlan.bulkDeleted"), { description: `${selectedIds.size} ${t("contentPlan.posts")}` });
    setSelectedIds(new Set());
    setShowBulkDeleteConfirm(false);
    setBulkMode(false);
  }, [selectedIds, t]);

  const bulkMove = useCallback(() => {
    if (!bulkMoveDate) return;
    setItems((prev) => prev.map((i) => selectedIds.has(i.id) ? { ...i, date: bulkMoveDate } : i));
    toast.success(t("contentPlan.bulkMoved"), { description: `${selectedIds.size} ${t("contentPlan.posts")}` });
    setSelectedIds(new Set());
    setShowBulkMoveInput(false);
    setBulkMoveDate("");
    setBulkMode(false);
  }, [selectedIds, bulkMoveDate, t]);

  const bulkChangeStatus = useCallback((status: PostStatus) => {
    setItems((prev) => prev.map((i) => selectedIds.has(i.id) ? { ...i, status } : i));
    toast.success(t("contentPlan.bulkStatusChanged"), { description: `${selectedIds.size} ${t("contentPlan.posts")}` });
    setSelectedIds(new Set());
    setShowBulkStatusMenu(false);
    setBulkMode(false);
  }, [selectedIds, t]);

  const exitBulkMode = useCallback(() => {
    setBulkMode(false);
    setSelectedIds(new Set());
    setShowBulkMoveInput(false);
    setShowBulkDeleteConfirm(false);
    setShowBulkStatusMenu(false);
  }, []);

  // ─── Reminders / Upcoming notifications ───
  const [showReminders, setShowReminders] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(() => {
    try { return localStorage.getItem("launchapp_notif") === "true"; } catch { return false; }
  });

  const upcomingPosts = useMemo(() => {
    const now = new Date();
    return items
      .filter((i) => i.status === "scheduled")
      .map((i) => {
        const postTime = new Date(`${i.date}T${i.time}`);
        const diffMs = postTime.getTime() - now.getTime();
        const diffMin = Math.round(diffMs / 60000);
        const diffH = Math.round(diffMs / 3600000);
        let label = "";
        if (diffMin < 0) label = t("contentPlan.overdue");
        else if (diffMin < 60) label = `${t("contentPlan.dueIn")} ${diffMin} ${t("contentPlan.minutes")}`;
        else if (diffH < 24) label = `${t("contentPlan.dueIn")} ${diffH} ${t("contentPlan.hours")}`;
        else if (diffH < 48) label = t("contentPlan.dueTomorrow");
        else label = `${t("contentPlan.dueIn")} ${Math.round(diffH / 24)}d`;
        return { ...i, diffMs, diffMin, label };
      })
      .filter((i) => i.diffMin < 48 * 60)
      .sort((a, b) => a.diffMs - b.diffMs);
  }, [items, t]);

  const enableNotifications = useCallback(async () => {
    if (typeof Notification !== "undefined" && Notification.permission !== "granted") {
      const perm = await Notification.requestPermission();
      if (perm === "granted") {
        setNotificationsEnabled(true);
        queueMicrotask(() => { try { localStorage.setItem("launchapp_notif", "true"); } catch {} });
        toast.success(t("contentPlan.remindersOn"));
      }
    } else {
      setNotificationsEnabled(true);
      queueMicrotask(() => { try { localStorage.setItem("launchapp_notif", "true"); } catch {} });
      toast.success(t("contentPlan.remindersOn"));
    }
  }, [t]);

  const disableNotifications = useCallback(() => {
    setNotificationsEnabled(false);
    queueMicrotask(() => { try { localStorage.setItem("launchapp_notif", "false"); } catch {} });
    toast.success(t("contentPlan.remindersOff"));
  }, [t]);

  // Browser notification check every 60s
  useEffect(() => {
    if (!notificationsEnabled) return;
    const checkInterval = setInterval(() => {
      const now = new Date();
      items.forEach((item) => {
        if (item.status !== "scheduled") return;
        const postTime = new Date(`${item.date}T${item.time}`);
        const diffMin = Math.round((postTime.getTime() - now.getTime()) / 60000);
        if (diffMin >= 0 && diffMin <= 15 && typeof Notification !== "undefined" && Notification.permission === "granted") {
          const key = `launchapp_notif_sent_${item.id}`;
          try {
            if (!localStorage.getItem(key)) {
              new Notification(`Launch OS: ${item.title}`, { body: `Scheduled for ${item.time} on ${PLATFORM_META[item.platform]?.label}`, icon: "/favicon.ico" });
              localStorage.setItem(key, "1");
            }
          } catch {}
        }
      });
    }, 60000);
    return () => clearInterval(checkInterval);
  }, [items, notificationsEnabled]);

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-4 sm:space-y-6">
      {/* Header */}
      <LargeTitle
        title={t("contentPlan.title")}
        subtitle={t("contentPlan.subtitle")}
        actions={
          <div className="flex items-center gap-2 flex-wrap">
            {/* Export dropdown (advanced only) */}
            {contentMode === "advanced" && (
            <div className="relative" ref={exportRef}>
              <button
                onClick={() => setShowExportMenu(!showExportMenu)}
                className="inline-flex items-center gap-1.5 text-xs text-zinc-400 hover:text-zinc-200 px-3 py-2 rounded-xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/5 transition-all active:scale-95"
              >
                <Download className="w-3.5 h-3.5" />{t("contentPlan.export")}
              </button>
              <AnimatePresence>
                {showExportMenu && (
                  <motion.div
                    initial={{ opacity: 0, y: -5, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -5, scale: 0.95 }}
                    className="absolute right-0 top-full mt-1.5 w-48 rounded-xl border border-white/10 bg-zinc-900 shadow-2xl z-30 overflow-hidden"
                  >
                    <button
                      onClick={() => { exportCSV(items, projectName); setShowExportMenu(false); toast.success(t("contentPlan.exportedCSV")); }}
                      className="w-full flex items-center gap-2.5 px-3.5 py-2.5 text-xs text-zinc-300 hover:text-white hover:bg-white/[0.04] transition-all"
                    >
                      <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                      {t("contentPlan.exportCSV")}
                    </button>
                    <button
                      onClick={() => { exportPDF(items, projectName); setShowExportMenu(false); toast.success(t("contentPlan.exportedPDF")); }}
                      className="w-full flex items-center gap-2.5 px-3.5 py-2.5 text-xs text-zinc-300 hover:text-white hover:bg-white/[0.04] transition-all border-t border-white/5"
                    >
                      <FileText className="w-4 h-4 text-red-400" />
                      {t("contentPlan.exportPDF")}
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            )}

            <button
              onClick={generateAI}
              className="inline-flex items-center gap-1.5 text-xs text-purple-400 hover:text-purple-300 px-3 py-2 rounded-xl bg-purple-500/10 hover:bg-purple-500/15 border border-purple-500/15 transition-all active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5" />{t("contentPlan.aiGenerate")}
            </button>
            <button
              onClick={() => setShowNewModal(true)}
              className="inline-flex items-center gap-1.5 bg-purple-600 hover:bg-purple-500 text-white px-4 py-2 rounded-xl text-sm transition-colors active:scale-95"
            >
              <Plus className="w-4 h-4" />{t("contentPlan.newPost")}
            </button>
          </div>
        }
      />

      {/* ─── Simple / Advanced Mode Toggle ─── */}
      <div className="flex items-center gap-3 p-3 rounded-xl border border-white/5 bg-white/[0.02]">
        <div className="flex items-center bg-white/[0.04] rounded-lg p-0.5">
          <button
            onClick={() => setContentMode("simple")}
            className={`px-3 py-1.5 rounded-md text-xs transition-all ${contentMode === "simple" ? "bg-purple-600 text-white shadow-md" : "text-zinc-500 hover:text-zinc-300"}`}
            style={{ fontWeight: 500 }}
          >
            {t("contentPlan.modeSimple")}
          </button>
          <button
            onClick={() => setContentMode("advanced")}
            className={`px-3 py-1.5 rounded-md text-xs transition-all ${contentMode === "advanced" ? "bg-purple-600 text-white shadow-md" : "text-zinc-500 hover:text-zinc-300"}`}
            style={{ fontWeight: 500 }}
          >
            {t("contentPlan.modeAdvanced")}
          </button>
        </div>
        <p className="text-xs text-zinc-500">
          {contentMode === "simple" ? t("contentPlan.simpleHint") : t("contentPlan.advancedHint")}
        </p>
      </div>

      {/* ─── AI Strategy Generator Banner (advanced only) ─── */}
      {contentMode === "advanced" && (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 sm:p-5 rounded-2xl border border-purple-500/10 bg-gradient-to-r from-purple-500/[0.04] via-cyan-500/[0.02] to-purple-500/[0.04] relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-40 h-40 bg-purple-500/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        <div className="flex flex-col gap-3 relative z-10">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center shrink-0">
              <Wand2 className="w-5 h-5 text-purple-400" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm text-white" style={{ fontWeight: 600 }}>{t("contentPlan.aiStrategy")}</h3>
              <p className="text-xs text-zinc-500 mt-0.5">{t("contentPlan.aiStrategyDesc")}</p>
            </div>
            <button
              onClick={generateFullStrategy}
              disabled={generatingStrategy}
              className="inline-flex items-center gap-1.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white px-4 py-2.5 rounded-xl text-sm transition-all active:scale-95 shrink-0"
            >
              {generatingStrategy ? (
                <>
                  <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }}>
                    <Sparkles className="w-4 h-4" />
                  </motion.div>
                  {t("contentPlan.generating")}
                </>
              ) : (
                <><Wand2 className="w-4 h-4" />{t("contentPlan.generateStrategy")}</>
              )}
            </button>
          </div>
          {/* Strategy template selector */}
          <div className="flex flex-wrap gap-2">
            {(Object.entries(STRATEGY_TEMPLATES) as [string, typeof STRATEGY_TEMPLATES["saas"]][]).map(([key, tpl]) => (
              <button
                key={key}
                onClick={() => setStrategyTemplate(key as "saas" | "b2b" | "consumer")}
                className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${strategyTemplate === key ? "bg-purple-500/15 border-purple-500/30 text-purple-300" : "border-white/5 text-zinc-500 hover:text-zinc-300 hover:border-white/10"}`}
              >
                <span style={{ fontWeight: 600 }}>{tpl.label}</span>
                <span className="text-zinc-600 ml-1.5">— {tpl.desc}</span>
              </button>
            ))}
          </div>
        </div>
      </motion.div>
      )}

      {/* Stats bar — enriched (advanced mode only) */}
      {contentMode === "advanced" && (
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-9 gap-3">
        {[
          { label: t("contentPlan.total"), value: stats.total, color: "text-white", bg: "bg-white/[0.03]", icon: CalendarDays },
          { label: t("contentPlan.statusIdea"), value: stats.ideas, color: "text-zinc-400", bg: "bg-zinc-500/[0.06]", icon: Target },
          { label: t("contentPlan.statusDraft"), value: stats.drafts, color: "text-amber-400", bg: "bg-amber-500/[0.06]", icon: Edit3 },
          { label: t("contentPlan.statusScheduled"), value: stats.scheduled, color: "text-cyan-400", bg: "bg-cyan-500/[0.06]", icon: Clock },
          { label: t("contentPlan.statusPublished"), value: stats.published, color: "text-emerald-400", bg: "bg-emerald-500/[0.06]", icon: Check },
          { label: t("contentPlan.statusPaused"), value: stats.paused, color: "text-orange-400", bg: "bg-orange-500/[0.06]", icon: Pause },
          { label: t("contentPlan.next7days"), value: stats.scheduledNext7, color: "text-blue-400", bg: "bg-blue-500/[0.06]", icon: TrendingUp },
          { label: t("contentPlan.fromEngine"), value: stats.engineSynced, color: "text-cyan-400", bg: "bg-cyan-500/[0.06]", icon: Link2 },
          { label: stats.topPlatform?.name || "---", value: stats.topPlatform?.count || 0, color: "text-purple-400", bg: "bg-purple-500/[0.06]", icon: BarChart3 },
        ].map((s) => (
          <div key={s.label} className={`p-3 rounded-xl border border-white/5 ${s.bg}`}>
            <div className="flex items-center gap-1.5 mb-1">
              <s.icon className={`w-3 h-3 ${s.color} opacity-50`} />
              <div className={`text-lg ${s.color}`} style={{ fontWeight: 700 }}>{s.value}</div>
            </div>
            <div className="text-[10px] text-zinc-500 truncate">{s.label}</div>
          </div>
        ))}
      </div>
      )}

      {/* Toolbar */}
      <div className="flex flex-col gap-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:justify-between">
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setViewMode("calendar")}
              className={`inline-flex items-center gap-1.5 text-xs px-3 py-2 rounded-lg border transition-all ${viewMode === "calendar" ? "bg-purple-500/10 border-purple-500/20 text-purple-400" : "border-white/5 text-zinc-500 hover:text-zinc-300"}`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />{t("contentPlan.calendar")}
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={`inline-flex items-center gap-1.5 text-xs px-3 py-2 rounded-lg border transition-all ${viewMode === "list" ? "bg-purple-500/10 border-purple-500/20 text-purple-400" : "border-white/5 text-zinc-500 hover:text-zinc-300"}`}
            >
              <List className="w-3.5 h-3.5" />{t("contentPlan.list")}
            </button>

            {/* Calendar scale: Month / Week / Day */}
            {viewMode === "calendar" && (
              <div className="flex items-center bg-white/[0.04] rounded-lg p-0.5 ml-1">
                {(["month", "week", "day"] as const).map((s) => (
                  <button
                    key={s}
                    onClick={() => setCalendarScale(s)}
                    className={`px-2.5 py-1 rounded-md text-[11px] transition-all ${calendarScale === s ? "bg-purple-600 text-white shadow-sm" : "text-zinc-500 hover:text-zinc-300"}`}
                    style={{ fontWeight: 500 }}
                  >
                    {t(`contentPlan.view${s.charAt(0).toUpperCase() + s.slice(1)}`)}
                  </button>
                ))}
              </div>
            )}

            {viewMode === "calendar" && calendarScale === "month" && (
              <span className="text-[10px] text-zinc-600 hidden sm:inline ml-1">
                {t("contentPlan.dragHint")}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Bulk mode toggle */}
            <button
              onClick={() => bulkMode ? exitBulkMode() : setBulkMode(true)}
              className={`inline-flex items-center gap-1 text-[11px] px-2.5 py-1.5 rounded-lg border transition-all ${bulkMode ? "bg-purple-500/10 border-purple-500/20 text-purple-400" : "border-white/5 text-zinc-500 hover:text-zinc-300"}`}
            >
              <CheckSquare className="w-3 h-3" />{t("contentPlan.bulkSelect")}
            </button>

            {/* Reminders bell */}
            <div className="relative">
              <button
                onClick={() => setShowReminders(!showReminders)}
                className={`w-8 h-8 rounded-lg flex items-center justify-center border transition-all relative ${showReminders ? "bg-purple-500/10 border-purple-500/20 text-purple-400" : "border-white/5 text-zinc-500 hover:text-zinc-300 hover:bg-white/5"}`}
              >
                <Bell className="w-3.5 h-3.5" />
                {upcomingPosts.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[9px] flex items-center justify-center" style={{ fontWeight: 700 }}>{upcomingPosts.length > 9 ? "9+" : upcomingPosts.length}</span>
                )}
              </button>
            </div>

            {/* Filters */}
            <div className="flex items-center gap-1.5">
              <Filter className="w-3 h-3 text-zinc-600" />
              <select
                value={filterPlatform}
                onChange={(e) => setFilterPlatform(e.target.value as Platform | "all")}
                className="text-xs bg-white/[0.03] border border-white/5 rounded-lg px-2.5 py-1.5 text-zinc-300 focus:outline-none focus:border-purple-500/30"
              >
                <option value="all">{t("contentPlan.allPlatforms")}</option>
                {Object.entries(PLATFORM_META).map(([key, meta]) => (
                  <option key={key} value={key}>{meta.label}</option>
                ))}
              </select>
            </div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as PostStatus | "all")}
              className="text-xs bg-white/[0.03] border border-white/5 rounded-lg px-2.5 py-1.5 text-zinc-300 focus:outline-none focus:border-purple-500/30"
            >
              <option value="all">{t("contentPlan.allStatuses")}</option>
              {Object.entries(STATUS_META).map(([key, meta]) => (
                <option key={key} value={key}>{lang === "ru" ? meta.labelRu : meta.label}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Bulk action bar */}
        <AnimatePresence>
          {bulkMode && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <div className="flex items-center gap-2 flex-wrap p-3 rounded-xl border border-purple-500/15 bg-purple-500/[0.04]">
                <span className="text-xs text-purple-400" style={{ fontWeight: 600 }}>{selectedIds.size} {t("contentPlan.bulkSelected")}</span>
                <div className="flex items-center gap-1.5 ml-2">
                  <button onClick={selectAll} className="text-[11px] text-zinc-400 hover:text-zinc-200 px-2 py-1 rounded-md hover:bg-white/5 transition-all">{t("contentPlan.bulkSelectAll")}</button>
                  <button onClick={deselectAll} className="text-[11px] text-zinc-400 hover:text-zinc-200 px-2 py-1 rounded-md hover:bg-white/5 transition-all">{t("contentPlan.bulkDeselectAll")}</button>
                </div>
                <div className="flex-1" />
                {selectedIds.size > 0 && (
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {/* Bulk status */}
                    <div className="relative">
                      <button onClick={() => setShowBulkStatusMenu(!showBulkStatusMenu)} className="inline-flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300 px-2.5 py-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/15 transition-all">
                        <Columns3 className="w-3 h-3" />{t("contentPlan.bulkStatus")}
                      </button>
                      {showBulkStatusMenu && (
                        <div className="absolute top-full mt-1 right-0 z-20 p-1.5 rounded-xl bg-zinc-900 border border-white/10 shadow-xl min-w-[140px]">
                          {(Object.keys(STATUS_META) as PostStatus[]).map((s) => (
                            <button key={s} onClick={() => bulkChangeStatus(s)} className={`w-full text-left text-[11px] px-2.5 py-1.5 rounded-lg hover:bg-white/5 transition-all ${STATUS_META[s].color.split(" ")[0]}`}>
                              {t(STATUS_META[s].i18nKey)}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                    {/* Bulk move */}
                    <div className="relative">
                      <button onClick={() => setShowBulkMoveInput(!showBulkMoveInput)} className="inline-flex items-center gap-1 text-[11px] text-amber-400 hover:text-amber-300 px-2.5 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/15 transition-all">
                        <MoveRight className="w-3 h-3" />{t("contentPlan.bulkMove")}
                      </button>
                      {showBulkMoveInput && (
                        <div className="absolute top-full mt-1 right-0 z-20 p-3 rounded-xl bg-zinc-900 border border-white/10 shadow-xl min-w-[220px] flex items-center gap-2">
                          <input type="date" value={bulkMoveDate} onChange={(e) => setBulkMoveDate(e.target.value)} className="flex-1 px-2 py-1.5 rounded-lg bg-white/[0.04] border border-white/10 text-xs text-white focus:outline-none focus:border-purple-500/30" />
                          <button onClick={bulkMove} className="text-[11px] text-amber-400 px-2.5 py-1.5 rounded-lg bg-amber-500/10 transition-all">{t("contentPlan.moveConfirm")}</button>
                        </div>
                      )}
                    </div>
                    {/* Bulk delete */}
                    <div className="relative">
                      <button onClick={() => setShowBulkDeleteConfirm(!showBulkDeleteConfirm)} className="inline-flex items-center gap-1 text-[11px] text-red-400 hover:text-red-300 px-2.5 py-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/15 transition-all">
                        <Trash2 className="w-3 h-3" />{t("contentPlan.bulkDelete")}
                      </button>
                      {showBulkDeleteConfirm && (
                        <div className="absolute top-full mt-1 right-0 z-20 p-3 rounded-xl bg-zinc-900 border border-white/10 shadow-xl min-w-[240px]">
                          <p className="text-[11px] text-zinc-400 mb-2">{t("contentPlan.bulkConfirmDelete")}</p>
                          <div className="flex items-center gap-2 justify-end">
                            <button onClick={() => setShowBulkDeleteConfirm(false)} className="text-[11px] text-zinc-500 px-2 py-1 transition-colors">{t("contentPlan.cancel")}</button>
                            <button onClick={bulkDelete} className="text-[11px] text-red-400 px-2.5 py-1.5 rounded-lg bg-red-500/10 transition-all">{t("contentPlan.bulkDelete")}</button>
                          </div>
                        </div>
                      )}
                    </div>
                    <button onClick={exitBulkMode} className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-600 hover:text-zinc-300 transition-all">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Reminders panel */}
        <AnimatePresence>
          {showReminders && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <div className="p-4 rounded-xl border border-white/5 bg-white/[0.02]">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-purple-400" />
                    <h4 className="text-xs text-white" style={{ fontWeight: 600 }}>{t("contentPlan.upcoming")} ({upcomingPosts.length})</h4>
                  </div>
                  <div className="flex items-center gap-2">
                    {notificationsEnabled ? (
                      <button onClick={disableNotifications} className="inline-flex items-center gap-1 text-[10px] text-emerald-400 px-2 py-1 rounded-md bg-emerald-500/10 transition-all">
                        <Bell className="w-2.5 h-2.5" />{t("contentPlan.remindersOn")}
                      </button>
                    ) : (
                      <button onClick={enableNotifications} className="inline-flex items-center gap-1 text-[10px] text-zinc-500 hover:text-zinc-300 px-2 py-1 rounded-md bg-white/[0.04] transition-all">
                        <BellOff className="w-2.5 h-2.5" />{t("contentPlan.enableNotifications")}
                      </button>
                    )}
                    <button onClick={() => setShowReminders(false)} className="w-6 h-6 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-600 hover:text-zinc-300 transition-all">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                {upcomingPosts.length === 0 ? (
                  <p className="text-xs text-zinc-500 text-center py-4">{t("contentPlan.noUpcoming")}</p>
                ) : (
                  <div className="space-y-1.5 max-h-[280px] overflow-y-auto">
                    {upcomingPosts.map((item) => {
                      const pm = PLATFORM_META[item.platform];
                      return (
                        <div key={item.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-white/[0.03] transition-all">
                          <div className={`w-7 h-7 rounded-lg ${pm.bgColor} flex items-center justify-center shrink-0`}>
                            <pm.icon className={`w-3 h-3 ${pm.color}`} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <span className="text-xs text-white truncate block">{item.title}</span>
                            <span className="text-[10px] text-zinc-500">{item.date} {item.time}</span>
                          </div>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full shrink-0 ${item.diffMin < 0 ? "text-red-400 bg-red-500/10" : item.diffMin < 60 ? "text-amber-400 bg-amber-500/10" : "text-zinc-400 bg-white/[0.04]"}`}>
                            {item.label}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ─── Calendar View with DnD ─── */}
      {viewMode === "calendar" && calendarScale === "month" && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="p-4 sm:p-5 rounded-2xl border border-white/5 bg-white/[0.02]">
          {/* Month navigation */}
          <div className="flex items-center justify-between mb-4">
            <button onClick={prevMonth} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-500 hover:text-zinc-300 transition-all">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-3">
              <h3 className="text-white" style={{ fontWeight: 600 }}>{monthName}</h3>
              <button onClick={goToday} className="text-[10px] text-purple-400 hover:text-purple-300 px-2 py-0.5 rounded bg-purple-500/10 transition-all">
                {t("contentPlan.today")}
              </button>
            </div>
            <button onClick={nextMonth} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-500 hover:text-zinc-300 transition-all">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Week day headers */}
          <div className="grid grid-cols-7 gap-px mb-1">
            {weekDays.map((d) => (
              <div key={d} className="text-center text-[10px] text-zinc-600 py-1.5" style={{ fontWeight: 600 }}>{d}</div>
            ))}
          </div>

          {/* Calendar grid */}
          <div className="grid grid-cols-7 gap-px">
            {Array.from({ length: firstDayOfWeek }).map((_, i) => (
              <div key={`empty-${i}`} className="min-h-[72px] sm:min-h-[90px] p-1 rounded-lg" />
            ))}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1;
              const dateStr = getDateStr(day);
              const isToday = dateStr === todayStr;
              const dayItems = itemsByDate[dateStr] || [];
              const isSelected = dayDrawerDate === dateStr;
              const isPast = dateStr < todayStr;

              return (
                <DroppableDayCell
                  key={day}
                  day={day}
                  dateStr={dateStr}
                  isToday={isToday}
                  isSelected={isSelected}
                  dayItems={dayItems}
                  onSelect={() => isSelected ? closeDayDrawer() : openDayDrawer(dateStr)}
                  onDrop={moveItemToDate}
                  isPast={isPast}
                />
              );
            })}
          </div>

          {/* Hint when no day is selected */}
          {!dayDrawerDate && (
            <div className="mt-3 text-center text-[11px] text-zinc-600 py-2">
              {t("contentPlan.clickDay")}
            </div>
          )}
        </motion.div>
      )}

      {/* ─── Week View ─── */}
      {viewMode === "calendar" && calendarScale === "week" && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="p-4 sm:p-5 rounded-2xl border border-white/5 bg-white/[0.02]">
          {/* Week navigation */}
          <div className="flex items-center justify-between mb-4">
            <button onClick={prevWeek} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-500 hover:text-zinc-300 transition-all">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-3">
              <h3 className="text-white text-sm" style={{ fontWeight: 600 }}>{weekLabel}</h3>
              <button onClick={goTodayWeek} className="text-[10px] text-purple-400 hover:text-purple-300 px-2 py-0.5 rounded bg-purple-500/10 transition-all">
                {t("contentPlan.today")}
              </button>
            </div>
            <button onClick={nextWeek} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-500 hover:text-zinc-300 transition-all">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Week columns */}
          <div className="grid grid-cols-7 gap-2">
            {weekDates.map((wd, i) => {
              const dateStr = wd.toISOString().split("T")[0];
              const isToday = dateStr === todayStr;
              const isPast = dateStr < todayStr;
              const dayItemsList = itemsByDate[dateStr] || [];
              return (
                <div
                  key={i}
                  onClick={() => dayDrawerDate === dateStr ? closeDayDrawer() : openDayDrawer(dateStr)}
                  className={`min-h-[200px] rounded-xl border p-2 flex flex-col cursor-pointer transition-all ${
                    dayDrawerDate === dateStr
                      ? "border-purple-500/30 bg-purple-500/[0.06]"
                      : isToday
                      ? "border-purple-500/20 bg-white/[0.04]"
                      : isPast
                      ? "border-white/5 bg-white/[0.01] opacity-60 hover:opacity-100"
                      : "border-white/5 hover:border-white/10 bg-white/[0.02]"
                  }`}
                >
                  <div className="text-center mb-2">
                    <div className="text-[10px] text-zinc-600" style={{ fontWeight: 600 }}>{weekDays[i]}</div>
                    <div className={`text-lg ${isToday ? "text-purple-400" : "text-white"}`} style={{ fontWeight: isToday ? 700 : 500 }}>{wd.getDate()}</div>
                  </div>
                  <div className="flex-1 space-y-1 overflow-hidden">
                    {dayItemsList.slice(0, 6).map((item) => {
                      const pm = PLATFORM_META[item.platform];
                      const sm = STATUS_META[item.status];
                      return (
                        <div key={item.id} className={`flex items-center gap-1 px-1.5 py-1 rounded-md text-[9px] sm:text-[10px] ${pm.bgColor} ${bulkMode ? "cursor-pointer" : ""}`}
                          onClick={(e) => { if (bulkMode) { e.stopPropagation(); toggleSelectId(item.id); } }}>
                          {bulkMode && (
                            selectedIds.has(item.id)
                              ? <CheckSquare className="w-2.5 h-2.5 text-purple-400 shrink-0" />
                              : <Square className="w-2.5 h-2.5 text-zinc-600 shrink-0" />
                          )}
                          <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${sm.dotColor}`} />
                          <span className={`truncate ${pm.color}`}>{item.title}</span>
                        </div>
                      );
                    })}
                    {dayItemsList.length > 6 && <span className="text-[9px] text-zinc-600 px-1">+{dayItemsList.length - 6}</span>}
                    {dayItemsList.length === 0 && <p className="text-[9px] text-zinc-700 text-center mt-4">{t("contentPlan.noPostsShort")}</p>}
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>
      )}

      {/* ─── Day View (timeline) ─── */}
      {viewMode === "calendar" && calendarScale === "day" && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="p-4 sm:p-5 rounded-2xl border border-white/5 bg-white/[0.02]">
          {/* Day navigation */}
          <div className="flex items-center justify-between mb-4">
            <button onClick={prevDay} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-500 hover:text-zinc-300 transition-all">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-3">
              <h3 className="text-white text-sm" style={{ fontWeight: 600 }}>{dayViewLabel}</h3>
              <button onClick={goTodayDay} className="text-[10px] text-purple-400 hover:text-purple-300 px-2 py-0.5 rounded bg-purple-500/10 transition-all">
                {t("contentPlan.today")}
              </button>
            </div>
            <button onClick={nextDay} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-500 hover:text-zinc-300 transition-all">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Timeline */}
          <div className="space-y-0">
            {TIME_SLOTS.map((slot) => {
              const hourItems = dayViewItems.filter((item) => item.time.startsWith(slot.split(":")[0]));
              const hourNum = parseInt(slot.split(":")[0]);
              const isCurrentHour = dayViewStr === todayStr && new Date().getHours() === hourNum;
              return (
                <div key={slot} className={`flex gap-3 py-2 border-b border-white/[0.03] ${isCurrentHour ? "bg-purple-500/[0.04] -mx-2 px-2 rounded-lg border-purple-500/10" : ""}`}>
                  <div className={`w-12 text-right shrink-0 text-[11px] pt-0.5 ${isCurrentHour ? "text-purple-400" : "text-zinc-600"}`} style={{ fontWeight: isCurrentHour ? 600 : 400 }}>
                    {slot}
                  </div>
                  <div className="flex-1 min-h-[32px]">
                    {hourItems.length > 0 ? (
                      <div className="space-y-1">
                        {hourItems.map((item) => {
                          const pm = PLATFORM_META[item.platform];
                          const sm = STATUS_META[item.status];
                          return (
                            <div key={item.id} className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg ${pm.bgColor} hover:ring-1 hover:ring-white/10 transition-all ${bulkMode ? "cursor-pointer" : ""}`}
                              onClick={() => { if (bulkMode) toggleSelectId(item.id); }}>
                              {bulkMode && (
                                selectedIds.has(item.id)
                                  ? <CheckSquare className="w-3 h-3 text-purple-400 shrink-0" />
                                  : <Square className="w-3 h-3 text-zinc-600 shrink-0" />
                              )}
                              <pm.icon className={`w-3 h-3 shrink-0 ${pm.color}`} />
                              <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${sm.dotColor}`} />
                              <span className={`text-xs truncate ${pm.color}`} style={{ fontWeight: 500 }}>{item.title}</span>
                              <span className={`text-[9px] px-1.5 py-0.5 rounded-full border ml-auto shrink-0 ${sm.color}`}>{t(sm.i18nKey)}</span>
                              <span className="text-[10px] text-zinc-500 shrink-0">{item.time}</span>
                            </div>
                          );
                        })}
                      </div>
                    ) : null}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Day view actions */}
          <div className="flex items-center justify-center gap-3 mt-4 pt-3 border-t border-white/[0.03]">
            {dayViewItems.length > 0 && (
              <button
                onClick={() => openDayDrawer(dayViewStr)}
                className="inline-flex items-center gap-1.5 text-xs text-purple-400 hover:text-purple-300 px-3 py-2 rounded-lg bg-purple-500/10 transition-all"
              >
                <Edit3 className="w-3.5 h-3.5" />{t("contentPlan.editInline")}
              </button>
            )}
            <button
              onClick={() => { setNewDate(dayViewStr); setShowNewModal(true); }}
              className="inline-flex items-center gap-1.5 text-xs text-purple-400 hover:text-purple-300 px-3 py-2 rounded-lg bg-purple-500/10 transition-all"
            >
              <Plus className="w-3.5 h-3.5" />{t("contentPlan.newPost")}
            </button>
          </div>

          {dayViewItems.length === 0 && (
            <div className="py-6 text-center">
              <CalendarDays className="w-8 h-8 text-zinc-700 mx-auto mb-2" />
              <p className="text-xs text-zinc-500">{t("contentPlan.noPosts")}</p>
            </div>
          )}
        </motion.div>
      )}

      {/* ═══ Day Detail Modal ═══ */}
      <AnimatePresence>
        {dayDrawerDate && viewMode === "calendar" && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 backdrop-blur-xl z-50"
              onClick={closeDayDrawer}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 30 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[95vw] max-w-2xl z-50 max-h-[88vh] flex flex-col liquid-glass-modal rounded-2xl"
              role="dialog"
              aria-modal="true"
            >
              {/* Modal header */}
              <div className="px-5 py-4 border-b border-white/5 shrink-0">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
                      <CalendarDays className="w-5 h-5 text-purple-400" />
                    </div>
                    <div>
                      <h3 className="text-white" style={{ fontWeight: 600 }}>
                        {new Date(dayDrawerDate + "T00:00").toLocaleDateString(lang === "ru" ? "ru-RU" : "en-US", { weekday: "long", day: "numeric", month: "long" })}
                      </h3>
                      <p className="text-[11px] text-zinc-500">
                        {dayDrawerItems.length} {dayDrawerItems.length === 1 ? t("contentPlan.postCount_one") : dayDrawerItems.length < 5 ? t("contentPlan.postCount_few") : t("contentPlan.postCount_many")}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => { setNewDate(dayDrawerDate); setShowNewModal(true); }}
                      className="inline-flex items-center gap-1.5 text-xs text-purple-400 hover:text-purple-300 px-3 py-2 rounded-lg bg-purple-500/10 hover:bg-purple-500/15 transition-all"
                    >
                      <Plus className="w-3.5 h-3.5" />{t("contentPlan.addHere")}
                    </button>
                    <button onClick={closeDayDrawer} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-500 hover:text-zinc-300 transition-all">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Scrollable posts list */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3">
                {dayDrawerItems.length === 0 ? (
                  <div className="py-12 text-center">
                    <CalendarDays className="w-10 h-10 text-zinc-700 mx-auto mb-3" />
                    <p className="text-sm text-zinc-500">{t("contentPlan.noPosts")}</p>
                    <button
                      onClick={() => { setNewDate(dayDrawerDate); setShowNewModal(true); }}
                      className="mt-4 inline-flex items-center gap-1.5 text-sm text-purple-400 hover:text-purple-300 px-4 py-2.5 rounded-xl bg-purple-500/10 transition-all"
                    >
                      <Plus className="w-4 h-4" />{t("contentPlan.newPost")}
                    </button>
                  </div>
                ) : (
                  dayDrawerItems.map((item) => {
                    const pm = PLATFORM_META[item.platform];
                    const sm = STATUS_META[item.status];
                    const isEditing = inlineEditId === item.id;
                    const isMoving = movePostId === item.id;
                    const isDeleting = confirmDeleteId === item.id;
                    const editData = isEditing ? inlineEditData : null;
                    const itemOverdue = isOverdue(item);

                    return (
                      <motion.div
                        key={item.id}
                        layout
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`rounded-xl border transition-all ${isEditing ? "border-purple-500/30 bg-purple-500/[0.04]" : itemOverdue ? "border-red-500/20 bg-red-500/[0.03]" : "border-white/[0.06] bg-white/[0.02] hover:border-white/10"}`}
                      >
                        {/* ── Normal View ── */}
                        {!isEditing && (
                          <div className="p-4">
                            <div className="flex items-start gap-3">
                              <div className={`w-10 h-10 rounded-xl ${pm.bgColor} flex items-center justify-center shrink-0`}>
                                <pm.icon className={`w-5 h-5 ${pm.color}`} />
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1 flex-wrap">
                                  <span className="text-sm text-white" style={{ fontWeight: 600 }}>{item.title}</span>
                                  <span className={`text-[9px] px-1.5 py-0.5 rounded-full border ${sm.color}`}>{t(sm.i18nKey)}</span>
                                  {itemOverdue && (
                                    <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-red-500/10 text-red-400 border border-red-500/20">{t("contentPlan.overdueBadge")}</span>
                                  )}
                                  {item.aiGenerated && <Sparkles className="w-3 h-3 text-purple-400 shrink-0" />}
                                </div>
                                <p className="text-xs text-zinc-500 line-clamp-2">{item.body.split("\n")[0]}</p>
                                <div className="flex items-center gap-3 mt-2">
                                  <span className="text-[10px] text-zinc-600 flex items-center gap-1">
                                    <Clock className="w-2.5 h-2.5" />{item.time}
                                  </span>
                                  <span className={`text-[10px] ${pm.color} flex items-center gap-1`}>
                                    <pm.icon className="w-2.5 h-2.5" />{pm.label}
                                  </span>
                                </div>
                              </div>
                            </div>

                            {/* Action buttons with token costs */}
                            <div className="flex items-center gap-1.5 mt-3 pt-3 border-t border-white/5 flex-wrap">
                              {/* Status actions */}
                              {item.status === "idea" && (
                                <button onClick={() => updateStatus(item.id, "draft")} className="inline-flex items-center gap-1 text-[10px] text-amber-400 hover:text-amber-300 px-2 py-1 rounded-md bg-amber-500/10 hover:bg-amber-500/15 transition-all">
                                  <Edit3 className="w-2.5 h-2.5" />{t("contentPlan.statusDraft")}
                                </button>
                              )}
                              {item.status === "draft" && (
                                <button onClick={() => updateStatus(item.id, "scheduled")} className="inline-flex items-center gap-1 text-[10px] text-cyan-400 hover:text-cyan-300 px-2 py-1 rounded-md bg-cyan-500/10 hover:bg-cyan-500/15 transition-all">
                                  <Send className="w-2.5 h-2.5" />{t("contentPlan.schedulePost")}
                                </button>
                              )}
                              {item.status === "scheduled" && !itemOverdue && (
                                <button onClick={() => updateStatus(item.id, "published")} className="inline-flex items-center gap-1 text-[10px] text-emerald-400 hover:text-emerald-300 px-2 py-1 rounded-md bg-emerald-500/10 hover:bg-emerald-500/15 transition-all">
                                  <Check className="w-2.5 h-2.5" />{t("contentPlan.publishPost")}
                                </button>
                              )}
                              {item.status !== "paused" && item.status !== "published" && !itemOverdue && (
                                <button
                                  onClick={() => checkTokens(TOKEN_COSTS.pause, () => updateStatus(item.id, "paused"))}
                                  className="inline-flex items-center gap-1 text-[10px] text-orange-400 hover:text-orange-300 px-2 py-1 rounded-md bg-orange-500/10 hover:bg-orange-500/15 transition-all"
                                >
                                  <Pause className="w-2.5 h-2.5" />{t("contentPlan.pausePost")}
                                  <span className="text-[8px] text-orange-400/60 ml-0.5 flex items-center gap-0.5"><Coins className="w-2 h-2" />{TOKEN_COSTS.pause}</span>
                                </button>
                              )}
                              {item.status === "paused" && !itemOverdue && (
                                <button
                                  onClick={() => checkTokens(TOKEN_COSTS.resume, () => updateStatus(item.id, "scheduled"))}
                                  className="inline-flex items-center gap-1 text-[10px] text-emerald-400 hover:text-emerald-300 px-2 py-1 rounded-md bg-emerald-500/10 hover:bg-emerald-500/15 transition-all"
                                >
                                  <Play className="w-2.5 h-2.5" />{t("contentPlan.resumePost")}
                                  <span className="text-[8px] text-emerald-400/60 ml-0.5 flex items-center gap-0.5"><Coins className="w-2 h-2" />{TOKEN_COSTS.resume}</span>
                                </button>
                              )}
                              {/* Relaunch button for overdue posts */}
                              {itemOverdue && (
                                <button
                                  onClick={() => checkTokens(TOKEN_COSTS.relaunch, () => {
                                    const tomorrow = new Date();
                                    tomorrow.setDate(tomorrow.getDate() + 1);
                                    const newDate = tomorrow.toISOString().split("T")[0];
                                    setItems((prev) => prev.map((i) => i.id === item.id ? { ...i, date: newDate, status: "scheduled" } : i));
                                    toast.success(t("contentPlan.relaunched"));
                                  })}
                                  className="inline-flex items-center gap-1 text-[10px] text-red-400 hover:text-red-300 px-2 py-1 rounded-md bg-red-500/10 hover:bg-red-500/15 transition-all"
                                >
                                  <Play className="w-2.5 h-2.5" />{t("contentPlan.relaunch")}
                                  <span className="text-[8px] text-red-400/60 ml-0.5 flex items-center gap-0.5"><Coins className="w-2 h-2" />{TOKEN_COSTS.relaunch}</span>
                                </button>
                              )}

                              <div className="flex-1" />

                              {/* Utility actions with token badges */}
                              <button onClick={() => setPreviewItem(item)} className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-purple-500/10 text-zinc-600 hover:text-purple-400 transition-all" title={t("contentPlan.preview")}>
                                <Eye className="w-3.5 h-3.5" />
                              </button>
                              <div className="relative group/edit">
                                <button
                                  onClick={() => checkTokens(TOKEN_COSTS.edit, () => startInlineEdit(item))}
                                  className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-600 hover:text-zinc-300 transition-all"
                                  title={t("contentPlan.editInline")}
                                >
                                  <Edit3 className="w-3.5 h-3.5" />
                                </button>
                                <span className="absolute -top-1 -right-1 text-[7px] px-1 py-0 rounded-full bg-purple-500/20 text-purple-400 pointer-events-none" style={{ fontWeight: 700 }}>{TOKEN_COSTS.edit}</span>
                              </div>
                              <div className="relative group/move">
                                <button
                                  onClick={() => checkTokens(TOKEN_COSTS.move, () => { setMovePostId(item.id); setMoveTargetDate(item.date); })}
                                  className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-cyan-500/10 text-zinc-600 hover:text-cyan-400 transition-all"
                                  title={t("contentPlan.moveToDate")}
                                >
                                  <ArrowRight className="w-3.5 h-3.5" />
                                </button>
                                <span className="absolute -top-1 -right-1 text-[7px] px-1 py-0 rounded-full bg-cyan-500/20 text-cyan-400 pointer-events-none" style={{ fontWeight: 700 }}>{TOKEN_COSTS.move}</span>
                              </div>
                              <div className="relative group/dup">
                                <button
                                  onClick={() => checkTokens(TOKEN_COSTS.duplicate, () => duplicateItem(item))}
                                  className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-600 hover:text-zinc-300 transition-all"
                                  title={t("contentPlan.duplicatePost")}
                                >
                                  <Copy className="w-3.5 h-3.5" />
                                </button>
                                <span className="absolute -top-1 -right-1 text-[7px] px-1 py-0 rounded-full bg-purple-500/20 text-purple-400 pointer-events-none" style={{ fontWeight: 700 }}>{TOKEN_COSTS.duplicate}</span>
                              </div>
                              <button onClick={() => setConfirmDeleteId(item.id)} className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-red-500/10 text-zinc-600 hover:text-red-400 transition-all" title={t("contentPlan.deletePost")}>
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            {/* Move to date inline */}
                            <AnimatePresence>
                              {isMoving && (
                                <motion.div
                                  initial={{ opacity: 0, height: 0 }}
                                  animate={{ opacity: 1, height: "auto" }}
                                  exit={{ opacity: 0, height: 0 }}
                                  className="overflow-hidden"
                                >
                                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 mt-3 pt-3 border-t border-white/5">
                                    <span className="text-[11px] text-zinc-500 shrink-0">{t("contentPlan.moveDateLabel")}:</span>
                                    <div className="flex items-center gap-2 flex-1">
                                      <input
                                        type="date"
                                        value={moveTargetDate}
                                        onChange={(e) => setMoveTargetDate(e.target.value)}
                                        className="flex-1 px-2 py-1.5 rounded-lg bg-white/[0.04] border border-white/10 text-xs text-white focus:outline-none focus:border-purple-500/30"
                                      />
                                      <input
                                        type="time"
                                        value={items.find(i => i.id === item.id)?.time || "10:00"}
                                        onChange={(e) => {
                                          setItems((prev) => prev.map((i) => i.id === item.id ? { ...i, time: e.target.value } : i));
                                        }}
                                        className="w-24 px-2 py-1.5 rounded-lg bg-white/[0.04] border border-white/10 text-xs text-white focus:outline-none focus:border-purple-500/30"
                                      />
                                    </div>
                                    <div className="flex items-center gap-1.5">
                                      <button onClick={confirmMovePost} className="text-[11px] text-cyan-400 hover:text-cyan-300 px-2.5 py-1.5 rounded-lg bg-cyan-500/10 transition-all">
                                        {t("contentPlan.moveConfirm")}
                                      </button>
                                      <button onClick={() => setMovePostId(null)} className="text-[11px] text-zinc-500 hover:text-zinc-300 px-2 py-1.5 transition-colors">
                                        {t("contentPlan.cancel")}
                                      </button>
                                    </div>
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>

                            {/* Delete confirmation */}
                            <AnimatePresence>
                              {isDeleting && (
                                <motion.div
                                  initial={{ opacity: 0, height: 0 }}
                                  animate={{ opacity: 1, height: "auto" }}
                                  exit={{ opacity: 0, height: 0 }}
                                  className="overflow-hidden"
                                >
                                  <div className="flex items-center gap-2 mt-3 pt-3 border-t border-red-500/10">
                                    <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0" />
                                    <span className="text-[11px] text-zinc-400 flex-1">{t("contentPlan.confirmDelete")}</span>
                                    <button onClick={confirmDeletePost} className="text-[11px] text-red-400 hover:text-red-300 px-2.5 py-1 rounded-lg bg-red-500/10 transition-all">
                                      {t("contentPlan.deletePost")}
                                    </button>
                                    <button onClick={() => setConfirmDeleteId(null)} className="text-[11px] text-zinc-500 hover:text-zinc-300 px-2 py-1 transition-colors">
                                      {t("contentPlan.cancel")}
                                    </button>
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        )}

                        {/* ── Inline Edit Mode ── */}
                        {isEditing && editData && (
                          <div className="p-4 space-y-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-purple-400" style={{ fontWeight: 600 }}>{t("contentPlan.editInline")}</span>
                                <span className="text-[9px] text-purple-400/60 flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-purple-500/10">
                                  <Coins className="w-2.5 h-2.5" />{TOKEN_COSTS.edit} {t("contentPlan.tokenCost").replace("{n}", "")}
                                </span>
                              </div>
                              <div className="flex items-center gap-2">
                                <button onClick={discardInlineEdit} className="text-[11px] text-zinc-500 hover:text-zinc-300 px-2 py-1 transition-colors">
                                  {t("contentPlan.discardChanges")}
                                </button>
                                <button onClick={saveInlineEdit} className="text-[11px] text-emerald-400 hover:text-emerald-300 px-3 py-1 rounded-lg bg-emerald-500/10 transition-all">
                                  <span className="flex items-center gap-1"><Check className="w-3 h-3" />{t("contentPlan.saveChanges")}</span>
                                </button>
                              </div>
                            </div>

                            {/* Title */}
                            <div>
                              <label className="text-[10px] text-zinc-500 mb-1 block">{t("contentPlan.postTitle")}</label>
                              <input
                                value={editData.title}
                                onChange={(e) => setInlineEditData({ ...editData, title: e.target.value })}
                                className="w-full px-3 py-2 rounded-lg bg-white/[0.04] border border-white/10 text-sm text-white focus:outline-none focus:border-purple-500/30"
                              />
                            </div>

                            {/* Body */}
                            <div>
                              <label className="text-[10px] text-zinc-500 mb-1 block">{t("contentPlan.postBody")}</label>
                              <textarea
                                value={editData.body}
                                onChange={(e) => setInlineEditData({ ...editData, body: e.target.value })}
                                rows={4}
                                className="w-full px-3 py-2 rounded-lg bg-white/[0.04] border border-white/10 text-sm text-white focus:outline-none focus:border-purple-500/30 resize-none"
                              />
                            </div>

                            {/* Platform selector with token cost */}
                            <div>
                              <label className="text-[10px] text-zinc-500 mb-1 flex items-center gap-1.5">
                                {t("contentPlan.channel")}
                                <span className="text-[8px] text-purple-400/60 flex items-center gap-0.5 px-1 py-0 rounded-full bg-purple-500/10">
                                  <Coins className="w-2 h-2" />{TOKEN_COSTS.changePlatform}
                                </span>
                              </label>
                              <div className="flex flex-wrap gap-1.5">
                                {Object.entries(PLATFORM_META).map(([key, meta]) => (
                                  <button
                                    key={key}
                                    onClick={() => {
                                      if (key !== editData.platform) {
                                        checkTokens(TOKEN_COSTS.changePlatform, () => setInlineEditData({ ...editData, platform: key as Platform }));
                                      }
                                    }}
                                    className={`inline-flex items-center gap-1 text-[10px] px-2 py-1 rounded-lg border transition-all ${editData.platform === key ? `${meta.bgColor} ${meta.color} border-current` : "border-white/5 text-zinc-500 hover:text-zinc-300"}`}
                                  >
                                    <meta.icon className="w-2.5 h-2.5" />{meta.label}
                                  </button>
                                ))}
                              </div>
                            </div>

                            {/* Status selector */}
                            <div>
                              <label className="text-[10px] text-zinc-500 mb-1 block">{t("contentPlan.status")}</label>
                              <div className="flex flex-wrap gap-1.5">
                                {(Object.keys(STATUS_META) as PostStatus[]).map((s) => (
                                  <button
                                    key={s}
                                    onClick={() => setInlineEditData({ ...editData, status: s })}
                                    className={`text-[10px] px-2 py-1 rounded-lg border transition-all ${editData.status === s ? STATUS_META[s].color : "border-white/5 text-zinc-500 hover:text-zinc-300"}`}
                                  >
                                    {t(STATUS_META[s].i18nKey)}
                                  </button>
                                ))}
                              </div>
                            </div>

                            {/* Date & Time */}
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="text-[10px] text-zinc-500 mb-1 block">{t("contentPlan.date")}</label>
                                <input
                                  type="date"
                                  value={editData.date}
                                  onChange={(e) => setInlineEditData({ ...editData, date: e.target.value })}
                                  className="w-full px-2 py-1.5 rounded-lg bg-white/[0.04] border border-white/10 text-xs text-white focus:outline-none focus:border-purple-500/30"
                                />
                              </div>
                              <div>
                                <label className="text-[10px] text-zinc-500 mb-1 block">{t("contentPlan.time")}</label>
                                <input
                                  type="time"
                                  value={editData.time}
                                  onChange={(e) => setInlineEditData({ ...editData, time: e.target.value })}
                                  className="w-full px-2 py-1.5 rounded-lg bg-white/[0.04] border border-white/10 text-xs text-white focus:outline-none focus:border-purple-500/30"
                                />
                              </div>
                            </div>
                          </div>
                        )}
                      </motion.div>
                    );
                  })
                )}
              </div>

              {/* Modal footer: token balance indicator */}
              <div className="px-5 py-3 border-t border-white/5 shrink-0 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Coins className="w-3.5 h-3.5 text-purple-400" />
                  <span className="text-xs text-purple-300" style={{ fontWeight: 600 }}>{tokenBalance.toLocaleString()}</span>
                  <span className="text-[10px] text-zinc-600">{t("contentPlan.tokenCost").replace("{n}", "").trim()}</span>
                </div>
                <button
                  onClick={() => navigate("/dashboard/tokens")}
                  className="text-[10px] text-purple-400/80 hover:text-purple-300 transition-colors"
                >
                  {t("contentPlan.buyTokens")}
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ─── List View with DnD handles ─── */}
      {viewMode === "list" && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-2">
          {sortedItems.length === 0 ? (
            <div className="p-8 rounded-2xl border border-white/5 bg-white/[0.02] text-center">
              <CalendarDays className="w-10 h-10 text-zinc-700 mx-auto mb-3" />
              <p className="text-sm text-zinc-500">{t("contentPlan.empty")}</p>
            </div>
          ) : (
            sortedItems.map((item) => (
              <DraggableListRow
                key={item.id}
                item={item}
                t={t}
                updateStatus={updateStatus}
                duplicateItem={duplicateItem}
                deleteItem={deleteItem}
                onEdit={openEdit}
                onPreview={setPreviewItem}
                onAbTest={startAbTest}
                abTest={abTests[item.id]}
                bulkMode={bulkMode}
                isSelected={selectedIds.has(item.id)}
                onToggleSelect={() => toggleSelectId(item.id)}
              />
            ))
          )}
        </motion.div>
      )}

      {/* ─── Launch CTA ─── */}
      {!progress.launched && (
        <div className="p-4 rounded-2xl border border-white/5 bg-white/[0.02] flex flex-col sm:flex-row items-center gap-3">
          <AlertCircle className="w-5 h-5 text-amber-400 shrink-0" />
          <p className="text-xs text-zinc-400 flex-1">{t("contentPlan.launchFirst")}</p>
          <button
            onClick={() => navigate("/dashboard/launch")}
            className="text-xs text-purple-400 hover:text-purple-300 px-3 py-2 rounded-lg bg-purple-500/10 transition-all flex items-center gap-1 shrink-0"
          >
            {t("contentPlan.goLaunch")} <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* ─── New Post Modal ─── */}
      <AnimatePresence>
        {showNewModal && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/60 backdrop-blur-xl z-50" onClick={() => setShowNewModal(false)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[92vw] max-w-lg z-50 p-5 rounded-2xl liquid-glass-modal"
              role="dialog" aria-modal="true" aria-label={t("contentPlan.newPost")}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white" style={{ fontWeight: 600 }}>{t("contentPlan.newPost")}</h3>
                <button onClick={() => setShowNewModal(false)} className="text-zinc-600 hover:text-zinc-400 transition-colors"><X className="w-4 h-4" /></button>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-[11px] text-zinc-500 mb-1 block">{t("contentPlan.platform")}</label>
                  <div className="flex flex-wrap gap-1.5">
                    {Object.entries(PLATFORM_META).map(([key, meta]) => (
                      <button
                        key={key}
                        onClick={() => setNewPlatform(key as Platform)}
                        className={`inline-flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg border transition-all ${newPlatform === key ? `${meta.bgColor} ${meta.color} border-current` : "border-white/5 text-zinc-500 hover:text-zinc-300"}`}
                      >
                        <meta.icon className="w-3 h-3" />{meta.label}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-[11px] text-zinc-500 mb-1 block">{t("contentPlan.postTitle")}</label>
                  <input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} placeholder="e.g. Launch announcement thread"
                    className="w-full px-3 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-sm text-white placeholder-zinc-600 focus:outline-none focus:border-purple-500/30" />
                </div>
                <div>
                  <label className="text-[11px] text-zinc-500 mb-1 block">{t("contentPlan.postBody")}</label>
                  <textarea value={newBody} onChange={(e) => setNewBody(e.target.value)} placeholder="Write your post content..." rows={4}
                    className="w-full px-3 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-sm text-white placeholder-zinc-600 focus:outline-none focus:border-purple-500/30 resize-none" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-zinc-500 mb-1 block">{t("contentPlan.date")}</label>
                    <input type="date" value={newDate} onChange={(e) => setNewDate(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-sm text-white focus:outline-none focus:border-purple-500/30" />
                  </div>
                  <div>
                    <label className="text-[11px] text-zinc-500 mb-1 block">{t("contentPlan.time")}</label>
                    <input type="time" value={newTime} onChange={(e) => setNewTime(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-sm text-white focus:outline-none focus:border-purple-500/30" />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 mt-5">
                <button onClick={() => setShowNewModal(false)} className="text-xs text-zinc-500 hover:text-zinc-300 px-4 py-2.5 rounded-xl transition-colors">
                  {t("contentPlan.cancel")}
                </button>
                <button onClick={createPost} disabled={!newTitle.trim()}
                  className="inline-flex items-center gap-1.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-40 disabled:cursor-not-allowed text-white px-5 py-2.5 rounded-xl text-sm transition-colors">
                  <Plus className="w-3.5 h-3.5" />{t("contentPlan.create")}
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ─── Edit Post Modal ─── */}
      <AnimatePresence>
        {editItem && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/60 backdrop-blur-xl z-50" onClick={() => setEditItem(null)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[92vw] max-w-lg z-50 p-5 rounded-2xl liquid-glass-modal max-h-[85vh] overflow-y-auto"
              role="dialog" aria-modal="true" aria-label={t("contentPlan.editPost")}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white" style={{ fontWeight: 600 }}>{t("contentPlan.editPost")}</h3>
                <button onClick={() => setEditItem(null)} className="text-zinc-600 hover:text-zinc-400 transition-colors"><X className="w-4 h-4" /></button>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-[11px] text-zinc-500 mb-1 block">{t("contentPlan.platform")}</label>
                  <div className="flex flex-wrap gap-1.5">
                    {Object.entries(PLATFORM_META).map(([key, meta]) => (
                      <button key={key} onClick={() => setEditItem({ ...editItem, platform: key as Platform })}
                        className={`inline-flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg border transition-all ${editItem.platform === key ? `${meta.bgColor} ${meta.color} border-current` : "border-white/5 text-zinc-500 hover:text-zinc-300"}`}>
                        <meta.icon className="w-3 h-3" />{meta.label}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-[11px] text-zinc-500 mb-1 block">{t("contentPlan.postTitle")}</label>
                  <input value={editItem.title} onChange={(e) => setEditItem({ ...editItem, title: e.target.value })}
                    className="w-full px-3 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-sm text-white focus:outline-none focus:border-purple-500/30" />
                </div>
                <div>
                  <label className="text-[11px] text-zinc-500 mb-1 block">{t("contentPlan.postBody")}</label>
                  <textarea value={editItem.body} onChange={(e) => setEditItem({ ...editItem, body: e.target.value })} rows={6}
                    className="w-full px-3 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-sm text-white focus:outline-none focus:border-purple-500/30 resize-none" />
                  {(() => {
                    const cl: Record<Platform, number> = { twitter: 280, linkedin: 3000, reddit: 40000, producthunt: 260, blog: 50000, newsletter: 10000, forum: 20000 };
                    const lim = cl[editItem.platform]; const len = editItem.body.length;
                    const p = Math.min((len / lim) * 100, 100); const ov = len > lim;
                    return (
                      <div className="mt-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-zinc-600">{len.toLocaleString()} / {lim.toLocaleString()} · {editItem.body.split(/\s+/).filter(Boolean).length} words</span>
                          <span className={`text-[10px] ${ov ? "text-red-400" : p > 80 ? "text-amber-400" : "text-emerald-400"}`} style={{ fontWeight: 600 }}>{ov ? `${len - lim} over` : `${Math.round(100 - p)}% left`}</span>
                        </div>
                        <div className="w-full h-1 rounded-full bg-white/5 overflow-hidden mt-1">
                          <div className={`h-full rounded-full transition-all ${ov ? "bg-red-500" : p > 80 ? "bg-amber-500" : "bg-emerald-500"}`} style={{ width: `${Math.min(p, 100)}%` }} />
                        </div>
                      </div>
                    );
                  })()}
                </div>
                <div>
                  <label className="text-[11px] text-zinc-500 mb-1 block">{t("contentPlan.status")}</label>
                  <div className="flex flex-wrap gap-1.5">
                    {(Object.keys(STATUS_META) as PostStatus[]).map((s) => (
                      <button key={s} onClick={() => setEditItem({ ...editItem, status: s })}
                        className={`text-xs px-2.5 py-1.5 rounded-lg border transition-all ${editItem.status === s ? STATUS_META[s].color : "border-white/5 text-zinc-500 hover:text-zinc-300"}`}>
                        {t(STATUS_META[s].i18nKey)}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-zinc-500 mb-1 block">{t("contentPlan.date")}</label>
                    <input type="date" value={editItem.date} onChange={(e) => setEditItem({ ...editItem, date: e.target.value })}
                      className="w-full px-3 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-sm text-white focus:outline-none focus:border-purple-500/30" />
                  </div>
                  <div>
                    <label className="text-[11px] text-zinc-500 mb-1 block">{t("contentPlan.time")}</label>
                    <input type="time" value={editItem.time} onChange={(e) => setEditItem({ ...editItem, time: e.target.value })}
                      className="w-full px-3 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-sm text-white focus:outline-none focus:border-purple-500/30" />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 mt-5">
                <button onClick={() => setEditItem(null)} className="text-xs text-zinc-500 hover:text-zinc-300 px-4 py-2.5 rounded-xl transition-colors">
                  {t("contentPlan.cancel")}
                </button>
                <button onClick={saveEdit}
                  className="inline-flex items-center gap-1.5 bg-purple-600 hover:bg-purple-500 text-white px-5 py-2.5 rounded-xl text-sm transition-colors">
                  <Check className="w-3.5 h-3.5" />{t("contentPlan.save")}
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ─── Post Preview Modal ─── */}
      <AnimatePresence>
        {previewItem && (() => {
          const pm = PLATFORM_META[previewItem.platform];
          const plat = previewItem.platform;
          const charLimits: Record<Platform, number> = { twitter: 280, linkedin: 3000, reddit: 40000, producthunt: 260, blog: 50000, newsletter: 10000, forum: 20000 };
          const charLimit = charLimits[plat];
          const bodyLen = previewItem.body.length;
          const pct = Math.min((bodyLen / charLimit) * 100, 100);
          const isOver = bodyLen > charLimit;
          return (
            <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/60 backdrop-blur-xl z-50" onClick={() => setPreviewItem(null)} />
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[92vw] max-w-md z-50 rounded-2xl liquid-glass-modal overflow-hidden max-h-[85vh] flex flex-col"
              >
                <div className={`px-4 py-3 flex items-center gap-2 border-b border-white/5 ${pm.bgColor} shrink-0`}>
                  <pm.icon className={`w-4 h-4 ${pm.color}`} />
                  <span className="text-sm text-white" style={{ fontWeight: 600 }}>{pm.label} Preview</span>
                  <button onClick={() => setPreviewItem(null)} className="ml-auto text-zinc-500 hover:text-zinc-300"><X className="w-4 h-4" /></button>
                </div>
                <div className="p-4 overflow-y-auto flex-1">
                  {plat === "twitter" && (
                    <div className="space-y-2.5">
                      <div className="flex items-center gap-2">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center text-xs text-white" style={{ fontWeight: 700 }}>R</div>
                        <div><div className="text-sm text-white" style={{ fontWeight: 600 }}>Roman</div><div className="text-[11px] text-zinc-500">@roman · {previewItem.time}</div></div>
                      </div>
                      <p className="text-sm text-zinc-200 whitespace-pre-line leading-relaxed">{previewItem.body}</p>
                      <div className="flex items-center gap-6 pt-2 border-t border-white/5 text-zinc-600 text-xs">
                        <span>Replies 12</span><span>Reposts 48</span><span>Likes 156</span><span>Views 2.4K</span>
                      </div>
                    </div>
                  )}
                  {plat === "linkedin" && (
                    <div className="space-y-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-sm text-white" style={{ fontWeight: 700 }}>R</div>
                        <div>
                          <div className="text-sm text-white" style={{ fontWeight: 600 }}>Roman</div>
                          <div className="text-[11px] text-zinc-500">Founder & CEO · {previewItem.date}</div>
                          <div className="text-[10px] text-zinc-600">Public</div>
                        </div>
                      </div>
                      <p className="text-sm text-zinc-300 whitespace-pre-line leading-relaxed">{previewItem.body}</p>
                      <div className="flex items-center gap-4 pt-2 border-t border-white/5 text-zinc-500 text-xs">
                        <span>89 likes</span><span>23 comments</span><span>12 reposts</span>
                      </div>
                    </div>
                  )}
                  {plat === "reddit" && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-xs text-zinc-500">
                        <span className="text-orange-400">r/startups</span><span>·</span><span>u/roman</span><span>·</span><span>{previewItem.date}</span>
                      </div>
                      <h3 className="text-white" style={{ fontWeight: 600 }}>{previewItem.title}</h3>
                      <p className="text-sm text-zinc-400 whitespace-pre-line leading-relaxed">{previewItem.body}</p>
                      <div className="flex items-center gap-4 pt-2 border-t border-white/5 text-zinc-500 text-xs">
                        <span>234 upvotes</span><span>67 comments</span><span>92% upvoted</span>
                      </div>
                    </div>
                  )}
                  {plat === "producthunt" && (
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center text-sm text-white" style={{ fontWeight: 800 }}>PH</div>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-white truncate" style={{ fontWeight: 700 }}>{previewItem.title}</h3>
                          <p className="text-xs text-zinc-400 mt-0.5 truncate">{previewItem.body.slice(0, 80)}</p>
                        </div>
                        <div className="flex flex-col items-center px-3 py-2 rounded-lg border border-orange-500/20 bg-orange-500/5 shrink-0">
                          <TrendingUp className="w-4 h-4 text-orange-400" />
                          <span className="text-xs text-orange-300" style={{ fontWeight: 600 }}>487</span>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {["SaaS", "Productivity", "AI"].map(tg => <span key={tg} className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-zinc-400">{tg}</span>)}
                      </div>
                      <p className="text-sm text-zinc-400 whitespace-pre-line leading-relaxed">{previewItem.body}</p>
                      <div className="flex items-center gap-4 pt-2 border-t border-white/5 text-zinc-500 text-xs">
                        <span>34 comments</span><span>Featured</span><span>#3 Product of the Day</span>
                      </div>
                    </div>
                  )}
                  {plat === "blog" && (
                    <div className="space-y-3">
                      <div className="w-full h-32 rounded-xl bg-gradient-to-br from-emerald-500/20 to-cyan-500/10 border border-white/5 flex items-center justify-center">
                        <Globe className="w-10 h-10 text-emerald-500/30" />
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-zinc-500">
                        <span className="text-emerald-400">{projectName} Blog</span><span>·</span><span>{previewItem.date}</span><span>·</span><span>{Math.ceil(previewItem.body.length / 250)} min read</span>
                      </div>
                      <h2 className="text-white text-lg" style={{ fontWeight: 700 }}>{previewItem.title}</h2>
                      <p className="text-sm text-zinc-400 whitespace-pre-line leading-relaxed">{previewItem.body.slice(0, 400)}{previewItem.body.length > 400 ? "..." : ""}</p>
                      <div className="flex items-center gap-3 pt-2 border-t border-white/5">
                        <div className="w-7 h-7 rounded-full bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center text-[10px] text-white" style={{ fontWeight: 700 }}>R</div>
                        <div className="text-xs text-zinc-500">By <span className="text-zinc-300">Roman</span></div>
                      </div>
                    </div>
                  )}
                  {plat === "newsletter" && (
                    <div className="border border-white/5 rounded-xl overflow-hidden">
                      <div className="bg-gradient-to-r from-violet-500/10 to-purple-500/10 px-4 py-3 border-b border-white/5">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-violet-500/20 flex items-center justify-center"><Rss className="w-4 h-4 text-violet-400" /></div>
                          <div>
                            <div className="text-sm text-white" style={{ fontWeight: 600 }}>{projectName} Weekly</div>
                            <div className="text-[10px] text-zinc-500">to: subscriber@email.com</div>
                          </div>
                        </div>
                      </div>
                      <div className="px-4 py-3">
                        <h3 className="text-white" style={{ fontWeight: 600 }}>{previewItem.title}</h3>
                        <p className="text-sm text-zinc-400 whitespace-pre-line leading-relaxed mt-2">{previewItem.body}</p>
                        <div className="mt-3 px-4 py-2 rounded-lg bg-violet-600 text-white text-xs text-center" style={{ fontWeight: 600 }}>Read More</div>
                      </div>
                      <div className="px-4 py-2 border-t border-white/5 text-[10px] text-zinc-600 text-center">
                        Sent to 2,847 subscribers · 42% open rate · 8.3% CTR
                      </div>
                    </div>
                  )}
                  {plat === "forum" && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-xs text-zinc-500">
                        <Hash className="w-3.5 h-3.5 text-amber-400" />
                        <span className="text-amber-400">Hacker News</span><span>·</span><span>{previewItem.date}</span>
                      </div>
                      <h3 className="text-orange-300" style={{ fontWeight: 600 }}>{previewItem.title}</h3>
                      <div className="text-xs text-zinc-500">(launch-os.com)</div>
                      <p className="text-sm text-zinc-400 whitespace-pre-line leading-relaxed mt-1">{previewItem.body.slice(0, 200)}</p>
                      <div className="flex items-center gap-4 pt-2 border-t border-white/5 text-zinc-500 text-xs">
                        <span>187 points</span><span>93 comments</span><span>3 hours ago</span>
                      </div>
                    </div>
                  )}
                </div>
                {/* Character counter */}
                <div className="px-4 py-2.5 border-t border-white/5 shrink-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] text-zinc-600">{bodyLen.toLocaleString()} / {charLimit.toLocaleString()} chars · {previewItem.body.split(/\s+/).filter(Boolean).length} words</span>
                    <span className={`text-[10px] ${isOver ? "text-red-400" : pct > 80 ? "text-amber-400" : "text-emerald-400"}`} style={{ fontWeight: 600 }}>{isOver ? `${bodyLen - charLimit} over` : `${Math.round(100 - pct)}% left`}</span>
                  </div>
                  <div className="w-full h-1 rounded-full bg-white/5 overflow-hidden">
                    <motion.div initial={{ width: 0 }} animate={{ width: `${Math.min(pct, 100)}%` }} className={`h-full rounded-full ${isOver ? "bg-red-500" : pct > 80 ? "bg-amber-500" : "bg-emerald-500"}`} />
                  </div>
                </div>
              </motion.div>
            </>
          );
        })()}
      </AnimatePresence>

      {/* ─── A/B Test Modal ─── */}
      <AnimatePresence>
        {abTestItem && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/60 backdrop-blur-xl z-50" onClick={() => setAbTestItem(null)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[92vw] max-w-lg z-50 p-5 rounded-2xl liquid-glass-modal"
            >
              <div className="flex items-center gap-2 mb-4">
                <Repeat className="w-4 h-4 text-orange-400" />
                <h3 className="text-white" style={{ fontWeight: 600 }}>{t("contentPlan.abTestTitle")}</h3>
                <button onClick={() => setAbTestItem(null)} className="ml-auto text-zinc-600 hover:text-zinc-400"><X className="w-4 h-4" /></button>
              </div>
              <div className="space-y-3">
                <div>
                  <label className="text-[11px] text-zinc-500 mb-1 block">Variant A (current)</label>
                  <div className="px-3 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-sm text-zinc-300">{abTestItem.title}</div>
                </div>
                <div>
                  <label className="text-[11px] text-zinc-500 mb-1 block">Variant B</label>
                  <input
                    value={abVariantB}
                    onChange={(e) => setAbVariantB(e.target.value)}
                    placeholder="Alternative headline..."
                    className="w-full px-3 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-sm text-white placeholder-zinc-600 focus:outline-none focus:border-orange-500/30"
                  />
                </div>
                <p className="text-[11px] text-zinc-600">{t("contentPlan.abTestDesc")}</p>
              </div>
              <div className="flex items-center justify-end gap-2 mt-4">
                <button onClick={() => setAbTestItem(null)} className="text-xs text-zinc-500 hover:text-zinc-300 px-4 py-2 rounded-xl transition-colors">{t("contentPlan.cancel")}</button>
                <button onClick={saveAbTest} disabled={!abVariantB.trim()} className="inline-flex items-center gap-1.5 bg-orange-600 hover:bg-orange-500 disabled:opacity-40 text-white px-4 py-2 rounded-xl text-sm transition-colors">
                  <Repeat className="w-3.5 h-3.5" />{t("contentPlan.startAbTest")}
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ─── Token Upsell Modal ─── */}
      <AnimatePresence>
        {showTokenUpsell && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/60 backdrop-blur-xl z-[60]" onClick={() => setShowTokenUpsell(false)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90vw] max-w-sm z-[60] liquid-glass-modal rounded-2xl p-6 text-center"
            >
              <div className="w-14 h-14 rounded-2xl bg-purple-500/10 flex items-center justify-center mx-auto mb-4">
                <Coins className="w-7 h-7 text-purple-400" />
              </div>
              <h3 className="text-white mb-2" style={{ fontWeight: 600 }}>{t("contentPlan.insufficientTokens")}</h3>
              <p className="text-xs text-zinc-400 mb-5 leading-relaxed">
                {t("contentPlan.insufficientDesc")
                  .replace("{n}", String(pendingTokenCost))
                  .replace("{b}", String(tokenBalance))}
              </p>
              <div className="flex flex-col gap-2">
                <button
                  onClick={() => { setShowTokenUpsell(false); navigate("/dashboard/tokens"); }}
                  className="w-full bg-purple-600 hover:bg-purple-500 text-white py-3 rounded-xl text-sm transition-all active:scale-[0.97] flex items-center justify-center gap-2"
                >
                  <Coins className="w-4 h-4" />
                  {t("contentPlan.buyTokens")}
                </button>
                <button
                  onClick={() => setShowTokenUpsell(false)}
                  className="text-xs text-zinc-500 hover:text-zinc-300 py-2 transition-colors"
                >
                  {t("contentPlan.cancel")}
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ═══ Wrapper with DnD Provider ═══ */
export function ContentPlan() {
  const backend = isTouchDevice ? TouchBackend : HTML5Backend;
  const options = isTouchDevice ? { enableMouseEvents: true, delayTouchStart: 200 } : undefined;

  return (
    <DndProvider backend={backend} options={options}>
      <ContentPlanInner />
    </DndProvider>
  );
}

export default ContentPlan;
