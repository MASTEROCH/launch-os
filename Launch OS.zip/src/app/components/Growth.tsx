import { ChannelsHub } from "./ChannelsHub";
import { useI18n } from "./i18n";
import { useDocumentTitle } from "./useDocumentTitle";

export function Growth() {
  const { t } = useI18n();
  useDocumentTitle(t("sidebar.growth"));

  return <ChannelsHub />;
}
