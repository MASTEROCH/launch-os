import { useI18n } from "./i18n";
import { useDocumentTitle } from "./useDocumentTitle";
import { MyProjects } from "./MyProjects";
import { usePullToRefresh } from "./usePullToRefresh";
import { PullToRefreshIndicator } from "./PullToRefreshIndicator";

export function ProjectsPage() {
  const { t } = useI18n();
  useDocumentTitle(t("projects.title"));

  const { pullY, isRefreshing, handlers: pullHandlers } = usePullToRefresh(
    () => new Promise<void>((resolve) => setTimeout(resolve, 800))
  );

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6" {...pullHandlers}>
      <PullToRefreshIndicator pullY={pullY} isRefreshing={isRefreshing} />
      <MyProjects />
    </div>
  );
}

export default ProjectsPage;
