import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Rocket, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router";
import { useI18n } from "./i18n";
import { LaunchLogo } from "./LaunchLogo";
import confetti from "canvas-confetti";
import { useForceDarkMode } from "./useForceDarkMode";

export function WelcomeSplash() {
  useForceDarkMode();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [step, setStep] = useState(0); // 0: logo, 1: text, 2: cta
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    // Fire confetti
    const fire = () => {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.5, x: 0.5 },
        colors: ["#8b5cf6", "#06b6d4", "#10b981", "#f59e0b", "#ec4899"],
        disableForReducedMotion: true,
      });
    };
    const t1 = setTimeout(fire, 300);
    const t2 = setTimeout(fire, 700);
    const t3 = setTimeout(() => setStep(1), 500);
    const t4 = setTimeout(() => setStep(2), 1200);
    // Auto-dismiss after 5s
    const t5 = setTimeout(() => {
      setDismissed(true);
      setTimeout(() => navigate("/dashboard"), 400);
    }, 5000);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); clearTimeout(t4); clearTimeout(t5); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleContinue = () => {
    setDismissed(true);
    setTimeout(() => navigate("/dashboard"), 300);
  };

  return (
    <AnimatePresence>
      {!dismissed && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 z-[200] bg-[var(--app-bg)] flex flex-col items-center justify-center p-6"
        >
          {/* Background glow */}
          <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-purple-500/10 rounded-full blur-[120px]" />
          <div className="absolute bottom-1/3 left-1/2 -translate-x-1/2 translate-y-1/2 w-[300px] h-[300px] bg-cyan-500/5 rounded-full blur-[100px]" />

          {/* Logo */}
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 200, damping: 15, delay: 0.1 }}
            className="relative mb-8"
          >
            <motion.div
              animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0, 0.3] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="absolute inset-0 rounded-3xl bg-purple-500/20 -m-3"
            />
            <LaunchLogo size={72} />
          </motion.div>

          {/* Welcome text */}
          {step >= 1 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-8"
            >
              <h1 className="text-3xl md:text-4xl text-white tracking-tight mb-3" style={{ fontWeight: 800 }}>
                {t("welcome.title")}
              </h1>
              <p className="text-zinc-400 max-w-md mx-auto">
                {t("welcome.subtitle")}
              </p>
            </motion.div>
          )}

          {/* CTA */}
          {step >= 2 && (
            <motion.button
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              onClick={handleContinue}
              className="flex items-center gap-2 px-8 py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white shadow-xl shadow-purple-500/25 transition-all cursor-pointer"
            >
              <Rocket className="w-4 h-4" />
              <span style={{ fontWeight: 600 }}>{t("welcome.cta")}</span>
              <ArrowRight className="w-4 h-4" />
            </motion.button>
          )}

          {/* Skip hint */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2 }}
            className="absolute bottom-8 text-xs text-zinc-600 cursor-pointer"
            onClick={handleContinue}
          >
            {t("welcome.skip")}
          </motion.p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
