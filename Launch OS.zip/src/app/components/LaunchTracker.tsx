import { useState, useEffect } from "react";
import { motion } from "motion/react";
import {
  Check, Loader, Circle, FileText, Rocket, Globe, Users, TrendingUp,
  Clock, ArrowUpRight, Radio, Calendar, List,
  FolderPlus, Coins, Sparkles, MessageSquare, Award, Flame, Filter,
} from "lucide-react";
import { useI18n } from "./i18n";
import { loadProgress } from "./user-progress";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { ProgressSkeleton, TimelineSkeleton } from "./PageSkeleton";
import { usePullToRefresh } from "./usePullToRefresh";
import { PullToRefreshIndicator } from "./PullToRefreshIndicator";

/* ═══════════════════════════════════════════
   Pipeline View (ex-LaunchTracker)
   ═══════════════════════════════════════════ */
const statusIcon = {
  complete: <Check className="w-4 h-4 text-emerald-400" />,
  active: <Loader className="w-4 h-4 text-purple-400 animate-spin" />,
  pending: <Circle className="w-4 h-4 text-zinc-600" />,
};
const statusBg = {
  complete: "border-emerald-500/30 bg-emerald-500/5",
  active: "border-purple-500/30 bg-purple-500/5",
  pending: "border-white/5 bg-white/[0.01]",
};

function PipelineView({ t, progress }: { t: (k: string) => string; progress: ReturnType<typeof loadProgress> }) {
  const stages = [
    { icon: FileText, title: t("tracker.contentGen"), desc: t("tracker.contentGenDesc"), status: "complete" as const, time: t("tracker.completed") + " 2h ago", details: ["Product Hunt description", "Reddit posts (2)", "Twitter thread", "LinkedIn post", "Email template"] },
    { icon: Rocket, title: t("tracker.launchPrep"), desc: t("tracker.launchPrepDesc"), status: "complete" as const, time: t("tracker.completed") + " 1h ago", details: ["Channel auth verified", "Content formatting", "Schedule confirmed"] },
    { icon: Globe, title: t("tracker.distStarted"), desc: t("tracker.distStartedDesc"), status: "active" as const, time: t("tracker.inProgress"), details: ["Reddit — published (done)", "Twitter — published (done)", "LinkedIn — publishing...", "Product Hunt — queued"] },
    { icon: Users, title: t("tracker.communityEng"), desc: t("tracker.communityEngDesc"), status: "pending" as const, time: t("tracker.estimated") + " 2h", details: ["Track upvotes & comments", "Auto-reply engagement", "Community signal detection"] },
    { icon: TrendingUp, title: t("tracker.trafficGrowth"), desc: t("tracker.trafficGrowthDesc"), status: "pending" as const, time: t("tracker.estimated") + " 24h", details: ["Traffic source tracking", "Conversion monitoring", "Growth report generation"] },
  ];

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="p-5 rounded-xl border border-white/5 bg-white/[0.02]">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm text-zinc-400">{t("tracker.overallProgress")}</span>
          <span className="text-sm text-white" style={{ fontWeight: 600 }}>48%</span>
        </div>
        <div className="w-full h-2 rounded-full bg-white/5 overflow-hidden">
          <motion.div initial={{ width: 0 }} animate={{ width: "48%" }} transition={{ duration: 1.5, ease: "easeOut" }} className="h-full rounded-full bg-gradient-to-r from-purple-500 via-violet-500 to-cyan-500" />
        </div>
        <div className="flex items-center justify-between mt-3 text-xs text-zinc-600">
          <span>2/5 {t("tracker.stagesCompleted")}</span>
          <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{t("tracker.estCompletion")}: 24h</span>
        </div>
      </div>

      <div className="relative">
        {stages.map((stage, i) => (
          <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }} className="relative flex gap-4 pb-8 last:pb-0">
            {i < stages.length - 1 && <div className="absolute left-[19px] top-10 bottom-0 w-px bg-white/5" />}
            <div className={`w-10 h-10 shrink-0 rounded-xl border flex items-center justify-center ${statusBg[stage.status]}`}>{statusIcon[stage.status]}</div>
            <div className={`flex-1 p-5 rounded-xl border transition-all ${statusBg[stage.status]}`}>
              <div className="flex items-start justify-between gap-2 mb-2">
                <div><h3 className="text-white" style={{ fontWeight: 600 }}>{stage.title}</h3><p className="text-sm text-zinc-500">{stage.desc}</p></div>
                <span className="text-xs text-zinc-600 shrink-0">{stage.time}</span>
              </div>
              <div className="mt-3 space-y-1.5">
                {stage.details.map((d) => (
                  <div key={d} className="flex items-center gap-2 text-xs text-zinc-500">
                    <div className={`w-1.5 h-1.5 rounded-full ${stage.status === "complete" ? "bg-emerald-500" : stage.status === "active" ? "bg-purple-500" : "bg-zinc-700"}`} />{d}
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: t("tracker.postsPublished"), value: "3/6" },
          { label: t("tracker.upvotes"), value: "47" },
          { label: t("tracker.newVisitors"), value: "284" },
          { label: t("tracker.comments"), value: "12" },
        ].map((s) => (
          <div key={s.label} className="p-4 rounded-xl border border-white/5 bg-white/[0.02]">
            <div className="text-lg text-white" style={{ fontWeight: 700 }}>{s.value}</div>
            <div className="text-xs text-zinc-500 flex items-center gap-1">{s.label}<ArrowUpRight className="w-3 h-3 text-emerald-400" /></div>
          </div>
        ))}
      </div>

      <div className="p-5 rounded-xl border border-white/5 bg-white/[0.02]">
        <div className="flex items-center gap-2 mb-4">
          <Radio className="w-4 h-4 text-purple-400" />
          <h3 className="text-white" style={{ fontWeight: 600 }}>{t("tracker.channelBreakdown")}</h3>
        </div>
        <div className="grid sm:grid-cols-3 gap-3">
          {[
            { label: t("engine.autoPost"), channels: ["Twitter/X", "LinkedIn", "Product Hunt"], status: t("tracker.autoPosted"), badgeCls: "bg-emerald-500/10 text-emerald-400", dotCls: "bg-emerald-500" },
            { label: t("engine.assisted"), channels: ["Reddit", "Hacker News"], status: t("tracker.assistedWaiting"), badgeCls: "bg-amber-500/10 text-amber-400", dotCls: "bg-amber-500" },
            { label: t("engine.managed"), channels: ["Email PR", "SEO", "Catalogs"], status: t("tracker.managedRunning"), badgeCls: "bg-purple-500/10 text-purple-400", dotCls: "bg-purple-500" },
          ].map((tier) => (
            <div key={tier.label} className="p-3 rounded-xl border border-white/5 bg-white/[0.01]">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-zinc-400" style={{ fontWeight: 600 }}>{tier.label}</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full ${tier.badgeCls}`} style={{ fontWeight: 500 }}>{tier.status}</span>
              </div>
              <div className="space-y-1.5">
                {tier.channels.map((ch) => (
                  <div key={ch} className="flex items-center gap-2 text-xs text-zinc-500">
                    <div className={`w-1.5 h-1.5 rounded-full ${tier.dotCls}`} />
                    {ch}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════
   Timeline View (ex-LaunchTimeline)
   ═══════════════════════════════════════════ */
interface TimelineEvent {
  id: string;
  icon: typeof Rocket;
  titleKey: string;
  descKey: string;
  time: string;
  color: string;
  category: "milestone" | "distribution";
  completed: boolean;
}

type FilterType = "all" | "milestone" | "distribution";

const colorMap: Record<string, { bg: string; text: string; border: string; line: string }> = {
  purple: { bg: "bg-purple-500/15", text: "text-purple-400", border: "border-purple-500/30", line: "bg-purple-500" },
  cyan: { bg: "bg-cyan-500/15", text: "text-cyan-400", border: "border-cyan-500/30", line: "bg-cyan-500" },
  amber: { bg: "bg-amber-500/15", text: "text-amber-400", border: "border-amber-500/30", line: "bg-amber-500" },
  violet: { bg: "bg-violet-500/15", text: "text-violet-400", border: "border-violet-500/30", line: "bg-violet-500" },
  emerald: { bg: "bg-emerald-500/15", text: "text-emerald-400", border: "border-emerald-500/30", line: "bg-emerald-500" },
  orange: { bg: "bg-orange-500/15", text: "text-orange-400", border: "border-orange-500/30", line: "bg-orange-500" },
  rose: { bg: "bg-rose-500/15", text: "text-rose-400", border: "border-rose-500/30", line: "bg-rose-500" },
};

function TimelineView({ t, progress }: { t: (k: string) => string; progress: ReturnType<typeof loadProgress> }) {
  const [filter, setFilter] = useState<FilterType>("all");
  const day = progress.launchDay;
  const projectName = progress.projectName || "AI Task Manager";

  const allEvents: TimelineEvent[] = [
    { id: "created", icon: FolderPlus, titleKey: "timeline.eventCreated", descKey: "timeline.eventCreatedDesc", time: "Day 0 — 10:00 AM", color: "purple", category: "milestone", completed: progress.projectCreated },
    { id: "tokens", icon: Coins, titleKey: "timeline.eventTokens", descKey: "timeline.eventTokensDesc", time: "Day 0 — 10:15 AM", color: "cyan", category: "milestone", completed: progress.tokensAvailable > 0 },
    { id: "channels", icon: Radio, titleKey: "timeline.eventChannels", descKey: "timeline.eventChannelsDesc", time: "Day 0 — 10:30 AM", color: "amber", category: "distribution", completed: progress.channelsConnected > 0 },
    { id: "content", icon: Sparkles, titleKey: "timeline.eventContent", descKey: "timeline.eventContentDesc", time: "Day 0 — 11:00 AM", color: "violet", category: "distribution", completed: progress.launched },
    { id: "launch", icon: Rocket, titleKey: "timeline.eventLaunch", descKey: "timeline.eventLaunchDesc", time: "Day 1 — 9:00 AM", color: "emerald", category: "milestone", completed: progress.launched },
    { id: "reddit", icon: MessageSquare, titleKey: "timeline.eventReddit", descKey: "timeline.eventRedditDesc", time: "Day 2 — 2:30 PM", color: "orange", category: "distribution", completed: day >= 2 },
    { id: "traffic", icon: TrendingUp, titleKey: "timeline.eventTraffic", descKey: "timeline.eventTrafficDesc", time: "Day 3 — 11:00 AM", color: "emerald", category: "milestone", completed: day >= 3 },
    { id: "users100", icon: Users, titleKey: "timeline.eventMilestone", descKey: "timeline.eventMilestoneDesc", time: "Day 4 — 4:00 PM", color: "cyan", category: "milestone", completed: day >= 4 },
    { id: "ph", icon: Award, titleKey: "timeline.eventPH", descKey: "timeline.eventPHDesc", time: "Day 5 — 8:00 AM", color: "amber", category: "milestone", completed: day >= 5 },
    { id: "viral", icon: Flame, titleKey: "timeline.eventViral", descKey: "timeline.eventViralDesc", time: "Day 7 — 10:00 AM", color: "rose", category: "distribution", completed: day >= 7 },
  ];

  const completedEvents = allEvents.filter((e) => e.completed);
  const nextPending = allEvents.find((e) => !e.completed);
  const visibleEvents = nextPending ? [...completedEvents, nextPending] : completedEvents;
  const filtered = filter === "all" ? visibleEvents : visibleEvents.filter((e) => e.category === filter);
  const hasEvents = visibleEvents.length > 0;

  const filters = [
    { id: "all" as const, label: t("timeline.filterAll") },
    { id: "milestone" as const, label: t("timeline.filterMilestones") },
    { id: "distribution" as const, label: t("timeline.filterDistribution") },
  ];

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex items-center gap-1.5">
        <Filter className="w-3.5 h-3.5 text-zinc-600 mr-1" />
        {filters.map((f) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`text-xs px-3 py-1.5 rounded-lg transition-all ${
              filter === f.id
                ? "bg-purple-500/10 text-purple-400 border border-purple-500/20"
                : "text-zinc-500 border border-white/5 hover:border-white/10 hover:text-zinc-300"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Project badge */}
      {progress.projectCreated && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-purple-500/5 border border-purple-500/10">
          <Rocket className="w-3.5 h-3.5 text-purple-400" />
          <span className="text-xs text-purple-300" style={{ fontWeight: 600 }}>{projectName}</span>
          {progress.launched && (
            <span className="text-[10px] text-emerald-400 ml-auto">Day {day}/7</span>
          )}
        </div>
      )}

      {/* Timeline */}
      {hasEvents ? (
        <div className="relative">
          <div className="absolute left-[19px] top-0 bottom-0 w-px bg-white/[0.06]" />
          <div className="space-y-1">
            {filtered.map((event, i) => {
              const c = colorMap[event.color] || colorMap.purple;
              const isLast = i === filtered.length - 1;
              const isPending = !event.completed;

              return (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.08, duration: 0.4 }}
                  className="relative flex gap-4 pb-6"
                >
                  <div className="relative z-10 flex flex-col items-center shrink-0">
                    <div className={`w-10 h-10 rounded-xl ${isPending ? "bg-white/[0.03] border border-dashed border-white/10" : c.bg} flex items-center justify-center ${isPending ? "opacity-50" : ""}`}>
                      <event.icon className={`w-4.5 h-4.5 ${isPending ? "text-zinc-600" : c.text}`} />
                    </div>
                    {!isLast && (
                      <div className={`w-px flex-1 mt-1 ${isPending ? "bg-white/[0.04]" : c.line} opacity-30`} />
                    )}
                  </div>

                  <div className={`flex-1 pb-2 ${isPending ? "opacity-50" : ""}`}>
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className={`text-sm ${isPending ? "text-zinc-500" : "text-white"}`} style={{ fontWeight: 600 }}>
                        {t(event.titleKey)}
                      </span>
                      {isPending && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/[0.04] text-zinc-600 border border-white/5">
                          upcoming
                        </span>
                      )}
                      {event.completed && (
                        <span className={`text-[10px] px-2 py-0.5 rounded-full ${c.bg} ${c.text} border ${c.border}`}>
                          {event.category === "milestone" ? t("timeline.filterMilestones") : t("timeline.filterDistribution")}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-zinc-500 leading-relaxed">{t(event.descKey)}</p>
                    <span className="text-[11px] text-zinc-700 mt-1 block">{event.time}</span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="p-12 rounded-2xl border border-dashed border-white/5 bg-white/[0.01] flex flex-col items-center justify-center text-center"
        >
          <div className="w-16 h-16 rounded-2xl bg-purple-500/10 border border-purple-500/15 flex items-center justify-center mb-4">
            <Calendar className="w-7 h-7 text-purple-400/50" />
          </div>
          <p className="text-sm text-zinc-500">{t("timeline.noEvents")}</p>
        </motion.div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════
   Main Component — tabs: Pipeline | Timeline
   ═══════════════════════════════════════════ */
type ViewMode = "pipeline" | "timeline";

export function LaunchTracker() {
  const { t } = useI18n();
  useDocumentTitle(t("sidebar.launchTracker"));
  const progress = loadProgress();
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<ViewMode>("pipeline");

  const { pullY, isRefreshing, handlers: pullHandlers } = usePullToRefresh(
    () => new Promise<void>((resolve) => setTimeout(resolve, 1200))
  );

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(timer);
  }, []);

  const viewTabs = [
    { key: "pipeline" as ViewMode, label: t("tracker.viewPipeline"), icon: List },
    { key: "timeline" as ViewMode, label: t("tracker.viewTimeline"), icon: Calendar },
  ];

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-4 sm:space-y-6" {...pullHandlers}>
      <PullToRefreshIndicator pullY={pullY} isRefreshing={isRefreshing} />
      <LargeTitle
        title={t("tracker.title")}
        subtitle={t("tracker.subtitle")}
        badge={
          <span className="text-xs bg-purple-500/10 text-purple-400 px-2 py-0.5 rounded-full" style={{ fontWeight: 600 }}>{progress.projectName || "AI Task Manager"}</span>
        }
        actions={
          <div className="flex gap-1">
            {viewTabs.map((vt) => (
              <button
                key={vt.key}
                onClick={() => setView(vt.key)}
                className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs transition-all ${
                  view === vt.key
                    ? "bg-purple-500/10 text-purple-400 border border-purple-500/20"
                    : "text-zinc-500 border border-white/5 hover:border-white/10 hover:text-zinc-300"
                }`}
                style={{ fontWeight: view === vt.key ? 600 : 400 }}
              >
                <vt.icon className="w-3 h-3" />
                {vt.label}
              </button>
            ))}
          </div>
        }
      />

      {loading ? (
        view === "pipeline" ? <ProgressSkeleton steps={5} /> : <TimelineSkeleton />
      ) : (
        view === "pipeline" ? (
          <PipelineView t={t} progress={progress} />
        ) : (
          <TimelineView t={t} progress={progress} />
        )
      )}
    </div>
  );
}