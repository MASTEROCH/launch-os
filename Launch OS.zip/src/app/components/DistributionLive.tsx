import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Radio, CheckCircle, Clock, AlertTriangle, Loader2, Play, Pause,
  RefreshCw, Zap, Globe, Eye, Send, TrendingUp, Activity, Wifi,
  ExternalLink, ChevronRight, RotateCcw, Sparkles, Target,
} from "lucide-react";
import { useI18n } from "./i18n";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { usePullToRefresh } from "./usePullToRefresh";
import { PullToRefreshIndicator } from "./PullToRefreshIndicator";
import { loadProgress } from "./user-progress";
import { useNavigate } from "react-router";
import { CountUp } from "./CountUp";

/* ─── Channel definitions ─── */
interface Channel {
  id: string;
  name: string;
  icon: string;
  color: string;
  estReach: number;
  tokenCost: number;
  tier: "auto" | "assisted" | "managed";
}

const CHANNELS: Channel[] = [
  { id: "reddit", name: "Reddit", icon: "R", color: "from-orange-500 to-red-600", estReach: 12400, tokenCost: 15, tier: "auto" },
  { id: "twitter", name: "Twitter / X", icon: "X", color: "from-sky-500 to-blue-600", estReach: 8900, tokenCost: 10, tier: "auto" },
  { id: "linkedin", name: "LinkedIn", icon: "in", color: "from-blue-600 to-blue-800", estReach: 5600, tokenCost: 12, tier: "auto" },
  { id: "producthunt", name: "Product Hunt", icon: "PH", color: "from-orange-500 to-amber-600", estReach: 4200, tokenCost: 25, tier: "auto" },
  { id: "hn", name: "Hacker News", icon: "Y", color: "from-orange-600 to-orange-800", estReach: 3800, tokenCost: 8, tier: "auto" },
  { id: "devto", name: "Dev.to", icon: "DEV", color: "from-zinc-600 to-zinc-800", estReach: 2100, tokenCost: 8, tier: "auto" },
  { id: "indiehackers", name: "Indie Hackers", icon: "IH", color: "from-blue-500 to-indigo-700", estReach: 1800, tokenCost: 10, tier: "auto" },
  { id: "betalist", name: "BetaList", icon: "BL", color: "from-emerald-500 to-teal-700", estReach: 1200, tokenCost: 12, tier: "assisted" },
  { id: "medium", name: "Medium", icon: "M", color: "from-zinc-700 to-zinc-900", estReach: 3400, tokenCost: 15, tier: "auto" },
  { id: "quora", name: "Quora", icon: "Q", color: "from-red-600 to-red-800", estReach: 2800, tokenCost: 8, tier: "auto" },
  { id: "discord", name: "Discord Servers", icon: "DC", color: "from-indigo-500 to-purple-700", estReach: 4500, tokenCost: 5, tier: "auto" },
  { id: "slack", name: "Slack Communities", icon: "SL", color: "from-purple-500 to-fuchsia-700", estReach: 2200, tokenCost: 5, tier: "auto" },
  { id: "facebook", name: "Facebook Groups", icon: "FB", color: "from-blue-600 to-blue-800", estReach: 6700, tokenCost: 12, tier: "assisted" },
  { id: "youtube", name: "YouTube", icon: "YT", color: "from-red-500 to-red-700", estReach: 8200, tokenCost: 30, tier: "managed" },
  { id: "tiktok", name: "TikTok", icon: "TT", color: "from-pink-500 to-violet-700", estReach: 15000, tokenCost: 25, tier: "managed" },
  { id: "instagram", name: "Instagram", icon: "IG", color: "from-pink-500 to-amber-500", estReach: 9800, tokenCost: 20, tier: "assisted" },
];

type PostStatus = "queued" | "generating" | "posting" | "posted" | "failed" | "scheduled";

interface QueueItem {
  id: string;
  channel: Channel;
  status: PostStatus;
  progress: number;
  startedAt?: number;
  completedAt?: number;
  reach?: number;
  engagement?: number;
  logMessages: string[];
}

const STATUS_PHASES = ["generating", "posting", "posted"] as const;

function randomBetween(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function DistributionLive() {
  const { t } = useI18n();
  const navigate = useNavigate();
  useDocumentTitle(t("distro.title"));

  const progress = loadProgress();

  const { pullY, isRefreshing, handlers: pullHandlers } = usePullToRefresh(
    () => new Promise<void>((r) => setTimeout(r, 800))
  );

  const [queue, setQueue] = useState<QueueItem[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [totalPosted, setTotalPosted] = useState(0);
  const [totalReach, setTotalReach] = useState(0);
  const [totalTokens, setTotalTokens] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [liveLog, setLiveLog] = useState<{ time: string; text: string; color: string }[]>([]);
  const logEndRef = useRef<HTMLDivElement>(null);

  const addLog = useCallback((text: string, color = "text-zinc-400") => {
    const now = new Date();
    const time = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}:${now.getSeconds().toString().padStart(2, "0")}`;
    setLiveLog((prev) => [...prev.slice(-50), { time, text, color }]);
  }, []);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [liveLog]);

  // Initialize queue
  const initQueue = useCallback(() => {
    const items: QueueItem[] = CHANNELS.map((ch) => ({
      id: `q_${ch.id}_${Date.now()}`,
      channel: ch,
      status: "queued" as PostStatus,
      progress: 0,
      logMessages: [],
    }));
    setQueue(items);
    setTotalPosted(0);
    setTotalReach(0);
    setTotalTokens(0);
    setLiveLog([]);
  }, []);

  useEffect(() => {
    initQueue();
  }, [initQueue]);

  // Distribution simulation engine
  const startDistribution = useCallback(() => {
    setIsRunning(true);
    addLog("[START] Distribution engine started", "text-emerald-400");
    addLog("[AUTH] Authenticating channel connections...", "text-zinc-500");

    let tick = 0;
    intervalRef.current = setInterval(() => {
      tick++;
      setQueue((prev) => {
        const updated = [...prev];
        // Find first queued item or active item
        const activeIdx = updated.findIndex((item) => item.status === "generating" || item.status === "posting");
        const queuedIdx = updated.findIndex((item) => item.status === "queued");

        // Start new items (up to 3 concurrent)
        const activeCount = updated.filter((item) => item.status === "generating" || item.status === "posting").length;
        if (activeCount < 3 && queuedIdx !== -1) {
          updated[queuedIdx] = {
            ...updated[queuedIdx],
            status: "generating",
            progress: 5,
            startedAt: Date.now(),
          };
          addLog(`[GEN] ${updated[queuedIdx].channel.name} — generating content...`, "text-purple-400");
        }

        // Progress active items
        updated.forEach((item, i) => {
          if (item.status === "generating") {
            const newProgress = Math.min(item.progress + randomBetween(8, 20), 100);
            updated[i] = { ...item, progress: newProgress };
            if (newProgress >= 45 && item.progress < 45) {
              updated[i].status = "posting";
              addLog(`[POST] ${item.channel.name} — content ready, posting...`, "text-cyan-400");
            }
          } else if (item.status === "posting") {
            const newProgress = Math.min(item.progress + randomBetween(10, 25), 100);
            updated[i] = { ...item, progress: newProgress };

            // Random failure (5% chance)
            if (newProgress > 60 && Math.random() < 0.03) {
              updated[i] = { ...item, status: "failed", progress: newProgress };
              addLog(`[FAIL] ${item.channel.name} — rate limit, will retry`, "text-red-400");
              return;
            }

            if (newProgress >= 100) {
              const reach = Math.round(item.channel.estReach * (0.7 + Math.random() * 0.6));
              const engagement = Math.round(reach * (0.02 + Math.random() * 0.05));
              updated[i] = {
                ...item,
                status: "posted",
                progress: 100,
                completedAt: Date.now(),
                reach,
                engagement,
              };
              addLog(`[DONE] ${item.channel.name} — posted! Reach: ${reach.toLocaleString()}, engagement: ${engagement}`, "text-emerald-400");
              setTotalPosted((p) => p + 1);
              setTotalReach((p) => p + reach);
              setTotalTokens((p) => p + item.channel.tokenCost);
            }
          }
        });

        // Check if all done
        const allDone = updated.every((item) => item.status === "posted" || item.status === "failed");
        if (allDone) {
          setIsRunning(false);
          if (intervalRef.current) clearInterval(intervalRef.current);
          addLog("[COMPLETE] Distribution complete!", "text-amber-400");
        }

        return updated;
      });
    }, 800);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [addLog]);

  const togglePause = () => {
    if (isRunning) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      setIsRunning(false);
      addLog("[PAUSE] Distribution paused", "text-amber-400");
    } else {
      startDistribution();
    }
  };

  const retryFailed = () => {
    setQueue((prev) =>
      prev.map((item) =>
        item.status === "failed"
          ? { ...item, status: "queued", progress: 0 }
          : item
      )
    );
    addLog("[RETRY] Retrying failed channels...", "text-cyan-400");
    if (!isRunning) startDistribution();
  };

  // Cleanup
  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  // Stats
  const queuedCount = queue.filter((q) => q.status === "queued").length;
  const activeCount = queue.filter((q) => q.status === "generating" || q.status === "posting").length;
  const completedCount = queue.filter((q) => q.status === "posted").length;
  const failedCount = queue.filter((q) => q.status === "failed").length;
  const avgEngagement = completedCount > 0
    ? Math.round(queue.filter((q) => q.status === "posted").reduce((s, q) => s + (q.engagement || 0), 0) / completedCount)
    : 0;

  const hasStarted = queue.some((q) => q.status !== "queued");

  /* ─── Empty state (no project) ─── */
  if (!progress.projectCreated) {
    return (
      <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6" {...pullHandlers}>
        <PullToRefreshIndicator pullY={pullY} isRefreshing={isRefreshing} />
        <LargeTitle title={t("distro.title")} subtitle={t("distro.subtitle")} />
        <div className="flex flex-col items-center text-center py-16">
          <div className="w-16 h-16 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center mb-5">
            <Radio className="w-7 h-7 text-purple-500/50" />
          </div>
          <h3 className="text-zinc-300 mb-2" style={{ fontWeight: 600 }}>{t("distro.emptyTitle")}</h3>
          <p className="text-sm text-zinc-600 mb-6 max-w-md">{t("distro.emptyDesc")}</p>
          <button
            onClick={() => navigate("/dashboard/new-project")}
            className="bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white px-6 py-2.5 rounded-xl text-sm transition-all shadow-lg shadow-purple-500/20"
            style={{ fontWeight: 600 }}
          >
            {t("dash.createFirst")}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6" {...pullHandlers}>
      <PullToRefreshIndicator pullY={pullY} isRefreshing={isRefreshing} />
      <LargeTitle title={t("distro.title")} subtitle={t("distro.subtitle")} />

      {/* ═══ Live Stats Bar ═══ */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: t("distro.channelsActive"), value: activeCount + completedCount, icon: Globe, color: "purple", sub: `${queuedCount} ${t("distro.queued").toLowerCase()}` },
          { label: t("distro.postsPublished"), value: completedCount, icon: Send, color: "emerald", sub: failedCount > 0 ? `${failedCount} ${t("distro.failed").toLowerCase()}` : `of ${queue.length}` },
          { label: t("distro.totalReach"), value: totalReach, icon: Eye, color: "cyan", sub: `avg ${avgEngagement} eng.` },
          { label: t("distro.tokensSpent"), value: totalTokens, icon: Zap, color: "amber", sub: `of ${queue.reduce((s, q) => s + q.channel.tokenCost, 0)}` },
        ].map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className="p-4 rounded-xl border border-white/5 bg-white/[0.02]"
          >
            <div className="flex items-center gap-2 mb-2">
              <div className={`w-7 h-7 rounded-lg bg-${stat.color}-500/10 flex items-center justify-center`}>
                <stat.icon className={`w-3.5 h-3.5 text-${stat.color}-400`} />
              </div>
              <span className="text-[11px] text-zinc-500" style={{ fontWeight: 500 }}>{stat.label}</span>
            </div>
            <div className="text-xl text-white" style={{ fontWeight: 700 }}>
              {stat.value > 999 ? <CountUp value={stat.value.toLocaleString()} duration={1500} /> : stat.value}
            </div>
            <div className="text-[10px] text-zinc-600 mt-0.5">{stat.sub}</div>
          </motion.div>
        ))}
      </div>

      {/* ═══ Controls ═══ */}
      <div className="flex items-center gap-3 flex-wrap">
        {!hasStarted ? (
          <button
            onClick={startDistribution}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white px-5 py-2.5 rounded-xl text-sm transition-all shadow-lg shadow-purple-500/20"
            style={{ fontWeight: 600 }}
          >
            <Play className="w-4 h-4" />
            {t("distro.startDistribution")}
          </button>
        ) : (
          <button
            onClick={togglePause}
            className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm transition-all ${
              isRunning
                ? "bg-amber-600 hover:bg-amber-500 text-white"
                : "bg-emerald-600 hover:bg-emerald-500 text-white"
            }`}
            style={{ fontWeight: 600 }}
          >
            {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            {isRunning ? t("distro.pause") : t("distro.resume")}
          </button>
        )}
        {failedCount > 0 && (
          <button
            onClick={retryFailed}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-white/10 text-sm text-zinc-400 hover:text-white hover:bg-white/5 transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            {t("distro.retry")} ({failedCount})
          </button>
        )}
        <button
          onClick={() => { if (intervalRef.current) clearInterval(intervalRef.current); setIsRunning(false); initQueue(); }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-white/10 text-sm text-zinc-500 hover:text-zinc-300 hover:bg-white/5 transition-all"
        >
          <RefreshCw className="w-4 h-4" />
          Reset
        </button>

        {/* Live indicator */}
        {isRunning && (
          <div className="ml-auto flex items-center gap-2">
            <div className="relative flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs text-emerald-400" style={{ fontWeight: 600 }}>LIVE</span>
            </div>
          </div>
        )}
      </div>

      {/* ═══ Channel Queue ═══ */}
      <div className="grid gap-4 lg:grid-cols-[1fr,380px]">
        {/* Queue list */}
        <div className="space-y-2">
          <h3 className="text-zinc-400 text-xs mb-2" style={{ fontWeight: 600 }}>{t("distro.queueTitle")} ({queue.length})</h3>
          <AnimatePresence>
            {queue.map((item, i) => (
              <QueueItemCard key={item.id} item={item} index={i} t={t} />
            ))}
          </AnimatePresence>
        </div>

        {/* Live log */}
        <div className="border border-white/5 rounded-xl bg-black/30 p-4 h-[600px] flex flex-col">
          <div className="flex items-center gap-2 mb-3 pb-3 border-b border-white/5">
            <Activity className="w-4 h-4 text-zinc-500" />
            <span className="text-xs text-zinc-400" style={{ fontWeight: 600 }}>{t("distro.liveLog")}</span>
            {isRunning && (
              <div className="ml-auto flex items-center gap-1">
                <Wifi className="w-3 h-3 text-emerald-500 animate-pulse" />
              </div>
            )}
          </div>
          <div className="flex-1 overflow-y-auto space-y-1 font-mono text-[11px] scrollbar-hide">
            {liveLog.length === 0 && (
              <div className="text-zinc-700 italic">Waiting for distribution to start…</div>
            )}
            {liveLog.map((entry, i) => (
              <div key={i} className="flex gap-2">
                <span className="text-zinc-700 shrink-0">{entry.time}</span>
                <span className={entry.color}>{entry.text}</span>
              </div>
            ))}
            <div ref={logEndRef} />
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── Queue Item Card ─── */
function QueueItemCard({ item, index, t }: { item: QueueItem; index: number; t: (k: string) => string }) {
  const statusConfig: Record<PostStatus, { icon: typeof Clock; color: string; bg: string; label: string }> = {
    queued:     { icon: Clock,         color: "text-zinc-500",   bg: "bg-zinc-500/10",    label: t("distro.queued") },
    generating: { icon: Sparkles,      color: "text-purple-400", bg: "bg-purple-500/10",  label: t("distro.generating") },
    posting:    { icon: Send,          color: "text-cyan-400",   bg: "bg-cyan-500/10",    label: t("distro.posting") },
    posted:     { icon: CheckCircle,   color: "text-emerald-400",bg: "bg-emerald-500/10", label: t("distro.posted") },
    failed:     { icon: AlertTriangle, color: "text-red-400",    bg: "bg-red-500/10",     label: t("distro.failed") },
    scheduled:  { icon: Clock,         color: "text-amber-400",  bg: "bg-amber-500/10",   label: t("distro.scheduled") },
  };

  const cfg = statusConfig[item.status];
  const StatusIcon = cfg.icon;
  const isActive = item.status === "generating" || item.status === "posting";

  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.02 }}
      className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
        isActive
          ? "border-purple-500/20 bg-purple-500/[0.03]"
          : item.status === "posted"
          ? "border-emerald-500/10 bg-emerald-500/[0.02]"
          : item.status === "failed"
          ? "border-red-500/10 bg-red-500/[0.02]"
          : "border-white/[0.03] bg-white/[0.01]"
      }`}
    >
      {/* Channel icon */}
      <div className={`w-9 h-9 rounded-lg bg-gradient-to-br ${item.channel.color} flex items-center justify-center text-white text-xs shrink-0`} style={{ fontWeight: 700 }}>
        {item.channel.icon}
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-[13px] text-white truncate" style={{ fontWeight: 600 }}>{item.channel.name}</span>
          <span className="text-[9px] text-zinc-600 bg-white/[0.04] px-1.5 py-0.5 rounded uppercase" style={{ fontWeight: 600 }}>
            {item.channel.tier}
          </span>
        </div>

        {/* Progress bar */}
        {isActive && (
          <div className="h-1 rounded-full bg-white/[0.04] overflow-hidden mb-1">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-purple-500 to-cyan-500"
              animate={{ width: `${item.progress}%` }}
              transition={{ type: "spring", stiffness: 100, damping: 20 }}
            />
          </div>
        )}

        <div className="flex items-center gap-3 text-[10px] text-zinc-600">
          <span className="flex items-center gap-0.5">
            <Eye className="w-3 h-3" />
            {item.reach ? item.reach.toLocaleString() : `~${item.channel.estReach.toLocaleString()}`}
          </span>
          <span className="flex items-center gap-0.5">
            <Zap className="w-3 h-3" />
            {item.channel.tokenCost} tokens
          </span>
          {item.engagement !== undefined && item.engagement > 0 && (
            <span className="flex items-center gap-0.5 text-emerald-500">
              <TrendingUp className="w-3 h-3" />
              {item.engagement}
            </span>
          )}
        </div>
      </div>

      {/* Status badge */}
      <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] ${cfg.bg} ${cfg.color} shrink-0`} style={{ fontWeight: 600 }}>
        {isActive ? (
          <Loader2 className="w-3 h-3 animate-spin" />
        ) : (
          <StatusIcon className="w-3 h-3" />
        )}
        <span className="hidden sm:inline">{cfg.label}</span>
      </div>
    </motion.div>
  );
}

export default DistributionLive;