import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { useNavigate, useLocation } from "react-router";
import {
  Play, X, ChevronRight, ChevronLeft, Sparkles, Package,
  Compass, Zap, TrendingUp, BarChart3, CalendarDays,
  Pause, SkipForward, RotateCcw,
} from "lucide-react";
import { useI18n } from "./i18n";

interface TourStep {
  path: string;
  titleKey: string;
  descKey: string;
  icon: typeof Sparkles;
  color: string;
  delay: number;
}

const TOUR_STEPS: TourStep[] = [
  { path: "/dashboard", titleKey: "tour.step0.title", descKey: "tour.step0.desc", icon: BarChart3, color: "purple", delay: 3000 },
  { path: "/dashboard/new-project", titleKey: "tour.step1.title", descKey: "tour.step1.desc", icon: Sparkles, color: "purple", delay: 4000 },
  { path: "/dashboard/package", titleKey: "tour.step2.title", descKey: "tour.step2.desc", icon: Package, color: "violet", delay: 4000 },
  { path: "/dashboard/growth", titleKey: "tour.step3.title", descKey: "tour.step3.desc", icon: Compass, color: "cyan", delay: 3500 },
  { path: "/dashboard/launch", titleKey: "tour.step4.title", descKey: "tour.step4.desc", icon: Zap, color: "emerald", delay: 4000 },
  { path: "/dashboard/tracker", titleKey: "tour.step5.title", descKey: "tour.step5.desc", icon: TrendingUp, color: "amber", delay: 3500 },
  { path: "/dashboard/analytics", titleKey: "tour.step6.title", descKey: "tour.step6.desc", icon: BarChart3, color: "cyan", delay: 3000 },
  { path: "/dashboard/content-plan", titleKey: "tour.step7.title", descKey: "tour.step7.desc", icon: CalendarDays, color: "violet", delay: 3000 },
];

const colorClasses: Record<string, { bg: string; text: string; border: string; glow: string }> = {
  purple: { bg: "bg-purple-500/15", text: "text-purple-400", border: "border-purple-500/30", glow: "shadow-purple-500/20" },
  violet: { bg: "bg-violet-500/15", text: "text-violet-400", border: "border-violet-500/30", glow: "shadow-violet-500/20" },
  cyan: { bg: "bg-cyan-500/15", text: "text-cyan-400", border: "border-cyan-500/30", glow: "shadow-cyan-500/20" },
  emerald: { bg: "bg-emerald-500/15", text: "text-emerald-400", border: "border-emerald-500/30", glow: "shadow-emerald-500/20" },
  amber: { bg: "bg-amber-500/15", text: "text-amber-400", border: "border-amber-500/30", glow: "shadow-amber-500/20" },
};

export function DemoTour() {
  const [active, setActive] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [paused, setPaused] = useState(false);
  const [progress, setProgress] = useState(0);
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useI18n();
  const timerRef = useRef<ReturnType<typeof setTimeout>>();
  const progressRef = useRef<ReturnType<typeof setInterval>>();
  const [showFab, setShowFab] = useState(true);

  // Hide FAB if not on a dashboard route
  useEffect(() => {
    setShowFab(location.pathname.startsWith("/dashboard"));
  }, [location.pathname]);

  const stopTour = useCallback(() => {
    setActive(false);
    setCurrentStep(0);
    setPaused(false);
    setProgress(0);
    clearTimeout(timerRef.current);
    clearInterval(progressRef.current);
  }, []);

  const goToStep = useCallback((stepIdx: number) => {
    if (stepIdx >= TOUR_STEPS.length) {
      stopTour();
      return;
    }
    setCurrentStep(stepIdx);
    setProgress(0);
    setPaused(false);
    const step = TOUR_STEPS[stepIdx];
    navigate(step.path);
  }, [navigate, stopTour]);

  // Auto-advance timer
  useEffect(() => {
    if (!active || paused) return;
    clearTimeout(timerRef.current);
    clearInterval(progressRef.current);

    const step = TOUR_STEPS[currentStep];
    const totalMs = step.delay;
    const tick = 50;
    let elapsed = 0;

    progressRef.current = setInterval(() => {
      elapsed += tick;
      setProgress(Math.min((elapsed / totalMs) * 100, 100));
    }, tick);

    timerRef.current = setTimeout(() => {
      clearInterval(progressRef.current);
      goToStep(currentStep + 1);
    }, totalMs);

    return () => {
      clearTimeout(timerRef.current);
      clearInterval(progressRef.current);
    };
  }, [active, currentStep, paused, goToStep]);

  const startTour = useCallback(() => {
    setActive(true);
    setCurrentStep(0);
    setProgress(0);
    setPaused(false);
    navigate(TOUR_STEPS[0].path);
  }, [navigate]);

  const togglePause = useCallback(() => {
    setPaused((p) => !p);
  }, []);

  if (!showFab) return null;

  const step = TOUR_STEPS[currentStep];
  const cc = colorClasses[step?.color || "purple"];

  return (
    <>
      {/* ─── FAB: Start Demo Tour ─── */}
      <AnimatePresence>
        {!active && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ type: "spring", stiffness: 400, damping: 25 }}
            onClick={startTour}
            className="fixed bottom-24 md:bottom-6 right-4 md:right-6 z-[60] flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-purple-600 to-violet-600 text-white shadow-xl shadow-purple-500/30 hover:shadow-purple-500/40 hover:from-purple-500 hover:to-violet-500 transition-all cursor-pointer fab-attention"
            aria-label="Start Demo Tour"
          >
            <Play className="w-4 h-4" />
            <span className="text-sm" style={{ fontWeight: 600 }}>Demo</span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* ─── Tour Overlay ─── */}
      <AnimatePresence>
        {active && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ type: "spring", stiffness: 400, damping: 30 }}
            className="fixed bottom-24 md:bottom-6 left-4 right-4 md:left-auto md:right-6 md:w-[380px] z-[60]"
          >
            <div className={`relative rounded-2xl border ${cc.border} bg-zinc-900/95 backdrop-blur-xl shadow-2xl ${cc.glow} overflow-hidden`}>
              {/* Progress bar */}
              <div className="h-0.5 bg-white/5">
                <motion.div
                  className={`h-full ${cc.bg.replace("/15", "")} opacity-60`}
                  style={{ width: `${progress}%`, background: step.color === "purple" ? "#8b5cf6" : step.color === "violet" ? "#8b5cf6" : step.color === "cyan" ? "#06b6d4" : step.color === "emerald" ? "#10b981" : "#f59e0b" }}
                  transition={{ duration: 0.05, ease: "linear" }}
                />
              </div>

              <div className="p-4">
                {/* Header */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className={`w-8 h-8 rounded-xl ${cc.bg} flex items-center justify-center`}>
                      <step.icon className={`w-4 h-4 ${cc.text}`} />
                    </div>
                    <div>
                      <div className="text-[10px] text-zinc-500 uppercase tracking-wider" style={{ fontWeight: 600 }}>
                        {t("tour.stepLabel")} {currentStep + 1}/{TOUR_STEPS.length}
                      </div>
                      <div className="text-sm text-white" style={{ fontWeight: 600 }}>
                        {t(step.titleKey)}
                      </div>
                    </div>
                  </div>
                  <button onClick={stopTour} className="w-7 h-7 rounded-lg flex items-center justify-center text-zinc-500 hover:text-zinc-300 hover:bg-white/5 transition-all cursor-pointer">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Description */}
                <p className="text-xs text-zinc-400 leading-relaxed mb-4">
                  {t(step.descKey)}
                </p>

                {/* Step indicators */}
                <div className="flex gap-1 mb-3">
                  {TOUR_STEPS.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => goToStep(i)}
                      className={`h-1 rounded-full transition-all cursor-pointer ${
                        i < currentStep ? "w-3 bg-emerald-500/50" :
                        i === currentStep ? "flex-1 bg-purple-500" :
                        "w-3 bg-white/[0.08]"
                      }`}
                    />
                  ))}
                </div>

                {/* Controls */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => goToStep(Math.max(0, currentStep - 1))}
                      disabled={currentStep === 0}
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-zinc-500 hover:text-zinc-300 hover:bg-white/5 disabled:opacity-30 transition-all cursor-pointer"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <button
                      onClick={togglePause}
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-zinc-500 hover:text-zinc-300 hover:bg-white/5 transition-all cursor-pointer"
                    >
                      {paused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      onClick={() => goToStep(currentStep + 1)}
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-zinc-500 hover:text-zinc-300 hover:bg-white/5 transition-all cursor-pointer"
                    >
                      {currentStep < TOUR_STEPS.length - 1 ? <ChevronRight className="w-4 h-4" /> : <RotateCcw className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                  {currentStep < TOUR_STEPS.length - 1 ? (
                    <button
                      onClick={() => goToStep(currentStep + 1)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs transition-colors cursor-pointer"
                      style={{ fontWeight: 500 }}
                    >
                      {t("tour.next")} <SkipForward className="w-3 h-3" />
                    </button>
                  ) : (
                    <button
                      onClick={stopTour}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs transition-colors cursor-pointer"
                      style={{ fontWeight: 500 }}
                    >
                      {t("tour.finish")}
                    </button>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}