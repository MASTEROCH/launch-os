import { useState, useMemo, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Sparkles, Copy, RefreshCw, Pencil, Clock, Check, Rocket,
  Radio, AlertCircle, Link2, CheckCircle, ExternalLink, Eye,
  X, Save, CalendarDays, MessageSquare, List, Bot, User,
  ChevronRight, CheckCircle2,
} from "lucide-react";
import { toast as sonnerToast } from "sonner";
import { useI18n } from "./i18n";
import { useNavigate } from "react-router";
import { loadProgress, updateProgress as updateUserProgress } from "./user-progress";
import { useDocumentTitle } from "./useDocumentTitle";
import { fireConfetti, dispatchBonusEvent } from "./Confetti";
import { LargeTitle } from "./LargeTitle";
import { usePullToRefresh } from "./usePullToRefresh";
import { PullToRefreshIndicator } from "./PullToRefreshIndicator";
import { copyToClipboard } from "./clipboard";
import { syncToContentPlan } from "./content-plan-bridge";

/* ─── Channel → Content template mapping ─── */
interface ContentTemplate {
  channelId: string;
  platform: string;
  icon: string;
  tier: "auto" | "assisted" | "managed";
  titleKey: string;
  generateContent: (name: string, desc: string) => string;
  regenerateVariants: ((name: string, desc: string) => string)[];
  estReach: number;
  tokenCost: number;
}

const allContentTemplates: ContentTemplate[] = [
  {
    channelId: "producthunt",
    platform: "Product Hunt",
    icon: "PH",
    tier: "auto",
    titleKey: "Product Hunt Launch",
    generateContent: (name, desc) => `${name} — ${desc || "The next big thing in productivity."}. Stop doing things manually. Let AI handle the heavy lifting. Built for founders and developers who ship fast.`,
    regenerateVariants: [
      (name, desc) => `Introducing ${name} — ${desc || "a smarter way to work"}. We built this because we were tired of tools that create more work than they save. ${name} uses AI to automate what used to take hours. Try it today and see the difference.`,
      (name) => `Meet ${name}. The tool that does what your team wished they had 6 months ago. AI-first. No setup. No learning curve. Just results. Join 2,000+ founders who've already made the switch.`,
      (name) => `Why we built ${name}: Because every existing solution in this space is stuck in 2019. We reimagined the entire workflow from scratch, powered by AI that actually understands context. Early adopters are seeing 3x productivity gains.`,
    ],
    estReach: 4200,
    tokenCost: 25,
  },
  {
    channelId: "twitter",
    platform: "Twitter / X",
    icon: "X",
    tier: "auto",
    titleKey: "Twitter Thread (5 tweets)",
    generateContent: (name) => `[Thread] I spent 6 months building ${name}. Here's why existing tools frustrated me and what I built instead:\n\n1/ Every tool in this space makes YOU do the heavy lifting. But what if AI could understand context and do it for you?\n\n2/ We trained a model on 1M+ workflows...`,
    regenerateVariants: [
      (name) => `[Thread] ${name} is live! Here's the 6-month journey from idea to launch:\n\n1/ It started with a frustration -- why do we still manually organize everything?\n\n2/ I talked to 100+ founders. They all had the same problem.\n\n3/ So I built an AI that learns YOUR patterns...`,
      (name) => `I just shipped ${name} and I'm terrified. [Thread]\n\n1/ Building in public means everyone sees your mistakes\n\n2/ But after 200 beta users and 40% productivity gains, I know this works\n\n3/ Here's what makes ${name} different from everything else...`,
    ],
    estReach: 3800,
    tokenCost: 15,
  },
  {
    channelId: "linkedin",
    platform: "LinkedIn",
    icon: "in",
    tier: "auto",
    titleKey: "LinkedIn Announcement",
    generateContent: (name) => `Excited to announce the launch of ${name} — a new approach that puts AI at the center. After 6 months of development and feedback from 200+ beta users, we're ready to share it with the world. Check it out and let me know what you think!`,
    regenerateVariants: [
      (name) => `Today marks a milestone: ${name} is officially live.\n\nWhat started as a side project has grown into something I'm truly proud of. We've helped 200+ beta users save an average of 5 hours per week.\n\nIf you're tired of tools that create more work than they save, give ${name} a try. I'd love your feedback.`,
    ],
    estReach: 2400,
    tokenCost: 15,
  },
  {
    channelId: "facebook",
    platform: "Facebook",
    icon: "f",
    tier: "auto",
    titleKey: "Facebook Post",
    generateContent: (name, desc) => `Just launched ${name}! ${desc || "An AI-powered solution"} that's changing how teams work. Check it out and share with anyone who might benefit!\n\n#launch #startup #ai #productivity`,
    regenerateVariants: [
      (name) => `Big news! ${name} is finally here!\n\nAfter months of building, testing, and iterating, we're thrilled to share our AI-powered tool with the world. It's designed to save you time and make your workflow smoother.\n\nTry it free -> [link]\n\n#launch #ai #productivity`,
    ],
    estReach: 1800,
    tokenCost: 10,
  },
  {
    channelId: "instagram",
    platform: "Instagram",
    icon: "IG",
    tier: "auto",
    titleKey: "Instagram Carousel",
    generateContent: (name) => `Slide 1: Introducing ${name}\nSlide 2: The Problem -- Why existing tools fall short\nSlide 3: The Solution -- How AI changes everything\nSlide 4: Key Features (3 highlights)\nSlide 5: CTA -- Try it free today\n\nCaption: Ready to stop doing busywork?...`,
    regenerateVariants: [
      (name) => `Slide 1: ${name} is HERE\nSlide 2: "I was spending 10 hours/week on..." (relatable pain)\nSlide 3: Now AI does it in minutes\nSlide 4: Real results from beta users\nSlide 5: Link in bio -- try it free\n\nCaption: The future of productivity is here.`,
    ],
    estReach: 1200,
    tokenCost: 10,
  },
  {
    channelId: "youtube",
    platform: "YouTube",
    icon: "YT",
    tier: "auto",
    titleKey: "YouTube Short",
    generateContent: (name) => `Title: ${name} in 60 Seconds -- Why I Built This\nHook: "What if AI could handle your entire workflow?"\nScript outline: Problem > Solution > Demo > CTA\nThumbnail text: "This changes everything"\nTags: AI, productivity, automation, startup`,
    regenerateVariants: [
      (name) => `Title: I Built an AI That Replaces 5 Tools -- ${name}\nHook: "You're wasting 10 hours a week. Here's proof."\nScript: Show old workflow (painful) > Show ${name} (fast) > Reaction > CTA\nThumbnail: Split screen before/after\nTags: AI tools, workflow, automation`,
    ],
    estReach: 2100,
    tokenCost: 20,
  },
  {
    channelId: "reddit",
    platform: "Reddit",
    icon: "R",
    tier: "assisted",
    titleKey: "Reddit Post — r/SaaS, r/startups",
    generateContent: (name, desc) => `Hey r/SaaS! I built ${name} — ${desc || "an AI-powered tool"} that actually understands how developers work. It auto-categorizes tasks, suggests priorities based on deadlines, and creates daily focus lists. Been using it for 3 months internally and our team productivity went up 40%. Would love your feedback!`,
    regenerateVariants: [
      (name) => `After burning out on manual workflows, I built ${name}. It's an AI tool that learns how YOU work and automates the boring stuff. No templates. No setup wizards. It just watches, learns, and starts helping.\n\nOpen beta is live — would love brutally honest feedback from this community.`,
    ],
    estReach: 5200,
    tokenCost: 20,
  },
  {
    channelId: "hackernews",
    platform: "Hacker News",
    icon: "Y",
    tier: "assisted",
    titleKey: "Show HN Post",
    generateContent: (name, desc) => `Show HN: ${name} — ${desc || "AI-powered productivity tool"}\n\nHey HN, I've been working on ${name} for the past 6 months. The core idea: instead of you organizing work, AI does it based on context, deadlines, and your patterns.\n\nTech stack: React, Python, GPT-4. Would love technical feedback on the approach.`,
    regenerateVariants: [
      (name) => `Show HN: ${name} — Context-aware AI that organizes your work\n\nI got frustrated with every productivity tool requiring ME to be organized first. So I built ${name}: it watches your activity across tools (with permission), builds a context model, and suggests daily priorities.\n\nNo rules to configure. No templates. It learns.\n\nTech: React + FastAPI + fine-tuned LLM. Feedback welcome.`,
    ],
    estReach: 6800,
    tokenCost: 20,
  },
  {
    channelId: "indiehackers",
    platform: "Indie Hackers",
    icon: "IH",
    tier: "assisted",
    titleKey: "Indie Hackers Milestone",
    generateContent: (name) => `Just launched ${name}!\n\nAfter 6 months of building in public, I'm finally launching. Here's what I learned:\n\n1. Validation before building saved me months\n2. Early beta users shaped the product direction\n3. Distribution > Features\n\nWould love your feedback and support!`,
    regenerateVariants: [
      (name) => `Launch day! ${name} is live!\n\nRevenue so far: $0 (but 200 beta users!)\n\nHere's my honest breakdown:\n- Total build time: 6 months\n- Biggest mistake: building features nobody asked for\n- Best decision: talking to users every single week\n\nAMA + would love your feedback!`,
    ],
    estReach: 2800,
    tokenCost: 15,
  },
  {
    channelId: "telegram",
    platform: "Telegram",
    icon: "TG",
    tier: "assisted",
    titleKey: "Telegram Channel Post",
    generateContent: (name, desc) => `[NEW] ${name}\n\n${desc || "AI-powered solution for modern teams"}\n\nKey features:\n- Smart automation\n- AI-powered insights\n- One-click setup\n\nTry it free -> [link]\n\n#startup #launch #ai`,
    regenerateVariants: [
      (name) => `${name} -- now live!\n\nWhy it matters:\n-> Saves 5+ hours/week\n-> No learning curve\n-> Works with your existing tools\n\nEarly bird pricing available for the first 100 users.\n\n[link]\n\n#ai #productivity #launch`,
    ],
    estReach: 1500,
    tokenCost: 10,
  },
  {
    channelId: "devto",
    platform: "Dev.to",
    icon: "DEV",
    tier: "assisted",
    titleKey: "Dev.to Technical Article",
    generateContent: (name) => `# How I Built ${name}: Technical Deep Dive\n\n## The Problem\nExisting tools in this space don't leverage AI effectively...\n\n## Architecture\nReact frontend + Python backend + GPT-4 for core AI...\n\n## Key Technical Decisions\n1. Why we chose streaming over batch processing\n2. Fine-tuning vs prompt engineering\n3. Real-time sync architecture`,
    regenerateVariants: [
      (name) => `# Building ${name}: Lessons From Fine-Tuning an LLM for Productivity\n\n## Why Generic AI Fails for Workflow Automation\nOut-of-the-box LLMs don't understand YOUR work patterns...\n\n## Our Approach: Context-First AI\nInstead of generic prompts, we built a context layer...\n\n## Results\n- 40% productivity gain in beta\n- 92% accuracy on task categorization\n- <200ms response time`,
    ],
    estReach: 3200,
    tokenCost: 15,
  },
  {
    channelId: "email-pr",
    platform: "Email PR",
    icon: "PR",
    tier: "managed",
    titleKey: "Press Outreach Template",
    generateContent: (name) => `Subject: ${name} — Redefining Productivity with AI\n\nHi [Name],\n\nI'm reaching out because I noticed your coverage of AI productivity tools. We just launched ${name}, which uses AI to automate task organization for developers and founders.\n\nKey highlights:\n• 40% productivity improvement in beta\n• 200+ beta users\n• Unique AI approach\n\nWould love to schedule a quick demo. Available this week?`,
    regenerateVariants: [
      (name) => `Subject: Quick question about covering ${name}\n\nHi [Name],\n\nI follow your newsletter and noticed you covered [similar tool] last month. We just launched ${name}, which takes a fundamentally different approach — instead of configuring rules, our AI learns from user behavior.\n\nEarly data:\n• 40% time savings (avg across 200 beta users)\n• 4.8/5 satisfaction score\n\n5-minute demo? Happy to work around your schedule.`,
    ],
    estReach: 8500,
    tokenCost: 30,
  },
  {
    channelId: "catalogs",
    platform: "Startup Catalogs",
    icon: "CT",
    tier: "managed",
    titleKey: "Directory Submissions (80+)",
    generateContent: (name, desc) => `Product: ${name}\nTagline: ${desc || "AI-powered productivity for modern teams"}\nCategory: AI / Productivity / SaaS\n\nAuto-submitting to:\n• BetaList\n• SaaSHub\n• AlternativeTo\n• There's An AI For That\n• Futurepedia\n• SideProjectors\n• ... and 74 more directories`,
    regenerateVariants: [
      (name, desc) => `Product: ${name}\nTagline: ${desc || "The AI-first productivity platform"}\nCategory: AI / Productivity / Developer Tools\n\nSubmission batch 1 (priority):\n• Product Hunt, BetaList, SaaSHub (high DA)\n\nBatch 2 (directories):\n• AlternativeTo, G2, Capterra, GetApp\n\nBatch 3 (AI-specific):\n• There's An AI For That, Futurepedia, AI Tool Directory\n\nBatch 4 (startup):\n• SideProjectors, BetaPage, StartupBase, Launching Next\n\nTotal: 84 directories, ETA: 48 hours`,
    ],
    estReach: 12000,
    tokenCost: 40,
  },
  {
    channelId: "seo",
    platform: "SEO Engine",
    icon: "SEO",
    tier: "managed",
    titleKey: "SEO Landing Page & Blog",
    generateContent: (name) => `H1: AI-Powered ${name} for Modern Teams\nH2: Stop Working Harder. Start Working Smarter.\n\nSEO Strategy:\n• 12 target keywords identified\n• 3 blog posts scheduled\n• Backlink outreach to 40 sites\n• Schema markup optimization\n• Meta descriptions for 5 pages`,
    regenerateVariants: [
      (name) => `H1: ${name} — AI That Actually Understands How You Work\nH2: Join 2,000+ Founders Who Save 5 Hours Every Week\n\nKeyword Strategy (refreshed):\n• Primary: "${name.toLowerCase()} ai tool" (2.4K vol)\n• Secondary: "ai productivity tool" (8.1K vol)\n• Long-tail: "automate workflow with ai" (1.2K vol)\n\nContent Calendar:\n• Week 1: "Why Traditional Productivity Tools Fail" (blog)\n• Week 2: "${name} vs [Competitor]" (comparison page)\n• Week 3: "How AI Saves 5 Hours/Week" (case study)`,
    ],
    estReach: 15000,
    tokenCost: 35,
  },
  {
    channelId: "newsletters",
    platform: "Newsletter Mentions",
    icon: "NL",
    tier: "managed",
    titleKey: "Newsletter Pitches (200+)",
    generateContent: (name) => `Pitching ${name} to:\n\n• TLDR Newsletter (500K subscribers)\n• Morning Brew Tech (250K)\n• Ben's Bites (100K)\n• The Hustle (2.5M)\n• Product Hunt Daily (500K)\n• Hacker Newsletter (60K)\n\nPersonalized pitch templates created for each newsletter's tone and audience. Scheduled across 2 weeks for maximum coverage.`,
    regenerateVariants: [
      (name) => `Newsletter outreach strategy for ${name}:\n\nTier 1 — High priority (personalized emails):\n• TLDR (500K) — AI tools segment\n• Ben's Bites (100K) — perfect audience fit\n• The Rundown AI (300K) — new tool spotlight\n\nTier 2 — Medium priority:\n• Morning Brew (250K) — tech section\n Hacker Newsletter (60K) — Show HN feature\n• Changelog (50K) — developer tools\n\nTier 3 — Long tail (180+ newsletters):\nAuto-personalized pitches via AI. ETA: rolling over 2 weeks.`,
    ],
    estReach: 35000,
    tokenCost: 50,
  },
  {
    channelId: "forums",
    platform: "Niche Forums",
    icon: "FM",
    tier: "managed",
    titleKey: "Forum Posts (300+ forums)",
    generateContent: (name) => `AI is discovering relevant forums for ${name}:\n\n[done] Identified 312 relevant forums\n[done] Tone-adapted posts generated\n[done] Community rules compliance checked\n[done] Posting schedule optimized\n\nCategories: Developer tools, Productivity, AI/ML, SaaS, Startup communities, Remote work, Tech news`,
    regenerateVariants: [
      (name) => `Forum distribution plan for ${name} (refreshed):\n\nAnalysis complete:\n- 327 forums identified (+15 new)\n- 89% relevance score (avg)\n- 12 flagged as "no self-promo" -> value-first approach\n\nPosting strategy:\n- Week 1: Top 50 forums (highest engagement)\n- Week 2: Mid-tier forums (niche communities)\n- Week 3: Long-tail + follow-up engagement\n\nTone profiles: Casual tech, Professional, Developer-focused, Startup founder`,
    ],
    estReach: 18000,
    tokenCost: 45,
  },
];

/* ─── Content Card type ─── */
interface ContentCard {
  id: string;
  platform: string;
  title: string;
  content: string;
  status: "generated" | "scheduled" | "published";
  icon: string;
  tier: "auto" | "assisted" | "managed";
  estReach: number;
  tokenCost: number;
  scheduledDate?: string;
  variantIndex: number;
}

export function LaunchEngine() {
  const { t } = useI18n();
  useDocumentTitle(t("sidebar.launchEngine"));
  const navigate = useNavigate();
  const progress = loadProgress();

  // ─── Loading skeleton ───
  const [loading, setLoading] = useState(true);

  // ─── Pull to refresh ───
  const { pullY, isRefreshing, handlers: pullHandlers } = usePullToRefresh(
    () => new Promise<void>((resolve) => setTimeout(resolve, 1200))
  );

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 700);
    return () => clearTimeout(timer);
  }, []);

  // ─── First-visit onboarding ───
  const [onboardStep, setOnboardStep] = useState<number>(() => {
    try {
      if (localStorage.getItem("launchapp_engine_visited")) return -1;
      return 0;
    } catch { return -1; }
  });
  const dismissOnboard = () => {
    setOnboardStep(-1);
    try { localStorage.setItem("launchapp_engine_visited", "1"); } catch {}
  };
  const nextOnboard = () => {
    if (onboardStep < 1) setOnboardStep(onboardStep + 1);
    else dismissOnboard();
  };

  // Load connected channels from localStorage
  const connectedChannelIds = useMemo(() => {
    try {
      const raw = localStorage.getItem("launchapp_channels");
      if (!raw) return [] as string[];
      const state = JSON.parse(raw) as Record<string, string>;
      return Object.entries(state)
        .filter(([_, status]) => status === "connected" || status === "active")
        .map(([id]) => id);
    } catch { return [] as string[]; }
  }, []);

  const channelNames: Record<string, string> = {
    twitter: "Twitter/X", linkedin: "LinkedIn", facebook: "Facebook",
    instagram: "Instagram", producthunt: "Product Hunt", youtube: "YouTube",
    reddit: "Reddit", hackernews: "Hacker News", indiehackers: "Indie Hackers",
    telegram: "Telegram", devto: "Dev.to",
    "email-pr": "Email PR", catalogs: "Catalogs", seo: "SEO",
    newsletters: "Newsletters", forums: "Forums",
  };

  const managedIds = ["email-pr", "catalogs", "seo", "newsletters", "forums"];
  const activeIds = [...new Set([...connectedChannelIds, ...managedIds])];
  const totalActive = activeIds.length;

  // Generate dynamic content cards based on connected channels
  const [cards, setCards] = useState<ContentCard[]>(() => {
    const name = progress.projectName || "AI Task Manager";
    const desc = progress.projectDescription || "";
    return allContentTemplates
      .filter((tpl) => activeIds.includes(tpl.channelId))
      .map((tpl, i) => ({
        id: tpl.channelId,
        platform: tpl.platform,
        title: tpl.titleKey,
        content: tpl.generateContent(name, desc),
        status: (i === 0 ? "scheduled" : "generated") as ContentCard["status"],
        icon: tpl.icon,
        tier: tpl.tier,
        estReach: tpl.estReach,
        tokenCost: tpl.tokenCost,
        variantIndex: -1,
      }));
  });

  const [copied, setCopied] = useState<string | null>(null);
  const [launching, setLaunching] = useState(false);

  // ─── Chat mode state ───
  const [chatMode, setChatMode] = useState(() => {
    try { return localStorage.getItem("launchapp_engine_chat_mode") === "1"; } catch { return false; }
  });
  const [chatRevealedCount, setChatRevealedCount] = useState(0);
  const [chatApproved, setChatApproved] = useState<Set<string>>(new Set());
  const [chatTypingCard, setChatTypingCard] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const toggleChatMode = () => {
    const next = !chatMode;
    setChatMode(next);
    try { localStorage.setItem("launchapp_engine_chat_mode", next ? "1" : "0"); } catch {}
    if (next) {
      // Start chat flow
      setChatRevealedCount(0);
      setChatApproved(new Set());
      // Reveal first card after greeting
      setTimeout(() => {
        setChatTypingCard(true);
        setTimeout(() => {
          setChatTypingCard(false);
          setChatRevealedCount(1);
        }, 1200);
      }, 800);
    }
  };

  const chatApproveCard = (cardId: string) => {
    setChatApproved(prev => {
      const next = new Set(prev);
      next.add(cardId);
      return next;
    });
    // Reveal next card after approval animation
    const currentIdx = cards.findIndex(c => c.id === cardId);
    if (currentIdx < cards.length - 1) {
      setTimeout(() => {
        setChatTypingCard(true);
        setTimeout(() => {
          setChatTypingCard(false);
          setChatRevealedCount(prev => prev + 1);
        }, 1000);
      }, 600);
    }
    // Auto-scroll
    setTimeout(() => chatEndRef.current?.scrollIntoView({ behavior: "smooth" }), 200);
  };

  // Initialize chat mode on mount if toggled on
  useEffect(() => {
    if (chatMode && chatRevealedCount === 0 && cards.length > 0) {
      setTimeout(() => {
        setChatTypingCard(true);
        setTimeout(() => {
          setChatTypingCard(false);
          setChatRevealedCount(1);
        }, 1200);
      }, 800);
    }
  }, [chatMode]); // eslint-disable-line react-hooks/exhaustive-deps

  // ─── Editing state ───
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState("");
  const editRef = useRef<HTMLTextAreaElement>(null);

  // ─── Regenerate typing state ───
  const [regeneratingId, setRegeneratingId] = useState<string | null>(null);
  const [typingText, setTypingText] = useState("");
  const typingRef = useRef<{ cancel: boolean }>({ cancel: false });

  // ─── Schedule state ───
  const [schedulingId, setSchedulingId] = useState<string | null>(null);
  const [scheduleDate, setScheduleDate] = useState("");
  const [scheduleTime, setScheduleTime] = useState("09:00");

  const totalReach = cards.reduce((sum, c) => sum + c.estReach, 0);
  const totalTokens = cards.reduce((sum, c) => sum + c.tokenCost, 0);

  const handleCopy = (id: string, content: string) => {
    copyToClipboard(content);
    setCopied(id);
    sonnerToast.success(t("engine.copied"));
    setTimeout(() => setCopied(null), 2000);
  };

  // ─── Edit handlers ───
  const startEdit = (card: ContentCard) => {
    setEditingId(card.id);
    setEditContent(card.content);
    setTimeout(() => editRef.current?.focus(), 50);
  };

  const saveEdit = (id: string) => {
    setCards((prev) => prev.map((c) => c.id === id ? { ...c, content: editContent } : c));
    setEditingId(null);
    sonnerToast.success(t("engine.saved"));
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditContent("");
  };

  // ─── Regenerate with typing effect ───
  const handleRegenerate = useCallback((cardId: string) => {
    const tpl = allContentTemplates.find((t) => t.channelId === cardId);
    if (!tpl || tpl.regenerateVariants.length === 0) return;

    const card = cards.find((c) => c.id === cardId);
    if (!card) return;

    const nextIdx = (card.variantIndex + 1) % tpl.regenerateVariants.length;
    const name = progress.projectName || "AI Task Manager";
    const desc = progress.projectDescription || "";
    const newContent = tpl.regenerateVariants[nextIdx](name, desc);

    // Start typing animation
    setRegeneratingId(cardId);
    setTypingText("");
    typingRef.current = { cancel: false };

    let i = 0;
    const typeChar = () => {
      if (typingRef.current.cancel) return;
      if (i < newContent.length) {
        // Type multiple chars at once for speed
        const chunk = Math.min(3, newContent.length - i);
        setTypingText(newContent.slice(0, i + chunk));
        i += chunk;
        setTimeout(typeChar, 12 + Math.random() * 18);
      } else {
        // Done typing
        setCards((prev) => prev.map((c) => c.id === cardId ? { ...c, content: newContent, variantIndex: nextIdx } : c));
        setRegeneratingId(null);
        setTypingText("");
      }
    };

    // Small delay before starting to type
    setTimeout(typeChar, 400);
  }, [cards, progress.projectName, progress.projectDescription]);

  // ─── Schedule handlers ───
  const openSchedule = (id: string) => {
    setSchedulingId(id);
    // Default to tomorrow
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    setScheduleDate(tomorrow.toISOString().split("T")[0]);
    setScheduleTime("09:00");
  };

  const confirmSchedule = () => {
    if (!schedulingId || !scheduleDate) return;
    const dateStr = `${scheduleDate} ${scheduleTime}`;
    setCards((prev) => prev.map((c) => c.id === schedulingId ? { ...c, status: "scheduled" as const, scheduledDate: dateStr } : c));
    setSchedulingId(null);
    sonnerToast.success(`${t("engine.scheduledFor")} ${dateStr}`);
  };

  const [launchPhase, setLaunchPhase] = useState<"idle" | "countdown" | "ignition" | "liftoff">("idle");
  
  const handleLaunch = () => {
    setLaunching(true);
    setLaunchPhase("countdown");
    
    // Phase 1: Countdown (1.5s)
    setTimeout(() => setLaunchPhase("ignition"), 1500);
    
    // Phase 2: Ignition — cards start flipping to published (1.5s)
    setTimeout(() => {
      setLaunchPhase("liftoff");
      // Stagger card publishing
      cards.forEach((_, i) => {
        setTimeout(() => {
          setCards((p) => p.map((c, j) => j <= i ? { ...c, status: "published" as const } : c));
        }, i * 200);
      });
    }, 3000);
    
    // Phase 3: Liftoff — confetti + redirect
    setTimeout(() => {
      setLaunching(false);
      setLaunchPhase("idle");
      updateUserProgress({ launched: true, launchDay: 1 });
      fireConfetti();
      // Double confetti burst
      setTimeout(() => fireConfetti(), 400);
      // Auto-sync to content plan
      syncToContentPlan(cards.map(c => ({ ...c, status: "published" as const })));
      dispatchBonusEvent({ message: "Launch started! Distribution is live.", type: "launch" });
      setTimeout(() => navigate("/dashboard/tracker"), 800);
    }, 3000 + cards.length * 200 + 500);
  };

  const statusColors: Record<string, string> = {
    generated: "bg-amber-500/10 text-amber-400",
    scheduled: "bg-cyan-500/10 text-cyan-400",
    published: "bg-emerald-500/10 text-emerald-400",
  };
  const statusLabels: Record<string, string> = {
    generated: t("engine.generated"),
    scheduled: t("engine.scheduled"),
    published: t("engine.published"),
  };
  const tierBadge: Record<string, { cls: string; label: string }> = {
    auto: { cls: "bg-purple-500/10 text-purple-400 border-purple-500/20", label: t("engine.autoPost") },
    assisted: { cls: "bg-amber-500/10 text-amber-400 border-amber-500/20", label: t("engine.assisted") },
    managed: { cls: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20", label: t("engine.managed") },
  };

  if (loading) {
    return (
      <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-6 animate-pulse">
        {/* Header skeleton */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="h-7 w-52 rounded-lg bg-white/[0.06]" />
            <div className="h-4 w-72 rounded-lg bg-white/[0.04] mt-2" />
          </div>
          <div className="h-12 w-40 rounded-xl bg-white/[0.06]" />
        </div>
        {/* Stats skeleton */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="p-4 rounded-xl border border-white/[0.03] bg-white/[0.01]">
              <div className="h-6 w-10 rounded bg-white/[0.06] mb-1" />
              <div className="h-3 w-20 rounded bg-white/[0.04]" />
            </div>
          ))}
        </div>
        {/* Channel bar skeleton */}
        <div className="p-4 rounded-xl border border-white/[0.03] bg-white/[0.01]">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-4 h-4 rounded bg-white/[0.06]" />
            <div className="h-4 w-32 rounded bg-white/[0.06]" />
          </div>
          <div className="flex flex-wrap gap-2">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-6 w-20 rounded-full bg-white/[0.05]" />
            ))}
          </div>
        </div>
        {/* Content cards skeleton */}
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="p-5 rounded-xl border border-white/[0.03] bg-white/[0.01]">
              <div className="flex items-start gap-3 mb-3">
                <div className="w-9 h-9 rounded-lg bg-white/[0.05]" />
                <div className="flex-1">
                  <div className="h-4 w-40 rounded bg-white/[0.06] mb-1.5" />
                  <div className="h-3 w-24 rounded bg-white/[0.04]" />
                </div>
                <div className="h-5 w-16 rounded-full bg-white/[0.05]" />
              </div>
              <div className="h-3 w-full rounded bg-white/[0.04] mb-2" />
              <div className="h-3 w-3/4 rounded bg-white/[0.03] mb-2" />
              <div className="h-3 w-1/2 rounded bg-white/[0.03] mb-4" />
              <div className="flex gap-2">
                {[1, 2, 3, 4].map((j) => (
                  <div key={j} className="h-7 w-20 rounded-lg bg-white/[0.04]" />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-6" {...pullHandlers}>
      <PullToRefreshIndicator pullY={pullY} isRefreshing={isRefreshing} />
      {/* ─── Onboarding overlay ─── */}
      <AnimatePresence>
        {onboardStep >= 0 && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 z-40"
            onClick={dismissOnboard}
          />
        )}
      </AnimatePresence>

      {/* Header — iOS Large Title */}
      <LargeTitle
        title={t("engine.title")}
        subtitle={t("engine.subtitle")}
        badge={
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs bg-purple-500/10 text-purple-400 px-2 py-0.5 rounded-full" style={{ fontWeight: 600 }}>{progress.projectName || "AI Task Manager"}</span>
            {/* Chat / Classic mode toggle */}
            <button
              onClick={toggleChatMode}
              className={`inline-flex items-center gap-1.5 text-[11px] px-2.5 py-1 rounded-full border transition-all ${
                chatMode
                  ? "bg-cyan-500/10 text-cyan-400 border-cyan-500/20"
                  : "bg-white/[0.03] text-zinc-500 border-white/5 hover:text-zinc-400 hover:border-white/10"
              }`}
              style={{ fontWeight: 500 }}
            >
              {chatMode ? <><MessageSquare className="w-3 h-3" />{t("engine.chatMode")}</> : <><List className="w-3 h-3" />{t("engine.classicMode")}</>}
            </button>
          </div>
        }
        actions={
          <div className="relative">
            <motion.button
              onClick={handleLaunch}
              disabled={launching || cards.length === 0}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className={`relative inline-flex items-center gap-2 text-white px-6 py-3 rounded-xl text-sm transition-all overflow-hidden ${
                launching
                  ? "bg-gradient-to-r from-amber-600 to-orange-600 shadow-lg shadow-orange-500/30"
                  : "bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 shadow-lg shadow-purple-500/20"
              } disabled:opacity-50 ${onboardStep === 1 ? "relative z-50 ring-2 ring-purple-400/50 ring-offset-2 ring-offset-zinc-950" : ""}`}
              style={{ fontWeight: 600 }}
            >
              {/* Pulse ring when ready */}
              {!launching && cards.length > 0 && (
                <motion.div
                  className="absolute inset-0 rounded-xl border-2 border-purple-400/50"
                  animate={{ scale: [1, 1.15, 1], opacity: [0.5, 0, 0.5] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              )}
              {launchPhase === "countdown" && (
                <><motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 0.8, ease: "linear" }}><RefreshCw className="w-4 h-4" /></motion.div>{t("engine.preparing") || "Preparing..."}</>
              )}
              {launchPhase === "ignition" && (
                <><motion.div animate={{ scale: [1, 1.3, 1] }} transition={{ repeat: Infinity, duration: 0.4 }}><Sparkles className="w-4 h-4" /></motion.div>{t("engine.ignition") || "Ignition!"}</>
              )}
              {launchPhase === "liftoff" && (
                <><motion.div animate={{ y: [0, -3, 0] }} transition={{ repeat: Infinity, duration: 0.3 }}><Rocket className="w-4 h-4" /></motion.div>{t("engine.distributing")}</>
              )}
              {launchPhase === "idle" && (
                <><Rocket className="w-4 h-4" />{t("engine.launchAll")}</>
              )}
            </motion.button>
          </div>
        }
      />
      {/* Tour tooltips — fixed centered modal */}
      <AnimatePresence>
        {onboardStep >= 0 && (
          <motion.div
            key={`engine-tour-${onboardStep}`}
            initial={{ opacity: 0, y: 10, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.96 }}
            className="fixed z-[100] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90vw] max-w-sm"
          >
            <div className="relative p-5 rounded-2xl bg-zinc-900 border border-purple-500/30 shadow-2xl shadow-purple-500/10">
              <button onClick={dismissOnboard} className="absolute top-3 right-3 text-zinc-600 hover:text-zinc-400 transition-colors"><X className="w-3.5 h-3.5" /></button>
              <div className="text-xs text-purple-400 mb-2" style={{ fontWeight: 600 }}>{onboardStep + 1}/2</div>
              <div className="text-sm text-white mb-1" style={{ fontWeight: 600 }}>
                {onboardStep === 0 ? t("onboard.engine.title") : t("onboard.engine.title2")}
              </div>
              <p className="text-xs text-zinc-400 mb-4 leading-relaxed">
                {onboardStep === 0 ? t("onboard.engine.desc") : t("onboard.engine.desc2")}
              </p>
              <div className="flex items-center gap-1.5 mb-4">
                {[0, 1].map((i) => (
                  <div key={i} className={`h-1 rounded-full transition-all ${i < onboardStep ? "w-5 bg-purple-500/50" : i === onboardStep ? "w-7 bg-purple-500" : "w-3 bg-white/[0.08]"}`} />
                ))}
              </div>
              <div className="flex items-center justify-between">
                <button onClick={dismissOnboard} className="text-xs text-zinc-600 hover:text-zinc-400 transition-colors">{t("onboard.skip")}</button>
                <button onClick={nextOnboard} className="text-xs text-white bg-purple-600 hover:bg-purple-500 px-4 py-2 rounded-lg transition-colors">
                  {onboardStep < 1 ? <>{t("onboard.next")} <ChevronRight className="w-3 h-3 inline" /></> : <>{t("onboard.gotIt")} <Check className="w-3 h-3 inline" /></>}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── Launch Countdown Overlay ─── */}
      <AnimatePresence>
        {launchPhase !== "idle" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 flex items-center justify-center bg-black/60 backdrop-blur-sm pointer-events-none"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 1.2, opacity: 0 }}
              className="text-center"
            >
              {launchPhase === "countdown" && (
                <>
                  <motion.div
                    animate={{ scale: [1, 1.2, 1], opacity: [0.7, 1, 0.7] }}
                    transition={{ duration: 1, repeat: Infinity }}
                    className="text-6xl mb-4"
                  ><Rocket className="w-16 h-16 text-purple-400" /></motion.div>
                  <div className="text-2xl text-white mb-2" style={{ fontWeight: 700 }}>
                    {t("engine.preparingLaunch") || "Preparing launch..."}
                  </div>
                  <div className="text-sm text-zinc-400">
                    {t("engine.generatingContent") || "Generating content for"} {cards.length} {t("engine.channelsLabel")}
                  </div>
                </>
              )}
              {launchPhase === "ignition" && (
                <>
                  <motion.div
                    animate={{ rotate: [0, 10, -10, 0], scale: [1, 1.3, 1] }}
                    transition={{ duration: 0.5, repeat: Infinity }}
                    className="text-7xl mb-4"
                  ><Sparkles className="w-20 h-20 text-amber-400" /></motion.div>
                  <div className="text-2xl text-white mb-2" style={{ fontWeight: 700 }}>
                    {t("engine.ignitionPhase") || "Ignition!"}
                  </div>
                  <div className="text-sm text-amber-400" style={{ fontWeight: 600 }}>
                    {t("engine.publishingNow") || "Publishing to all channels..."}
                  </div>
                </>
              )}
              {launchPhase === "liftoff" && (
                <>
                  <motion.div
                    animate={{ y: [0, -20, 0] }}
                    transition={{ duration: 0.6, repeat: Infinity }}
                    className="text-7xl mb-4"
                  ><Rocket className="w-20 h-20 text-emerald-400" /></motion.div>
                  <div className="text-2xl text-white mb-2" style={{ fontWeight: 700 }}>
                    {t("engine.liftoff") || "Liftoff!"}
                  </div>
                  <div className="text-sm text-emerald-400" style={{ fontWeight: 600 }}>
                    {t("engine.distributionLive") || "Distribution is live across all channels!"}
                  </div>
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: "100%" }}
                    transition={{ duration: 2, ease: "linear" }}
                    className="h-1 bg-gradient-to-r from-purple-500 via-violet-500 to-emerald-500 rounded-full mt-4 mx-auto max-w-xs"
                  />
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: t("engine.contentPieces"), value: cards.length.toString() },
          { label: t("engine.targetChannels"), value: totalActive.toString() },
          { label: t("engine.estReach"), value: totalReach >= 1000 ? `${(totalReach / 1000).toFixed(1)}K` : totalReach.toString() },
          { label: t("engine.tokensUsed"), value: totalTokens.toString() },
        ].map((s) => (
          <div key={s.label} className="p-4 rounded-xl border border-white/5 bg-white/[0.02]">
            <div className="text-lg text-white" style={{ fontWeight: 700 }}>{s.value}</div>
            <div className="text-xs text-zinc-500">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Channel Status Bar */}
      <div className="p-4 rounded-xl border border-white/5 bg-white/[0.02]">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-white" style={{ fontWeight: 600 }}>{t("engine.channelStatus")}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const result = syncToContentPlan(cards);
                if (result.added > 0 || result.updated > 0) {
                  sonnerToast.success(t("engine.syncedToPlan"), { description: `+${result.added} new, ${result.updated} updated` });
                } else {
                  sonnerToast.info(t("engine.alreadySynced"));
                }
              }}
              className="inline-flex items-center gap-1.5 text-[11px] text-cyan-400 hover:text-cyan-300 px-2.5 py-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/15 border border-cyan-500/15 transition-all active:scale-95"
            >
              <CalendarDays className="w-3 h-3" />{t("engine.syncToPlan")}
            </button>
            <span className="text-xs text-zinc-500">{t("engine.readyToLaunch")} {totalActive} {t("engine.channelsLabel")}</span>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {connectedChannelIds.filter((id) => !managedIds.includes(id)).map((id) => (
            <span key={id} className="text-[11px] px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
              <Check className="w-3 h-3" />{channelNames[id] || id}
            </span>
          ))}
          {managedIds.map((id) => (
            <span key={id} className="text-[11px] px-2.5 py-1 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20 flex items-center gap-1">
              <Radio className="w-3 h-3" />{channelNames[id] || id}
            </span>
          ))}
        </div>
        {connectedChannelIds.filter((id) => !managedIds.includes(id)).length === 0 && (
          <div className="mt-3 flex items-center gap-2 p-2.5 rounded-lg bg-amber-500/5 border border-amber-500/10">
            <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="text-xs text-zinc-400 flex-1">{t("engine.noChannelsWarning")}</span>
            <button onClick={() => navigate("/dashboard/growth")} className="text-xs text-purple-400 hover:text-purple-300 flex items-center gap-1 shrink-0">
              <Link2 className="w-3 h-3" />{t("engine.connectFirst")}
            </button>
          </div>
        )}
      </div>

      {/* ─── Chat Mode View ─── */}
      {chatMode && cards.length > 0 && (
        <div className="space-y-3">
          {/* AI Greeting */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex gap-3 items-start"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center shrink-0 mt-0.5">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className="flex-1 max-w-[85%]">
              <div className="text-[10px] text-purple-400 mb-1" style={{ fontWeight: 600 }}>{t("engine.aiName")}</div>
              <div className="p-3.5 rounded-2xl rounded-tl-md bg-white/[0.04] border border-white/5 text-sm text-zinc-300 leading-relaxed">
                {t("engine.aiGreeting").replace("{n}", String(cards.length))}
              </div>
            </div>
          </motion.div>

          {/* Chat cards — revealed one by one */}
          {cards.slice(0, chatRevealedCount).map((card, i) => {
            const isApproved = chatApproved.has(card.id);
            return (
              <div key={card.id} className="space-y-3">
                {/* AI message with card intro */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="flex gap-3 items-start"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center shrink-0 mt-0.5">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1 max-w-[85%]">
                    <div className="text-[10px] text-purple-400 mb-1" style={{ fontWeight: 600 }}>{t("engine.aiName")}</div>
                    <div className="p-3.5 rounded-2xl rounded-tl-md bg-white/[0.04] border border-white/5">
                      <div className="text-xs text-zinc-400 mb-2">{t("engine.aiCardIntro").replace("{platform}", card.platform)}</div>
                      {/* Card content bubble */}
                      <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-7 h-7 rounded-lg bg-white/5 flex items-center justify-center text-xs text-zinc-400" style={{ fontWeight: 700 }}>{card.icon}</div>
                          <div>
                            <div className="text-xs text-white" style={{ fontWeight: 600 }}>{card.title}</div>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <span className="text-[9px] text-zinc-600">{card.platform}</span>
                              <span className={`text-[8px] px-1.5 py-0.5 rounded-full border ${tierBadge[card.tier].cls}`} style={{ fontWeight: 600 }}>{tierBadge[card.tier].label}</span>
                            </div>
                          </div>
                          <span className="ml-auto text-[10px] text-zinc-600 flex items-center gap-1"><Eye className="w-3 h-3" />{card.estReach >= 1000 ? `${(card.estReach / 1000).toFixed(1)}K` : card.estReach}</span>
                        </div>
                        <div className="text-xs text-zinc-400 leading-relaxed whitespace-pre-line line-clamp-4">{card.content}</div>
                      </div>
                      {/* Action row */}
                      {!isApproved && (
                        <div className="flex items-center gap-2 mt-3 flex-wrap">
                          <button
                            onClick={() => chatApproveCard(card.id)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-white bg-purple-600 hover:bg-purple-500 transition-colors"
                          >
                            <Check className="w-3 h-3" />{t("engine.approve")}
                          </button>
                          <button onClick={() => startEdit(card)} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-zinc-400 border border-white/5 hover:border-white/10 hover:text-zinc-300 transition-all">
                            <Pencil className="w-3 h-3" />{t("engine.edit")}
                          </button>
                          <button onClick={() => handleRegenerate(card.id)} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-zinc-400 border border-white/5 hover:border-purple-500/20 hover:text-purple-400 transition-all">
                            <RefreshCw className="w-3 h-3" />{t("engine.regenerate")}
                          </button>
                          <button onClick={() => handleCopy(card.id, card.content)} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-zinc-400 border border-white/5 hover:border-white/10 hover:text-zinc-300 transition-all">
                            {copied === card.id ? <><Check className="w-3 h-3 text-emerald-400" /><span className="text-emerald-400">{t("engine.copied")}</span></> : <><Copy className="w-3 h-3" />{t("engine.copy")}</>}
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>

                {/* User approval message */}
                {isApproved && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex gap-3 items-start justify-end"
                  >
                    <div className="max-w-[70%]">
                      <div className="text-[10px] text-zinc-500 mb-1 text-right" style={{ fontWeight: 600 }}>{t("engine.you")}</div>
                      <div className="p-3 rounded-2xl rounded-tr-md bg-purple-500/15 border border-purple-500/20 text-sm text-purple-300 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        {t("engine.approvedLabel")} — {card.platform}
                      </div>
                    </div>
                    <div className="w-8 h-8 rounded-full bg-white/[0.06] flex items-center justify-center shrink-0 mt-0.5">
                      <User className="w-4 h-4 text-zinc-400" />
                    </div>
                  </motion.div>
                )}
              </div>
            );
          })}

          {/* Typing indicator */}
          {chatTypingCard && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex gap-3 items-start"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center shrink-0 mt-0.5">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="p-3.5 rounded-2xl rounded-tl-md bg-white/[0.04] border border-white/5">
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-purple-400/60 animate-bounce" style={{ animationDelay: "0ms" }} />
                  <div className="w-2 h-2 rounded-full bg-purple-400/60 animate-bounce" style={{ animationDelay: "150ms" }} />
                  <div className="w-2 h-2 rounded-full bg-purple-400/60 animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
              </div>
            </motion.div>
          )}

          {/* All done message */}
          {chatRevealedCount >= cards.length && chatApproved.size >= cards.length && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex gap-3 items-start"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-500 to-cyan-600 flex items-center justify-center shrink-0 mt-0.5">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1 max-w-[85%]">
                <div className="text-[10px] text-emerald-400 mb-1" style={{ fontWeight: 600 }}>{t("engine.aiName")}</div>
                <div className="p-3.5 rounded-2xl rounded-tl-md bg-emerald-500/[0.06] border border-emerald-500/15 text-sm text-emerald-300 leading-relaxed">
                  {t("engine.aiAllDone")}
                </div>
              </div>
            </motion.div>
          )}

          <div ref={chatEndRef} />
        </div>
      )}

      {/* Content Cards (classic mode) */}
      {!chatMode && <div className="space-y-4">
        {cards.map((card, i) => (
          <motion.div key={card.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }} className="p-5 rounded-xl border border-white/5 bg-white/[0.02] hover:border-white/10 transition-all">
            <div className="flex items-start justify-between gap-4 mb-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center text-sm text-zinc-400" style={{ fontWeight: 700 }}>{card.icon}</div>
                <div>
                  <div className="text-sm text-white" style={{ fontWeight: 600 }}>{card.title}</div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-xs text-zinc-600">{card.platform}</span>
                    <span className={`text-[9px] px-1.5 py-0.5 rounded-full border ${tierBadge[card.tier].cls}`} style={{ fontWeight: 600 }}>{tierBadge[card.tier].label}</span>
                    {card.scheduledDate && (
                      <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 flex items-center gap-1">
                        <CalendarDays className="w-2.5 h-2.5" />{card.scheduledDate}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-[10px] text-zinc-600 flex items-center gap-1"><Eye className="w-3 h-3" />{card.estReach >= 1000 ? `${(card.estReach / 1000).toFixed(1)}K` : card.estReach}</span>
                <span className={`text-xs px-2.5 py-0.5 rounded-full ${statusColors[card.status]}`} style={{ fontWeight: 500 }}>{statusLabels[card.status]}</span>
              </div>
            </div>

            {/* ─── Content area ─── */}
            {editingId === card.id ? (
              /* Editing mode */
              <div className="mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <Pencil className="w-3 h-3 text-purple-400" />
                  <span className="text-[11px] text-purple-400" style={{ fontWeight: 600 }}>{t("engine.editing")}</span>
                </div>
                <textarea
                  ref={editRef}
                  value={editContent}
                  onChange={(e) => setEditContent(e.target.value)}
                  className="w-full min-h-[120px] bg-white/[0.03] border border-purple-500/20 rounded-lg p-3 text-sm text-zinc-300 leading-relaxed outline-none focus:border-purple-500/40 transition-colors resize-y"
                />
                <div className="flex items-center gap-2 mt-2">
                  <button onClick={() => saveEdit(card.id)} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-white bg-purple-600 hover:bg-purple-500 transition-colors">
                    <Save className="w-3 h-3" />{t("engine.save")}
                  </button>
                  <button onClick={cancelEdit} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-zinc-400 border border-white/5 hover:border-white/10 hover:text-zinc-300 transition-all">
                    <X className="w-3 h-3" />{t("engine.cancel")}
                  </button>
                </div>
              </div>
            ) : regeneratingId === card.id ? (
              /* Regenerating with typing effect */
              <div className="mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-3 h-3 text-purple-400 animate-pulse" />
                  <span className="text-[11px] text-purple-400" style={{ fontWeight: 600 }}>{t("engine.regenerating")}</span>
                </div>
                <div className="text-sm text-zinc-400 leading-relaxed whitespace-pre-line p-3 rounded-lg bg-purple-500/[0.03] border border-purple-500/10 min-h-[80px]">
                  {typingText}
                  <span className="inline-block w-0.5 h-4 bg-purple-400 ml-0.5 animate-pulse align-text-bottom" />
                </div>
              </div>
            ) : (
              /* Normal view */
              <div className="text-sm text-zinc-400 leading-relaxed mb-4 whitespace-pre-line line-clamp-3">{card.content}</div>
            )}

            {/* Action buttons */}
            {editingId !== card.id && regeneratingId !== card.id && (
              <div className="flex items-center gap-2 flex-wrap">
                <button onClick={() => startEdit(card)} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-zinc-400 border border-white/5 hover:border-white/10 hover:text-zinc-300 transition-all"><Pencil className="w-3 h-3" />{t("engine.edit")}</button>
                <button onClick={() => handleRegenerate(card.id)} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-zinc-400 border border-white/5 hover:border-purple-500/20 hover:text-purple-400 hover:bg-purple-500/5 transition-all"><RefreshCw className="w-3 h-3" />{t("engine.regenerate")}</button>
                <button onClick={() => handleCopy(card.id, card.content)} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-zinc-400 border border-white/5 hover:border-white/10 hover:text-zinc-300 transition-all">
                  {copied === card.id ? <><Check className="w-3 h-3 text-emerald-400" /><span className="text-emerald-400">{t("engine.copied")}</span></> : <><Copy className="w-3 h-3" />{t("engine.copy")}</>}
                </button>
                <button onClick={() => openSchedule(card.id)} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-zinc-400 border border-white/5 hover:border-cyan-500/20 hover:text-cyan-400 hover:bg-cyan-500/5 transition-all"><Clock className="w-3 h-3" />{t("engine.schedule")}</button>
                {card.tier === "assisted" && (
                  <button className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-amber-400 border border-amber-500/15 bg-amber-500/5 hover:bg-amber-500/10 transition-all">
                    <ExternalLink className="w-3 h-3" />Open {card.platform}
                  </button>
                )}
              </div>
            )}
          </motion.div>
        ))}
      </div>}

      {/* Empty state when no cards */}
      {cards.length === 0 && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-12 rounded-2xl border border-dashed border-white/5 bg-white/[0.01] flex flex-col items-center justify-center text-center">
          <div className="w-16 h-16 rounded-2xl bg-purple-500/10 border border-purple-500/15 flex items-center justify-center mb-4">
            <Radio className="w-7 h-7 text-purple-400/50" />
          </div>
          <h3 className="text-zinc-400 text-sm" style={{ fontWeight: 600 }}>{t("engine.noChannelsWarning")}</h3>
          <button onClick={() => navigate("/dashboard/growth")} className="mt-4 inline-flex items-center gap-2 bg-purple-600 hover:bg-purple-500 text-white px-5 py-2.5 rounded-xl text-sm transition-colors">
            <Link2 className="w-4 h-4" />{t("engine.connectFirst")}
          </button>
        </motion.div>
      )}

      {/* ─── Schedule Modal ─── */}
      <AnimatePresence>
        {schedulingId && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center"
            onClick={() => setSchedulingId(null)}
          >
            <div className="fixed inset-0 bg-black/40" />
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-sm mx-4 p-6 rounded-2xl border border-white/10 bg-[#141418] shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center gap-2 mb-4">
                <CalendarDays className="w-5 h-5 text-purple-400" />
                <h3 className="text-sm text-white" style={{ fontWeight: 600 }}>{t("engine.schedulePick")}</h3>
              </div>
              <div className="space-y-3">
                <input
                  type="date"
                  value={scheduleDate}
                  onChange={(e) => setScheduleDate(e.target.value)}
                  className="w-full bg-white/[0.03] border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white outline-none focus:border-purple-500/40 transition-colors [color-scheme:dark]"
                />
                <input
                  type="time"
                  value={scheduleTime}
                  onChange={(e) => setScheduleTime(e.target.value)}
                  className="w-full bg-white/[0.03] border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white outline-none focus:border-purple-500/40 transition-colors [color-scheme:dark]"
                />
              </div>
              <div className="flex items-center gap-2 mt-5">
                <button onClick={confirmSchedule} className="flex-1 inline-flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-500 text-white px-4 py-2.5 rounded-xl text-sm transition-colors">
                  <Check className="w-3.5 h-3.5" />{t("engine.scheduleConfirm")}
                </button>
                <button onClick={() => setSchedulingId(null)} className="px-4 py-2.5 rounded-xl text-sm text-zinc-400 border border-white/5 hover:border-white/10 hover:text-zinc-300 transition-all">
                  {t("engine.cancel")}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}