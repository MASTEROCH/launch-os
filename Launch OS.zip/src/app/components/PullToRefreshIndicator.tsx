import { motion, AnimatePresence } from "motion/react";
import { RefreshCw } from "lucide-react";

interface Props {
  pullY: number;
  isRefreshing: boolean;
  threshold?: number;
}

/**
 * Visual pull-to-refresh indicator — shows spinner with rubber-band feel.
 * Mobile only (hidden on md+).
 */
export function PullToRefreshIndicator({ pullY, isRefreshing, threshold = 70 }: Props) {
  return (
    <AnimatePresence>
      {(pullY > 10 || isRefreshing) && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: Math.max(pullY, isRefreshing ? 48 : 0) }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="flex items-center justify-center overflow-hidden md:hidden -mt-4 -mx-4 sm:-mx-6"
        >
          <motion.div
            animate={{ rotate: isRefreshing ? 360 : pullY * 3 }}
            transition={
              isRefreshing
                ? { repeat: Infinity, duration: 0.8, ease: "linear" }
                : { type: "spring" }
            }
          >
            <RefreshCw
              className={`w-5 h-5 transition-colors duration-150 ${
                pullY > threshold || isRefreshing
                  ? "text-purple-400"
                  : "text-zinc-600"
              }`}
            />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
