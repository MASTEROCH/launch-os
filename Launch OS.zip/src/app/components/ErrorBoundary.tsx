import React from "react";
import { AlertTriangle, RefreshCw, Home } from "lucide-react";
import { LS_KEYS } from "./user-progress";

type Lang = "en" | "ru";

const ERROR_TEXTS: Record<string, Record<Lang, string>> = {
  title: { en: "Something went wrong", ru: "Что-то пошло не так" },
  desc: {
    en: "An unexpected error occurred. You can try reloading the page or go back to the home page.",
    ru: "Произошла непредвиденная ошибка. Попробуйте перезагрузить страницу или вернитесь на главную.",
  },
  home: { en: "Home", ru: "На главную" },
  reload: { en: "Reload Page", ru: "Перезагрузить" },
};

function getLang(): Lang {
  try {
    const saved = localStorage.getItem(LS_KEYS.lang);
    if (saved === "ru") return "ru";
  } catch { /* ignore */ }
  return "en";
}

interface Props {
  children: React.ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("[ErrorBoundary]", error, errorInfo);
  }

  handleReload = () => {
    window.location.reload();
  };

  handleGoHome = () => {
    window.location.href = "/";
  };

  render() {
    if (this.state.hasError) {
      const lang = getLang();

      return (
        <div className="min-h-screen bg-[var(--app-bg)] flex items-center justify-center p-6">
          <div className="max-w-md w-full text-center">
            <div className="w-16 h-16 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-6">
              <AlertTriangle className="w-7 h-7 text-red-400" />
            </div>
            <h1 className="text-xl text-white mb-2" style={{ fontWeight: 700 }}>
              {ERROR_TEXTS.title[lang]}
            </h1>
            <p className="text-sm text-zinc-500 mb-6">
              {ERROR_TEXTS.desc[lang]}
            </p>
            {this.state.error && (
              <div className="mb-6 p-3 rounded-xl bg-red-500/5 border border-red-500/10 text-left">
                <p className="text-xs text-red-400/80 font-mono break-all">
                  {this.state.error.message}
                </p>
              </div>
            )}
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={this.handleGoHome}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-white/10 hover:border-white/20 text-sm text-zinc-300 hover:text-white transition-all"
              >
                <Home className="w-4 h-4" />
                {ERROR_TEXTS.home[lang]}
              </button>
              <button
                onClick={this.handleReload}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-sm text-white transition-all"
              >
                <RefreshCw className="w-4 h-4" />
                {ERROR_TEXTS.reload[lang]}
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
