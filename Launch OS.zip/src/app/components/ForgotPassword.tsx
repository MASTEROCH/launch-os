import { useState } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { Rocket, Mail, ArrowLeft, ArrowRight, Loader, CheckCircle2, KeyRound, Lock, Eye, EyeOff, Sun, Moon } from "lucide-react";
import { useI18n, LangSwitcher } from "./i18n";
import { useTheme } from "./ThemeProvider";
import { FloatingOrbs } from "./FloatingOrbs";
import { LaunchLogo } from "./LaunchLogo";
import { useForceDarkMode } from "./useForceDarkMode";

type Step = "email" | "sent" | "code" | "newPassword" | "done";

function AuthBackground() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      <div className="absolute top-1/4 -left-32 w-[500px] h-[500px] bg-purple-500/8 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 -right-32 w-[400px] h-[400px] bg-violet-500/6 rounded-full blur-3xl" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/4 rounded-full blur-3xl" />
      <div className="absolute inset-0" style={{ backgroundImage: "radial-gradient(rgba(139,92,246,0.04) 1px, transparent 1px)", backgroundSize: "32px 32px" }} />
    </div>
  );
}

export function ForgotPassword() {
  useForceDarkMode();
  const navigate = useNavigate();
  const { t } = useI18n();
  const { theme, toggleTheme } = useTheme();

  const [step, setStep] = useState<Step>("email");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState(["", "", "", "", "", ""]);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);

  const maskedEmail = email
    ? email.replace(/^(.{2})(.*)(@.*)$/, (_, a, b, c) => a + b.replace(/./g, "*") + c)
    : "";

  const handleSendEmail = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setStep("sent");
      // auto-advance to code input after showing "sent" animation
      setTimeout(() => setStep("code"), 2000);
    }, 1500);
  };

  const handleResend = () => {
    if (resendCooldown > 0) return;
    setResendCooldown(60);
    const interval = setInterval(() => {
      setResendCooldown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleCodeChange = (index: number, value: string) => {
    if (value.length > 1) value = value.slice(-1);
    if (value && !/^\d$/.test(value)) return;
    const newCode = [...code];
    newCode[index] = value;
    setCode(newCode);
    // Auto-focus next input
    if (value && index < 5) {
      const next = document.getElementById(`code-${index + 1}`);
      next?.focus();
    }
  };

  const handleCodeKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !code[index] && index > 0) {
      const prev = document.getElementById(`code-${index - 1}`);
      prev?.focus();
    }
  };

  const handleVerifyCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (code.some((d) => !d)) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setStep("newPassword");
    }, 1200);
  };

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword !== confirmPassword) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setStep("done");
    }, 1500);
  };

  return (
    <div className="relative min-h-screen bg-[var(--app-bg)] text-white flex flex-col overflow-hidden">
      <AuthBackground />
      <FloatingOrbs />

      {/* Top bar */}
      <div className="liquid-glass relative z-10 flex items-center justify-between px-6 py-4">
        <button onClick={() => navigate("/")} className="flex items-center gap-2 hover:opacity-80 transition-opacity">
          <LaunchLogo size={32} />
          <span style={{ fontWeight: 700 }}>Launch OS</span>
        </button>
        <div className="flex items-center gap-2">
          <LangSwitcher />
          <button
            onClick={toggleTheme}
            aria-label={theme === "dark" ? "Switch to light theme" : "Switch to dark theme"}
            className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-500 hover:text-zinc-300 transition-all"
          >
            {theme === "dark" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Center */}
      <div className="relative z-10 flex-1 flex items-center justify-center px-4 py-8">
        <div className="w-full max-w-md">

          <AnimatePresence mode="wait">

            {/* ──── Step 1: Enter email ──── */}
            {step === "email" && (
              <motion.div key="email" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.35 }}>
                {/* Icon */}
                <div className="relative w-14 h-14 mx-auto mb-6">
                  <motion.div animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0, 0.3] }} transition={{ duration: 2, repeat: Infinity }} className="absolute inset-0 rounded-2xl bg-purple-500/20" />
                  <div className="relative w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center shadow-lg shadow-purple-500/30">
                    <KeyRound className="w-6 h-6 text-white" />
                  </div>
                </div>

                <div className="text-center mb-6">
                  <h1 className="text-2xl tracking-tight mb-1.5" style={{ fontWeight: 700 }}>{t("forgot.title")}</h1>
                  <p className="text-sm text-zinc-500 leading-relaxed">{t("forgot.subtitle")}</p>
                </div>

                <form onSubmit={handleSendEmail} className="space-y-4">
                  <div>
                    <label className="text-xs text-zinc-500 mb-1 block">{t("forgot.emailLabel")}</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder={t("forgot.emailPh")}
                        required
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-sm"
                      />
                    </div>
                  </div>

                  <motion.button
                    type="submit"
                    disabled={loading || !email}
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                    className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 disabled:opacity-50 text-white py-3 rounded-xl text-sm transition-all shadow-lg shadow-purple-500/20"
                  >
                    {loading ? (
                      <><Loader className="w-4 h-4 animate-spin" />{t("forgot.sending")}</>
                    ) : (
                      <>{t("forgot.sendLink")}<ArrowRight className="w-4 h-4" /></>
                    )}
                  </motion.button>
                </form>

                <button
                  onClick={() => navigate("/login")}
                  className="flex items-center justify-center gap-1.5 w-full mt-5 text-xs text-zinc-600 hover:text-zinc-400 transition-colors"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  {t("forgot.backToLogin")}
                </button>
              </motion.div>
            )}

            {/* ──── Step 2: Email sent animation ──── */}
            {step === "sent" && (
              <motion.div key="sent" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} transition={{ duration: 0.4 }}
                className="text-center"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 200, damping: 12, delay: 0.15 }}
                  className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-green-500/10 border border-emerald-500/20 flex items-center justify-center"
                >
                  <Mail className="w-8 h-8 text-emerald-400" />
                </motion.div>

                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
                  <h2 className="text-xl mb-2" style={{ fontWeight: 700 }}>{t("forgot.checkInbox")}</h2>
                  <p className="text-sm text-zinc-500 leading-relaxed">
                    {t("forgot.sentTo")} <span className="text-zinc-300" style={{ fontWeight: 500 }}>{maskedEmail}</span>
                  </p>
                </motion.div>

                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 2, ease: "linear" }}
                  className="h-0.5 bg-gradient-to-r from-purple-500 to-emerald-500 rounded-full mt-8 mx-auto max-w-xs"
                />
              </motion.div>
            )}

            {/* ──── Step 3: Enter verification code ──── */}
            {step === "code" && (
              <motion.div key="code" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.35 }}>
                <div className="w-14 h-14 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-purple-500/20 to-violet-500/10 border border-purple-500/20 flex items-center justify-center">
                  <Mail className="w-6 h-6 text-purple-400" />
                </div>

                <div className="text-center mb-6">
                  <h1 className="text-2xl tracking-tight mb-1.5" style={{ fontWeight: 700 }}>{t("forgot.enterCode")}</h1>
                  <p className="text-sm text-zinc-500 leading-relaxed">
                    {t("forgot.codeSentTo")} <span className="text-zinc-300" style={{ fontWeight: 500 }}>{maskedEmail}</span>
                  </p>
                </div>

                <form onSubmit={handleVerifyCode} className="space-y-6">
                  {/* 6-digit code input */}
                  <div className="flex items-center justify-center gap-2.5">
                    {code.map((digit, i) => (
                      <input
                        key={i}
                        id={`code-${i}`}
                        type="text"
                        inputMode="numeric"
                        maxLength={1}
                        value={digit}
                        onChange={(e) => handleCodeChange(i, e.target.value)}
                        onKeyDown={(e) => handleCodeKeyDown(i, e)}
                        className={`w-11 h-13 text-center text-lg rounded-xl border transition-all focus:outline-none ${
                          digit
                            ? "bg-purple-500/10 border-purple-500/30 text-white"
                            : "bg-white/[0.03] border-white/10 text-white"
                        } focus:border-purple-500/50`}
                        style={{ fontWeight: 600 }}
                      />
                    ))}
                  </div>

                  <motion.button
                    type="submit"
                    disabled={loading || code.some((d) => !d)}
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                    className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 disabled:opacity-50 text-white py-3 rounded-xl text-sm transition-all shadow-lg shadow-purple-500/20"
                  >
                    {loading ? (
                      <><Loader className="w-4 h-4 animate-spin" />{t("forgot.verifying")}</>
                    ) : (
                      <>{t("forgot.verify")}<ArrowRight className="w-4 h-4" /></>
                    )}
                  </motion.button>
                </form>

                <div className="text-center mt-5">
                  <span className="text-xs text-zinc-600">
                    {t("forgot.noCode")}{" "}
                    <button
                      onClick={handleResend}
                      disabled={resendCooldown > 0}
                      className="text-purple-400 hover:text-purple-300 disabled:text-zinc-600 transition-colors"
                      style={{ fontWeight: 500 }}
                    >
                      {resendCooldown > 0 ? `${t("forgot.resendIn")} ${resendCooldown}s` : t("forgot.resend")}
                    </button>
                  </span>
                </div>

                <button
                  onClick={() => setStep("email")}
                  className="flex items-center justify-center gap-1.5 w-full mt-4 text-xs text-zinc-600 hover:text-zinc-400 transition-colors"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  {t("forgot.changeEmail")}
                </button>
              </motion.div>
            )}

            {/* ──── Step 4: New password ──── */}
            {step === "newPassword" && (
              <motion.div key="newPassword" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.35 }}>
                <div className="w-14 h-14 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-purple-500/20 to-violet-500/10 border border-purple-500/20 flex items-center justify-center">
                  <Lock className="w-6 h-6 text-purple-400" />
                </div>

                <div className="text-center mb-6">
                  <h1 className="text-2xl tracking-tight mb-1.5" style={{ fontWeight: 700 }}>{t("forgot.newPasswordTitle")}</h1>
                  <p className="text-sm text-zinc-500 leading-relaxed">{t("forgot.newPasswordSub")}</p>
                </div>

                <form onSubmit={handleResetPassword} className="space-y-4">
                  <div>
                    <label className="text-xs text-zinc-500 mb-1 block">{t("forgot.newPasswordLabel")}</label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                      <input
                        type={showPassword ? "text" : "password"}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder={t("forgot.newPasswordPh")}
                        required
                        className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-sm"
                      />
                      <button type="button" onClick={() => setShowPassword((v) => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-zinc-400 transition-colors">
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Password strength indicator */}
                  {newPassword && (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}>
                      <div className="flex gap-1.5">
                        {[1, 2, 3, 4].map((level) => {
                          const strength =
                            (newPassword.length >= 8 ? 1 : 0) +
                            (/[A-Z]/.test(newPassword) ? 1 : 0) +
                            (/\d/.test(newPassword) ? 1 : 0) +
                            (/[^A-Za-z0-9]/.test(newPassword) ? 1 : 0);
                          const colors = ["bg-red-500", "bg-orange-500", "bg-yellow-500", "bg-emerald-500"];
                          return (
                            <div key={level} className={`h-1 flex-1 rounded-full transition-colors ${level <= strength ? colors[strength - 1] : "bg-white/5"}`} />
                          );
                        })}
                      </div>
                      <p className="text-xs text-zinc-600 mt-1.5">{t("forgot.passwordHint")}</p>
                    </motion.div>
                  )}

                  <div>
                    <label className="text-xs text-zinc-500 mb-1 block">{t("forgot.confirmLabel")}</label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                      <input
                        type={showPassword ? "text" : "password"}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder={t("forgot.confirmPh")}
                        required
                        className={`w-full pl-10 pr-10 py-2.5 rounded-xl bg-white/[0.03] border text-white placeholder-zinc-600 focus:outline-none transition-colors text-sm ${
                          confirmPassword && confirmPassword !== newPassword
                            ? "border-red-500/40 focus:border-red-500/60"
                            : confirmPassword && confirmPassword === newPassword
                            ? "border-emerald-500/40 focus:border-emerald-500/60"
                            : "border-white/10 focus:border-purple-500/50"
                        }`}
                      />
                      {confirmPassword && confirmPassword === newPassword && (
                        <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400" />
                      )}
                    </div>
                    {confirmPassword && confirmPassword !== newPassword && (
                      <p className="text-xs text-red-400 mt-1">{t("forgot.mismatch")}</p>
                    )}
                  </div>

                  <motion.button
                    type="submit"
                    disabled={loading || !newPassword || newPassword !== confirmPassword}
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                    className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 disabled:opacity-50 text-white py-3 rounded-xl text-sm transition-all shadow-lg shadow-purple-500/20"
                  >
                    {loading ? (
                      <><Loader className="w-4 h-4 animate-spin" />{t("forgot.resetting")}</>
                    ) : (
                      <>{t("forgot.resetPassword")}<ArrowRight className="w-4 h-4" /></>
                    )}
                  </motion.button>
                </form>
              </motion.div>
            )}

            {/* ──── Step 5: Done ──── */}
            {step === "done" && (
              <motion.div key="done" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} transition={{ duration: 0.4 }}
                className="text-center"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 200, damping: 12, delay: 0.15 }}
                  className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-green-500/10 border border-emerald-500/20 flex items-center justify-center"
                >
                  <CheckCircle2 className="w-9 h-9 text-emerald-400" />
                </motion.div>

                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
                  <h2 className="text-xl mb-2" style={{ fontWeight: 700 }}>{t("forgot.doneTitle")}</h2>
                  <p className="text-sm text-zinc-500 leading-relaxed mb-6">{t("forgot.doneSub")}</p>

                  <motion.button
                    onClick={() => navigate("/login")}
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                    className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white py-3 rounded-xl text-sm transition-all shadow-lg shadow-purple-500/20"
                  >
                    {t("forgot.goToLogin")}
                    <ArrowRight className="w-4 h-4" />
                  </motion.button>
                </motion.div>
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </div>

      {/* Footer */}
      <div className="relative z-10 text-center py-4">
        <p className="text-xs text-zinc-700">&copy; 2026 Launch OS</p>
      </div>
    </div>
  );
}