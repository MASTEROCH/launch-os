import { useState, useEffect, useRef } from "react";
import { motion, useMotionValue, useTransform } from "motion/react";

/**
 * iOS-style Large Title header with:
 * - Collapsible header that smoothly transitions to compact sticky header
 * - Blur-behind glass effect on BOTH mobile and desktop
 * - Parallax depth effect on scroll (title moves at 0.4x scroll speed)
 * - Opacity fade as title scrolls away
 */
interface LargeTitleProps {
  title: string;
  subtitle?: string;
  /** Badge element next to title */
  badge?: React.ReactNode;
  /** Optional right-side actions */
  actions?: React.ReactNode;
  /** scroll container ref — defaults to closest <main> */
  scrollRef?: React.RefObject<HTMLElement | null>;
  children?: React.ReactNode;
}

export function LargeTitle({ title, subtitle, badge, actions, scrollRef, children }: LargeTitleProps) {
  const [collapsed, setCollapsed] = useState(false);
  const sentinelRef = useRef<HTMLDivElement>(null);
  const titleAreaRef = useRef<HTMLDivElement>(null);

  // Motion values for parallax
  const scrollY = useMotionValue(0);
  const parallaxY = useTransform(scrollY, [0, 120], [0, 48], { clamp: false });
  const titleOpacity = useTransform(scrollY, [0, 60, 100], [1, 0.6, 0]);
  const titleScale = useTransform(scrollY, [0, 100], [1, 0.95]);

  // Track scroll position of the nearest <main> for parallax
  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel) return;
    const container = scrollRef?.current ?? sentinel.closest("main");
    if (!container) return;

    const handleScroll = () => {
      scrollY.set(container.scrollTop);
    };

    container.addEventListener("scroll", handleScroll, { passive: true });
    return () => container.removeEventListener("scroll", handleScroll);
  }, [scrollRef, scrollY]);

  // IntersectionObserver on sentinel for collapse detection
  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel) return;

    const scrollContainer = scrollRef?.current ?? sentinel.closest("main");
    const observer = new IntersectionObserver(
      ([entry]) => {
        setCollapsed(!entry.isIntersecting);
      },
      {
        root: scrollContainer,
        threshold: 0,
        rootMargin: "-1px 0px 0px 0px",
      }
    );

    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [scrollRef]);

  return (
    <>
      {/* Collapsed compact header — sticky at top, visible when scrolled
          Now works on BOTH mobile and desktop with blur-behind glass */}
      <motion.div
        initial={false}
        animate={{
          opacity: collapsed ? 1 : 0,
          y: collapsed ? 0 : -8,
          pointerEvents: collapsed ? ("auto" as const) : ("none" as const),
        }}
        transition={{ duration: 0.22, ease: [0.25, 0.1, 0.25, 1] }}
        className="sticky top-0 z-30 large-title-compact"
      >
        <div className="flex items-center justify-between max-w-7xl mx-auto px-4 sm:px-6 py-2.5">
          <div className="flex items-center gap-2 min-w-0">
            <h2
              className="text-[15px] text-white truncate"
              style={{ fontWeight: 600 }}
            >
              {title}
            </h2>
            {badge}
          </div>
          {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
        </div>
      </motion.div>

      {/* Large title area with parallax */}
      <div className="px-4 sm:px-6 pt-2 pb-1 overflow-hidden" ref={titleAreaRef}>
        <div ref={sentinelRef} className="h-0 w-full" />
        <motion.div
          style={{
            y: parallaxY,
            opacity: titleOpacity,
            scale: titleScale,
            transformOrigin: "left top",
          }}
          className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 sm:gap-4 parallax-title"
        >
          <div className="min-w-0">
            <div className="flex items-center gap-2.5">
              <h1
                className="text-[28px] sm:text-xl text-white tracking-tight"
                style={{ fontWeight: 700 }}
              >
                {title}
              </h1>
              {badge}
            </div>
            {subtitle && (
              <p className="text-sm text-zinc-500 mt-0.5">{subtitle}</p>
            )}
          </div>
          {actions && (
            <div className="flex items-center gap-2 shrink-0">
              {actions}
            </div>
          )}
        </motion.div>
      </div>

      {children}
    </>
  );
}
