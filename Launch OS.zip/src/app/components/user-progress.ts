/* ─── Shared user progress state (localStorage) ─── */

/* ═══════════════════════════════════════════════════
   Centralized localStorage key registry
   All keys used across the app are listed here.
   ═══════════════════════════════════════════════════ */
export const LS_KEYS = {
  progress: "launchapp_user_progress",
  subscription: "launchapp_subscription",
  theme: "launchapp_theme",
  accent: "launchapp_accent",
  lang: "launchapp-lang",
  referralTree: "launchapp_referral_tree",
  referralSeenCount: "launchapp_referral_seen_count",
  pkgTourDone: "launchapp_pkg_tour_done",
  chTourDone: "launchapp_ch_tour_done",
  engineOnboardDone: "launchapp_engine_onboard_done",
  tokenOnboardDone: "launchapp_token_onboard_done",
  packageGenerated: "launchapp_package_generated",
  trialWarned: "launchapp_trial_warned",       // sessionStorage
  dashTourDone: "launchapp_dash_tour_done",
  projects: "launchapp_projects",
  activeProjectId: "launchapp_active_project_id",
  sidebarCollapsed: "launchapp_sidebar_collapsed",
  communityBadgeSeen: "launchapp_community_badge_seen",
  communityUnread: "launchapp_community_unread",
  channels: "launchapp_channels",
  apiKeys: "launchapp_api_keys",
  channelRewards: "launchapp_ch_rewards",
} as const;

/* ═══════════════════════════════════════════════════
   Project model — multi-project support
   ═══════════════════════════════════════════════════ */
export interface Project {
  id: string;
  name: string;
  category: string;
  url: string;
  description: string;
  audience: string;
  status: "draft" | "ready" | "launched" | "paused";
  createdAt: number;
  updatedAt: number;
  launchDay: number;       // 0 = not launched, 1-7 for days since launch
  channelsConnected: number;
  tokensUsed: number;
  contentGenerated: number; // percentage 0-100
  color: string;            // accent for project card
}

const DEFAULT_PROJECT_COLORS = ["purple", "blue", "emerald", "rose", "amber", "cyan", "violet", "orange"];

export function createProject(data: Partial<Project>): Project {
  return {
    id: `proj_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    name: data.name || "Untitled Project",
    category: data.category || "",
    url: data.url || "",
    description: data.description || "",
    audience: data.audience || "",
    status: data.status || "draft",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    launchDay: data.launchDay || 0,
    channelsConnected: data.channelsConnected || 0,
    tokensUsed: data.tokensUsed || 0,
    contentGenerated: data.contentGenerated || 0,
    color: data.color || DEFAULT_PROJECT_COLORS[Math.floor(Math.random() * DEFAULT_PROJECT_COLORS.length)],
  };
}

export function loadProjects(): Project[] {
  try {
    const raw = localStorage.getItem(LS_KEYS.projects);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch { /* ignore */ }
  return [];
}

export function saveProjects(projects: Project[]): void {
  localStorage.setItem(LS_KEYS.projects, JSON.stringify(projects));
}

export function addProject(data: Partial<Project>): Project {
  const projects = loadProjects();
  const project = createProject(data);
  projects.unshift(project);
  saveProjects(projects);
  setActiveProjectId(project.id);
  return project;
}

export function updateProject(id: string, patch: Partial<Project>): Project | null {
  const projects = loadProjects();
  const idx = projects.findIndex((p) => p.id === id);
  if (idx === -1) return null;
  projects[idx] = { ...projects[idx], ...patch, updatedAt: Date.now() };
  saveProjects(projects);
  return projects[idx];
}

export function deleteProject(id: string): void {
  const projects = loadProjects().filter((p) => p.id !== id);
  saveProjects(projects);
  const activeId = getActiveProjectId();
  if (activeId === id) {
    setActiveProjectId(projects[0]?.id || null);
  }
}

export function getActiveProjectId(): string | null {
  try {
    return localStorage.getItem(LS_KEYS.activeProjectId) || null;
  } catch { return null; }
}

export function setActiveProjectId(id: string | null): void {
  if (id) {
    localStorage.setItem(LS_KEYS.activeProjectId, id);
  } else {
    localStorage.removeItem(LS_KEYS.activeProjectId);
  }
}

export function getActiveProject(): Project | null {
  const id = getActiveProjectId();
  if (!id) return null;
  const projects = loadProjects();
  return projects.find((p) => p.id === id) || null;
}

/* ═══════════════════════════════════════════════════
   User progress (legacy — backward-compatible)
   ═══════════════════════════════════════════════════ */
export interface UserProgress {
  projectCreated: boolean;
  tokensAvailable: number;
  channelsConnected: number;
  launched: boolean;
  projectName: string;
  projectCategory: string;
  projectUrl: string;
  projectDescription: string;
  launchDay: number; // 0 = not launched, 1-7 for simulating days since launch
  tourCompleted: boolean;
  /* ─── Extended onboarding data (UX: avoid re-entry) ─── */
  userName: string;
  userEmail: string;
  audience: string;
  goal: string;
  onboardingCompleted: boolean;
  lastCompletedStep: number; // 0-5 pipeline step index for "continue where you left off"
  lastVisit: number; // timestamp for welcome-back logic
}

export const DEFAULT_PROGRESS: UserProgress = {
  projectCreated: false,
  tokensAvailable: 0,
  channelsConnected: 0,
  launched: false,
  projectName: "",
  projectCategory: "",
  projectUrl: "",
  projectDescription: "",
  launchDay: 0,
  tourCompleted: false,
  userName: "",
  userEmail: "",
  audience: "",
  goal: "",
  onboardingCompleted: false,
  lastCompletedStep: 0,
  lastVisit: 0,
};

export function loadProgress(): UserProgress {
  try {
    const raw = localStorage.getItem(LS_KEYS.progress);
    if (raw) return { ...DEFAULT_PROGRESS, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return DEFAULT_PROGRESS;
}

export function saveProgress(p: UserProgress): void {
  localStorage.setItem(LS_KEYS.progress, JSON.stringify(p));
}

export function updateProgress(patch: Partial<UserProgress>): UserProgress {
  const current = loadProgress();
  const next = { ...current, ...patch };
  saveProgress(next);
  // Notify listeners (e.g. Layout token balance)
  try {
    document.dispatchEvent(new CustomEvent("launchapp:progress", { detail: next }));
  } catch { /* SSR-safe */ }
  return next;
}

/**
 * Full application reset — clears ALL localStorage keys used by Launch OS.
 * Preserves theme and language preferences by default.
 */
export function resetAllData(preservePreferences = true): void {
  const theme = preservePreferences ? localStorage.getItem(LS_KEYS.theme) : null;
  const accent = preservePreferences ? localStorage.getItem(LS_KEYS.accent) : null;
  const lang = preservePreferences ? localStorage.getItem(LS_KEYS.lang) : null;
  const sidebarCollapsed = preservePreferences ? localStorage.getItem(LS_KEYS.sidebarCollapsed) : null;

  // Clear all registered keys
  Object.values(LS_KEYS).forEach((key) => {
    localStorage.removeItem(key);
  });

  // Also clear sessionStorage trial warning
  try { sessionStorage.removeItem(LS_KEYS.trialWarned); } catch { /* ignore */ }

  // Restore preferences if requested
  if (theme) localStorage.setItem(LS_KEYS.theme, theme);
  if (accent) localStorage.setItem(LS_KEYS.accent, accent);
  if (lang) localStorage.setItem(LS_KEYS.lang, lang);
  if (sidebarCollapsed) localStorage.setItem(LS_KEYS.sidebarCollapsed, sidebarCollapsed);
}

/** Legacy reset — clears only the main progress key */
export function resetProgress(): void {
  localStorage.removeItem(LS_KEYS.progress);
}

/** Check if user is "authenticated" (completed onboarding or has subscription) */
export function isAuthenticated(): boolean {
  const progress = loadProgress();
  if (progress.onboardingCompleted) return true;
  try {
    const sub = localStorage.getItem(LS_KEYS.subscription);
    if (sub) return true;
  } catch { /* ignore */ }
  return false;
}