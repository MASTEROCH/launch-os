import { motion, AnimatePresence } from "motion/react";
import { Outlet, useNavigate, useLocation } from "react-router";
import { useState, useEffect, useRef, useCallback, Suspense } from "react";
import {
  LayoutDashboard,
  Rocket,
  Zap,
  BarChart3,
  Coins,
  Settings,
  TrendingUp,
  ChevronLeft,
  ChevronRight,
  Bell,
  LogOut,
  Check,
  CheckCheck,
  Heart,
  Trophy,
  MessageSquare,
  MessageCircle,
  User,
  Search,
  Command,
  Gift,
  WifiOff,
  Wifi,
  Sun,
  Moon,
  MoreHorizontal,
  Package,
  Compass,
  Sparkles,
  FolderKanban,
  CalendarDays,
  Users,
  Map as MapIcon,
  HelpCircle,
} from "lucide-react";
import { useI18n, LangSwitcher } from "./i18n";
import { loadProgress, LS_KEYS, updateProgress } from "./user-progress";
import { CommandPalette } from "./CommandPalette";
import { useTheme } from "./ThemeProvider";
import { FloatingOrbs } from "./FloatingOrbs";
import { useBonusConfetti, fireConfetti } from "./Confetti";
import { PageSkeleton } from "./PageSkeleton";
import { LaunchLogo } from "./LaunchLogo";
import { useRubberBand } from "./useRubberBand";
import { ComingSoonModal, type ComingSoonFeatureId } from "./ComingSoonModal";
import { getUserAvatar } from "./avatars";
import { checkAndUpdateTrialStatus, PLAN_PRICES, type Subscription } from "./subscription";
import { toast } from "sonner";
import { GracePeriodModal } from "./GracePeriodModal";
import { DemoTour } from "./DemoTour";

interface Notification {
  id: string;
  type: "upvote" | "comment" | "friend" | "tokens" | "badge";
  messageKey: string;
  time: number;
  read: boolean;
  icon: typeof Rocket;
  color: string;
}

/* Layout — force HMR remount after useRubberBand spring upgrade */
export function Layout() {
  const [collapsed, setCollapsed] = useState(() => {
    try {
      return localStorage.getItem("launchapp_sidebar_collapsed") === "1";
    } catch { return false; }
  });
  const [mobileSheetOpen, setMobileSheetOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useI18n();
  const { theme, toggleTheme } = useTheme();

  // ─── Persist sidebar collapsed state ───
  const handleToggleCollapsed = useCallback(() => {
    setCollapsed((prev) => !prev);
  }, []);

  // Persist sidebar collapsed state outside updater
  useEffect(() => {
    try { localStorage.setItem("launchapp_sidebar_collapsed", collapsed ? "1" : "0"); } catch {}
  }, [collapsed]);

  // ─── Auto-fire confetti on bonus events ───
  useBonusConfetti();

  // ─── Haptic feedback helper ───
  const haptic = useCallback((intensity: number = 10) => {
    try { navigator?.vibrate?.(intensity); } catch {}
  }, []);

  // ─── Theme toggle with haptic ───
  const handleToggleTheme = useCallback(() => {
    haptic(8);
    toggleTheme();
  }, [toggleTheme, haptic]);

  // ─── Grace Period modal state ───
  const [graceModalSub, setGraceModalSub] = useState<Subscription | null>(null);

  // ─── Trial status check & auto-transition on mount ───
  useEffect(() => {
    const result = checkAndUpdateTrialStatus();
    if (!result) return;

    const timer = setTimeout(() => {
      if (result.action === "grace_offer") {
        // Show grace period modal instead of auto-transitioning
        setGraceModalSub(result.sub);
      } else if (result.action === "transitioned") {
        const price = PLAN_PRICES[result.sub.planId] || 59;
        toast.info(t("trial.transitionedTitle"), {
          description: `${t("trial.transitionedBody")} ($${price}/mo)`,
          duration: 8000,
        });
      } else if (result.action === "warning") {
        toast.warning(t("trial.warningTitle"), {
          description: t("trial.warningBody"),
          duration: 10000,
        });
      }
    }, 1500); // slight delay so it doesn't flash instantly

    return () => clearTimeout(timer);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ─── Track navigation direction for iOS slide transitions ───
  const prevPath = useRef(location.pathname);
  const [slideDirection, setSlideDirection] = useState<"forward" | "back">("forward");

  useEffect(() => {
    const prev = prevPath.current;
    const curr = location.pathname;
    // Simple heuristic: deeper path = forward, shallower = back
    setSlideDirection(curr.length >= prev.length ? "forward" : "back");
    prevPath.current = curr;
  }, [location.pathname]);

  // ─── Offline detection ───
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [showBackOnline, setShowBackOnline] = useState(false);

  useEffect(() => {
    const goOffline = () => setIsOffline(true);
    const goOnline = () => {
      setIsOffline(false);
      setShowBackOnline(true);
      setTimeout(() => setShowBackOnline(false), 3000);
    };
    window.addEventListener("offline", goOffline);
    window.addEventListener("online", goOnline);
    return () => {
      window.removeEventListener("offline", goOffline);
      window.removeEventListener("online", goOnline);
    };
  }, []);

  // Close mobile sheet on route change
  useEffect(() => {
    setMobileSheetOpen(false);
  }, [location.pathname]);

  // ─── Live token balance ───
  const [tokenBalance, setTokenBalance] = useState(() => {
    const p = loadProgress();
    return p.tokensAvailable > 0 ? p.tokensAvailable : 1250;
  });

  // ─── Non-linear pipeline progress (per-step completion) ───
  const computeCompletedSteps = useCallback((): Set<number> => {
    const p = loadProgress();
    const steps = new Set<number>();
    if (p.projectCreated) steps.add(1);
    try { if (localStorage.getItem("launchapp_package_generated")) steps.add(2); } catch {}
    if (p.channelsConnected > 0) steps.add(3);
    if (p.launched) steps.add(4);
    if (p.launched && p.launchDay >= 3) steps.add(5);
    return steps;
  }, []);

  const [completedSteps, setCompletedSteps] = useState<Set<number>>(computeCompletedSteps);
  const prevCompletedCountRef = useRef(completedSteps.size);

  // Derived values for UI
  const pipelineCount = completedSteps.size;
  const nextStep = [1, 2, 3, 4, 5].find((s) => !completedSteps.has(s)) ?? null;

  // ─── Confetti burst when all 5 steps completed ───
  useEffect(() => {
    const prevCount = prevCompletedCountRef.current;
    prevCompletedCountRef.current = pipelineCount;
    if (pipelineCount === 5 && prevCount < 5) {
      haptic(20);
      fireConfetti();
      setTimeout(() => fireConfetti(), 400);
      toast.success(t("progress.allComplete") || "All 5 steps complete!", {
        description: t("progress.allCompleteDesc") || "Your launch journey is finished. Time to grow!",
        duration: 6000,
      });
    }
  }, [pipelineCount, haptic, t]);

  // ─── Listen for in-tab progress events ───
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail as { tokensAvailable?: number };
      if (detail && typeof detail.tokensAvailable === "number") {
        setTokenBalance(detail.tokensAvailable > 0 ? detail.tokensAvailable : 1250);
      }
      // Recompute per-step completion (non-linear)
      setCompletedSteps(computeCompletedSteps());
    };
    document.addEventListener("launchapp:progress", handler);
    return () => document.removeEventListener("launchapp:progress", handler);
  }, [computeCompletedSteps]);

  // ─── Cross-tab sync via storage events ───
  useEffect(() => {
    const handler = (e: StorageEvent) => {
      // Any launchapp key change from another tab triggers recompute
      if (e.key && e.key.startsWith("launchapp")) {
        setCompletedSteps(computeCompletedSteps());
        // Also refresh token balance
        const p = loadProgress();
        setTokenBalance(p.tokensAvailable > 0 ? p.tokensAvailable : 1250);
      }
    };
    window.addEventListener("storage", handler);
    return () => window.removeEventListener("storage", handler);
  }, [computeCompletedSteps]);

  // ─── Notifications ───
  const [notifications, setNotifications] = useState<Notification[]>([
    { id: "n1", type: "upvote", messageKey: "layout.notifLaunch", time: 2, read: false, icon: TrendingUp, color: "text-emerald-400" },
    { id: "n2", type: "comment", messageKey: "layout.notifComment", time: 15, read: false, icon: MessageSquare, color: "text-blue-400" },
    { id: "n3", type: "friend", messageKey: "layout.notifFriend", time: 45, read: false, icon: Heart, color: "text-pink-400" },
    { id: "n4", type: "tokens", messageKey: "layout.notifTokens", time: 120, read: true, icon: Coins, color: "text-purple-400" },
    { id: "n5", type: "badge", messageKey: "layout.notifBadge", time: 300, read: true, icon: Trophy, color: "text-amber-400" },
  ]);
  const [showNotifications, setShowNotifications] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);

  const [showProfile, setShowProfile] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);

  // ─── Coming Soon modal state ───
  const [comingSoonFeature, setComingSoonFeature] = useState<ComingSoonFeatureId | null>(null);



  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setShowNotifications(false);
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) setShowProfile(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  // ─── Listen for referral events ───
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail as {
        name: string;
        level: number;
        tokens: number;
        parentName?: string;
      };
      const newNotif: Notification = {
        id: `ref-${Date.now()}`,
        type: "tokens",
        messageKey: `${detail.name} ${detail.parentName ? `joined via ${detail.parentName} (L${detail.level})` : "joined via your link"}! +${detail.tokens} tokens`,
        time: 0,
        read: false,
        icon: Gift,
        color: "text-emerald-400",
      };
      setNotifications((prev) => [newNotif, ...prev]);
    };
    document.addEventListener("launchapp:referral", handler);
    return () => document.removeEventListener("launchapp:referral", handler);
  }, []);

  // ─── Listen for bonus events (purchases, launches, rewards) ───
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail as {
        message: string;
        tokens?: number;
        type?: string;
      };
      const typeIcons: Record<string, { icon: typeof Rocket; color: string }> = {
        purchase: { icon: Coins, color: "text-purple-400" },
        launch: { icon: Rocket, color: "text-emerald-400" },
        reward: { icon: Trophy, color: "text-amber-400" },
        referral: { icon: Gift, color: "text-cyan-400" },
      };
      const { icon, color } = typeIcons[detail.type || "reward"] || typeIcons.reward;
      const newNotif: Notification = {
        id: `bonus-${Date.now()}`,
        type: "tokens",
        messageKey: detail.message,
        time: 0,
        read: false,
        icon,
        color,
      };
      setNotifications((prev) => [newNotif, ...prev]);
    };
    document.addEventListener("launchapp:bonus", handler);
    return () => document.removeEventListener("launchapp:bonus", handler);
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;
  const markAllRead = () => setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  const markOneRead = (id: string) => setNotifications((prev) => prev.map((n) => n.id === id ? { ...n, read: true } : n));

  const formatTime = (mins: number) => {
    if (mins < 1) return t("layout.justNow");
    if (mins < 60) return `${mins} ${t("layout.minutesAgo")}`;
    return `${Math.floor(mins / 60)} ${t("layout.hoursAgo")}`;
  };

  // ─── Sidebar sections (radically simplified) ───
  type NavItem = { icon: typeof Rocket; label: string; path: string; badge?: number; step?: number };

  // Community badge: dynamic unread count, persisted in localStorage
  // Mock: starts at 3 unread events, resets when user visits /dashboard/community
  const [communityBadge, setCommunityBadge] = useState<number>(() => {
    try {
      const stored = localStorage.getItem(LS_KEYS.communityUnread);
      if (stored !== null) return parseInt(stored, 10) || 0;
      // First visit: mock 3 new community events
      localStorage.setItem(LS_KEYS.communityUnread, "3");
      return 3;
    } catch { return 0; }
  });

  // Clear community badge when visiting community page
  useEffect(() => {
    if (location.pathname === "/dashboard/community" && communityBadge > 0) {
      setCommunityBadge(0);
      try {
        localStorage.setItem(LS_KEYS.communityUnread, "0");
        localStorage.setItem(LS_KEYS.communityBadgeSeen, "1");
      } catch {}
    }
  }, [location.pathname, communityBadge]);

  // Listen for community events (other tabs, simulated events)
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail as { count?: number } | undefined;
      const count = detail?.count ?? 1;
      setCommunityBadge((prev) => prev + count);
    };
    document.addEventListener("launchapp:community-event", handler);
    return () => document.removeEventListener("launchapp:community-event", handler);
  }, []);

  // Persist community badge count outside updater (avoids side-effect in setState)
  useEffect(() => {
    try { localStorage.setItem(LS_KEYS.communityUnread, String(communityBadge)); } catch {}
  }, [communityBadge]);

  // Demo mode: simulate +1 community event every 3-7 min (randomised)
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    const schedule = () => {
      const delay = (3 + Math.random() * 4) * 60 * 1000; // 3-7 min
      timer = setTimeout(() => {
        if (location.pathname !== "/dashboard/community") {
          setCommunityBadge((prev) => prev + 1);
        }
        schedule(); // next tick with new random delay
      }, delay);
    };
    schedule();
    return () => clearTimeout(timer);
  }, [location.pathname]);

  // Demo mode: advance launchDay every 2 min after launch (max 7)
  useEffect(() => {
    const p = loadProgress();
    if (!p.launched || p.launchDay >= 7) return;
    let timer: ReturnType<typeof setTimeout>;
    const advance = () => {
      const current = loadProgress();
      if (!current.launched || current.launchDay >= 7) return;
      const nextDay = Math.min(current.launchDay + 1, 7);
      updateProgress({ launchDay: nextDay });
      if (nextDay < 7) {
        timer = setTimeout(advance, 2 * 60 * 1000);
      }
    };
    timer = setTimeout(advance, 2 * 60 * 1000);
    return () => clearTimeout(timer);
  }, [completedSteps]); // re-run when steps change (launch triggers recompute)

  // The 5-step launch journey — the core of the product
  const journeyItems: NavItem[] = [
    { icon: Sparkles, label: t("sidebar.newProject"), path: "/dashboard/new-project", step: 1 },
    { icon: Package, label: t("sidebar.package"), path: "/dashboard/package", step: 2 },
    { icon: Compass, label: t("sidebar.growth"), path: "/dashboard/growth", step: 3 },
    { icon: Zap, label: t("sidebar.launchEngine"), path: "/dashboard/launch", step: 4 },
    { icon: TrendingUp, label: t("sidebar.launchTracker"), path: "/dashboard/tracker", step: 5 },
  ];

  // Quick access — always visible above the journey
  const quickAccessItems: NavItem[] = [
    { icon: FolderKanban, label: t("sidebar.projects"), path: "/dashboard/projects" },
    { icon: Users, label: t("sidebar.community"), path: "/dashboard/community", badge: communityBadge },
  ];

  // Tools — iteration layer after the 5 steps
  const toolItems: NavItem[] = [
    { icon: CalendarDays, label: t("sidebar.contentPlan"), path: "/dashboard/content-plan" },
    { icon: BarChart3, label: t("sidebar.analytics"), path: "/dashboard/analytics" },
    { icon: MapIcon, label: t("sidebar.roadmap"), path: "/dashboard/roadmap" },
    { icon: Settings, label: t("sidebar.settings"), path: "/dashboard/settings" },
    { icon: HelpCircle, label: t("sidebar.faq"), path: "/dashboard/faq" },
  ];

  // Helper: render a single nav button
  const renderNavButton = (item: NavItem, showStep?: boolean) => {
    const isActive = location.pathname === item.path;
    const stepDone = item.step ? completedSteps.has(item.step) : false;
    const isNextStep = item.step ? item.step === nextStep : false;
    return (
      <div key={item.path} className="relative group/nav">
        <button onClick={() => navigate(item.path)}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all ${isActive ? "bg-purple-500/10 text-purple-400" : "text-zinc-500 hover:text-zinc-300 hover:bg-white/[0.03]"}`}>
          <div className="relative shrink-0">
            {showStep && item.step && !collapsed ? (
              <div className={`w-6 h-6 rounded-lg flex items-center justify-center text-[11px] ${
                stepDone
                  ? "bg-emerald-500/20 text-emerald-400"
                  : isActive
                  ? "bg-purple-500/20 text-purple-400"
                  : isNextStep
                  ? "bg-purple-500/10 text-purple-400/70 ring-1 ring-purple-500/30"
                  : "bg-white/[0.04] text-zinc-600"
              }`} style={{ fontWeight: 700 }}>{stepDone ? <Check className="w-3.5 h-3.5" /> : item.step}</div>
            ) : (
              <item.icon className="w-4.5 h-4.5" />
            )}
            {"badge" in item && item.badge ? (
              <div className="absolute -top-1.5 -right-1.5 min-w-[14px] h-3.5 px-0.5 rounded-full bg-purple-500 flex items-center justify-center">
                <span className="text-[8px] text-white" style={{ fontWeight: 700 }}>{item.badge}</span>
              </div>
            ) : null}
          </div>
          {!collapsed && (
            <span className="whitespace-nowrap flex-1 text-left">{item.label}</span>
          )}
          {!collapsed && showStep && isNextStep && item.step && item.step <= 5 && (
            <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-purple-500/15 text-purple-400" style={{ fontWeight: 600 }}>
              {t("progress.next") || "Next"}
            </span>
          )}
        </button>
        {/* Tooltip for collapsed sidebar */}
        {collapsed && (
          <div className="absolute left-full top-1/2 -translate-y-1/2 ml-2 px-2.5 py-1.5 rounded-lg bg-zinc-800 border border-white/10 text-xs text-zinc-200 whitespace-nowrap opacity-0 invisible group-hover/nav:opacity-100 group-hover/nav:visible transition-all duration-150 z-50 pointer-events-none shadow-xl" style={{ fontWeight: 500 }}>
            {item.label}
            {isNextStep && <span className="ml-1.5 text-purple-400">({t("progress.next") || "Next"})</span>}
          </div>
        )}
      </div>
    );
  };

  // Shared nav renderer for desktop sidebar
  const renderNav = () => (
    <nav className="flex-1 py-3 px-2 overflow-y-auto">
      {/* Home button — always first */}
      <div className="mb-0.5">
        {renderNavButton({ icon: LayoutDashboard, label: t("sidebar.dashboard"), path: "/dashboard" })}
      </div>

      {/* Quick Access — Projects & Community */}
      <div className="space-y-0.5">
        {quickAccessItems.map((item) => renderNavButton(item))}
      </div>

      {/* 5-Step Journey — the main event */}
      <div className="my-2 mx-3 h-px bg-white/5" />
      {!collapsed && (
        <div className="mb-1.5 mt-2 px-3">
          <span className="text-[10px] text-zinc-600 uppercase tracking-widest" style={{ fontWeight: 600 }}>{t("sidebar.journeySection")}</span>
        </div>
      )}
      <div className="space-y-0.5">
        {journeyItems.map((item) => renderNavButton(item, true))}
      </div>

      {/* Tools — iteration layer */}
      <div className="my-2 mx-3 h-px bg-white/5" />
      {!collapsed && (
        <div className="mb-1.5 mt-2 px-3">
          <span className="text-[10px] text-zinc-600 uppercase tracking-widest" style={{ fontWeight: 600 }}>{t("sidebar.toolsSimple")}</span>
        </div>
      )}
      <div className="space-y-0.5">
        {toolItems.map((item) => renderNavButton(item))}
      </div>
    </nav>
  );

  // Flat navItems for legacy usage
  const navItems = [
    { icon: LayoutDashboard, label: t("sidebar.dashboard"), path: "/dashboard" },
    ...quickAccessItems,
    ...journeyItems,
    ...toolItems,
  ];

  // Bottom tab bar items (4 core + More)
  const bottomTabItems: NavItem[] = [
    { icon: LayoutDashboard, label: t("tab.home"), path: "/dashboard" },
    { icon: Zap, label: t("tab.launch"), path: "/dashboard/launch" },
    { icon: Users, label: t("tab.community"), path: "/dashboard/community", badge: communityBadge },
    { icon: CalendarDays, label: t("tab.content"), path: "/dashboard/content-plan" },
  ];

  // Items shown in the "More" bottom sheet — simplified
  const moreSheetPipeline: NavItem[] = [
    { icon: Sparkles, label: t("sidebar.newProject"), path: "/dashboard/new-project", step: 1 },
    { icon: Package, label: t("sidebar.package"), path: "/dashboard/package", step: 2 },
    { icon: Compass, label: t("sidebar.growth"), path: "/dashboard/growth", step: 3 },
    { icon: Zap, label: t("sidebar.launchEngine"), path: "/dashboard/launch", step: 4 },
    { icon: TrendingUp, label: t("sidebar.launchTracker"), path: "/dashboard/tracker", step: 5 },
  ];

  const moreSheetTools: NavItem[] = [
    { icon: FolderKanban, label: t("sidebar.projects"), path: "/dashboard/projects" },
    { icon: Users, label: t("sidebar.community"), path: "/dashboard/community" },
    { icon: BarChart3, label: t("sidebar.analytics"), path: "/dashboard/analytics" },
    { icon: Coins, label: t("sidebar.tokens"), path: "/dashboard/tokens" },
    { icon: MapIcon, label: t("sidebar.roadmap"), path: "/dashboard/roadmap" },
  ];

  const moreSheetAccount: NavItem[] = [
    { icon: Settings, label: t("sidebar.settings"), path: "/dashboard/settings" },
    { icon: HelpCircle, label: t("sidebar.faq"), path: "/dashboard/faq" },
  ];

  const allMoreItems = [...moreSheetPipeline, ...moreSheetTools, ...moreSheetAccount];

  // Profile menu items — minimal
  const profileMenuItems = [
    { icon: User, label: t("sidebar.settings"), action: () => navigate("/dashboard/settings") },
    { icon: Coins, label: t("sidebar.tokens"), action: () => navigate("/dashboard/tokens") },
    { icon: HelpCircle, label: t("sidebar.faq"), action: () => navigate("/dashboard/faq") },
  ];

  // Check if current path matches a bottom tab (for active state)
  const isBottomTabActive = (path: string) => location.pathname === path;
  const isMoreActive = allMoreItems.some((item) => location.pathname === item.path);

  // ─── iOS-style swipe-back gesture navigation ───
  const swipeStartX = useRef(0);
  const swipeStartY = useRef(0);
  const isSwiping = useRef(false);
  const [swipeBackX, setSwipeBackX] = useState(0);
  const mainRef = useRef<HTMLElement>(null);

  const onSwipeStart = useCallback((e: React.TouchEvent) => {
    const touch = e.touches[0];
    if (touch.clientX <= 24 && location.pathname !== "/dashboard") {
      swipeStartX.current = touch.clientX;
      swipeStartY.current = touch.clientY;
      isSwiping.current = true;
    }
  }, [location.pathname]);

  const onSwipeMove = useCallback((e: React.TouchEvent) => {
    if (!isSwiping.current) return;
    const touch = e.touches[0];
    const dx = touch.clientX - swipeStartX.current;
    const dy = Math.abs(touch.clientY - swipeStartY.current);
    if (dy > 40) {
      isSwiping.current = false;
      setSwipeBackX(0);
      return;
    }
    if (dx > 0) {
      setSwipeBackX(Math.min(dx * 0.6, window.innerWidth * 0.6));
    }
  }, []);

  const onSwipeEnd = useCallback(() => {
    if (!isSwiping.current) return;
    isSwiping.current = false;
    const threshold = window.innerWidth * 0.25;
    if (swipeBackX > threshold) {
      haptic(15);
      setSwipeBackX(0);
      navigate(-1);
    } else {
      setSwipeBackX(0);
    }
  }, [swipeBackX, haptic, navigate]);

  // ─── iOS rubber band overscroll ───
  const { overscrollY, onRubberTouchStart, onRubberTouchMove, onRubberTouchEnd } = useRubberBand(mainRef);

  // Combine swipe-back + rubber band touch handlers
  const combinedTouchStart = useCallback((e: React.TouchEvent) => {
    onSwipeStart(e);
    if (!isSwiping.current) {
      onRubberTouchStart(e);
    }
  }, [onSwipeStart, onRubberTouchStart]);

  const combinedTouchMove = useCallback((e: React.TouchEvent) => {
    if (isSwiping.current) {
      onSwipeMove(e);
    } else {
      onRubberTouchMove(e);
    }
  }, [onSwipeMove, onRubberTouchMove]);

  const combinedTouchEnd = useCallback((e: React.TouchEvent) => {
    onSwipeEnd();
    onRubberTouchEnd(e);
  }, [onSwipeEnd, onRubberTouchEnd]);

  // ─── Swipe-down to close bottom sheet ───
  const sheetRef = useRef<HTMLDivElement>(null);
  const [sheetDragY, setSheetDragY] = useState(0);
  const touchStartY = useRef(0);
  const isDraggingSheet = useRef(false);

  const onSheetTouchStart = useCallback((e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
    isDraggingSheet.current = true;
    setSheetDragY(0);
  }, []);

  const onSheetTouchMove = useCallback((e: React.TouchEvent) => {
    if (!isDraggingSheet.current) return;
    const deltaY = e.touches[0].clientY - touchStartY.current;
    if (deltaY > 0) {
      setSheetDragY(deltaY);
    }
  }, []);

  const onSheetTouchEnd = useCallback(() => {
    isDraggingSheet.current = false;
    if (sheetDragY > 100) {
      haptic(15);
      setMobileSheetOpen(false);
    }
    setSheetDragY(0);
  }, [sheetDragY, haptic]);

  return (
    <div className="flex h-screen bg-[var(--app-bg)] text-white overflow-hidden">
      {/* ─── Floating background orbs ─── */}
      <FloatingOrbs count={4} />

      {/* ─── Command Palette (Cmd+K) ─── */}
      <CommandPalette />

      {/* ─── Mobile Bottom Sheet overlay ─── */}
      <AnimatePresence>
        {mobileSheetOpen && (
          <>
            <motion.div
              key="sheet-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[150] bg-black/50 backdrop-blur-sm md:hidden"
              onClick={() => { haptic(5); setMobileSheetOpen(false); }}
            />
            <motion.div
              key="sheet-content"
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 32, stiffness: 400, mass: 0.8 }}
              className="fixed bottom-0 left-0 right-0 z-[150] md:hidden ios-sheet-glass rounded-t-[20px] max-h-[80vh] flex flex-col"
              ref={sheetRef}
              onTouchStart={onSheetTouchStart}
              onTouchMove={onSheetTouchMove}
              onTouchEnd={onSheetTouchEnd}
              style={{
                transform: sheetDragY > 0 ? `translateY(${sheetDragY}px)` : undefined,
                transition: sheetDragY > 0 ? 'none' : undefined,
                paddingBottom: "env(safe-area-inset-bottom)",
              }}
            >
              {/* iOS-style drag handle */}
              <div className="flex justify-center pt-2.5 pb-1 cursor-grab active:cursor-grabbing">
                <div className={`h-[5px] rounded-full transition-all duration-200 ${sheetDragY > 60 ? 'bg-purple-400 w-16' : 'bg-zinc-500/40 w-9'}`} />
              </div>

              {/* Scrollable nav items — simplified iOS grouped style */}
              <div className="flex-1 overflow-y-auto px-4 pt-2 pb-4 space-y-4">
                {/* 5-Step Journey — the star of the show */}
                <div>
                  <div className="px-1 pb-2">
                    <span className="text-[11px] text-zinc-500 uppercase tracking-widest" style={{ fontWeight: 600 }}>{t("mobile.pipelineSection")}</span>
                  </div>
                  <div className="rounded-2xl overflow-hidden ios-card">
                    {moreSheetPipeline.map((item, idx) => {
                      const isActive = location.pathname === item.path;
                      const stepDone = item.step ? completedSteps.has(item.step) : false;
                      const isNext = item.step ? item.step === nextStep : false;
                      return (
                        <button
                          key={item.path}
                          onClick={() => { haptic(); navigate(item.path); }}
                          className={`ios-list-item w-full flex items-center gap-3.5 px-4 py-[14px] text-[15px] transition-all ${
                            idx < moreSheetPipeline.length - 1 ? "border-b border-white/[0.04]" : ""
                          } ${isActive ? "text-purple-400" : "text-zinc-300"}`}
                        >
                          {/* Step number badge */}
                          <div className={`w-8 h-8 rounded-[10px] flex items-center justify-center shrink-0 text-[13px] ${
                            stepDone
                              ? "bg-emerald-500/15 text-emerald-400"
                              : isActive
                              ? "bg-purple-500/15 text-purple-400"
                              : isNext
                              ? "bg-purple-500/10 text-purple-400/70 ring-1 ring-purple-500/30"
                              : "bg-white/[0.05] text-zinc-500"
                          }`} style={{ fontWeight: 700 }}>
                            {stepDone ? <Check className="w-4 h-4" /> : item.step}
                          </div>
                          <span className="flex-1 text-left" style={{ fontWeight: isActive ? 600 : 400 }}>{item.label}</span>
                          {isNext && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/15 text-purple-400" style={{ fontWeight: 600 }}>
                              {t("progress.next") || "Next"}
                            </span>
                          )}
                          {isActive && !isNext && <div className="ml-auto w-2 h-2 rounded-full bg-purple-500" />}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Tools — minimal */}
                <div>
                  <div className="px-1 pb-2">
                    <span className="text-[11px] text-zinc-500 uppercase tracking-widest" style={{ fontWeight: 600 }}>{t("mobile.toolsSection")}</span>
                  </div>
                  <div className="rounded-2xl overflow-hidden ios-card">
                    {moreSheetTools.map((item, idx) => {
                      const isActive = location.pathname === item.path;
                      return (
                        <button
                          key={item.path}
                          onClick={() => { haptic(); navigate(item.path); }}
                          className={`ios-list-item w-full flex items-center gap-3.5 px-4 py-[14px] text-[15px] transition-all ${
                            idx < moreSheetTools.length - 1 ? "border-b border-white/[0.04]" : ""
                          } ${isActive ? "text-purple-400" : "text-zinc-300"}`}
                        >
                          <div className={`w-8 h-8 rounded-[10px] flex items-center justify-center shrink-0 ${isActive ? "bg-purple-500/15" : "bg-white/[0.05]"}`}>
                            <item.icon className="w-[18px] h-[18px]" />
                          </div>
                          <span style={{ fontWeight: isActive ? 600 : 400 }}>{item.label}</span>
                          {isActive && <div className="ml-auto w-2 h-2 rounded-full bg-purple-500" />}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Account — settings + logout */}
                <div>
                  <div className="px-1 pb-2">
                    <span className="text-[11px] text-zinc-500 uppercase tracking-widest" style={{ fontWeight: 600 }}>{t("mobile.account")}</span>
                  </div>
                  <div className="rounded-2xl overflow-hidden ios-card">
                    {moreSheetAccount.map((item) => {
                      const isActive = location.pathname === item.path;
                      return (
                        <button
                          key={item.path}
                          onClick={() => { haptic(); navigate(item.path); }}
                          className={`ios-list-item w-full flex items-center gap-3.5 px-4 py-[14px] text-[15px] transition-all border-b border-white/[0.04] ${isActive ? "text-purple-400" : "text-zinc-300"}`}
                        >
                          <div className={`w-8 h-8 rounded-[10px] flex items-center justify-center shrink-0 ${isActive ? "bg-purple-500/15" : "bg-white/[0.05]"}`}>
                            <item.icon className="w-[18px] h-[18px]" />
                          </div>
                          <span style={{ fontWeight: isActive ? 600 : 400 }}>{item.label}</span>
                        </button>
                      );
                    })}
                    <button
                      onClick={() => { haptic(); setMobileSheetOpen(false); navigate("/"); }}
                      className="ios-list-item w-full flex items-center gap-3.5 px-4 py-[14px] text-[15px] text-red-400/80 transition-all"
                    >
                      <div className="w-8 h-8 rounded-[10px] flex items-center justify-center shrink-0 bg-red-500/[0.08]">
                        <LogOut className="w-[18px] h-[18px]" />
                      </div>
                      <span style={{ fontWeight: 400 }}>{t("sidebar.logout")}</span>
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ─── Desktop sidebar ─── */}
      <aside className={`liquid-glass-sidebar hidden md:flex flex-col transition-all duration-300 shrink-0 ${collapsed ? "w-16" : "w-60"}`}>
        <div className="h-16 flex items-center px-4 border-b border-white/5">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <LaunchLogo size={32} />
            {!collapsed && <span className="tracking-tight whitespace-nowrap" style={{ fontSize: "1rem", fontWeight: 700 }}>Launch OS</span>}
          </div>
        </div>
        {renderNav()}
        <div className="p-2 border-t border-white/5 space-y-1">
          <button onClick={handleToggleCollapsed} aria-label={collapsed ? t("a11y.expandSidebar") : t("a11y.collapseSidebar")}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-zinc-600 hover:text-zinc-400 hover:bg-white/[0.03] transition-all text-sm">
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            {!collapsed && <span>{t("sidebar.collapse")}</span>}
          </button>
          <button onClick={() => navigate("/")}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-red-500/60 hover:text-red-400 hover:bg-red-500/5 transition-all text-sm">
            <LogOut className="w-4 h-4" />
            {!collapsed && <span>{t("sidebar.logout")}</span>}
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col overflow-hidden">
        {/* ─── Header ─── */}
        <header className="liquid-glass h-14 md:h-16 flex items-center justify-between px-3 sm:px-6 shrink-0 relative z-20">
          <div className="flex items-center gap-2">
            {/* Mobile: Logo instead of hamburger */}
            <div className="flex md:hidden items-center gap-2">
              <LaunchLogo size={28} />
              <span className="tracking-tight" style={{ fontSize: "0.875rem", fontWeight: 700 }}>Launch OS</span>
            </div>
            <span className="text-sm text-zinc-500 hidden md:block">{t("layout.welcomeBack")}</span>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-4">
            <LangSwitcher />

            {/* ─── Mobile search button ─── */}
            <button
              onClick={() => document.dispatchEvent(new KeyboardEvent("keydown", { key: "k", metaKey: true, bubbles: true }))}
              aria-label="Search"
              className="sm:hidden w-9 h-9 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-500 hover:text-zinc-300 transition-all"
            >
              <Search className="w-4.5 h-4.5" />
            </button>

            {/* ─── Theme toggle ─── */}
            <button
              onClick={handleToggleTheme}
              aria-label={theme === "dark" ? "Switch to light theme" : "Switch to dark theme"}
              className="w-9 h-9 md:w-8 md:h-8 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-500 hover:text-zinc-300 transition-all"
            >
              <AnimatePresence mode="wait" initial={false}>
                {theme === "dark" ? (
                  <motion.div key="moon" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }} transition={{ duration: 0.2 }}>
                    <Moon className="w-4.5 h-4.5 md:w-4 md:h-4" />
                  </motion.div>
                ) : (
                  <motion.div key="sun" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }} transition={{ duration: 0.2 }}>
                    <Sun className="w-4.5 h-4.5 md:w-4 md:h-4" />
                  </motion.div>
                )}
              </AnimatePresence>
            </button>

            {/* ─── Cmd+K search hint (desktop only) ─── */}
            <button
              onClick={() => document.dispatchEvent(new KeyboardEvent("keydown", { key: "k", metaKey: true, bubbles: true }))}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-white/5 hover:border-white/10 hover:bg-white/[0.03] transition-all text-zinc-600 hover:text-zinc-400"
            >
              <Search className="w-3 h-3" />
              <span className="text-xs">Search</span>
              <kbd className="ml-1 flex items-center gap-0.5 px-1 py-0.5 rounded bg-white/5 text-[10px] text-zinc-600">
                <Command className="w-2.5 h-2.5" />K
              </kbd>
            </button>

            {/* ─── Token Balance (humanized) ─── */}
            <button
              onClick={() => navigate("/dashboard/tokens")}
              className="hidden sm:flex flex-col items-end px-2.5 sm:px-3 py-1 rounded-lg bg-purple-500/10 border border-purple-500/20 hover:bg-purple-500/15 hover:border-purple-500/30 transition-all group"
            >
              <div className="flex items-center gap-1.5">
                <Coins className="w-3.5 h-3.5 text-purple-400 group-hover:text-purple-300 transition-colors" />
                <span className="text-xs sm:text-sm text-purple-300" style={{ fontWeight: 600 }}>{tokenBalance.toLocaleString()} {t("layout.tokens")}</span>
              </div>
              <span className="text-[10px] text-purple-400/60 hidden sm:block">
                {t("tokens.generationsLeft").replace("{n}", String(Math.floor(tokenBalance / 25)))}
              </span>
            </button>

            {/* ─── Notifications Bell ─── */}
            <div className="relative" ref={notifRef}>
              <button
                onClick={() => { setShowNotifications(!showNotifications); setShowProfile(false); }}
                aria-label={t("a11y.notifications")}
                className={`w-9 h-9 md:w-8 md:h-8 rounded-lg flex items-center justify-center transition-all relative ${showNotifications ? "bg-white/10 text-white" : "hover:bg-white/5 text-zinc-500 hover:text-zinc-300"}`}
              >
                <Bell className={`w-4.5 h-4.5 md:w-4 md:h-4 ${unreadCount > 0 && !showNotifications ? "notif-bell-bounce" : ""}`} />
                {unreadCount > 0 && (
                  <div className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-purple-500 flex items-center justify-center glow-pulse">
                    <span className="text-[10px] text-white" style={{ fontWeight: 700 }}>{unreadCount}</span>
                  </div>
                )}
              </button>

              {showNotifications && (
                <div role="dialog" aria-modal="true" aria-label={t("a11y.notifications")} className="liquid-glass-modal absolute right-0 top-full mt-2 w-80 rounded-xl z-[120] overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-3 border-b border-white/5">
                    <h3 className="text-sm text-white" style={{ fontWeight: 600 }}>{t("layout.notifications")}</h3>
                    {unreadCount > 0 && (
                      <button onClick={markAllRead} className="text-[11px] text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-1">
                        <CheckCheck className="w-3 h-3" />
                        {t("layout.markAllRead")}
                      </button>
                    )}
                  </div>
                  <div className="max-h-80 overflow-y-auto">
                    {notifications.map((notif) => (
                      <button
                        key={notif.id}
                        onClick={() => markOneRead(notif.id)}
                        className={`w-full flex items-start gap-3 px-4 py-3 text-left transition-all hover:bg-white/[0.03] ${!notif.read ? "bg-purple-500/[0.04]" : ""}`}
                      >
                        <div className={`w-8 h-8 rounded-lg shrink-0 flex items-center justify-center mt-0.5 ${!notif.read ? "bg-white/[0.06]" : "bg-white/[0.03]"}`}>
                          <notif.icon className={`w-3.5 h-3.5 ${notif.color}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className={`text-xs leading-relaxed ${!notif.read ? "text-zinc-200" : "text-zinc-500"}`}>
                            {t(notif.messageKey)}
                          </p>
                          <span className="text-[10px] text-zinc-600 mt-0.5 block">{formatTime(notif.time)}</span>
                        </div>
                        {!notif.read && <div className="w-2 h-2 rounded-full bg-purple-500 shrink-0 mt-2" />}
                        {notif.read && <Check className="w-3 h-3 text-zinc-700 shrink-0 mt-1.5" />}
                      </button>
                    ))}
                  </div>
                  <div className="border-t border-white/5 px-4 py-2.5">
                    <button
                      onClick={() => { setShowNotifications(false); navigate("/dashboard/community"); }}
                      className="w-full text-center text-[11px] text-purple-400 hover:text-purple-300 transition-colors"
                    >
                      {t("layout.viewAll")} &gt;
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* ─── Messages Icon ─── */}
            <button
              onClick={() => navigate("/dashboard/messages")}
              aria-label={t("sidebar.messages")}
              className={`w-9 h-9 md:w-8 md:h-8 rounded-lg flex items-center justify-center transition-all relative ${location.pathname === "/dashboard/messages" ? "bg-white/10 text-white" : "hover:bg-white/5 text-zinc-500 hover:text-zinc-300"}`}
            >
              <MessageCircle className="w-4.5 h-4.5 md:w-4 md:h-4" />
              <div className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-cyan-500 flex items-center justify-center">
                <span className="text-[10px] text-white" style={{ fontWeight: 700 }}>3</span>
              </div>
            </button>

            {/* ─── Profile Avatar Menu ─── */}
            <div className="relative" ref={profileRef}>
              <button
                onClick={() => { setShowProfile(!showProfile); setShowNotifications(false); }}
                aria-label={t("a11y.profileMenu")}
                className={`w-9 h-9 md:w-8 md:h-8 rounded-full overflow-hidden transition-all ring-2 ${showProfile ? "ring-purple-400/50 scale-105" : "ring-transparent hover:ring-purple-400/20"}`}
              >
                <img src={getUserAvatar()} alt="Profile" className="w-full h-full object-cover" />
              </button>

              {showProfile && (
                <div className="liquid-glass-modal absolute right-0 top-full mt-2 w-56 rounded-xl z-[120] overflow-hidden">
                  <div className="px-4 py-3 border-b border-white/5">
                    <div className="flex items-center gap-3">
                      <img src={getUserAvatar()} alt="Profile" className="w-9 h-9 rounded-full object-cover shrink-0" />
                      <div className="min-w-0">
                        <p className="text-sm text-white truncate" style={{ fontWeight: 600 }}>Roman</p>
                        <p className="text-[11px] text-zinc-500 truncate">{t("layout.plan")}</p>
                      </div>
                    </div>
                    <div className="mt-2.5 px-2.5 py-1.5 rounded-lg bg-purple-500/10 border border-purple-500/15">
                      <div className="flex items-center gap-1.5">
                        <Coins className="w-3 h-3 text-purple-400" />
                        <span className="text-xs text-purple-300" style={{ fontWeight: 600 }}>{tokenBalance.toLocaleString()} {t("layout.tokens")}</span>
                      </div>
                      <div className="text-[10px] text-purple-400/60 mt-0.5 pl-[18px]">
                        {t("tokens.postsLeft").replace("{n}", String(Math.floor(tokenBalance / 15)))}
                      </div>
                    </div>
                  </div>
                  <div className="py-1.5">
                    {profileMenuItems.map((item, i) => (
                      <button
                        key={i}
                        onClick={() => { setShowProfile(false); item.action(); }}
                        className="w-full flex items-center gap-2.5 px-4 py-2.5 text-xs text-zinc-400 hover:text-zinc-200 hover:bg-white/[0.04] transition-all"
                      >
                        <item.icon className="w-3.5 h-3.5" />
                        {item.label}
                      </button>
                    ))}
                  </div>
                  <div className="border-t border-white/5 py-1.5">
                    <button
                      onClick={() => { setShowProfile(false); navigate("/"); }}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 text-xs text-red-400/70 hover:text-red-400 hover:bg-red-500/5 transition-all"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      {t("layout.logout")}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* ─── iOS-style mobile progress bar ─── */}
        <div className="md:hidden shrink-0 px-3 py-2 border-b border-white/5 bg-[var(--app-bg-80)] backdrop-blur-sm">
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-zinc-500 shrink-0" style={{ fontWeight: 600 }}>
              {pipelineCount < 5
                ? `${pipelineCount}/5`
                : t("progress.complete")}
            </span>
            <div className="flex-1 flex gap-1">
              {[1, 2, 3, 4, 5].map((step) => {
                const done = completedSteps.has(step);
                const isNextSeg = step === nextStep;
                return (
                  <div key={step} className="flex-1 h-[3px] rounded-full overflow-hidden bg-white/[0.06]">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{
                        width: done ? "100%" : isNextSeg ? "30%" : "0%",
                      }}
                      transition={{ duration: 0.5, ease: "easeOut" }}
                      className={`h-full rounded-full ${
                        done
                          ? "bg-purple-500"
                          : isNextSeg
                          ? "bg-purple-500/50"
                          : ""
                      }`}
                    />
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* ─── Offline / Back online banner ─── */}
        <AnimatePresence>
          {isOffline && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden shrink-0"
            >
              <div className="flex items-center justify-center gap-2 px-4 py-2 bg-red-500/10 border-b border-red-500/20">
                <WifiOff className="w-3.5 h-3.5 text-red-400" />
                <span className="text-xs text-red-300" style={{ fontWeight: 500 }}>{t("layout.offline")}</span>
              </div>
            </motion.div>
          )}
          {showBackOnline && !isOffline && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden shrink-0"
            >
              <div className="flex items-center justify-center gap-2 px-4 py-2 bg-emerald-500/10 border-b border-emerald-500/20">
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-xs text-emerald-300" style={{ fontWeight: 500 }}>{t("layout.backOnline")}</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ─── Main content (with bottom padding on mobile for tab bar) ─── */}
        <main
          className="flex-1 overflow-y-auto relative main-content-area"
          ref={mainRef}
          onTouchStart={combinedTouchStart}
          onTouchMove={combinedTouchMove}
          onTouchEnd={combinedTouchEnd}
        >
          {/* Safe area spacer for mobile bottom tab bar */}
          <style>{`
            @media (max-width: 767px) {
              .main-content-area { padding-bottom: calc(68px + env(safe-area-inset-bottom, 0px)); }
            }
          `}</style>
          {/* Swipe-back edge shadow indicator (mobile only) */}
          <AnimatePresence>
            {swipeBackX > 5 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: Math.min(swipeBackX / 120, 0.7) }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.1 }}
                className="fixed top-0 left-0 bottom-0 w-8 z-40 md:hidden pointer-events-none"
                style={{
                  background: "linear-gradient(90deg, rgba(139,92,246,0.15), transparent)",
                }}
              />
            )}
          </AnimatePresence>

          <div style={{
            transform: `${swipeBackX > 0 ? `translateX(${swipeBackX}px)` : ''} ${overscrollY !== 0 ? `translateY(${overscrollY}px)` : ''}`.trim() || undefined,
            transition: (swipeBackX > 0 || overscrollY !== 0) ? 'none' : 'transform 0.35s cubic-bezier(0.25, 0.1, 0.25, 1)',
          }}>
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={location.pathname}
                initial={{
                  opacity: 0,
                  x: slideDirection === "forward" ? 60 : -60,
                }}
                animate={{ opacity: 1, x: 0 }}
                exit={{
                  opacity: 0,
                  x: slideDirection === "forward" ? -30 : 30,
                }}
                transition={{
                  type: "spring",
                  stiffness: 380,
                  damping: 36,
                  mass: 0.8,
                  opacity: { duration: 0.18 },
                }}
              >
                <Suspense fallback={<PageSkeleton />}>
                  <Outlet />
                </Suspense>
              </motion.div>
            </AnimatePresence>
          </div>
        </main>

        {/* ─── Mobile Bottom Tab Bar ─── */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 ios-tab-glass" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
          <div className="flex items-stretch justify-around h-[52px]">
            {bottomTabItems.map((item) => {
              const isActive = isBottomTabActive(item.path);
              return (
                <button
                  key={item.path}
                  onClick={() => {
                    haptic();
                    if (item.badge && item.badge > 0) {
                      try { localStorage.setItem("launchapp_community_badge_seen", "1"); } catch {}
                    }
                    navigate(item.path);
                  }}
                  className="flex-1 flex flex-col items-center justify-center gap-0.5 relative"
                >
                  <div className="relative flex items-center justify-center w-10 h-7">
                    {isActive && (
                      <motion.div
                        layoutId="mobileTabPill"
                        className="absolute inset-0 rounded-full bg-purple-500/12"
                        transition={{ type: "spring", stiffness: 500, damping: 35, mass: 0.6 }}
                      />
                    )}
                    <motion.div
                      animate={{ scale: isActive ? 1 : 0.92, y: isActive ? -1 : 0 }}
                      transition={{ type: "spring", stiffness: 500, damping: 30 }}
                    >
                      <item.icon className={`w-[22px] h-[22px] transition-colors duration-150 ${isActive ? "text-purple-400" : "text-zinc-500"}`} strokeWidth={isActive ? 2.2 : 1.8} />
                    </motion.div>
                    {/* Badge indicator */}
                    {item.badge && item.badge > 0 && !isActive && (
                      <motion.span
                        initial={{ scale: 0 }}
                        animate={{ scale: [1, 1.15, 1] }}
                        transition={{
                          scale: {
                            duration: 0.3,
                            ease: "easeOut",
                          },
                        }}
                        className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-red-500 text-white text-[9px] flex items-center justify-center z-10 shadow-lg shadow-red-500/30 animate-pulse"
                        style={{ fontWeight: 700 }}
                      >
                        {item.badge > 9 ? "9+" : item.badge}
                      </motion.span>
                    )}
                  </div>
                  <span className={`text-[10px] transition-colors duration-150 ${isActive ? "text-purple-400" : "text-zinc-500"}`} style={{ fontWeight: isActive ? 600 : 400 }}>{item.label}</span>
                </button>
              );
            })}
            {/* More button */}
            <button
              onClick={() => { haptic(); setMobileSheetOpen(true); }}
              className="flex-1 flex flex-col items-center justify-center gap-0.5 relative"
            >
              <div className="relative flex items-center justify-center w-10 h-7">
                {isMoreActive && !mobileSheetOpen && (
                  <motion.div
                    layoutId="mobileTabPill"
                    className="absolute inset-0 rounded-full bg-purple-500/12"
                    transition={{ type: "spring", stiffness: 500, damping: 35, mass: 0.6 }}
                  />
                )}
                <motion.div
                  animate={{ scale: (isMoreActive || mobileSheetOpen) ? 1 : 0.92 }}
                  transition={{ type: "spring", stiffness: 500, damping: 30 }}
                >
                  <MoreHorizontal className={`w-[22px] h-[22px] transition-colors duration-150 ${(isMoreActive || mobileSheetOpen) ? "text-purple-400" : "text-zinc-500"}`} strokeWidth={(isMoreActive || mobileSheetOpen) ? 2.2 : 1.8} />
                </motion.div>
              </div>
              <span className={`text-[10px] transition-colors duration-150 ${(isMoreActive || mobileSheetOpen) ? "text-purple-400" : "text-zinc-500"}`} style={{ fontWeight: isMoreActive ? 600 : 400 }}>{t("mobile.more")}</span>
            </button>
          </div>
        </nav>
      </div>

      {/* ─── Coming Soon Feature Modal ─── */}
      <AnimatePresence>
        {comingSoonFeature && (
          <ComingSoonModal featureId={comingSoonFeature} onClose={() => setComingSoonFeature(null)} />
        )}
      </AnimatePresence>

      {/* ─── Grace Period Modal ─── */}
      <AnimatePresence>
        {graceModalSub && (
          <GracePeriodModal
            subscription={graceModalSub}
            onClose={() => setGraceModalSub(null)}
            onUpdate={() => setGraceModalSub(null)}
          />
        )}
      </AnimatePresence>

      {/* ─── Demo Tour (pitch helper) ─── */}
      <DemoTour />
    </div>
  );
}