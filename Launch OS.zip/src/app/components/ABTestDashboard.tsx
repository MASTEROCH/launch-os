import { useState, useEffect, useMemo } from "react";
import { motion } from "motion/react";
import {
  BarChart3, TrendingUp, Users, Zap, ArrowUpRight,
  RefreshCw, Trash2, FlaskConical, Eye, MousePointerClick,
  ShoppingCart, Percent, Trophy, AlertCircle,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell,
} from "recharts";
import { useI18n } from "./i18n";
import { LargeTitle } from "./LargeTitle";
import { useDocumentTitle } from "./useDocumentTitle";
import { WhyBlock } from "./WhyBlock";
import { toast } from "sonner";

interface ABEvent {
  variant: "A" | "B";
  action: string;
  plan?: string;
  timestamp: number;
}

function loadABEvents(): ABEvent[] {
  try {
    const raw = localStorage.getItem("launchapp_ab_events");
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

const CHART_COLORS = {
  A: "#8b5cf6",
  B: "#06b6d4",
};

const PLAN_COLORS = ["#a855f7", "#06b6d4", "#10b981", "#f59e0b"];

export function ABTestDashboard() {
  const { t } = useI18n();
  useDocumentTitle(t("ab.title"));
  const [events, setEvents] = useState<ABEvent[]>(loadABEvents);

  // Refresh events when tab becomes visible
  useEffect(() => {
    const handler = () => setEvents(loadABEvents());
    window.addEventListener("focus", handler);
    return () => window.removeEventListener("focus", handler);
  }, []);

  const analytics = useMemo(() => {
    const variantA = events.filter((e) => e.variant === "A");
    const variantB = events.filter((e) => e.variant === "B");

    const viewsA = variantA.filter((e) => e.action === "view_pricing").length;
    const viewsB = variantB.filter((e) => e.action === "view_pricing").length;
    const selectsA = variantA.filter((e) => e.action === "select_plan").length;
    const selectsB = variantB.filter((e) => e.action === "select_plan").length;

    const conversionA = viewsA > 0 ? (selectsA / viewsA) * 100 : 0;
    const conversionB = viewsB > 0 ? (selectsB / viewsB) * 100 : 0;

    // Plan breakdown
    const planBreakdownA: Record<string, number> = {};
    const planBreakdownB: Record<string, number> = {};
    variantA.filter((e) => e.action === "select_plan" && e.plan).forEach((e) => {
      planBreakdownA[e.plan!] = (planBreakdownA[e.plan!] || 0) + 1;
    });
    variantB.filter((e) => e.action === "select_plan" && e.plan).forEach((e) => {
      planBreakdownB[e.plan!] = (planBreakdownB[e.plan!] || 0) + 1;
    });

    // Winner determination
    const winner = conversionA > conversionB ? "A" : conversionB > conversionA ? "B" : "tie";
    const liftPercent = conversionA > 0 && conversionB > 0
      ? Math.abs(((conversionA > conversionB ? conversionA - conversionB : conversionB - conversionA) / Math.min(conversionA, conversionB)) * 100)
      : 0;

    // Statistical significance (simplified chi-square)
    const totalViews = viewsA + viewsB;
    const totalSelects = selectsA + selectsB;
    const isSignificant = totalViews >= 30 && totalSelects >= 5;

    // Timeline data (group by day)
    const dayMap: Record<string, { day: string; A: number; B: number }> = {};
    events.forEach((e) => {
      if (e.action !== "select_plan") return;
      const d = new Date(e.timestamp).toLocaleDateString("en-US", { month: "short", day: "numeric" });
      if (!dayMap[d]) dayMap[d] = { day: d, A: 0, B: 0 };
      dayMap[d][e.variant]++;
    });
    const timeline = Object.values(dayMap).slice(-7);

    // Plan preference data for pie chart
    const allPlans = new Set([...Object.keys(planBreakdownA), ...Object.keys(planBreakdownB)]);
    const planData = [...allPlans].map((plan) => ({
      name: plan.replace(/\s*Launch$/, ""),
      A: planBreakdownA[plan] || 0,
      B: planBreakdownB[plan] || 0,
      total: (planBreakdownA[plan] || 0) + (planBreakdownB[plan] || 0),
    }));

    return {
      viewsA, viewsB, selectsA, selectsB,
      conversionA, conversionB,
      winner, liftPercent, isSignificant,
      timeline, planData,
      totalEvents: events.length,
      currentVariant: (() => { try { return localStorage.getItem("launchapp_ab_pricing") || "?"; } catch { return "?"; } })(),
    };
  }, [events]);

  const handleClearData = () => {
    localStorage.removeItem("launchapp_ab_events");
    localStorage.removeItem("launchapp_ab_pricing");
    setEvents([]);
    toast.success(t("ab.cleared"));
  };

  const handleRefresh = () => {
    setEvents(loadABEvents());
    toast.success(t("ab.refreshed"));
  };

  const hasData = events.length > 0;

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-6">
      <LargeTitle
        title={t("ab.title")}
        subtitle={t("ab.subtitle")}
        badge={
          <span className="text-xs bg-purple-500/10 text-purple-400 px-2.5 py-0.5 rounded-full flex items-center gap-1" style={{ fontWeight: 600 }}>
            <FlaskConical className="w-3 h-3" />
            {t("ab.variant")}: {analytics.currentVariant}
          </span>
        }
        actions={
          <div className="flex items-center gap-2">
            <button onClick={handleRefresh} className="text-xs text-zinc-500 hover:text-zinc-300 px-3 py-2 rounded-lg border border-white/5 hover:border-white/10 transition-all flex items-center gap-1.5">
              <RefreshCw className="w-3 h-3" />{t("ab.refresh")}
            </button>
            <button onClick={handleClearData} className="text-xs text-red-400/60 hover:text-red-400 px-3 py-2 rounded-lg border border-white/5 hover:border-red-500/20 transition-all flex items-center gap-1.5">
              <Trash2 className="w-3 h-3" />{t("ab.clear")}
            </button>
          </div>
        }
      />

      {/* Why block */}
      <WhyBlock label={t("ab.whyLabel")} color="purple" variant="banner">
        {t("ab.whyExplain")}
      </WhyBlock>

      {!hasData ? (
        /* Empty state */
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-12 rounded-2xl border border-dashed border-white/5 bg-white/[0.01] text-center"
        >
          <div className="w-16 h-16 rounded-2xl bg-purple-500/10 flex items-center justify-center mx-auto mb-4">
            <BarChart3 className="w-7 h-7 text-purple-400/40" />
          </div>
          <h3 className="text-zinc-400" style={{ fontWeight: 600 }}>{t("ab.noData")}</h3>
          <p className="text-sm text-zinc-600 mt-2 max-w-md mx-auto">{t("ab.noDataDesc")}</p>
        </motion.div>
      ) : (
        <>
          {/* Winner banner */}
          {analytics.isSignificant && analytics.winner !== "tie" && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`p-4 rounded-xl border ${analytics.winner === "A" ? "border-purple-500/20 bg-purple-500/[0.04]" : "border-cyan-500/20 bg-cyan-500/[0.04]"}`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${analytics.winner === "A" ? "bg-purple-500/15" : "bg-cyan-500/15"}`}>
                  <Trophy className={`w-5 h-5 ${analytics.winner === "A" ? "text-purple-400" : "text-cyan-400"}`} />
                </div>
                <div>
                  <div className="text-sm text-white" style={{ fontWeight: 600 }}>
                    {t("ab.winnerIs")} {analytics.winner} ({analytics.winner === "A" ? t("ab.variantAName") : t("ab.variantBName")})
                  </div>
                  <div className="text-xs text-zinc-500 mt-0.5">
                    +{analytics.liftPercent.toFixed(1)}% {t("ab.lift")} · {analytics.totalEvents} {t("ab.totalEvents")}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {!analytics.isSignificant && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-amber-500/5 border border-amber-500/10">
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="text-xs text-zinc-400">{t("ab.notSignificant")}</span>
            </div>
          )}

          {/* Key metrics grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {[
              {
                label: t("ab.viewsA"),
                value: analytics.viewsA,
                sub: t("ab.variantAName"),
                icon: Eye,
                color: "purple",
              },
              {
                label: t("ab.viewsB"),
                value: analytics.viewsB,
                sub: t("ab.variantBName"),
                icon: Eye,
                color: "cyan",
              },
              {
                label: t("ab.conversionA"),
                value: `${analytics.conversionA.toFixed(1)}%`,
                sub: `${analytics.selectsA} ${t("ab.selections")}`,
                icon: Percent,
                color: "purple",
              },
              {
                label: t("ab.conversionB"),
                value: `${analytics.conversionB.toFixed(1)}%`,
                sub: `${analytics.selectsB} ${t("ab.selections")}`,
                icon: Percent,
                color: "cyan",
              },
            ].map((stat, i) => {
              const colorMap: Record<string, string> = {
                purple: "bg-purple-500/10 text-purple-400",
                cyan: "bg-cyan-500/10 text-cyan-400",
              };
              return (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="p-4 rounded-xl border border-white/5 bg-white/[0.02]"
                >
                  <div className={`w-8 h-8 rounded-lg ${colorMap[stat.color]} flex items-center justify-center mb-3`}>
                    <stat.icon className="w-4 h-4" />
                  </div>
                  <div className="text-xl text-white" style={{ fontWeight: 700 }}>{stat.value}</div>
                  <div className="text-xs text-zinc-500 mt-0.5">{stat.label}</div>
                  <div className="text-xs text-zinc-600 mt-0.5">{stat.sub}</div>
                </motion.div>
              );
            })}
          </div>

          {/* Charts */}
          <div className="grid lg:grid-cols-2 gap-4 sm:gap-6">
            {/* Conversion comparison */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="p-4 sm:p-6 rounded-xl border border-white/5 bg-white/[0.02]"
            >
              <h3 className="text-white mb-1" style={{ fontWeight: 600 }}>{t("ab.conversionComparison")}</h3>
              <p className="text-xs text-zinc-500 mb-4">{t("ab.conversionComparisonDesc")}</p>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={[
                  { name: t("ab.views"), A: analytics.viewsA, B: analytics.viewsB },
                  { name: t("ab.clicks"), A: analytics.selectsA, B: analytics.selectsB },
                ]}>
                  <CartesianGrid stroke="rgba(255,255,255,0.03)" strokeDasharray="3 3" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: "#52525b", fontSize: 12 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: "#52525b", fontSize: 12 }} />
                  <Tooltip contentStyle={{ background: "#18181b", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", fontSize: "12px" }} />
                  <Bar dataKey="A" fill={CHART_COLORS.A} radius={[4, 4, 0, 0]} barSize={32} name={`${t("ab.variant")} A`} />
                  <Bar dataKey="B" fill={CHART_COLORS.B} radius={[4, 4, 0, 0]} barSize={32} name={`${t("ab.variant")} B`} />
                </BarChart>
              </ResponsiveContainer>
              <div className="flex items-center justify-center gap-6 mt-3">
                <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded-sm" style={{ background: CHART_COLORS.A }} /><span className="text-xs text-zinc-400">{t("ab.variant")} A: {t("ab.variantAName")}</span></div>
                <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded-sm" style={{ background: CHART_COLORS.B }} /><span className="text-xs text-zinc-400">{t("ab.variant")} B: {t("ab.variantBName")}</span></div>
              </div>
            </motion.div>

            {/* Plan preference */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="p-4 sm:p-6 rounded-xl border border-white/5 bg-white/[0.02]"
            >
              <h3 className="text-white mb-1" style={{ fontWeight: 600 }}>{t("ab.planPreference")}</h3>
              <p className="text-xs text-zinc-500 mb-4">{t("ab.planPreferenceDesc")}</p>
              {analytics.planData.length > 0 ? (
                <>
                  <ResponsiveContainer width="100%" height={180}>
                    <PieChart>
                      <Pie
                        data={analytics.planData}
                        dataKey="total"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={70}
                        paddingAngle={3}
                      >
                        {analytics.planData.map((_entry, index) => (
                          <Cell key={`cell-${index}`} fill={PLAN_COLORS[index % PLAN_COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ background: "#18181b", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", fontSize: "12px" }} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex flex-wrap justify-center gap-3 mt-2">
                    {analytics.planData.map((plan, i) => (
                      <div key={plan.name} className="flex items-center gap-1.5">
                        <div className="w-2.5 h-2.5 rounded-sm" style={{ background: PLAN_COLORS[i % PLAN_COLORS.length] }} />
                        <span className="text-xs text-zinc-400">{plan.name} ({plan.total})</span>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <ShoppingCart className="w-8 h-8 text-zinc-700 mb-2" />
                  <p className="text-xs text-zinc-600">{t("ab.noSelections")}</p>
                </div>
              )}
            </motion.div>
          </div>

          {/* Timeline */}
          {analytics.timeline.length > 1 && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="p-4 sm:p-6 rounded-xl border border-white/5 bg-white/[0.02]"
            >
              <h3 className="text-white mb-1" style={{ fontWeight: 600 }}>{t("ab.timeline")}</h3>
              <p className="text-xs text-zinc-500 mb-4">{t("ab.timelineDesc")}</p>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={analytics.timeline}>
                  <CartesianGrid stroke="rgba(255,255,255,0.03)" strokeDasharray="3 3" />
                  <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: "#52525b", fontSize: 11 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: "#52525b", fontSize: 11 }} />
                  <Tooltip contentStyle={{ background: "#18181b", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", fontSize: "12px" }} />
                  <Bar dataKey="A" fill={CHART_COLORS.A} radius={[3, 3, 0, 0]} stackId="a" name={`${t("ab.variant")} A`} />
                  <Bar dataKey="B" fill={CHART_COLORS.B} radius={[3, 3, 0, 0]} stackId="a" name={`${t("ab.variant")} B`} />
                </BarChart>
              </ResponsiveContainer>
            </motion.div>
          )}

          {/* Raw event log */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="p-4 sm:p-6 rounded-xl border border-white/5 bg-white/[0.02]"
          >
            <h3 className="text-white mb-3" style={{ fontWeight: 600 }}>{t("ab.eventLog")} ({events.length})</h3>
            <div className="max-h-48 overflow-y-auto space-y-1.5 scrollbar-hide">
              {events.slice().reverse().slice(0, 50).map((event, i) => (
                <div key={i} className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/[0.02] transition-colors">
                  <div className={`w-6 h-6 rounded-md flex items-center justify-center text-[10px] shrink-0 ${event.variant === "A" ? "bg-purple-500/15 text-purple-400" : "bg-cyan-500/15 text-cyan-400"}`} style={{ fontWeight: 700 }}>
                    {event.variant}
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="text-xs text-zinc-300">{event.action}</span>
                    {event.plan && <span className="text-xs text-zinc-500 ml-2">({event.plan})</span>}
                  </div>
                  <span className="text-[10px] text-zinc-600 shrink-0">
                    {new Date(event.timestamp).toLocaleTimeString()}
                  </span>
                </div>
              ))}
            </div>
          </motion.div>
        </>
      )}
    </div>
  );
}
