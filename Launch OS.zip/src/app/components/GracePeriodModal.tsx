import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Clock, CreditCard, X, Zap, Shield, Calendar, ArrowRight,
  CheckCircle, AlertTriangle, XCircle, Sparkles, Percent, Timer,
} from "lucide-react";
import { useI18n } from "./i18n";
import { toast } from "sonner";
import {
  purchaseGraceDay,
  dismissGraceOffer,
  cancelSubscription,
  getGraceTimeRemainingMs,
  getDiscountedPrice,
  GRACE_PRICE,
  FIRST_MONTH_DISCOUNT,
  type Subscription,
} from "./subscription";

interface GracePeriodModalProps {
  subscription: Subscription;
  onClose: () => void;
  onUpdate: () => void;
}

/* ─── Countdown hook ─── */
function useCountdown(sub: Subscription) {
  const [ms, setMs] = useState(() => getGraceTimeRemainingMs(sub));

  useEffect(() => {
    const id = setInterval(() => {
      const remaining = getGraceTimeRemainingMs(sub);
      setMs(remaining);
      if (remaining <= 0) clearInterval(id);
    }, 1000);
    return () => clearInterval(id);
  }, [sub]);

  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  const pad = (n: number) => String(n).padStart(2, "0");

  return {
    hours, minutes, seconds,
    formatted: `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`,
    expired: ms <= 0,
    urgent: totalSeconds < 3600, // less than 1 hour
    ms,
  };
}

export function GracePeriodModal({ subscription, onClose, onUpdate }: GracePeriodModalProps) {
  const { t } = useI18n();
  const [processing, setProcessing] = useState<"grace" | "skip" | "cancel" | null>(null);
  const [success, setSuccess] = useState<"grace" | "skip" | "cancel" | null>(null);

  const countdown = useCountdown(subscription);
  const discount = getDiscountedPrice(subscription.planId);
  const discountPercent = Math.round(FIRST_MONTH_DISCOUNT * 100);

  // Auto-activate when countdown hits 0
  useEffect(() => {
    if (countdown.expired && !processing && !success) {
      dismissGraceOffer();
      toast.info(t("trial.transitionedTitle"), { duration: 6000 });
      onUpdate();
      onClose();
    }
  }, [countdown.expired]); // eslint-disable-line react-hooks/exhaustive-deps

  const handlePurchaseGrace = useCallback(async () => {
    setProcessing("grace");
    await new Promise((r) => setTimeout(r, 1200));
    purchaseGraceDay();
    setProcessing(null);
    setSuccess("grace");
    toast.success(t("grace.purchasedToast"), { duration: 5000 });
    setTimeout(() => { onUpdate(); onClose(); }, 1800);
  }, [t, onUpdate, onClose]);

  const handleSkip = useCallback(async () => {
    setProcessing("skip");
    await new Promise((r) => setTimeout(r, 800));
    dismissGraceOffer();
    setProcessing(null);
    setSuccess("skip");
    toast.info(t("grace.discountActivatedToast").replace("{pct}", `${discountPercent}`).replace("{price}", `$${discount.discounted}`), { duration: 6000 });
    setTimeout(() => { onUpdate(); onClose(); }, 1500);
  }, [t, onUpdate, onClose, discountPercent, discount.discounted]);

  const handleCancel = useCallback(async () => {
    setProcessing("cancel");
    await new Promise((r) => setTimeout(r, 800));
    cancelSubscription();
    setProcessing(null);
    setSuccess("cancel");
    toast.success(t("grace.cancelledToast"), { duration: 5000 });
    setTimeout(() => { onUpdate(); onClose(); }, 1500);
  }, [t, onUpdate, onClose]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md"
      onClick={(e) => e.target === e.currentTarget && !processing && !success && onClose()}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0, y: 10 }}
        transition={{ type: "spring", damping: 28, stiffness: 350 }}
        className="w-full max-w-md rounded-2xl overflow-hidden relative"
        role="dialog"
        aria-modal="true"
        aria-label={t("grace.title")}
        style={{
          background: "linear-gradient(135deg, rgba(20,20,25,0.98), rgba(15,15,20,0.98))",
          border: "1px solid rgba(255,255,255,0.08)",
          boxShadow: "0 25px 50px -12px rgba(0,0,0,0.6), 0 0 80px rgba(139,92,246,0.08), inset 0 1px 0 rgba(255,255,255,0.05)",
        }}
      >
        {/* Decorative glow */}
        <div className="absolute -top-24 -right-24 w-48 h-48 rounded-full bg-amber-500/8 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-40 h-40 rounded-full bg-purple-500/6 blur-3xl pointer-events-none" />

        {/* Success overlay */}
        <AnimatePresence>
          {success && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-[#0e0e12]/95 backdrop-blur-sm"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 300, delay: 0.1 }}
              >
                {success === "grace" && <CheckCircle className="w-12 h-12 text-emerald-400" />}
                {success === "skip" && <Percent className="w-12 h-12 text-cyan-400" />}
                {success === "cancel" && <XCircle className="w-12 h-12 text-red-400" />}
              </motion.div>
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.25 }}
                className="text-white text-center px-6"
                style={{ fontWeight: 600 }}
              >
                {success === "grace" && t("grace.purchasedSuccess")}
                {success === "skip" && t("grace.discountSuccess").replace("{pct}", `${discountPercent}`)}
                {success === "cancel" && t("grace.cancelledSuccess")}
              </motion.p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Close button */}
        {!processing && !success && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-10 w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-zinc-500 hover:text-zinc-300 transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        <div className="relative z-10 p-6">
          {/* Header */}
          <div className="text-center mb-4">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1 }}
              className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500/20 to-orange-500/20 border border-amber-500/20 mb-4"
            >
              <Clock className="w-7 h-7 text-amber-400" />
            </motion.div>

            <motion.h2
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="text-xl text-white mb-2"
              style={{ fontWeight: 700 }}
            >
              {t("grace.title")}
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-sm text-zinc-400 max-w-xs mx-auto leading-relaxed"
            >
              {t("grace.subtitle")}
            </motion.p>
          </div>

          {/* ═══ Countdown Timer ═══ */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.25 }}
            className="mb-5"
          >
            <motion.div
              animate={countdown.urgent ? {
                boxShadow: [
                  "0 0 0px rgba(239,68,68,0)",
                  "0 0 20px rgba(239,68,68,0.15)",
                  "0 0 0px rgba(239,68,68,0)",
                ],
                scale: [1, 1.012, 1],
              } : {}}
              transition={countdown.urgent ? {
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              } : {}}
              className={`relative p-3.5 rounded-xl border overflow-hidden ${
                countdown.urgent
                  ? "border-red-500/25 bg-red-500/[0.04]"
                  : "border-amber-500/15 bg-amber-500/[0.03]"
              }`}
            >
              {/* Urgent pulsing glow overlay */}
              {countdown.urgent && (
                <motion.div
                  className="absolute inset-0 rounded-xl pointer-events-none"
                  animate={{
                    background: [
                      "radial-gradient(ellipse at center, rgba(239,68,68,0.0) 0%, transparent 70%)",
                      "radial-gradient(ellipse at center, rgba(239,68,68,0.06) 0%, transparent 70%)",
                      "radial-gradient(ellipse at center, rgba(239,68,68,0.0) 0%, transparent 70%)",
                    ],
                  }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                />
              )}

              {/* Animated progress bar behind */}
              <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-white/[0.03]">
                <motion.div
                  className={`h-full ${countdown.urgent ? "bg-red-500/60" : "bg-amber-500/40"}`}
                  animate={{ width: `${(countdown.ms / (24 * 60 * 60 * 1000)) * 100}%` }}
                  transition={{ duration: 1, ease: "linear" }}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                    countdown.urgent ? "bg-red-500/15" : "bg-amber-500/10"
                  }`}>
                    <Timer className={`w-3.5 h-3.5 ${countdown.urgent ? "text-red-400" : "text-amber-400"}`} />
                  </div>
                  <div>
                    <p className={`text-[10px] uppercase tracking-wider ${countdown.urgent ? "text-red-400/70" : "text-amber-400/70"}`} style={{ fontWeight: 600 }}>
                      {t("grace.countdownLabel")}
                    </p>
                    <p className={`text-[10px] ${countdown.urgent ? "text-red-500/40" : "text-amber-500/40"}`}>
                      {t("grace.countdownSub")}
                    </p>
                  </div>
                </div>

                {/* Digital clock display */}
                <div className="flex items-center gap-1">
                  {countdown.formatted.split("").map((char, i) => (
                    <motion.span
                      key={i}
                      animate={countdown.urgent && char !== ":" ? {
                        scale: [1, 1.08, 1],
                      } : {}}
                      transition={countdown.urgent && char !== ":" ? {
                        duration: 1,
                        repeat: Infinity,
                        ease: "easeInOut",
                        delay: i * 0.06,
                      } : {}}
                      className={`${
                        char === ":"
                          ? `text-xs ${countdown.urgent ? "text-red-500/40" : "text-amber-500/40"}`
                          : `inline-flex items-center justify-center w-[22px] h-[28px] rounded-md text-sm ${
                              countdown.urgent
                                ? "bg-red-500/10 text-red-300 border border-red-500/15"
                                : "bg-amber-500/8 text-amber-300 border border-amber-500/10"
                            }`
                      }`}
                      style={char !== ":" ? { fontWeight: 700, fontVariantNumeric: "tabular-nums" } : { fontWeight: 400 }}
                    >
                      {char}
                    </motion.span>
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>

          {/* Option cards */}
          <div className="space-y-3">
            {/* ── Option 1: Buy grace day ── */}
            <motion.button
              initial={{ opacity: 0, x: -15 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              onClick={handlePurchaseGrace}
              disabled={!!processing}
              className="w-full text-left group"
            >
              <div className="relative p-4 rounded-xl border border-emerald-500/20 bg-gradient-to-r from-emerald-500/[0.06] to-cyan-500/[0.04] hover:from-emerald-500/[0.1] hover:to-cyan-500/[0.07] transition-all overflow-hidden">
                {/* Recommended badge */}
                <div className="absolute top-0 right-0">
                  <div className="flex items-center gap-1 px-2.5 py-0.5 bg-emerald-500/15 text-emerald-400 text-[9px] rounded-bl-lg border-l border-b border-emerald-500/15" style={{ fontWeight: 700 }}>
                    <Sparkles className="w-2.5 h-2.5" />
                    {t("grace.recommended")}
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 border border-emerald-500/15 flex items-center justify-center shrink-0 mt-0.5">
                    {processing === "grace" ? (
                      <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                        <Sparkles className="w-5 h-5 text-emerald-400" />
                      </motion.div>
                    ) : (
                      <Calendar className="w-5 h-5 text-emerald-400" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0 pr-2">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-white text-sm" style={{ fontWeight: 600 }}>
                        {t("grace.buyTitle")}
                      </span>
                    </div>
                    <p className="text-xs text-zinc-400 leading-relaxed mb-2">
                      {t("grace.buyDesc")}
                    </p>
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/15">
                      <CreditCard className="w-3 h-3 text-emerald-400" />
                      <span className="text-emerald-400 text-xs" style={{ fontWeight: 700 }}>${GRACE_PRICE}</span>
                      <span className="text-zinc-500 text-[10px]">· {t("grace.oneTimeCharge")}</span>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-emerald-500/40 group-hover:text-emerald-400 transition-colors shrink-0 mt-3" />
                </div>
              </div>
            </motion.button>

            {/* ── Option 2: Activate now with discount ── */}
            <motion.button
              initial={{ opacity: 0, x: -15 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              onClick={handleSkip}
              disabled={!!processing}
              className="w-full text-left group"
            >
              <div className="relative p-4 rounded-xl border border-cyan-500/15 bg-gradient-to-r from-cyan-500/[0.04] to-purple-500/[0.03] hover:from-cyan-500/[0.08] hover:to-purple-500/[0.06] hover:border-cyan-500/25 transition-all overflow-hidden">
                {/* Discount badge */}
                <div className="absolute top-0 right-0">
                  <div className="flex items-center gap-1 px-2.5 py-0.5 bg-cyan-500/15 text-cyan-400 text-[9px] rounded-bl-lg border-l border-b border-cyan-500/15" style={{ fontWeight: 700 }}>
                    <Percent className="w-2.5 h-2.5" />
                    -{discountPercent}% {t("grace.firstMonth")}
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/15 to-purple-500/15 border border-cyan-500/10 flex items-center justify-center shrink-0 mt-0.5">
                    {processing === "skip" ? (
                      <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                        <Zap className="w-5 h-5 text-cyan-400" />
                      </motion.div>
                    ) : (
                      <Zap className="w-5 h-5 text-cyan-400" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0 pr-2">
                    <span className="text-white text-sm" style={{ fontWeight: 600 }}>
                      {t("grace.skipTitle")}
                    </span>
                    <p className="text-xs text-zinc-400 leading-relaxed mt-0.5">
                      {t("grace.discountDesc")}
                    </p>
                    {/* Price display with strikethrough */}
                    <div className="flex items-center gap-2 mt-2">
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cyan-500/10 border border-cyan-500/15">
                        <span className="text-zinc-500 text-xs line-through">${discount.original}</span>
                        <span className="text-cyan-400 text-xs" style={{ fontWeight: 700 }}>${discount.discounted}</span>
                        <span className="text-zinc-500 text-[10px]">/{t("grace.perMonth")}</span>
                      </div>
                      <span className="text-emerald-400/80 text-[10px]" style={{ fontWeight: 600 }}>
                        {t("grace.save")} ${discount.savings}
                      </span>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-cyan-500/40 group-hover:text-cyan-400 transition-colors shrink-0 mt-3" />
                </div>
              </div>
            </motion.button>

            {/* ── Option 3: Cancel subscription ── */}
            <motion.button
              initial={{ opacity: 0, x: -15 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
              onClick={handleCancel}
              disabled={!!processing}
              className="w-full text-left group"
            >
              <div className="p-4 rounded-xl border border-red-500/10 bg-red-500/[0.02] hover:bg-red-500/[0.05] hover:border-red-500/15 transition-all">
                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-red-500/[0.06] border border-red-500/10 flex items-center justify-center shrink-0 mt-0.5">
                    {processing === "cancel" ? (
                      <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                        <AlertTriangle className="w-5 h-5 text-red-400" />
                      </motion.div>
                    ) : (
                      <XCircle className="w-5 h-5 text-red-400/60" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0 pr-2">
                    <span className="text-red-400/80 text-sm" style={{ fontWeight: 600 }}>
                      {t("grace.cancelTitle")}
                    </span>
                    <p className="text-xs text-zinc-600 leading-relaxed mt-0.5">
                      {t("grace.cancelDesc")}
                    </p>
                  </div>
                </div>
              </div>
            </motion.button>
          </div>

          {/* Security footer */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="flex items-center justify-center gap-2 mt-5 text-[10px] text-zinc-600"
          >
            <Shield className="w-3 h-3 text-emerald-500/40" />
            <span>{t("grace.secure")}</span>
            <span>·</span>
            <span>**** {subscription.cardLast4}</span>
          </motion.div>
        </div>
      </motion.div>
    </motion.div>
  );
}