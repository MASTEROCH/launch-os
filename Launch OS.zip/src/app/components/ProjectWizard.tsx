import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { useNavigate } from "react-router";
import {
  ArrowLeft, ArrowRight, Rocket, Check, Globe, Tag, Users,
  Target, Sparkles, Zap, Radio, Link2, RefreshCw, Shield, CheckCircle,
  Package, FileText, MessageSquare, HelpCircle, Lightbulb,
} from "lucide-react";
import { useI18n } from "./i18n";
import { updateProgress, loadProgress } from "./user-progress";
import { useDocumentTitle } from "./useDocumentTitle";
import { toast as sonnerToast } from "sonner";
import confetti from "canvas-confetti";
import { WhyBlock } from "./WhyBlock";

const categories = ["AI Tool", "SaaS", "Mobile App", "Game", "Web Platform", "Creative Product", "Startup"];

/* ─── A/B test for pricing card order ─── */
function getABVariant(): "A" | "B" {
  try {
    const saved = localStorage.getItem("launchapp_ab_pricing");
    if (saved === "A" || saved === "B") return saved;
    const variant = Math.random() < 0.5 ? "A" : "B";
    localStorage.setItem("launchapp_ab_pricing", variant);
    return variant as "A" | "B";
  } catch {
    return "A";
  }
}
const abVariant = getABVariant();

/* ─── A/B analytics tracking ─── */
interface ABEvent {
  variant: "A" | "B";
  action: string;
  plan?: string;
  timestamp: number;
}

function trackABEvent(action: string, plan?: string) {
  try {
    const raw = localStorage.getItem("launchapp_ab_events");
    const events: ABEvent[] = raw ? JSON.parse(raw) : [];
    events.push({ variant: abVariant, action, plan, timestamp: Date.now() });
    localStorage.setItem("launchapp_ab_events", JSON.stringify(events));
  } catch {}
}

// Track page view on load
try { trackABEvent("view_pricing"); } catch {}

/* ─── Wizard channel data (compact) ─── */
interface WizardChannel {
  id: string;
  name: string;
  icon: string;
  tier: "auto" | "assisted" | "managed";
  color: string;
  bgColor: string;
}

const wizardChannels: WizardChannel[] = [
  { id: "twitter", name: "Twitter / X", icon: "X", tier: "auto", color: "text-white", bgColor: "bg-zinc-800" },
  { id: "linkedin", name: "LinkedIn", icon: "in", tier: "auto", color: "text-[#0A66C2]", bgColor: "bg-[#0A66C2]/10" },
  { id: "producthunt", name: "Product Hunt", icon: "PH", tier: "auto", color: "text-[#DA552F]", bgColor: "bg-[#DA552F]/10" },
  { id: "facebook", name: "Facebook", icon: "f", tier: "auto", color: "text-[#1877F2]", bgColor: "bg-[#1877F2]/10" },
  { id: "instagram", name: "Instagram", icon: "IG", tier: "auto", color: "text-[#E4405F]", bgColor: "bg-[#E4405F]/10" },
  { id: "reddit", name: "Reddit", icon: "R", tier: "assisted", color: "text-[#FF4500]", bgColor: "bg-[#FF4500]/10" },
  { id: "hackernews", name: "Hacker News", icon: "Y", tier: "assisted", color: "text-[#FF6600]", bgColor: "bg-[#FF6600]/10" },
  { id: "telegram", name: "Telegram", icon: "TG", tier: "assisted", color: "text-[#26A5E4]", bgColor: "bg-[#26A5E4]/10" },
];

const managedChannels: WizardChannel[] = [
  { id: "email-pr", name: "Email PR", icon: "PR", tier: "managed", color: "text-purple-400", bgColor: "bg-purple-500/10" },
  { id: "catalogs", name: "Startup Catalogs", icon: "CT", tier: "managed", color: "text-cyan-400", bgColor: "bg-cyan-500/10" },
  { id: "seo", name: "SEO Engine", icon: "SE", tier: "managed", color: "text-emerald-400", bgColor: "bg-emerald-500/10" },
  { id: "newsletters", name: "Newsletters", icon: "NL", tier: "managed", color: "text-amber-400", bgColor: "bg-amber-500/10" },
  { id: "forums", name: "Niche Forums", icon: "FM", tier: "managed", color: "text-rose-400", bgColor: "bg-rose-500/10" },
];

/* ─── Helper: load/save channel state ─── */
function loadChannelState(): Record<string, string> {
  try {
    const raw = localStorage.getItem("launchapp_channels");
    if (raw) return JSON.parse(raw);
  } catch {}
  return {};
}
function saveChannelState(state: Record<string, string>) {
  localStorage.setItem("launchapp_channels", JSON.stringify(state));
}

export function ProjectWizard() {
  const navigate = useNavigate();
  const { t } = useI18n();
  useDocumentTitle(t("sidebar.newProject"));
  const [step, setStep] = useState(0);
  // Pre-fill from onboarding data to avoid double data entry
  const [form, setForm] = useState(() => {
    const p = loadProgress();
    return {
      name: p.projectName || "",
      url: p.projectUrl || "",
      description: p.projectDescription || "",
      category: p.projectCategory || "",
      audience: p.audience || "",
      goal: p.goal || "",
      strategy: "",
    };
  });

  // Channel connection state for step 2
  const [channelStates, setChannelStates] = useState<Record<string, "disconnected" | "connecting" | "connected">>(() => {
    const saved = loadChannelState();
    const result: Record<string, string> = {};
    wizardChannels.forEach((ch) => {
      const s = saved[ch.id];
      result[ch.id] = s === "connected" || s === "active" ? "connected" : "disconnected";
    });
    return result as Record<string, "disconnected" | "connecting" | "connected">;
  });

  const connectedCount = Object.values(channelStates).filter((s) => s === "connected").length;

  const handleConnectChannel = (id: string, name: string) => {
    setChannelStates((prev) => ({ ...prev, [id]: "connecting" }));
    setTimeout(() => {
      setChannelStates((prev) => {
        const next = { ...prev, [id]: "connected" as const };
        // Persist to localStorage
        const saved = loadChannelState();
        saved[id] = "connected";
        saveChannelState(saved);
        return next;
      });
      sonnerToast.success(`${name} — ${t("wizard.connected")}!`);
    }, 1800);
  };

  const handleDisconnectChannel = (id: string) => {
    setChannelStates((prev) => {
      const next = { ...prev, [id]: "disconnected" as const };
      const saved = loadChannelState();
      saved[id] = "disconnected";
      saveChannelState(saved);
      return next;
    });
  };

  const strategies = [
    {
      name: t("wizard.starterLaunch"),
      desc: t("wizard.starterDesc"),
      features: t("wizard.starterFeatures"),
      tokens: 100,
      channels: "50+",
      price: "$19",
      color: "purple",
      gradient: "from-purple-600 to-violet-600",
      border: "border-purple-500/30",
      bg: "bg-purple-500/5",
      iconBg: "bg-purple-500/15",
      iconColor: "text-purple-400",
    },
    {
      name: t("wizard.growthLaunch"),
      desc: t("wizard.growthDesc"),
      features: t("wizard.growthFeatures"),
      tokens: 300,
      channels: "200+",
      price: "$49",
      color: "cyan",
      popular: true,
      gradient: "from-cyan-600 to-blue-600",
      border: "border-cyan-500/30",
      bg: "bg-cyan-500/5",
      iconBg: "bg-cyan-500/15",
      iconColor: "text-cyan-400",
    },
    {
      name: t("wizard.viralLaunch"),
      desc: t("wizard.viralDesc"),
      features: t("wizard.viralFeatures"),
      tokens: 500,
      channels: "All",
      price: "$129",
      color: "emerald",
      gradient: "from-emerald-600 to-teal-600",
      border: "border-emerald-500/30",
      bg: "bg-emerald-500/5",
      iconBg: "bg-emerald-500/15",
      iconColor: "text-emerald-400",
    },
  ];

  // ─── Package generation state (step 2) ───
  const [packGenerating, setPackGenerating] = useState(false);
  const [packReady, setPackReady] = useState(false);
  const packItems = [
    { key: "oneLiner", label: "One-liner", icon: Zap, color: "purple" },
    { key: "elevatorPitch", label: "Elevator Pitch", icon: Rocket, color: "violet" },
    { key: "landingCopy", label: "Landing Copy", icon: FileText, color: "cyan" },
    { key: "offer", label: "Offer", icon: Package, color: "emerald" },
    { key: "faq", label: "FAQ", icon: HelpCircle, color: "amber" },
    { key: "platformContent", label: "Platform Posts", icon: MessageSquare, color: "pink" },
  ];
  const [packProgress, setPackProgress] = useState<string[]>([]);

  const handleGeneratePack = () => {
    setPackGenerating(true);
    setPackProgress([]);
    let i = 0;
    const interval = setInterval(() => {
      if (i < packItems.length) {
        const currentKey = packItems[i].key;
        setPackProgress((prev) => [...prev, currentKey]);
        i++;
      } else {
        clearInterval(interval);
        setPackGenerating(false);
        setPackReady(true);
        // Wire generated content keys to PackageBuilder via localStorage
        try {
          const allPackKeys = ["oneLiner", "elevatorPitch", "landingCopy", "offer", "faq", "founderBio", "productHunt", "twitter", "linkedin", "telegram", "emailOutreach"];
          localStorage.setItem("launchapp_package_generated", JSON.stringify(allPackKeys));
        } catch {}
        sonnerToast.success(t("wizard.packSaved"));
      }
    }, 600);
  };

  const totalSteps = 5;

  // Phase labels for the progress bar
  const phases = [
    { label: t("wizard.clarifyPhase"), steps: [0, 1] },
    { label: t("wizard.packagePhase"), steps: [2] },
    { label: t("wizard.routePhase"), steps: [3, 4] },
  ];

  const handleNext = () => {
    if (step < totalSteps - 1) setStep(step + 1);
    else {
      // Save project to shared progress (including audience/goal for downstream use)
      updateProgress({
        projectCreated: true,
        projectName: form.name || "My Project",
        projectCategory: form.category || "Startup",
        projectUrl: form.url,
        projectDescription: form.description,
        audience: form.audience,
        goal: form.goal,
        channelsConnected: connectedCount + managedChannels.length,
        lastCompletedStep: 3, // project + package + channels done
      });
      navigate("/dashboard/launch");
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  };

  const handleSkipChannels = () => {
    updateProgress({ channelsConnected: managedChannels.length });
    setStep(step + 1);
  };

  const stepLabels = [
    t("wizard.productDetails"),
    t("wizard.targetGoals"),
    t("wizard.generatePack"),
    t("wizard.connectChannels"),
    t("wizard.chooseStrategy"),
  ];

  return (
    <div className="p-4 sm:p-6 max-w-3xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <button onClick={() => (step > 0 ? setStep(step - 1) : navigate("/dashboard"))} className="w-8 h-8 rounded-lg border border-white/10 flex items-center justify-center hover:bg-white/5 transition-colors">
          <ArrowLeft className="w-4 h-4 text-zinc-400" />
        </button>
        <div>
          <h1 className="text-xl tracking-tight" style={{ fontWeight: 700 }}>{t("wizard.title")}</h1>
          <p className="text-sm text-zinc-500">{t("wizard.step")} {step + 1} {t("wizard.of")} {totalSteps} — {stepLabels[step]}</p>
        </div>
      </div>

      {/* Phase labels */}
      <div className="flex gap-1 mb-3">
        {phases.map((phase, pi) => {
          const isActive = phase.steps.includes(step);
          const isDone = phase.steps.every((s) => s < step);
          return (
            <div key={pi} className="flex-1 text-center">
              <span className={`text-[10px] uppercase tracking-wider transition-colors ${isActive ? "text-purple-400" : isDone ? "text-emerald-400/60" : "text-zinc-600"}`} style={{ fontWeight: 600 }}>
                {isDone && <Check className="w-2.5 h-2.5 inline mr-0.5" />}
                {phase.label}
              </span>
            </div>
          );
        })}
      </div>

      {/* Progress bar */}
      <div className="flex gap-2 mb-10">
        {Array.from({ length: totalSteps }).map((_, s) => (
          <div key={s} className="flex-1 h-1 rounded-full bg-white/5 overflow-hidden">
            <div className={`h-full rounded-full transition-all duration-500 ${s <= step ? "bg-purple-500 w-full" : "w-0"}`} />
          </div>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {/* Step 0: Product Details */}
        {step === 0 && (
          <motion.div key="s0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center"><Rocket className="w-4 h-4 text-purple-400" /></div>
              <span className="text-white" style={{ fontWeight: 600 }}>{t("wizard.productDetails")}</span>
            </div>
            <WhyBlock label={t("why.step0Label")} color="purple" variant="banner">
              {t("why.step0")}
            </WhyBlock>
            <div>
              <label className="text-sm text-zinc-400 mb-1.5 block">{t("wizard.projectName")} *</label>
              <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder={t("wizard.projectNamePh")} className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors" />
            </div>
            <div>
              <label className="text-sm text-zinc-400 mb-1.5 block"><Globe className="w-3.5 h-3.5 inline mr-1" />{t("wizard.websiteUrl")}</label>
              <input value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} placeholder="https://yourproduct.com" className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors" />
              <WhyBlock label={t("why.urlLabel")} color="purple">
                {t("why.url")}
              </WhyBlock>
            </div>
            <div>
              <label className="text-sm text-zinc-400 mb-1.5 block">{t("wizard.shortDesc")} *</label>
              <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder={t("wizard.shortDescPh")} rows={3} className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors resize-none" />
              <WhyBlock label={t("why.descLabel")} color="purple">
                {t("why.desc")}
              </WhyBlock>
            </div>
            <div>
              <label className="text-sm text-zinc-400 mb-2 block"><Tag className="w-3.5 h-3.5 inline mr-1" />{t("wizard.category")} *</label>
              <div className="flex flex-wrap gap-2">
                {categories.map((c) => (
                  <button key={c} onClick={() => setForm({ ...form, category: c })} className={`px-4 py-2 rounded-lg text-sm transition-all ${form.category === c ? "bg-purple-500/20 text-purple-300 border border-purple-500/30" : "bg-white/[0.03] text-zinc-500 border border-white/5 hover:border-white/10"}`}>{c}</button>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* Step 1: Target & Goals */}
        {step === 1 && (
          <motion.div key="s1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-cyan-500/10 flex items-center justify-center"><Users className="w-4 h-4 text-cyan-400" /></div>
              <span className="text-white" style={{ fontWeight: 600 }}>{t("wizard.targetGoals")}</span>
            </div>
            <WhyBlock label={t("why.step1Label")} color="cyan" variant="banner">
              {t("why.step1")}
            </WhyBlock>
            <div>
              <label className="text-sm text-zinc-400 mb-1.5 block"><Users className="w-3.5 h-3.5 inline mr-1" />{t("wizard.targetAudience")} *</label>
              <input value={form.audience} onChange={(e) => setForm({ ...form, audience: e.target.value })} placeholder={t("wizard.targetAudiencePh")} className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors" />
              <WhyBlock label={t("why.audienceLabel")} color="cyan">
                {t("why.audience")}
              </WhyBlock>
            </div>
            <div>
              <label className="text-sm text-zinc-400 mb-1.5 block"><Target className="w-3.5 h-3.5 inline mr-1" />{t("wizard.launchGoal")} *</label>
              <textarea value={form.goal} onChange={(e) => setForm({ ...form, goal: e.target.value })} placeholder={t("wizard.launchGoalPh")} rows={3} className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors resize-none" />
              <WhyBlock label={t("why.goalLabel")} color="cyan">
                {t("why.goal")}
              </WhyBlock>
            </div>
          </motion.div>
        )}

        {/* Step 2: Generate Content Pack (Package) */}
        {step === 2 && (
          <motion.div key="s2pkg" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-violet-500/10 flex items-center justify-center"><Package className="w-4 h-4 text-violet-400" /></div>
              <div>
                <span className="text-white" style={{ fontWeight: 600 }}>{t("wizard.generatePack")}</span>
                <p className="text-xs text-zinc-500 mt-0.5">{t("wizard.generatePackDesc")}</p>
              </div>
            </div>
            <WhyBlock label={t("why.step2Label")} color="violet" variant="banner">
              {t("why.step2")}
            </WhyBlock>

            {/* Content items */}
            <div className="space-y-2">
              {packItems.map((item, idx) => {
                const done = packProgress.includes(item.key);
                const isGenerating = packGenerating && !done && packProgress.length === idx;
                return (
                  <motion.div
                    key={item.key}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    className={`flex items-center gap-3 p-3.5 rounded-xl border transition-all ${done ? "border-emerald-500/20 bg-emerald-500/[0.03]" : isGenerating ? "border-purple-500/20 bg-purple-500/[0.03]" : "border-white/5 bg-white/[0.02]"}`}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${done ? "bg-emerald-500/10" : `bg-${item.color}-500/10`}`}>
                      {done ? (
                        <Check className="w-4 h-4 text-emerald-400" />
                      ) : isGenerating ? (
                        <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                          <Sparkles className="w-4 h-4 text-purple-400" />
                        </motion.div>
                      ) : (
                        <item.icon className={`w-4 h-4 text-${item.color}-400`} />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className={`text-sm ${done ? "text-emerald-300" : "text-zinc-300"}`} style={{ fontWeight: 500 }}>{item.label}</div>
                      {isGenerating && <div className="text-[10px] text-purple-400 mt-0.5">{t("wizard.generatingPack")}</div>}
                    </div>
                    {done && <span className="text-[10px] text-emerald-400/80 px-2 py-0.5 rounded-full bg-emerald-500/10 flex items-center gap-0.5"><Check className="w-3 h-3" /></span>}
                  </motion.div>
                );
              })}
            </div>

            {/* Generate / Ready state */}
            {!packReady && !packGenerating && (
              <motion.button
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                onClick={handleGeneratePack}
                className="w-full py-4 rounded-xl bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white text-sm transition-all flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                {t("wizard.generatePack")}
              </motion.button>
            )}

            {packGenerating && (
              <div className="flex items-center justify-center gap-3 py-4">
                <div className="w-5 h-5 rounded-full border-2 border-purple-400 border-t-transparent animate-spin" />
                <span className="text-sm text-zinc-400">{t("wizard.generatingPack")}</span>
              </div>
            )}

            {packReady && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-5 rounded-xl border border-emerald-500/20 bg-emerald-500/[0.03] text-center space-y-3"
              >
                <div className="w-12 h-12 rounded-full bg-emerald-500/15 flex items-center justify-center mx-auto">
                  <CheckCircle className="w-6 h-6 text-emerald-400" />
                </div>
                <div className="text-sm text-emerald-300" style={{ fontWeight: 600 }}>{t("wizard.packReady")}</div>
                <p className="text-xs text-zinc-500">{t("wizard.packReadyDesc")}</p>
                <button
                  onClick={() => navigate("/dashboard/package")}
                  className="text-xs text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-1 mx-auto"
                >
                  <Lightbulb className="w-3 h-3" />
                  {t("wizard.viewInBuilder")}
                </button>
              </motion.div>
            )}
          </motion.div>
        )}

        {/* Step 3: Connect Channels */}
        {step === 3 && (
          <motion.div key="s3ch" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center"><Radio className="w-4 h-4 text-amber-400" /></div>
                <span className="text-white" style={{ fontWeight: 600 }}>{t("wizard.connectChannels")}</span>
              </div>
              {connectedCount > 0 && (
                <span className="text-xs text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full flex items-center gap-1" style={{ fontWeight: 600 }}>
                  <CheckCircle className="w-3 h-3" />
                  {connectedCount} {t("wizard.channelsConnected")}
                </span>
              )}
            </div>
            <p className="text-xs text-zinc-500">{t("wizard.connectChannelsSub")}</p>
            <WhyBlock label={t("why.step3Label")} color="amber" variant="banner">
              {t("why.step3")}
            </WhyBlock>

            {/* Auto-post & Assisted channels */}
            <div className="space-y-2">
              <div className="text-[10px] text-zinc-600 uppercase tracking-wider px-1" style={{ fontWeight: 600 }}>
                {t("ch.tierAuto")} & {t("ch.tierAssisted")}
              </div>
              <div className="grid sm:grid-cols-2 gap-2">
                {wizardChannels.map((ch) => {
                  const state = channelStates[ch.id] || "disconnected";
                  return (
                    <motion.div
                      key={ch.id}
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                        state === "connected"
                          ? "border-emerald-500/20 bg-emerald-500/[0.03]"
                          : state === "connecting"
                          ? "border-purple-500/20 bg-purple-500/[0.03]"
                          : "border-white/5 bg-white/[0.02] hover:border-white/10"
                      }`}
                    >
                      <div className={`w-9 h-9 rounded-lg ${ch.bgColor} flex items-center justify-center text-xs ${ch.color} shrink-0`} style={{ fontWeight: 800 }}>
                        {ch.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm text-white" style={{ fontWeight: 500 }}>{ch.name}</div>
                        <div className="text-[10px] text-zinc-600">
                          {ch.tier === "auto" ? t("ch.autoLabel") : t("ch.assistedLabel")}
                        </div>
                      </div>
                      {state === "disconnected" && (
                        <button
                          onClick={() => handleConnectChannel(ch.id, ch.name)}
                          className="text-xs text-purple-400 bg-purple-500/10 hover:bg-purple-500/15 px-3 py-1.5 rounded-lg border border-purple-500/20 transition-all flex items-center gap-1 shrink-0"
                        >
                          <Link2 className="w-3 h-3" />{t("wizard.connect")}
                        </button>
                      )}
                      {state === "connecting" && (
                        <div className="text-xs text-purple-400 px-3 py-1.5 flex items-center gap-1 shrink-0">
                          <RefreshCw className="w-3 h-3 animate-spin" />{t("wizard.connecting")}
                        </div>
                      )}
                      {state === "connected" && (
                        <button
                          onClick={() => handleDisconnectChannel(ch.id)}
                          className="text-xs text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/20 flex items-center gap-1 shrink-0 hover:bg-red-500/10 hover:text-red-400 hover:border-red-500/20 transition-all"
                        >
                          <Check className="w-3 h-3" />{t("wizard.connected")}
                        </button>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* Launch OS-managed (always active) */}
            <div className="space-y-2">
              <div className="text-[10px] text-zinc-600 uppercase tracking-wider px-1" style={{ fontWeight: 600 }}>
                {t("ch.tierManaged")}
              </div>
              <div className="p-3 rounded-xl border border-purple-500/10 bg-purple-500/[0.02]">
                <div className="flex items-center gap-2 mb-2.5">
                  <Shield className="w-3.5 h-3.5 text-purple-400" />
                  <span className="text-[11px] text-purple-400" style={{ fontWeight: 600 }}>{t("wizard.managedAuto")}</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {managedChannels.map((ch) => (
                    <span key={ch.id} className="text-[11px] px-2.5 py-1 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/15 flex items-center gap-1">
                      <span>{ch.icon}</span> {ch.name}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Step 4: Choose Strategy */}
        {step === 4 && (
          <motion.div key="s4str" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center"><Zap className="w-4 h-4 text-emerald-400" /></div>
                <span className="text-white" style={{ fontWeight: 600 }}>{t("wizard.chooseStrategy")}</span>
              </div>
              <p className="text-sm text-zinc-500 ml-10">{t("wizard.strategySubtitle")}</p>
            </div>
            <WhyBlock label={t("why.step4Label")} color="emerald" variant="banner">
              {t("why.step4")}
            </WhyBlock>

            {/* Summary of connected channels */}
            {connectedCount > 0 && (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/10">
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="text-sm text-zinc-400">
                  {connectedCount + managedChannels.length} {t("engine.channelsLabel")} {t("ch.readyToPost")}
                </span>
              </div>
            )}

            {/* Pricing cards */}
            <div className="grid gap-4">
              {(abVariant === "B" ? [...strategies].reverse() : strategies).map((s, idx) => {
                const isSelected = form.strategy === s.name;
                return (
                  <motion.div
                    key={s.name}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.08 }}
                    className={`relative rounded-2xl border overflow-hidden transition-all ${
                      isSelected
                        ? `${s.border} ${s.bg} shadow-lg`
                        : "border-white/5 bg-white/[0.02] hover:border-white/10"
                    }`}
                  >
                    {s.popular && (
                      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-500 to-blue-500" />
                    )}

                    <div className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => setForm({ ...form, strategy: s.name })}
                            className="shrink-0"
                          >
                            {isSelected ? (
                              <div className="w-6 h-6 rounded-full bg-purple-500 flex items-center justify-center">
                                <Check className="w-3.5 h-3.5 text-white" />
                              </div>
                            ) : (
                              <div className="w-6 h-6 rounded-full border-2 border-white/15 hover:border-white/30 transition-colors" />
                            )}
                          </button>
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="text-white" style={{ fontWeight: 600 }}>{s.name}</h3>
                              {s.popular && (
                                <span className="text-[10px] bg-cyan-500/15 text-cyan-400 px-2 py-0.5 rounded-full" style={{ fontWeight: 600 }}>
                                  {t("wizard.recommended")}
                                </span>
                              )}
                            </div>
                            <p className="text-sm text-zinc-500 mt-0.5">{s.desc}</p>
                          </div>
                        </div>
                        <div className="text-right shrink-0 ml-4">
                          <div className="text-2xl text-white" style={{ fontWeight: 700 }}>{s.price}</div>
                          <div className="text-xs text-zinc-500">{t("wizard.perMonth")}</div>
                        </div>
                      </div>

                      {/* Features */}
                      <div className="ml-9 mb-4">
                        <p className="text-xs text-zinc-400 leading-relaxed">{s.features}</p>
                      </div>

                      {/* Stats row */}
                      <div className="flex items-center gap-6 ml-9 mb-4">
                        <div className="flex items-center gap-1.5">
                          <div className={`w-5 h-5 rounded-md ${s.iconBg} flex items-center justify-center`}>
                            <Radio className={`w-3 h-3 ${s.iconColor}`} />
                          </div>
                          <span className="text-sm text-zinc-300" style={{ fontWeight: 500 }}>{s.channels}</span>
                          <span className="text-xs text-zinc-600">{t("wizard.channelsAccess")}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <div className={`w-5 h-5 rounded-md ${s.iconBg} flex items-center justify-center`}>
                            <Sparkles className={`w-3 h-3 ${s.iconColor}`} />
                          </div>
                          <span className="text-sm text-zinc-300" style={{ fontWeight: 500 }}>{s.tokens}</span>
                          <span className="text-xs text-zinc-600">{t("wizard.tokensIncluded")}</span>
                        </div>
                      </div>

                      {/* Buy button */}
                      <div className="ml-9">
                        <button
                          onClick={() => {
                            const wasSelected = form.strategy === s.name;
                            setForm({ ...form, strategy: s.name });
                            if (!wasSelected) {
                              trackABEvent("select_plan", s.name);
                              confetti({
                                particleCount: 80,
                                spread: 60,
                                origin: { y: 0.7 },
                                colors: ["#a855f7", "#06b6d4", "#10b981", "#f59e0b"],
                              });
                            }
                            sonnerToast.success(`${s.name} — ${t("wizard.selected")}!`);
                          }}
                          className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm transition-all ${
                            isSelected
                              ? `bg-gradient-to-r ${s.gradient} text-white shadow-lg`
                              : "bg-white/[0.04] border border-white/10 text-zinc-300 hover:bg-white/[0.06] hover:border-white/20"
                          }`}
                        >
                          {isSelected ? (
                            <>
                              <Check className="w-4 h-4" />
                              {t("wizard.selected")}
                            </>
                          ) : (
                            <>
                              <Zap className="w-4 h-4" />
                              {t("wizard.buyPlan")} {s.name.split(" ")[0]}
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <div className="flex items-center justify-between mt-10 pt-6 border-t border-white/5">
        <button onClick={() => (step > 0 ? setStep(step - 1) : navigate("/dashboard"))} className="text-sm text-zinc-500 hover:text-zinc-300 transition-colors flex items-center gap-1">
          <ArrowLeft className="w-4 h-4" />{step > 0 ? t("wizard.back") : t("wizard.cancel")}
        </button>
        <div className="flex items-center gap-3">
          {step === 3 && (
            <button onClick={handleSkipChannels} className="text-xs text-zinc-600 hover:text-zinc-400 transition-colors">
              {t("wizard.skipChannels")}
            </button>
          )}
          <button
            onClick={handleNext}
            disabled={step === 2 && !packReady}
            className="inline-flex items-center gap-2 bg-purple-600 hover:bg-purple-500 disabled:opacity-40 disabled:cursor-not-allowed text-white px-6 py-2.5 rounded-xl text-sm transition-colors"
          >
            {step < totalSteps - 1 ? <>{t("wizard.next")} <ArrowRight className="w-4 h-4" /></> : <><Sparkles className="w-4 h-4" />{t("wizard.generateContent")}</>}
          </button>
        </div>
      </div>
    </div>
  );
}