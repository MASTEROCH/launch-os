/* ═══════════════════════════════════════════
   Shared avatar URL constants
   Used across Community, Leaderboard, Profile, etc.
   ═══════════════════════════════════════════ */

/** Stock avatar photos for mock founder data */
export const AVATAR_URLS: Record<string, string> = {
  f1: "https://images.unsplash.com/photo-1672685667592-0392f458f46f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBoZWFkc2hvdCUyMHBvcnRyYWl0JTIwbWFufGVufDF8fHx8MTc3MzA4MjQyNnww&ixlib=rb-4.1.0&q=80&w=200",
  f2: "https://images.unsplash.com/photo-1655249481446-25d575f1c054?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBoZWFkc2hvdCUyMHBvcnRyYWl0JTIwd29tYW58ZW58MXx8fHwxNzczMDc2MTI3fDA&ixlib=rb-4.1.0&q=80&w=200",
  f3: "https://images.unsplash.com/photo-1758599543126-59e3154d7195?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMGVudHJlcHJlbmV1ciUyMHBvcnRyYWl0JTIwbWFsZXxlbnwxfHx8fDE3NzMxNDQ3Mjh8MA&ixlib=rb-4.1.0&q=80&w=200",
  f4: "https://images.unsplash.com/photo-1765648636207-22c892e8fae9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMGJ1c2luZXNzJTIwd29tYW4lMjBwb3J0cmFpdCUyMHNtaWxlfGVufDF8fHx8MTc3MzE0NDcyOXww&ixlib=rb-4.1.0&q=80&w=200",
  f5: "https://images.unsplash.com/photo-1706025090996-63717544be2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc2lhbiUyMG1hbiUyMHByb2Zlc3Npb25hbCUyMGhlYWRzaG90fGVufDF8fHx8MTc3MzEwOTMxM3ww&ixlib=rb-4.1.0&q=80&w=200",
  f6: "https://images.unsplash.com/photo-1668752741330-8adc5cef7485?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwd29tYW4lMjBwcm9mZXNzaW9uYWwlMjBwb3J0cmFpdHxlbnwxfHx8fDE3NzMwMzc2ODN8MA&ixlib=rb-4.1.0&q=80&w=200",
  f7: "https://images.unsplash.com/photo-1769071166862-8cc3a6f2ac5c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWFyZGVkJTIwbWFuJTIwcG9ydHJhaXQlMjBzdGFydHVwJTIwZm91bmRlcnxlbnwxfHx8fDE3NzMxNDQ3MzB8MA&ixlib=rb-4.1.0&q=80&w=200",
  f8: "https://images.unsplash.com/photo-1767439567636-792a76f6e4b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMHdvbWFuJTIwY3JlYXRpdmUlMjBwcm9mZXNzaW9uYWwlMjBwb3J0cmFpdHxlbnwxfHx8fDE3NzMwODU0OTJ8MA&ixlib=rb-4.1.0&q=80&w=200",
};

/** Default user avatar (the current logged-in user) */
export const DEFAULT_USER_AVATAR = "https://images.unsplash.com/photo-1764084051438-369ad6a09334?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWRkbGUlMjBhZ2VkJTIwbWFuJTIwYnVzaW5lc3MlMjBwb3J0cmFpdHxlbnwxfHx8fDE3NzMwNzUyNDZ8MA&ixlib=rb-4.1.0&q=80&w=200";

/** Available avatar options for user to choose from */
export const AVATAR_OPTIONS = [
  DEFAULT_USER_AVATAR,
  "https://images.unsplash.com/photo-1672685667592-0392f458f46f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBoZWFkc2hvdCUyMHBvcnRyYWl0JTIwbWFufGVufDF8fHx8MTc3MzA4MjQyNnww&ixlib=rb-4.1.0&q=80&w=200",
  "https://images.unsplash.com/photo-1655249481446-25d575f1c054?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBoZWFkc2hvdCUyMHBvcnRyYWl0JTIwd29tYW58ZW58MXx8fHwxNzczMDc2MTI3fDA&ixlib=rb-4.1.0&q=80&w=200",
  "https://images.unsplash.com/photo-1758599543126-59e3154d7195?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMGVudHJlcHJlbmV1ciUyMHBvcnRyYWl0JTIwbWFsZXxlbnwxfHx8fDE3NzMxNDQ3Mjh8MA&ixlib=rb-4.1.0&q=80&w=200",
  "https://images.unsplash.com/photo-1765648636207-22c892e8fae9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMGJ1c2luZXNzJTIwd29tYW4lMjBwb3J0cmFpdCUyMHNtaWxlfGVufDF8fHx8MTc3MzE0NDcyOXww&ixlib=rb-4.1.0&q=80&w=200",
  "https://images.unsplash.com/photo-1706025090996-63717544be2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc2lhbiUyMG1hbiUyMHByb2Zlc3Npb25hbCUyMGhlYWRzaG90fGVufDF8fHx8MTc3MzEwOTMxM3ww&ixlib=rb-4.1.0&q=80&w=200",
  "https://images.unsplash.com/photo-1668752741330-8adc5cef7485?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwd29tYW4lMjBwcm9mZXNzaW9uYWwlMjBwb3J0cmFpdHxlbnwxfHx8fDE3NzMwMzc2ODN8MA&ixlib=rb-4.1.0&q=80&w=200",
  "https://images.unsplash.com/photo-1600696444233-20accba67df3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXRpbmElMjB3b21hbiUyMHBvcnRyYWl0JTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc3MzA5MjI1N3ww&ixlib=rb-4.1.0&q=80&w=200",
  "https://images.unsplash.com/photo-1769071166862-8cc3a6f2ac5c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWFyZGVkJTIwbWFuJTIwcG9ydHJhaXQlMjBzdGFydHVwJTIwZm91bmRlcnxlbnwxfHx8fDE3NzMxNDQ3MzB8MA&ixlib=rb-4.1.0&q=80&w=200",
  "https://images.unsplash.com/photo-1687570461530-fd0051bb2aaf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGFydHVwJTIwdGVhbSUyMG1lbWJlciUyMHBvcnRyYWl0JTIwZnJpZW5kbHl8ZW58MXx8fHwxNzczMTQ0NzMxfDA&ixlib=rb-4.1.0&q=80&w=200",
  "https://images.unsplash.com/photo-1740252117027-4275d3f84385?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1c2VyJTIwcHJvZmlsZSUyMGF2YXRhciUyMHBvcnRyYWl0JTIwY2FzdWFsfGVufDF8fHx8MTc3MzE0NDczMnww&ixlib=rb-4.1.0&q=80&w=200",
  "https://images.unsplash.com/photo-1767439567636-792a76f6e4b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMHdvbWFuJTIwY3JlYXRpdmUlMjBwcm9mZXNzaW9uYWwlMjBwb3J0cmFpdHxlbnwxfHx8fDE3NzMwODU0OTJ8MA&ixlib=rb-4.1.0&q=80&w=200",
];

/** Get user avatar from localStorage or return default */
export function getUserAvatar(): string {
  try {
    return localStorage.getItem("launchapp_avatar") || DEFAULT_USER_AVATAR;
  } catch {
    return DEFAULT_USER_AVATAR;
  }
}

/** Save user avatar to localStorage */
export function setUserAvatar(url: string): void {
  try {
    localStorage.setItem("launchapp_avatar", url);
  } catch {}
}
