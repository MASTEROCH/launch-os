import { motion, AnimatePresence } from "motion/react";
import {
  X, Briefcase, DollarSign, Handshake, Workflow, GraduationCap,
  Users, TrendingUp, PieChart, Target, Clock, Zap, ArrowRight,
  BarChart3, Mail, Calendar, FileText, Shield, Rocket, Star,
  Bot, Bell, BookOpen, Video, Award, Sparkles, CheckCircle,
  Wand2, Image, Clapperboard, Palette,
} from "lucide-react";
import { useI18n } from "./i18n";
import { useState } from "react";
import { toast } from "sonner";

export type ComingSoonFeatureId = "aiContent" | "crm" | "finance" | "investorHub" | "automations" | "training";

interface FeaturePreview {
  id: ComingSoonFeatureId;
  icon: typeof Briefcase;
  gradient: string;
  border: string;
  iconColor: string;
  mockScreenItems: { icon: typeof Users; label: string; desc: string; color: string }[];
  highlights: string[];
}

export function ComingSoonModal({
  featureId,
  onClose,
}: {
  featureId: ComingSoonFeatureId | null;
  onClose: () => void;
}) {
  const { t } = useI18n();
  const [notifiedFeatures, setNotifiedFeatures] = useState<Set<string>>(new Set());

  if (!featureId) return null;

  const handleNotify = () => {
    setNotifiedFeatures((prev) => new Set(prev).add(featureId));
    toast.success(t("cs.notified"));
  };

  const isNotified = notifiedFeatures.has(featureId);

  const features: Record<ComingSoonFeatureId, FeaturePreview> = {
    aiContent: {
      id: "aiContent",
      icon: Wand2,
      gradient: "from-indigo-500/20 to-violet-500/15",
      border: "border-indigo-500/20",
      iconColor: "text-indigo-400",
      mockScreenItems: [
        { icon: Image, label: t("cs.ai.item1"), desc: t("cs.ai.item1Desc"), color: "indigo" },
        { icon: Clapperboard, label: t("cs.ai.item2"), desc: t("cs.ai.item2Desc"), color: "violet" },
        { icon: Palette, label: t("cs.ai.item3"), desc: t("cs.ai.item3Desc"), color: "purple" },
        { icon: Star, label: t("cs.ai.item4"), desc: t("cs.ai.item4Desc"), color: "amber" },
      ],
      highlights: [t("cs.ai.hl1"), t("cs.ai.hl2"), t("cs.ai.hl3")],
    },
    crm: {
      id: "crm",
      icon: Briefcase,
      gradient: "from-blue-500/20 to-cyan-500/15",
      border: "border-blue-500/20",
      iconColor: "text-blue-400",
      mockScreenItems: [
        { icon: Users, label: t("cs.crm.item1"), desc: t("cs.crm.item1Desc"), color: "blue" },
        { icon: Mail, label: t("cs.crm.item2"), desc: t("cs.crm.item2Desc"), color: "cyan" },
        { icon: Target, label: t("cs.crm.item3"), desc: t("cs.crm.item3Desc"), color: "purple" },
        { icon: Bell, label: t("cs.crm.item4"), desc: t("cs.crm.item4Desc"), color: "amber" },
      ],
      highlights: [t("cs.crm.hl1"), t("cs.crm.hl2"), t("cs.crm.hl3")],
    },
    finance: {
      id: "finance",
      icon: DollarSign,
      gradient: "from-emerald-500/20 to-teal-500/15",
      border: "border-emerald-500/20",
      iconColor: "text-emerald-400",
      mockScreenItems: [
        { icon: BarChart3, label: t("cs.fin.item1"), desc: t("cs.fin.item1Desc"), color: "emerald" },
        { icon: PieChart, label: t("cs.fin.item2"), desc: t("cs.fin.item2Desc"), color: "teal" },
        { icon: TrendingUp, label: t("cs.fin.item3"), desc: t("cs.fin.item3Desc"), color: "cyan" },
        { icon: Calendar, label: t("cs.fin.item4"), desc: t("cs.fin.item4Desc"), color: "amber" },
      ],
      highlights: [t("cs.fin.hl1"), t("cs.fin.hl2"), t("cs.fin.hl3")],
    },
    investorHub: {
      id: "investorHub",
      icon: Handshake,
      gradient: "from-violet-500/20 to-purple-500/15",
      border: "border-violet-500/20",
      iconColor: "text-violet-400",
      mockScreenItems: [
        { icon: FileText, label: t("cs.inv.item1"), desc: t("cs.inv.item1Desc"), color: "violet" },
        { icon: Users, label: t("cs.inv.item2"), desc: t("cs.inv.item2Desc"), color: "purple" },
        { icon: Shield, label: t("cs.inv.item3"), desc: t("cs.inv.item3Desc"), color: "cyan" },
        { icon: Star, label: t("cs.inv.item4"), desc: t("cs.inv.item4Desc"), color: "amber" },
      ],
      highlights: [t("cs.inv.hl1"), t("cs.inv.hl2"), t("cs.inv.hl3")],
    },
    automations: {
      id: "automations",
      icon: Workflow,
      gradient: "from-orange-500/20 to-amber-500/15",
      border: "border-orange-500/20",
      iconColor: "text-orange-400",
      mockScreenItems: [
        { icon: Bot, label: t("cs.auto.item1"), desc: t("cs.auto.item1Desc"), color: "orange" },
        { icon: Clock, label: t("cs.auto.item2"), desc: t("cs.auto.item2Desc"), color: "amber" },
        { icon: Zap, label: t("cs.auto.item3"), desc: t("cs.auto.item3Desc"), color: "yellow" },
        { icon: Rocket, label: t("cs.auto.item4"), desc: t("cs.auto.item4Desc"), color: "emerald" },
      ],
      highlights: [t("cs.auto.hl1"), t("cs.auto.hl2"), t("cs.auto.hl3")],
    },
    training: {
      id: "training",
      icon: GraduationCap,
      gradient: "from-pink-500/20 to-rose-500/15",
      border: "border-pink-500/20",
      iconColor: "text-pink-400",
      mockScreenItems: [
        { icon: BookOpen, label: t("cs.train.item1"), desc: t("cs.train.item1Desc"), color: "pink" },
        { icon: Video, label: t("cs.train.item2"), desc: t("cs.train.item2Desc"), color: "rose" },
        { icon: Award, label: t("cs.train.item3"), desc: t("cs.train.item3Desc"), color: "purple" },
        { icon: Sparkles, label: t("cs.train.item4"), desc: t("cs.train.item4Desc"), color: "violet" },
      ],
      highlights: [t("cs.train.hl1"), t("cs.train.hl2"), t("cs.train.hl3")],
    },
  };

  const feature = features[featureId];

  const bgColors: Record<string, string> = {
    blue: "bg-blue-500/10", cyan: "bg-cyan-500/10", purple: "bg-purple-500/10",
    amber: "bg-amber-500/10", emerald: "bg-emerald-500/10", teal: "bg-teal-500/10",
    violet: "bg-violet-500/10", orange: "bg-orange-500/10", yellow: "bg-yellow-500/10",
    pink: "bg-pink-500/10", rose: "bg-rose-500/10", indigo: "bg-indigo-500/10",
  };
  const txtColors: Record<string, string> = {
    blue: "text-blue-400", cyan: "text-cyan-400", purple: "text-purple-400",
    amber: "text-amber-400", emerald: "text-emerald-400", teal: "text-teal-400",
    violet: "text-violet-400", orange: "text-orange-400", yellow: "text-yellow-400",
    pink: "text-pink-400", rose: "text-rose-400", indigo: "text-indigo-400",
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[100] flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 20 }}
          transition={{ type: "spring", damping: 28, stiffness: 300 }}
          className="relative w-full max-w-lg max-h-[85vh] overflow-y-auto rounded-2xl border border-white/10 bg-[#0f0f11] cs-modal-bg"
          role="dialog"
          aria-modal="true"
          aria-label={t(`cs.${featureId}.title`)}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Close */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-10 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors"
          >
            <X className="w-4 h-4 text-zinc-400" />
          </button>

          {/* Hero */}
          <div className={`relative p-6 sm:p-8 bg-gradient-to-br ${feature.gradient} overflow-hidden`}>
            {/* Pattern */}
            <div className="absolute inset-0" style={{ backgroundImage: "radial-gradient(rgba(255,255,255,0.04) 1px, transparent 1px)", backgroundSize: "20px 20px" }} />
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", delay: 0.1 }}
              className="relative z-10"
            >
              <div className={`w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/15 flex items-center justify-center mb-4`}>
                <feature.icon className={`w-7 h-7 ${feature.iconColor}`} />
              </div>
              <h2 className="text-xl text-white mb-1" style={{ fontWeight: 700 }}>{t(`cs.${featureId}.title`)}</h2>
              <p className="text-sm text-zinc-300 leading-relaxed">{t(`cs.${featureId}.desc`)}</p>
            </motion.div>
          </div>

          {/* Mock preview */}
          <div className="p-5 sm:p-6 space-y-5">
            {/* Feature preview cards */}
            <div>
              <div className="text-[10px] text-zinc-500 uppercase tracking-widest mb-3" style={{ fontWeight: 600 }}>
                {t("cs.previewLabel")}
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                {feature.mockScreenItems.map((item, i) => (
                  <motion.div
                    key={item.label}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.15 + i * 0.08 }}
                    className={`p-3.5 rounded-xl border border-white/[0.06] bg-white/[0.02] hover:border-white/10 transition-all cs-modal-preview-card`}
                  >
                    <div className={`w-8 h-8 rounded-lg ${bgColors[item.color]} flex items-center justify-center mb-2.5`}>
                      <item.icon className={`w-4 h-4 ${txtColors[item.color]}`} />
                    </div>
                    <div className="text-xs text-white mb-0.5" style={{ fontWeight: 600 }}>{item.label}</div>
                    <div className="text-[10px] text-zinc-500 leading-relaxed">{item.desc}</div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Highlights */}
            <div className={`p-4 rounded-xl border ${feature.border} bg-gradient-to-r ${feature.gradient}`}>
              <div className="text-[10px] text-zinc-400 uppercase tracking-widest mb-3" style={{ fontWeight: 600 }}>
                {t("cs.benefitsLabel")}
              </div>
              <ul className="space-y-2.5">
                {feature.highlights.map((hl) => (
                  <li key={hl} className="flex items-start gap-2.5">
                    <CheckCircle className={`w-4 h-4 ${feature.iconColor} shrink-0 mt-0.5`} />
                    <span className="text-sm text-zinc-300">{hl}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Status badge */}
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="flex items-center gap-3 p-4 rounded-xl bg-purple-500/[0.06] border border-purple-500/15"
            >
              <div className="w-10 h-10 rounded-xl bg-purple-500/15 flex items-center justify-center shrink-0">
                <Rocket className="w-5 h-5 text-purple-400" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm text-white" style={{ fontWeight: 600 }}>{t("cs.inDev")}</div>
                <div className="text-xs text-zinc-500 mt-0.5">{t("cs.inDevDesc")}</div>
              </div>
              <div className="shrink-0">
                <span className="text-[10px] text-purple-400 px-2.5 py-1 rounded-full bg-purple-500/15 border border-purple-500/20 animate-pulse" style={{ fontWeight: 600 }}>
                  {t("cs.inDevBadge")}
                </span>
              </div>
            </motion.div>

            {/* CTA buttons */}
            <div className="flex gap-2">
              <button
                onClick={handleNotify}
                disabled={isNotified}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm transition-all ${
                  isNotified
                    ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 cursor-default"
                    : "bg-purple-600 hover:bg-purple-500 text-white"
                }`}
              >
                {isNotified ? (
                  <><CheckCircle className="w-3.5 h-3.5" /> {t("cs.notified")}</>
                ) : (
                  <><Bell className="w-3.5 h-3.5" /> {t("cs.notifyMe")}</>
                )}
              </button>
              <button
                onClick={onClose}
                className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-white/[0.05] border border-white/[0.08] hover:bg-white/[0.08] text-sm text-zinc-300 transition-all"
              >
                {t("cs.understood")}
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}