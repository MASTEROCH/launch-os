import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ArrowUp, MessageCircle, Share2, Rocket, Flame, Trophy,
  Crown, Star, ExternalLink, Users, Eye, Globe, Clock,
  Zap, TrendingUp, Heart, Sparkles, ChevronRight, Radio,
  BadgeCheck, Megaphone,
} from "lucide-react";
import { useI18n } from "./i18n";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { usePullToRefresh } from "./usePullToRefresh";
import { PullToRefreshIndicator } from "./PullToRefreshIndicator";
import { AVATAR_URLS } from "./avatars";
import { copyToClipboard } from "./clipboard";
import { toast } from "sonner";

/* ─── Mock Launch Data ─── */
interface LaunchItem {
  id: string;
  name: string;
  tagline: string;
  category: string;
  founder: { name: string; avatar: string; verified: boolean; title: string };
  upvotes: number;
  comments: number;
  channelsUsed: number;
  totalReach: number;
  launchedAgo: number; // minutes
  gradient: string;
  icon: string;
  featured: boolean;
  live: boolean;
  signups?: number;
  mrr?: number;
  sponsored?: boolean;
}

const MOCK_LAUNCHES: LaunchItem[] = [
  {
    id: "l1", name: "Clarity AI", tagline: "AI meeting notes that actually understand context",
    category: "Productivity", founder: { name: "Sarah Chen", avatar: AVATAR_URLS.f2, verified: true, title: "CEO @ Clarity" },
    upvotes: 847, comments: 134, channelsUsed: 42, totalReach: 128000, launchedAgo: 25,
    gradient: "from-purple-500 to-violet-600", icon: "AI", featured: true, live: true, signups: 2340, mrr: 4200,
  },
  {
    id: "l2", name: "ShipFast", tagline: "Launch your SaaS in 48 hours with AI boilerplate",
    category: "DevTools", founder: { name: "Marc Dubois", avatar: AVATAR_URLS.f1, verified: true, title: "Indie Hacker" },
    upvotes: 623, comments: 89, channelsUsed: 38, totalReach: 95000, launchedAgo: 120,
    gradient: "from-emerald-500 to-teal-600", icon: "SF", featured: true, live: true, signups: 1890, mrr: 3100,
  },
  {
    id: "l3", name: "PixelFlow", tagline: "Design-to-code pipeline powered by computer vision",
    category: "Design Tools", founder: { name: "Aisha Williams", avatar: AVATAR_URLS.f6, verified: true, title: "CTO @ PixelFlow" },
    upvotes: 512, comments: 67, channelsUsed: 35, totalReach: 76000, launchedAgo: 240,
    gradient: "from-pink-500 to-rose-600", icon: "PX", featured: false, live: true, signups: 1240,
  },
  {
    id: "l4", name: "DataPipe", tagline: "ETL pipelines anyone can build — no SQL required",
    category: "Data / SaaS", founder: { name: "James Park", avatar: AVATAR_URLS.f5, verified: false, title: "Founder" },
    upvotes: 389, comments: 45, channelsUsed: 28, totalReach: 54000, launchedAgo: 480,
    gradient: "from-cyan-500 to-blue-600", icon: "DP", featured: false, live: false, signups: 890,
  },
  {
    id: "l5", name: "NomadBase", tagline: "The operating system for remote teams",
    category: "Remote Work", founder: { name: "Elena Popova", avatar: AVATAR_URLS.f4, verified: true, title: "CEO @ NomadBase" },
    upvotes: 345, comments: 52, channelsUsed: 31, totalReach: 47000, launchedAgo: 720,
    gradient: "from-amber-500 to-orange-600", icon: "NB", featured: false, live: false, signups: 780, mrr: 1900,
  },
  {
    id: "l6", name: "VoiceKit", tagline: "Add voice AI to any app in 5 lines of code",
    category: "AI / API", founder: { name: "David Kim", avatar: AVATAR_URLS.f3, verified: false, title: "Solo Founder" },
    upvotes: 278, comments: 38, channelsUsed: 22, totalReach: 38000, launchedAgo: 1440,
    gradient: "from-violet-500 to-purple-700", icon: "VK", featured: false, live: false,
  },
  {
    id: "l7", name: "GreenLedger", tagline: "Carbon accounting for SaaS companies, automated",
    category: "CleanTech", founder: { name: "Priya Sharma", avatar: AVATAR_URLS.f8, verified: true, title: "Co-founder" },
    upvotes: 234, comments: 29, channelsUsed: 18, totalReach: 29000, launchedAgo: 2880,
    gradient: "from-emerald-600 to-green-800", icon: "GL", featured: false, live: false, signups: 340,
  },
  {
    id: "l8", name: "ThreadCraft", tagline: "AI writes viral Twitter threads from your blog posts",
    category: "Marketing", founder: { name: "Alex Turner", avatar: AVATAR_URLS.f7, verified: false, title: "Growth Hacker" },
    upvotes: 198, comments: 24, channelsUsed: 15, totalReach: 22000, launchedAgo: 4320,
    gradient: "from-sky-500 to-indigo-600", icon: "TC", featured: false, live: false, signups: 560,
  },
];

type FeedTab = "trending" | "newest" | "featured";

function formatTimeAgo(mins: number, t: (k: string) => string): string {
  if (mins < 1) return t("feed.justNow");
  if (mins < 60) return `${mins}${t("feed.minAgo")}`;
  if (mins < 1440) return `${Math.floor(mins / 60)}${t("feed.hourAgo")}`;
  return `${Math.floor(mins / 1440)}${t("feed.dayAgo")}`;
}

export function LaunchFeed() {
  const { t } = useI18n();
  useDocumentTitle(t("feed.title"));

  const { pullY, isRefreshing, handlers: pullHandlers } = usePullToRefresh(
    () => new Promise<void>((r) => setTimeout(r, 800))
  );

  const [tab, setTab] = useState<FeedTab>("trending");
  const [votes, setVotes] = useState<Record<string, number>>({});
  const [following, setFollowing] = useState<Set<string>>(new Set());

  const toggleVote = useCallback((id: string) => {
    setVotes((prev) => ({
      ...prev,
      [id]: prev[id] ? 0 : 1,
    }));
  }, []);

  const toggleFollow = useCallback((founderId: string) => {
    setFollowing((prev) => {
      const next = new Set(prev);
      if (next.has(founderId)) next.delete(founderId);
      else next.add(founderId);
      return next;
    });
  }, []);

  const sorted = [...MOCK_LAUNCHES].sort((a, b) => {
    if (tab === "trending") return (b.upvotes + b.comments * 3) - (a.upvotes + a.comments * 3);
    if (tab === "newest") return a.launchedAgo - b.launchedAgo;
    if (tab === "featured") return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
    return 0;
  });

  // Leaderboard — top 5 by upvotes
  const leaderboard = [...MOCK_LAUNCHES].sort((a, b) => b.upvotes - a.upvotes).slice(0, 5);

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6" {...pullHandlers}>
      <PullToRefreshIndicator pullY={pullY} isRefreshing={isRefreshing} />
      <LargeTitle title={t("feed.title")} subtitle={t("feed.subtitle")} />

      {/* ═══ Live Banner ═══ */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-xl border border-purple-500/20 bg-gradient-to-r from-purple-500/[0.06] to-violet-500/[0.04] p-4"
      >
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-xs text-red-400" style={{ fontWeight: 700 }}>{t("feed.liveNow")}</span>
          </div>
          <span className="text-sm text-zinc-300">
            <span style={{ fontWeight: 700 }}>{MOCK_LAUNCHES.filter((l) => l.live).length}</span> launches active right now
          </span>
          <div className="ml-auto flex items-center gap-2 text-[11px] text-zinc-500">
            <Users className="w-3 h-3" />
            <span>1,247 founders online</span>
          </div>
        </div>
        {/* Floating avatars */}
        <div className="absolute right-4 top-1/2 -translate-y-1/2 flex -space-x-2">
          {Object.values(AVATAR_URLS).slice(0, 5).map((url, i) => (
            <img key={i} src={url} alt="" className="w-6 h-6 rounded-full border-2 border-zinc-900 object-cover" />
          ))}
          <div className="w-6 h-6 rounded-full bg-purple-500/20 border-2 border-zinc-900 flex items-center justify-center text-[8px] text-purple-400" style={{ fontWeight: 700 }}>
            +42
          </div>
        </div>
      </motion.div>

      {/* ═══ Tabs ═══ */}
      <div className="flex items-center gap-1 border-b border-white/5 pb-0.5">
        {(["trending", "newest", "featured"] as FeedTab[]).map((tabId) => (
          <button
            key={tabId}
            onClick={() => setTab(tabId)}
            className={`flex items-center gap-1.5 px-4 py-2 text-sm transition-all border-b-2 ${
              tab === tabId
                ? "text-white border-purple-500"
                : "text-zinc-500 border-transparent hover:text-zinc-300"
            }`}
            style={{ fontWeight: tab === tabId ? 600 : 400 }}
          >
            {tabId === "trending" && <Flame className="w-3.5 h-3.5" />}
            {tabId === "newest" && <Clock className="w-3.5 h-3.5" />}
            {tabId === "featured" && <Star className="w-3.5 h-3.5" />}
            {t(`feed.${tabId}`)}
          </button>
        ))}
      </div>

      {/* ═══ Main Content: Feed + Sidebar ═══ */}
      <div className="grid gap-6 lg:grid-cols-[1fr,320px]">
        {/* Feed */}
        <div className="space-y-4">
          {/* Sponsored project */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative rounded-xl border border-amber-500/20 bg-gradient-to-r from-amber-500/[0.04] to-orange-500/[0.02] overflow-hidden"
          >
            <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-400/40 to-transparent" />
            <div className="p-4 sm:p-5">
              <div className="flex items-center gap-2 mb-3">
                <Megaphone className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-[9px] text-amber-400 uppercase tracking-wider" style={{ fontWeight: 700 }}>{t("promote.sponsored")}</span>
              </div>
              <div className="flex gap-4">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-2xl shrink-0 shadow-lg">
                  {""}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-white text-[15px] mb-0.5" style={{ fontWeight: 700 }}>AutoReach Pro</h3>
                  <p className="text-[13px] text-zinc-400 mb-2">Automated outreach that books meetings while you sleep</p>
                  <div className="flex items-center gap-3 text-[10px] text-zinc-500">
                    <span className="bg-white/[0.04] px-2 py-0.5 rounded-md">Sales AI</span>
                    <span className="flex items-center gap-0.5"><Users className="w-3 h-3" />3,200 signups</span>
                    <span className="flex items-center gap-0.5 text-emerald-400"><TrendingUp className="w-3 h-3" />$8.2K MRR</span>
                  </div>
                </div>
                <button className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs shrink-0 hover:bg-amber-500/15 transition-all" style={{ fontWeight: 600 }}>
                  <ExternalLink className="w-3 h-3" />
                  Visit
                </button>
              </div>
            </div>
          </motion.div>

          <AnimatePresence>
            {sorted.map((launch, i) => {
              const hasVoted = !!votes[launch.id];
              const voteCount = launch.upvotes + (votes[launch.id] || 0);
              const isFollowing = following.has(launch.founder.name);

              return (
                <motion.div
                  key={launch.id}
                  layout
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className={`group relative rounded-xl border bg-white/[0.02] hover:bg-white/[0.04] transition-all ${
                    launch.featured ? "border-purple-500/20" : "border-white/5 hover:border-white/10"
                  }`}
                >
                  {/* Featured badge */}
                  {launch.featured && (
                    <div className="absolute -top-2 left-4 px-2 py-0.5 rounded-md bg-gradient-to-r from-amber-500 to-orange-500 text-[9px] text-white" style={{ fontWeight: 700 }}>
                      {t("feed.featured")}
                    </div>
                  )}

                  <div className="p-4 sm:p-5">
                    {/* Top row: founder + follow */}
                    <div className="flex items-center gap-3 mb-3">
                      <img src={launch.founder.avatar} alt="" className="w-8 h-8 rounded-xl object-cover border border-white/10" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[13px] text-white truncate" style={{ fontWeight: 600 }}>{launch.founder.name}</span>
                          {launch.founder.verified && <BadgeCheck className="w-3.5 h-3.5 text-purple-400 shrink-0" />}
                        </div>
                        <span className="text-[11px] text-zinc-600">{launch.founder.title}</span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {launch.live && (
                          <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-500/10 text-[9px] text-red-400" style={{ fontWeight: 700 }}>
                            <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                            LIVE
                          </span>
                        )}
                        <span className="text-[10px] text-zinc-600">
                          {formatTimeAgo(launch.launchedAgo, t)}
                        </span>
                      </div>
                    </div>

                    {/* Launch card */}
                    <div className="flex gap-4">
                      {/* Icon */}
                      <div className={`w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-gradient-to-br ${launch.gradient} flex items-center justify-center text-2xl shrink-0 shadow-lg`}>
                        {launch.icon}
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <h3 className="text-white text-[15px] mb-0.5" style={{ fontWeight: 700 }}>{launch.name}</h3>
                        <p className="text-[13px] text-zinc-400 mb-2">{launch.tagline}</p>
                        <span className="text-[10px] text-zinc-600 bg-white/[0.04] px-2 py-0.5 rounded-md">{launch.category}</span>
                      </div>

                      {/* Upvote button */}
                      <button
                        onClick={() => toggleVote(launch.id)}
                        className={`flex flex-col items-center gap-0.5 px-3 py-2 rounded-xl border transition-all shrink-0 ${
                          hasVoted
                            ? "border-purple-500/30 bg-purple-500/10 text-purple-400"
                            : "border-white/10 bg-white/[0.03] text-zinc-500 hover:text-white hover:border-white/20"
                        }`}
                      >
                        <ArrowUp className={`w-4 h-4 ${hasVoted ? "text-purple-400" : ""}`} />
                        <span className="text-xs" style={{ fontWeight: 700 }}>{voteCount}</span>
                      </button>
                    </div>

                    {/* Stats row */}
                    <div className="flex items-center gap-4 mt-4 pt-3 border-t border-white/[0.04] text-[11px] text-zinc-500 flex-wrap">
                      <span className="flex items-center gap-1"><Globe className="w-3 h-3" />{launch.channelsUsed} {t("feed.channels")}</span>
                      <span className="flex items-center gap-1"><Eye className="w-3 h-3" />{(launch.totalReach / 1000).toFixed(0)}K {t("feed.reach")}</span>
                      {launch.signups && (
                        <span className="flex items-center gap-1 text-emerald-500"><Users className="w-3 h-3" />{launch.signups.toLocaleString()} signups</span>
                      )}
                      {launch.mrr && (
                        <span className="flex items-center gap-1 text-amber-400"><TrendingUp className="w-3 h-3" />${launch.mrr.toLocaleString()} MRR</span>
                      )}
                      <div className="ml-auto flex items-center gap-3">
                        <button className="flex items-center gap-1 hover:text-zinc-300 transition-colors">
                          <MessageCircle className="w-3 h-3" />{launch.comments}
                        </button>
                        <button
                          onClick={() => { copyToClipboard(`https://launchos.app/launch/${launch.id}`); toast.success("Link copied!"); }}
                          className="flex items-center gap-1 hover:text-zinc-300 transition-colors"
                        >
                          <Share2 className="w-3 h-3" />{t("feed.share")}
                        </button>
                        <button
                          onClick={() => toggleFollow(launch.founder.name)}
                          className={`flex items-center gap-1 transition-colors ${
                            isFollowing ? "text-purple-400" : "hover:text-zinc-300"
                          }`}
                        >
                          <Heart className={`w-3 h-3 ${isFollowing ? "fill-purple-400" : ""}`} />
                          {isFollowing ? t("feed.following_btn") : t("feed.follow")}
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>

        {/* ═══ Sidebar: Leaderboard ═══ */}
        <div className="space-y-4">
          {/* Weekly Leaderboard */}
          <div className="p-4 rounded-xl border border-white/5 bg-white/[0.02]">
            <div className="flex items-center gap-2 mb-4">
              <Trophy className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm text-white" style={{ fontWeight: 700 }}>{t("feed.topLaunches")}</h3>
            </div>
            <div className="space-y-3">
              {leaderboard.map((launch, i) => {
                const medalColors = ["text-amber-400", "text-zinc-400", "text-orange-500"];
                return (
                  <div key={launch.id} className="flex items-center gap-3">
                    <span className="text-sm w-5 text-center">
                      {i < 3 ? <span className={`${medalColors[i]}`} style={{ fontWeight: 800 }}>#{i + 1}</span> : <span className="text-zinc-600 text-xs" style={{ fontWeight: 700 }}>{i + 1}</span>}
                    </span>
                    <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${launch.gradient} flex items-center justify-center text-sm shrink-0`}>
                      {launch.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="text-[13px] text-white truncate block" style={{ fontWeight: 600 }}>{launch.name}</span>
                      <span className="text-[10px] text-zinc-600">{launch.upvotes} {t("feed.upvotes")}</span>
                    </div>
                    {i === 0 && <Crown className="w-4 h-4 text-amber-400 shrink-0" />}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Launch Score card */}
          <div className="p-4 rounded-xl border border-purple-500/20 bg-gradient-to-br from-purple-500/[0.05] to-violet-500/[0.03]">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <h3 className="text-sm text-white" style={{ fontWeight: 700 }}>{t("feed.launchScore")}</h3>
            </div>
            <div className="text-3xl text-white mb-1" style={{ fontWeight: 800 }}>847</div>
            <div className="flex items-center gap-1 text-[11px] text-emerald-400 mb-3">
              <TrendingUp className="w-3 h-3" />
              +23% this week
            </div>
            <div className="space-y-2 text-[11px]">
              <div className="flex items-center justify-between">
                <span className="text-zinc-500">Community rank</span>
                <span className="text-white" style={{ fontWeight: 600 }}>#12 of 2,847</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-zinc-500">Launches this month</span>
                <span className="text-white" style={{ fontWeight: 600 }}>3</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-zinc-500">Total reach</span>
                <span className="text-white" style={{ fontWeight: 600 }}>128K</span>
              </div>
            </div>
          </div>

          {/* Trending categories */}
          <div className="p-4 rounded-xl border border-white/5 bg-white/[0.02]">
            <h3 className="text-sm text-white mb-3" style={{ fontWeight: 700 }}>Trending Categories</h3>
            <div className="flex flex-wrap gap-2">
              {["AI", "SaaS", "DevTools", "No-Code", "FinTech", "EdTech", "Marketing", "Productivity"].map((cat) => (
                <span key={cat} className="text-[11px] text-zinc-400 bg-white/[0.04] px-2.5 py-1 rounded-lg hover:bg-white/[0.08] hover:text-white cursor-pointer transition-all">
                  {cat}
                </span>
              ))}
            </div>
          </div>

          {/* Submit CTA */}
          <button className="w-full p-4 rounded-xl border border-purple-500/20 bg-gradient-to-r from-purple-500/[0.08] to-violet-500/[0.05] hover:from-purple-500/[0.12] hover:to-violet-500/[0.08] transition-all flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center shrink-0">
              <Rocket className="w-5 h-5 text-purple-400" />
            </div>
            <div className="text-left">
              <div className="text-sm text-white" style={{ fontWeight: 600 }}>{t("feed.submitLaunch")}</div>
              <div className="text-[11px] text-zinc-500">Get featured & boost your reach</div>
            </div>
            <ChevronRight className="w-4 h-4 text-zinc-600 ml-auto" />
          </button>

          {/* ═══ Activity Feed ═══ */}
          <div className="p-4 rounded-xl border border-white/5 bg-white/[0.02]">
            <div className="flex items-center gap-2 mb-3">
              <Radio className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm text-white" style={{ fontWeight: 700 }}>{t("activity.title")}</h3>
            </div>
            <div className="space-y-3">
              {[
                { avatar: AVATAR_URLS.f2, name: "Sarah Chen", action: t("activity.launched"), detail: "Clarity AI", time: "2m", color: "text-purple-400" },
                { avatar: AVATAR_URLS.f5, name: "James Park", action: t("activity.connected"), detail: "Product Hunt", time: "5m", color: "text-cyan-400" },
                { avatar: AVATAR_URLS.f4, name: "Elena Popova", action: t("activity.reached"), detail: "1,000 users", time: "12m", color: "text-emerald-400" },
                { avatar: AVATAR_URLS.f1, name: "Marc Dubois", action: t("activity.earned"), detail: "Viral Post", time: "18m", color: "text-amber-400" },
                { avatar: AVATAR_URLS.f6, name: "Aisha Williams", action: t("activity.invested"), detail: "$500K Seed", time: "25m", color: "text-rose-400" },
                { avatar: AVATAR_URLS.f3, name: "David Kim", action: t("activity.shipped"), detail: "AI Voice v2", time: "32m", color: "text-violet-400" },
                { avatar: AVATAR_URLS.f8, name: "Priya Sharma", action: t("activity.launched"), detail: "GreenLedger", time: "45m", color: "text-purple-400" },
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + i * 0.05 }}
                  className="flex items-center gap-2.5"
                >
                  <img src={item.avatar} alt="" className="w-6 h-6 rounded-full object-cover border border-white/10 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <span className="text-[11px] text-zinc-300" style={{ fontWeight: 600 }}>{item.name}</span>{" "}
                    <span className="text-[11px] text-zinc-500">{item.action}</span>{" "}
                    <span className={`text-[11px] ${item.color}`} style={{ fontWeight: 600 }}>{item.detail}</span>
                  </div>
                  <span className="text-[9px] text-zinc-600 shrink-0">{item.time}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LaunchFeed;