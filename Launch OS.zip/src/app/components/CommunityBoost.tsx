import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ArrowUp, Star, Trophy, Crown, Medal, Award,
  Users, UserPlus, UserCheck, MessageCircle, Search,
  ThumbsUp, MessageSquare, Send, X, Coins,
  Flame, Heart, Share2, Clock, Sparkles, Zap,
  Plus, Pin, Link, Eye, ChevronRight, Calendar, Target,
  Rocket, BadgeCheck, TrendingUp, Gift, ExternalLink, Lock,
  Gem, Handshake,
} from "lucide-react";

const badgeIconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Rocket, Flame, Star, Handshake, Gem, Trophy, Target, Crown,
};
import { toast as sonnerToast } from "sonner";
import { useNavigate, useLocation } from "react-router";
import { useI18n } from "./i18n";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { usePullToRefresh } from "./usePullToRefresh";
import { PullToRefreshIndicator } from "./PullToRefreshIndicator";
import { AVATAR_URLS } from "./avatars";
import { copyToClipboard } from "./clipboard";
import { ReferralProgram } from "./ReferralProgram";

/* ═══════════════════════════════════════════
   Skeleton
   ═══════════════════════════════════════════ */
function CommunitySkeleton() {
  return (
    <div className="space-y-6">
      {/* Suggested founders skeleton */}
      <div className="flex gap-3 overflow-hidden">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="w-[140px] shrink-0 p-4 rounded-xl border border-white/[0.04] bg-white/[0.01]">
            <div className="w-12 h-12 rounded-xl bg-white/[0.05] mx-auto mb-2 skeleton-shimmer" />
            <div className="h-3 w-20 rounded bg-white/[0.06] mx-auto mb-1 skeleton-shimmer" />
            <div className="h-2.5 w-14 rounded bg-white/[0.03] mx-auto skeleton-shimmer" />
          </div>
        ))}
      </div>
      {/* Feed skeleton */}
      <div className="space-y-3">
        {[1, 2, 3].map((i) => (
          <div key={i} className="p-4 rounded-xl border border-white/[0.04] bg-white/[0.01]">
            <div className="flex items-center gap-2.5 mb-3">
              <div className="w-8 h-8 rounded-xl bg-white/[0.05] skeleton-shimmer" />
              <div className="flex-1 space-y-1">
                <div className="h-3 w-24 rounded bg-white/[0.06] skeleton-shimmer" />
                <div className="h-2 w-16 rounded bg-white/[0.03] skeleton-shimmer" />
              </div>
            </div>
            <div className="h-3 w-full rounded bg-white/[0.04] mb-1.5 skeleton-shimmer" />
            <div className="h-3 w-3/4 rounded bg-white/[0.03] skeleton-shimmer" />
          </div>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════
   Types & Mock Data
   ═══════════════════════════════════════════ */
interface Project {
  id: string; name: string; tagline: string; category: string;
  upvotes: number; voted: boolean; featured: boolean;
  author: string; authorId: string; launchTime: string; gradient: string;
}

interface Founder {
  id: string; name: string; avatar: string; role: string; company: string;
  gradient: string; launches: number; tokens: number;
  online: boolean; mutualFriends: number; bio: string;
  skills: string[];
}

interface ForumReply {
  id: string; authorId: string; text: string; time: string;
  likes: number; liked: boolean;
}

interface FeedItem {
  id: string; type: "topic" | "launch";
  authorId: string; time: string; title?: string; content?: string;
  likes: number; liked: boolean; commentsCount: number;
  projectName?: string; category?: string;
  isOwn?: boolean; pinned?: boolean;
  replies?: ForumReply[];
}

const projectsData: Project[] = [
  { id: "1", name: "DevSync", tagline: "Real-time collaboration for developer teams", category: "SaaS", upvotes: 284, voted: false, featured: true, author: "Alex K.", authorId: "f1", launchTime: "2h ago", gradient: "from-purple-500 to-violet-600" },
  { id: "2", name: "AIWriter Pro", tagline: "AI-powered content creation for marketers", category: "AI Tool", upvotes: 231, voted: false, featured: true, author: "Maria S.", authorId: "f2", launchTime: "5h ago", gradient: "from-cyan-500 to-blue-600" },
  { id: "3", name: "QuickLaunch", tagline: "Launch landing pages in 5 minutes", category: "Web Platform", upvotes: 198, voted: false, featured: false, author: "John D.", authorId: "f3", launchTime: "8h ago", gradient: "from-emerald-500 to-teal-600" },
  { id: "4", name: "TaskFlow AI", tagline: "Smart task management with AI prioritization", category: "SaaS", upvotes: 167, voted: false, featured: false, author: "Sarah L.", authorId: "f4", launchTime: "12h ago", gradient: "from-amber-500 to-orange-600" },
  { id: "5", name: "PixelForge", tagline: "AI-powered design tool for non-designers", category: "Creative Product", upvotes: 145, voted: false, featured: false, author: "Tom R.", authorId: "f5", launchTime: "1d ago", gradient: "from-rose-500 to-pink-600" },
  { id: "6", name: "CodeReview AI", tagline: "Automated code reviews powered by GPT", category: "AI Tool", upvotes: 134, voted: false, featured: false, author: "Lisa M.", authorId: "f6", launchTime: "1d ago", gradient: "from-indigo-500 to-purple-600" },
];

const founders: Founder[] = [
  { id: "f1", name: "Alex Kowalski", avatar: "AK", role: "CEO & Founder", company: "DevSync", gradient: "from-purple-500 to-violet-600", launches: 3, tokens: 2400, online: true, mutualFriends: 2, bio: "Building collaboration tools for dev teams. Ex-Google.", skills: ["SaaS", "DevTools"] },
  { id: "f2", name: "Maria Sokolova", avatar: "MS", role: "Solo Founder", company: "AIWriter Pro", gradient: "from-cyan-500 to-blue-600", launches: 2, tokens: 1800, online: true, mutualFriends: 4, bio: "AI & content. Previously led marketing at Notion.", skills: ["AI", "Content"] },
  { id: "f3", name: "John Drummond", avatar: "JD", role: "Co-Founder & CTO", company: "QuickLaunch", gradient: "from-emerald-500 to-teal-600", launches: 5, tokens: 4200, online: false, mutualFriends: 1, bio: "Serial entrepreneur. 3 exits. Passionate about no-code tools.", skills: ["No-Code", "Growth"] },
  { id: "f4", name: "Sarah Lee", avatar: "SL", role: "Founder & CEO", company: "TaskFlow AI", gradient: "from-amber-500 to-orange-600", launches: 1, tokens: 800, online: true, mutualFriends: 3, bio: "First-time founder. YC S25 batch.", skills: ["AI", "Productivity"] },
  { id: "f5", name: "Tom Rodriguez", avatar: "TR", role: "Creative Director", company: "PixelForge", gradient: "from-rose-500 to-pink-600", launches: 2, tokens: 1500, online: false, mutualFriends: 0, bio: "Designer turned founder. Making design accessible.", skills: ["Design", "UX"] },
  { id: "f6", name: "Lisa Martinez", avatar: "LM", role: "Technical Founder", company: "CodeReview AI", gradient: "from-indigo-500 to-purple-600", launches: 4, tokens: 3100, online: true, mutualFriends: 5, bio: "ML engineer. Building AI tools for developers.", skills: ["AI", "DevTools"] },
  { id: "f7", name: "David Wang", avatar: "DW", role: "CEO", company: "MetricsHub", gradient: "from-sky-500 to-cyan-600", launches: 3, tokens: 2200, online: false, mutualFriends: 2, bio: "Data nerd. Previously analytics lead at Stripe.", skills: ["Analytics", "SaaS"] },
  { id: "f8", name: "Anna Petrova", avatar: "AP", role: "Solo Founder", company: "BotBuilder", gradient: "from-fuchsia-500 to-purple-600", launches: 1, tokens: 600, online: true, mutualFriends: 1, bio: "Making chatbots simple. No-code enthusiast.", skills: ["No-Code", "AI"] },
];

const initialFeed: FeedItem[] = [
  { id: "fi1", type: "topic", authorId: "f6", time: "25 min ago", title: "What's your #1 strategy for the first 48 hours after launch?", content: "I've launched 4 products now and each time the first 48 hours are crucial. What works for you?", likes: 18, liked: false, commentsCount: 3, category: "strategy", pinned: true, replies: [
    { id: "r1", authorId: "f1", text: "Product Hunt launch day + Twitter threads. Timing is everything — I always launch on Tuesday.", time: "20 min ago", likes: 5, liked: false },
    { id: "r2", authorId: "f3", text: "Community-first approach. Build relationships in niche groups weeks before launch.", time: "15 min ago", likes: 8, liked: false },
    { id: "r3", authorId: "f4", text: "For TaskFlow AI, early access waitlist was key. 300 signups before we even launched.", time: "10 min ago", likes: 3, liked: false },
  ] },
  { id: "fi2", type: "launch", authorId: "f1", time: "2h ago", projectName: "DevSync", likes: 42, liked: false, commentsCount: 1, category: "showoff" },
  { id: "fi3", type: "topic", authorId: "f4", time: "5h ago", title: "Looking for a technical co-founder for an AI productivity tool", content: "Building TaskFlow AI (YC S25). Our AI prioritization engine needs a strong ML engineer. Offering equity + salary.", likes: 31, liked: false, commentsCount: 2, category: "hiring", replies: [
    { id: "r8", authorId: "f7", text: "Sent you a DM! I have ML background and this sounds exciting.", time: "4h ago", likes: 2, liked: false },
    { id: "r9", authorId: "f6", text: "Check out my friend at Stanford — she's looking for exactly this kind of opportunity.", time: "3h ago", likes: 1, liked: false },
  ] },
  { id: "fi4", type: "topic", authorId: "f2", time: "12h ago", title: "Show Launch OS: AIWriter Pro — AI content for marketers", content: "After 6 months of building, AIWriter Pro is live! It generates blog posts, social content, and email campaigns with your brand voice.", likes: 37, liked: false, commentsCount: 2, category: "showoff" },
  { id: "fi5", type: "topic", authorId: "f3", time: "1d ago", title: "How I got 200 signups in 3 days without spending a dollar", content: "Used a combination of Reddit, Twitter threads, and a simple referral loop. Here's the playbook...", likes: 56, liked: false, commentsCount: 7, category: "marketing", pinned: true, replies: [
    { id: "r4", authorId: "f2", text: "This is gold! Can you share the Reddit post template you used?", time: "23h ago", likes: 12, liked: false },
    { id: "r5", authorId: "f6", text: "I used a similar approach for CodeReview AI. Twitter threads + HN Show were 80% of my traffic.", time: "22h ago", likes: 9, liked: false },
    { id: "r6", authorId: "f8", text: "Referral loops are underrated. What tool did you use for the referral system?", time: "20h ago", likes: 4, liked: false },
    { id: "r7", authorId: "f5", text: "Tried this exact approach last month. Got 150 signups, not bad for a design tool!", time: "18h ago", likes: 6, liked: false },
  ] },
  { id: "fi6", type: "topic", authorId: "f7", time: "1d ago", title: "Product-market fit signals: what metrics actually matter?", content: "Retention > acquisition. If people come back, you've got something. But how do you measure it early stage?", likes: 24, liked: false, commentsCount: 4, category: "product" },
  { id: "fi7", type: "topic", authorId: "f8", time: "2d ago", title: "Can I get honest feedback on my landing page?", content: "Just redesigned botbuilder.io. Looking for brutal honesty — is the value prop clear? Does the CTA work?", likes: 15, liked: false, commentsCount: 5, category: "feedback" },
];

const FORUM_CATEGORIES = [
  { key: "all", labelKey: "forum.allTopics", icon: MessageSquare, color: "text-zinc-400" },
  { key: "strategy", labelKey: "forum.strategy", icon: Zap, color: "text-purple-400" },
  { key: "marketing", labelKey: "forum.marketing", icon: Flame, color: "text-orange-400" },
  { key: "product", labelKey: "forum.product", icon: Star, color: "text-cyan-400" },
  { key: "hiring", labelKey: "forum.hiring", icon: Users, color: "text-emerald-400" },
  { key: "showoff", labelKey: "forum.showOff", icon: Trophy, color: "text-amber-400" },
  { key: "feedback", labelKey: "forum.feedback", icon: Heart, color: "text-pink-400" },
] as const;

const founderJoinDates: Record<string, string> = {
  f1: "Sep 2025", f2: "Nov 2025", f3: "Jun 2025", f4: "Jan 2026",
  f5: "Aug 2025", f6: "Jul 2025", f7: "Oct 2025", f8: "Feb 2026",
};

const founderProgress: Record<string, { step: number; label: string }> = {
  f1: { step: 5, label: "Growth" }, f2: { step: 4, label: "Launched" },
  f3: { step: 5, label: "Growth" }, f4: { step: 3, label: "Channels" },
  f5: { step: 4, label: "Launched" }, f6: { step: 5, label: "Growth" },
  f7: { step: 3, label: "Channels" }, f8: { step: 2, label: "Package" },
};

interface ActivityItem {
  id: string;
  type: "launch" | "upvote" | "join" | "badge" | "token";
  text: string;
  time: string;
}

const founderActivity: Record<string, ActivityItem[]> = {
  f1: [
    { id: "a1", type: "launch", text: "DevSync v2.0", time: "2d" },
    { id: "a2", type: "badge", text: "Top Launcher", time: "5d" },
    { id: "a3", type: "upvote", text: "AIWriter Pro", time: "1w" },
    { id: "a4", type: "token", text: "+150 tokens", time: "2w" },
  ],
  f2: [
    { id: "a5", type: "launch", text: "AIWriter Pro", time: "1d" },
    { id: "a6", type: "upvote", text: "DevSync", time: "3d" },
    { id: "a7", type: "join", text: "", time: "3mo" },
  ],
  f3: [
    { id: "a8", type: "badge", text: "Early Adopter", time: "1w" },
    { id: "a9", type: "launch", text: "QuickLaunch", time: "2w" },
    { id: "a10", type: "token", text: "+200 tokens", time: "1mo" },
  ],
  f4: [
    { id: "a11", type: "upvote", text: "DevSync", time: "1d" },
    { id: "a12", type: "launch", text: "TaskFlow AI", time: "1w" },
  ],
  f5: [
    { id: "a13", type: "launch", text: "PixelForge", time: "3d" },
    { id: "a14", type: "badge", text: "Community Star", time: "2w" },
  ],
  f6: [
    { id: "a15", type: "token", text: "+50 tokens", time: "1d" },
    { id: "a16", type: "upvote", text: "BotBuilder", time: "4d" },
    { id: "a17", type: "launch", text: "CodeReview AI v3", time: "2w" },
  ],
  f7: [
    { id: "a18", type: "join", text: "", time: "2mo" },
    { id: "a19", type: "upvote", text: "TaskFlow AI", time: "1w" },
  ],
  f8: [
    { id: "a20", type: "launch", text: "BotBuilder Beta", time: "5d" },
    { id: "a21", type: "badge", text: "Rising Star", time: "1w" },
    { id: "a22", type: "token", text: "+100 tokens", time: "2w" },
  ],
};

const activityIcons = {
  launch: Rocket,
  upvote: TrendingUp,
  join: Users,
  badge: BadgeCheck,
  token: Gift,
};

const activityColors = {
  launch: "text-purple-400 bg-purple-500/10",
  upvote: "text-cyan-400 bg-cyan-500/10",
  join: "text-emerald-400 bg-emerald-500/10",
  badge: "text-amber-400 bg-amber-500/10",
  token: "text-amber-400 bg-amber-500/10",
};

/* ═══════════════════════════════════════════
   Badges / Achievements
   ═══════════════════════════════════════════ */
interface Badge {
  id: string;
  icon: string;
  label: string;
  description: string;
  gradient: string;
  earned: boolean;
}

const allBadges: Badge[] = [
  { id: "b1", icon: "Rocket", label: "First Launch", description: "Launched your first project", gradient: "from-purple-600 to-indigo-600", earned: true },
  { id: "b2", icon: "Flame", label: "Streak 7", description: "Active 7 days in a row", gradient: "from-orange-500 to-red-600", earned: true },
  { id: "b3", icon: "Star", label: "Top 10", description: "Reached the leaderboard top 10", gradient: "from-amber-500 to-yellow-500", earned: true },
  { id: "b4", icon: "Handshake", label: "Networker", description: "Connected with 10+ founders", gradient: "from-emerald-500 to-teal-600", earned: true },
  { id: "b5", icon: "Gem", label: "Token King", description: "Earned 1000+ tokens", gradient: "from-cyan-500 to-blue-600", earned: true },
  { id: "b6", icon: "Trophy", label: "Champion", description: "Won a weekly launch challenge", gradient: "from-yellow-500 to-amber-600", earned: true },
  { id: "b7", icon: "Target", label: "Perfectionist", description: "Completed all 5 pipeline stages", gradient: "from-rose-500 to-pink-600", earned: false },
  { id: "b8", icon: "Crown", label: "Mentor", description: "Helped 5 founders launch", gradient: "from-fuchsia-500 to-purple-600", earned: false },
];

const founderBadges: Record<string, string[]> = {
  f1: ["b1", "b2", "b3", "b4", "b5", "b6"],
  f2: ["b1", "b2", "b4", "b5"],
  f3: ["b1", "b2", "b3", "b4", "b5", "b6", "b7"],
  f4: ["b1", "b4"],
  f5: ["b1", "b2", "b3", "b6"],
  f6: ["b1", "b2", "b3", "b4", "b5", "b6", "b7"],
  f7: ["b1", "b2"],
  f8: ["b1", "b4", "b5"],
};

/** Mock earned dates for badges */
const badgeEarnedDates: Record<string, string> = {
  b1: "Oct 2025", b2: "Nov 2025", b3: "Dec 2025",
  b4: "Jan 2026", b5: "Feb 2026", b6: "Feb 2026", b7: "Mar 2026",
};

/** Progress % for locked badges (towards earning) */
const badgeProgress: Record<string, number> = {
  b7: 72, b8: 35,
};

/** Extended project descriptions for preview */
const projectDescriptions: Record<string, string> = {
  "1": "DevSync is a real-time code collaboration platform that helps distributed engineering teams work together seamlessly. Features include live cursor tracking, integrated code review, and smart conflict resolution.",
  "2": "AIWriter Pro uses advanced language models to help content creators write faster and better. From blog posts to marketing copy, it adapts to your tone and style while ensuring factual accuracy.",
  "3": "QuickLaunch is a no-code platform that lets you create beautiful, conversion-optimized landing pages in under 5 minutes. Choose from 50+ templates and launch instantly.",
  "4": "TaskFlow AI is an intelligent project management tool that automatically prioritizes tasks, predicts bottlenecks, and suggests optimal workflows based on your team's patterns.",
  "5": "PixelForge is a browser-based design tool built for speed. Create UI designs, prototypes, and design systems with an intuitive interface and powerful collaboration features.",
  "6": "CodeReview AI automates the code review process using machine learning. It catches bugs, suggests improvements, and ensures code quality standards are met before merging.",
  "7": "BotBuilder lets anyone create sophisticated chatbots without coding. Connect to any platform, train with your data, and deploy in minutes with built-in analytics.",
};

/** Project mock metrics for preview */
const projectMetrics: Record<string, { users: string; mrr: string; growth: string }> = {
  "1": { users: "2.4K", mrr: "$8.2K", growth: "+32%" },
  "2": { users: "5.1K", mrr: "$14K", growth: "+45%" },
  "3": { users: "12K", mrr: "$22K", growth: "+28%" },
  "4": { users: "890", mrr: "$3.1K", growth: "+67%" },
  "5": { users: "1.8K", mrr: "$5.5K", growth: "+41%" },
  "6": { users: "3.2K", mrr: "$11K", growth: "+38%" },
  "7": { users: "620", mrr: "$1.8K", growth: "+85%" },
};

/** Play a short celebratory sound using Web Audio API */
function playConfettiSound() {
  try {
    const ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C5 E5 G5 C6
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0, ctx.currentTime + i * 0.08);
      gain.gain.linearRampToValueAtTime(0.15, ctx.currentTime + i * 0.08 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.08 + 0.3);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime + i * 0.08);
      osc.stop(ctx.currentTime + i * 0.08 + 0.35);
    });
  } catch {
    // Audio not available
  }
}

/* ═══════════════════════════════════════════
   Confetti Canvas
   ═══════════════════════════════════════════ */
function ConfettiCanvas({ active, onComplete }: { active: boolean; onComplete: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!active || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = canvas.offsetWidth * 2;
    canvas.height = canvas.offsetHeight * 2;
    ctx.scale(2, 2);

    const w = canvas.offsetWidth;
    const h = canvas.offsetHeight;

    const colors = [
      "#fbbf24", "#f59e0b", "#d97706", // ambers
      "#a78bfa", "#8b5cf6", "#7c3aed", // purples
      "#34d399", "#10b981", "#059669", // greens
      "#f472b6", "#ec4899", "#db2777", // pinks
      "#60a5fa", "#3b82f6", // blues
      "#ffffff",
    ];

    interface Particle {
      x: number; y: number; vx: number; vy: number;
      w: number; h: number; color: string;
      rotation: number; rotationSpeed: number;
      gravity: number; opacity: number; decay: number;
      shape: "rect" | "circle";
    }

    const particles: Particle[] = [];
    for (let i = 0; i < 80; i++) {
      particles.push({
        x: w / 2 + (Math.random() - 0.5) * 60,
        y: h * 0.45,
        vx: (Math.random() - 0.5) * 12,
        vy: -Math.random() * 14 - 4,
        w: Math.random() * 6 + 3,
        h: Math.random() * 4 + 2,
        color: colors[Math.floor(Math.random() * colors.length)],
        rotation: Math.random() * 360,
        rotationSpeed: (Math.random() - 0.5) * 12,
        gravity: 0.18 + Math.random() * 0.08,
        opacity: 1,
        decay: 0.008 + Math.random() * 0.006,
        shape: Math.random() > 0.4 ? "rect" : "circle",
      });
    }

    let frame = 0;
    const maxFrames = 150;
    let raf: number;

    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      let alive = false;

      for (const p of particles) {
        if (p.opacity <= 0) continue;
        alive = true;
        p.x += p.vx;
        p.vy += p.gravity;
        p.y += p.vy;
        p.vx *= 0.99;
        p.rotation += p.rotationSpeed;
        if (frame > maxFrames * 0.6) p.opacity -= p.decay;

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate((p.rotation * Math.PI) / 180);
        ctx.globalAlpha = Math.max(0, p.opacity);
        ctx.fillStyle = p.color;

        if (p.shape === "rect") {
          ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
        } else {
          ctx.beginPath();
          ctx.arc(0, 0, p.w / 2, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }

      frame++;
      if (alive && frame < maxFrames) {
        raf = requestAnimationFrame(draw);
      } else {
        ctx.clearRect(0, 0, w, h);
        onComplete();
      }
    };

    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [active, onComplete]);

  if (!active) return null;
  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 pointer-events-none z-30"
      style={{ width: "100%", height: "100%" }}
    />
  );
}

/** Returns simulated mutual friends for a founder */
const getMutualFounders = (founderId: string, allFounders: Founder[]): Founder[] => {
  // Deterministic pseudo-mutual based on founder index
  const idx = allFounders.findIndex((f) => f.id === founderId);
  const count = allFounders.find((f) => f.id === founderId)?.mutualFriends || 0;
  const mutuals: Founder[] = [];
  for (let i = 0; i < count && i < allFounders.length; i++) {
    const mIdx = (idx + i + 2) % allFounders.length;
    if (allFounders[mIdx].id !== founderId) mutuals.push(allFounders[mIdx]);
  }
  return mutuals.slice(0, count);
};

const placeColors = ["text-yellow-400", "text-zinc-300", "text-amber-600"];

/** Renders an avatar image or falls back to initials */
function FounderAvatar({ founder, size = "md", className = "" }: { founder: Founder; size?: "xs" | "sm" | "md" | "lg"; className?: string }) {
  const url = AVATAR_URLS[founder.id];
  const sizeClasses = { xs: "w-6 h-6 text-[8px]", sm: "w-8 h-8 text-[10px]", md: "w-12 h-12 text-sm", lg: "w-16 h-16 text-xl" };
  const radiusClasses = { xs: "rounded-lg", sm: "rounded-xl", md: "rounded-xl", lg: "rounded-xl" };
  const s = sizeClasses[size];
  const r = radiusClasses[size];
  return url ? (
    <img src={url} alt={founder.name} className={`${s} ${r} object-cover shrink-0 ${className}`} />
  ) : (
    <div className={`${s} ${r} bg-gradient-to-br ${founder.gradient} flex items-center justify-center text-white shrink-0 ${className}`} style={{ fontWeight: 700 }}>
      {founder.avatar}
    </div>
  );
}

/* ═══════════════════════════════════════════
   Main Component
   ═══════════════════════════════════════════ */
export function CommunityBoost() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const location = useLocation();
  useDocumentTitle(t("sidebar.community"));
  const [loading, setLoading] = useState(true);

  // Unseen referral badge: compare current tree length vs last-seen count
  const [unseenReferrals, setUnseenReferrals] = useState(() => {
    try {
      const saved = localStorage.getItem("launchapp_referral_tree");
      const seenCount = parseInt(localStorage.getItem("launchapp_referral_seen_count") || "0", 10);
      const currentCount = saved ? (JSON.parse(saved) as unknown[]).length : 3;
      return Math.max(0, currentCount - seenCount);
    } catch { return 0; }
  });

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(timer);
  }, []);

  // Open profile if navigated with state
  useEffect(() => {
    const state = location.state as { viewProfileId?: string } | null;
    if (state?.viewProfileId) {
      const f = founders.find((founder) => founder.id === state.viewProfileId);
      if (f) {
        setViewProfile(f);
        setActiveSection("network");
      }
      window.history.replaceState({}, "");
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Pull to refresh
  const { pullY, isRefreshing, handlers: pullHandlers } = usePullToRefresh(
    () => new Promise<void>((resolve) => setTimeout(resolve, 1000))
  );

  // Tab
  type Section = "network" | "launches" | "feed" | "referrals";
  const [activeSection, setActiveSection] = useState<Section>(() => {
    const params = new URLSearchParams(location.search);
    const tab = params.get("tab");
    if (tab === "referrals" || tab === "feed" || tab === "launches" || tab === "network") return tab;
    return "network";
  });

  // Clear referral badge if deep-linked to referrals tab
  useEffect(() => {
    if (activeSection === "referrals" && unseenReferrals > 0) {
      setUnseenReferrals(0);
      try {
        const saved = localStorage.getItem("launchapp_referral_tree");
        const count = saved ? (JSON.parse(saved) as unknown[]).length : 3;
        localStorage.setItem("launchapp_referral_seen_count", String(count));
      } catch {}
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Launches
  const [projectList, setProjectList] = useState(projectsData);
  const handleUpvote = (id: string) => {
    setProjectList((prev) => prev.map((p) => p.id === id ? { ...p, upvotes: p.voted ? p.upvotes - 1 : p.upvotes + 1, voted: !p.voted } : p));
  };
  const sorted = [...projectList].sort((a, b) => b.upvotes - a.upvotes);

  // Feed
  const [feedItems, setFeedItems] = useState(initialFeed);
  const handleLikeFeed = (id: string) => {
    setFeedItems((prev) => prev.map((fi) => fi.id === id ? { ...fi, likes: fi.liked ? fi.likes - 1 : fi.likes + 1, liked: !fi.liked } : fi));
  };

  // Forum
  const [forumCategory, setForumCategory] = useState("all");
  const [showCreateThread, setShowCreateThread] = useState(false);
  const [newThreadTitle, setNewThreadTitle] = useState("");
  const [newThreadContent, setNewThreadContent] = useState("");
  const [newThreadCategory, setNewThreadCategory] = useState("strategy");
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState("");
  const [unreadReplies, setUnreadReplies] = useState(3); // simulated unread
  const [openThreadId, setOpenThreadId] = useState<string | null>(null);

  const filteredFeed = (forumCategory === "all"
    ? feedItems
    : feedItems.filter((fi) => fi.category === forumCategory)
  ).sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0));

  const handleCreateThread = () => {
    if (!newThreadTitle.trim()) return;
    const newItem: FeedItem = {
      id: `fi-${Date.now()}`,
      type: "topic",
      authorId: "f1", // current user
      time: t("layout.justNow") || "Just now",
      title: newThreadTitle,
      content: newThreadContent,
      likes: 0,
      liked: false,
      commentsCount: 0,
      category: newThreadCategory,
      isOwn: true,
    };
    setFeedItems((prev) => [newItem, ...prev]);
    setNewThreadTitle("");
    setNewThreadContent("");
    setShowCreateThread(false);
    sonnerToast.success(t("forum.posted"));

    // Simulate a reply notification after 5-10 seconds
    const delay = 5000 + Math.random() * 5000;
    setTimeout(() => {
      const randomResponder = founders[Math.floor(Math.random() * founders.length)];
      const simReply: ForumReply = {
        id: `r-sim-${Date.now()}`, authorId: randomResponder.id,
        text: "Great thread! This is exactly what I needed to hear.",
        time: t("layout.justNow") || "Just now", likes: 1, liked: false,
      };
      setFeedItems((prev) =>
        prev.map((fi) => fi.id === newItem.id ? {
          ...fi, commentsCount: fi.commentsCount + 1,
          replies: [...(fi.replies || []), simReply],
        } : fi)
      );
      setUnreadReplies((prev) => prev + 1);
      sonnerToast(`${randomResponder.name} ${t("forum.commentNotif")}`);
      document.dispatchEvent(new CustomEvent("launchapp:bonus", {
        detail: {
          message: `${randomResponder.name} ${t("forum.commentNotif")}: "${newItem.title}"`,
          type: "reward",
        },
      }));
    }, delay);
  };

  const handleReply = (itemId: string) => {
    if (!replyText.trim()) return;
    const newReply: ForumReply = {
      id: `r-${Date.now()}`, authorId: "f1", text: replyText.trim(),
      time: t("layout.justNow") || "Just now", likes: 0, liked: false,
    };
    setFeedItems((prev) =>
      prev.map((fi) => fi.id === itemId ? {
        ...fi,
        commentsCount: fi.commentsCount + 1,
        replies: [...(fi.replies || []), newReply],
      } : fi)
    );
    const item = feedItems.find((fi) => fi.id === itemId);
    // Simulate push notification for own threads
    if (item?.isOwn) {
      const randomResponder = founders[Math.floor(Math.random() * founders.length)];
      sonnerToast(
        `${randomResponder.name} ${t("forum.commentNotif")}`,
        {}
      );
      // Dispatch a notification event for Layout.tsx bell
      document.dispatchEvent(new CustomEvent("launchapp:bonus", {
        detail: {
          message: `${randomResponder.name} ${t("forum.commentNotif")}: "${item.title}"`,
          type: "reward",
        },
      }));
    }
    setReplyText("");
    setReplyingTo(null);
    sonnerToast.success(t("forum.replyPosted"));
  };

  // Network
  const [friends, setFriends] = useState<Set<string>>(() => {
    try { const raw = localStorage.getItem("launchapp_friends"); return raw ? new Set(JSON.parse(raw)) : new Set<string>(); }
    catch { return new Set<string>(); }
  });
  const [searchQuery, setSearchQuery] = useState("");
  const [viewProfile, setViewProfile] = useState<Founder | null>(null);
  const [networkView, setNetworkView] = useState<"all" | "friends">("all");
  const [showSendTokens, setShowSendTokens] = useState(false);
  const [tokenAmount, setTokenAmount] = useState(10);
  const [nicheFilter, setNicheFilter] = useState<string>("all");
  const [showMutualFriends, setShowMutualFriends] = useState(false);
  const [profileTab, setProfileTab] = useState<"info" | "activity">("info");
  const [profileScrolled, setProfileScrolled] = useState(false);
  const [confettiActive, setConfettiActive] = useState(false);
  const [previewProject, setPreviewProject] = useState<Project | null>(null);
  const [selectedBadge, setSelectedBadge] = useState<Badge | null>(null);
  const profileScrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => { localStorage.setItem("launchapp_friends", JSON.stringify([...friends])); }, [friends]);

  const toggleFriend = useCallback((id: string) => {
    setFriends((prev) => {
      const next = new Set(prev);
      const founder = founders.find((f) => f.id === id);
      if (next.has(id)) { next.delete(id); }
      else { next.add(id); if (founder) sonnerToast.success(`${founder.name} — ${t("community.friendAdded")}`); }
      return next;
    });
  }, [t]);

  const nicheOptions = ["all", "SaaS", "AI", "No-Code", "Design", "DevTools", "Analytics", "Content", "Growth"];

  const filteredFounders = founders
    .filter((f) => networkView === "all" || friends.has(f.id))
    .filter((f) => nicheFilter === "all" || f.skills.some((s) => s.toLowerCase().includes(nicheFilter.toLowerCase())))
    .filter((f) => !searchQuery || f.name.toLowerCase().includes(searchQuery.toLowerCase()) || f.company.toLowerCase().includes(searchQuery.toLowerCase()) || f.skills.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase())));

  // Suggested founders — not yet friends, sorted by mutual friends
  const suggested = founders
    .filter((f) => !friends.has(f.id))
    .sort((a, b) => b.mutualFriends - a.mutualFriends)
    .slice(0, 5);

  const onlineCount = founders.filter((f) => f.online).length;

  const getFounder = (id: string) => founders.find((f) => f.id === id);

  /** Invite friend via Web Share API (mobile) or clipboard (desktop) */
  const handleInviteFriend = async () => {
    const referralCode = `usr_${Date.now().toString(36)}`;
    const referralLink = `https://launchos.app/invite?ref=${referralCode}`;
    const shareData = {
      title: "Launch OS",
      text: t("community.inviteText"),
      url: referralLink,
    };
    // Mobile: native share dialog
    if (typeof navigator.share === "function" && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent)) {
      try {
        await navigator.share(shareData);
        return;
      } catch {
        // user cancelled — fall through to clipboard
      }
    }
    // Desktop: copy to clipboard
    const ok = await copyToClipboard(referralLink);
    if (ok) {
      sonnerToast.success(t("community.linkCopied"), { duration: 2500 });
    } else {
      sonnerToast.error("Failed to copy");
    }
  };

  /** Get projects by author */
  const getFounderProjects = (founderId: string) => projectList.filter((p) => p.authorId === founderId);

  /** Share profile via Web Share or clipboard */
  const handleShareProfile = async (founder: Founder) => {
    const profileLink = `https://launchos.app/profile/${founder.id}`;
    const shareData = {
      title: `${founder.name} — Launch OS`,
      text: `${founder.name}, ${founder.role} @ ${founder.company}`,
      url: profileLink,
    };
    if (typeof navigator.share === "function" && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent)) {
      try { await navigator.share(shareData); return; } catch { /* cancelled */ }
    }
    const ok = await copyToClipboard(profileLink);
    if (ok) {
      sonnerToast.success(t("community.profileCopied"), { duration: 2500 });
    } else { sonnerToast.error("Failed to copy"); }
  };

  /** Close profile and reset sub-states */
  const closeProfile = () => {
    setViewProfile(null);
    setShowSendTokens(false);
    setShowMutualFriends(false);
    setProfileTab("info");
    setProfileScrolled(false);
    setConfettiActive(false);
    setPreviewProject(null);
    setSelectedBadge(null);
  };

  return (
    <div
      className="p-4 sm:p-6 max-w-4xl mx-auto space-y-5"
      {...pullHandlers}
    >
      <PullToRefreshIndicator pullY={pullY} isRefreshing={isRefreshing} />

      {/* Header */}
      <LargeTitle
        title={t("community.title")}
        subtitle={t("community.subtitle")}
        actions={
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs text-zinc-400"><span className="text-emerald-400" style={{ fontWeight: 600 }}>{onlineCount}</span> {t("community.online")}</span>
            </div>
            <button
              onClick={() => navigate("/dashboard/messages")}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-purple-400 bg-purple-500/10 border border-purple-500/15 hover:bg-purple-500/15 transition-all"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              {t("community.tabMessages")}
            </button>
          </div>
        }
      />

      {loading ? (
        <CommunitySkeleton />
      ) : (
        <>
          {/* Section tabs */}
          <div className="flex gap-2 overflow-x-auto scrollbar-hide -mx-4 px-4 sm:mx-0 sm:px-0">
            {([
              { key: "network" as Section, label: t("community.tabNetwork"), icon: Users, count: founders.length },
              { key: "launches" as Section, label: t("community.tabLeaderboard"), icon: Trophy, count: sorted.length },
              { key: "feed" as Section, label: t("community.tabForum"), icon: MessageSquare, count: feedItems.length, badge: unreadReplies },
              { key: "referrals" as Section, label: t("sidebar.referrals"), icon: Gift, count: 0, badge: unseenReferrals },
            ] as { key: Section; label: string; icon: typeof Users; count: number; badge?: number }[]).map((tab) => (
              <button
                key={tab.key}
                onClick={() => {
                  setActiveSection(tab.key);
                  if (tab.key === "feed") setUnreadReplies(0);
                  if (tab.key === "referrals") {
                    setUnseenReferrals(0);
                    try {
                      const saved = localStorage.getItem("launchapp_referral_tree");
                      const count = saved ? (JSON.parse(saved) as unknown[]).length : 3;
                      localStorage.setItem("launchapp_referral_seen_count", String(count));
                    } catch {}
                  }
                }}
                className={`shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm transition-all relative ${
                  activeSection === tab.key
                    ? "bg-purple-500/15 text-purple-300 border border-purple-500/20"
                    : "text-zinc-500 border border-white/5 hover:border-white/10 hover:text-zinc-300"
                }`}
                style={{ fontWeight: activeSection === tab.key ? 600 : 400 }}
              >
                <tab.icon className="w-3.5 h-3.5" />
                {tab.label}
                {tab.key !== "referrals" && <span className="text-xs opacity-50">({tab.count})</span>}
                {tab.badge != null && tab.badge > 0 && activeSection !== tab.key && (
                  <motion.span
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ type: "spring", stiffness: 500, damping: 15 }}
                    className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 flex items-center justify-center rounded-full bg-purple-500 text-[10px] text-white"
                    style={{ fontWeight: 700 }}
                  >
                    <motion.span
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
                    >
                      {tab.badge}
                    </motion.span>
                  </motion.span>
                )}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">

            {/* ═══════════ NETWORK (default) ═══════════ */}
            {activeSection === "network" && (
              <motion.div key="network" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="space-y-5">

                {/* Suggested connections */}
                {suggested.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <Sparkles className="w-4 h-4 text-purple-400" />
                      <span className="text-sm community-section-title" style={{ fontWeight: 600 }}>{t("community.suggested")}</span>
                    </div>
                    <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-1 -mx-4 px-4 sm:mx-0 sm:px-0">
                      {suggested.map((founder) => (
                        <motion.div
                          key={founder.id}
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className="shrink-0 w-[160px] p-4 rounded-xl border border-white/5 bg-white/[0.02] hover:border-purple-500/15 transition-all text-center"
                        >
                          <div className="relative mx-auto mb-2 w-fit cursor-pointer" onClick={() => setViewProfile(founder)}>
                            <FounderAvatar founder={founder} />
                            {founder.online && (
                              <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-400 border-2 border-[#09090b]" />
                            )}
                          </div>
                          <div className="text-sm community-section-title truncate" style={{ fontWeight: 600 }}>{founder.name}</div>
                          <div className="text-[10px] text-zinc-500 truncate">{founder.company}</div>
                          {founder.mutualFriends > 0 && (
                            <div className="text-[10px] text-purple-400 mt-1 flex items-center justify-center gap-0.5">
                              <Users className="w-2.5 h-2.5" />{founder.mutualFriends} {t("community.mutual")}
                            </div>
                          )}
                          <div className="flex gap-1.5 mt-2.5">
                            <button
                              onClick={() => toggleFriend(founder.id)}
                              className="flex-1 flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg text-[11px] bg-purple-500/10 text-purple-400 border border-purple-500/15 hover:bg-purple-500/15 transition-all"
                            >
                              <UserPlus className="w-3 h-3" />{t("community.addFriend")}
                            </button>
                            <button
                              onClick={() => setViewProfile(founder)}
                              className="px-2 py-1.5 rounded-lg text-[11px] text-zinc-500 border border-white/5 hover:border-white/10 hover:text-zinc-300 transition-all"
                              title={t("community.viewProfile")}
                            >
                              <Eye className="w-3 h-3" />
                            </button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Search + filter */}
                <div className="flex flex-col gap-2.5">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-zinc-600 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder={t("community.searchFounders")}
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none text-sm transition-colors"
                    />
                  </div>
                  {/* View toggles + Invite button */}
                  <div className="flex gap-1.5 mb-1">
                    <button
                      onClick={() => setNetworkView("all")}
                      className={`shrink-0 px-3 py-2 rounded-xl text-xs transition-all whitespace-nowrap ${networkView === "all" ? "bg-purple-500/15 text-purple-300 border border-purple-500/20" : "text-zinc-500 border border-white/5 hover:border-white/10"}`}
                    >
                      {t("community.allFounders")}
                    </button>
                    <button
                      onClick={() => setNetworkView("friends")}
                      className={`shrink-0 px-3 py-2 rounded-xl text-xs transition-all flex items-center gap-1.5 whitespace-nowrap ${networkView === "friends" ? "bg-purple-500/15 text-purple-300 border border-purple-500/20" : "text-zinc-500 border border-white/5 hover:border-white/10"}`}
                    >
                      <Heart className="w-3 h-3" />{t("community.myFriends")} ({friends.size})
                    </button>
                    <button
                      onClick={handleInviteFriend}
                      className="shrink-0 ml-auto px-3 py-2 rounded-xl text-xs transition-all flex items-center gap-1.5 whitespace-nowrap bg-emerald-500/10 text-emerald-400 border border-emerald-500/15 hover:bg-emerald-500/15 active:scale-95"
                    >
                      <Link className="w-3 h-3" />{t("community.inviteFriend")}
                    </button>
                  </div>
                  {/* Niche filter pills — horizontal scroll */}
                  <div className="flex gap-1.5 overflow-x-auto scrollbar-hide -mx-4 px-4 sm:mx-0 sm:px-0">
                    {nicheOptions.map((niche) => (
                      <button
                        key={niche}
                        onClick={() => setNicheFilter(niche)}
                        className={`shrink-0 px-3 py-1.5 rounded-lg text-xs transition-all whitespace-nowrap ${
                          nicheFilter === niche
                            ? "bg-purple-500/15 text-purple-300 border border-purple-500/20"
                            : "text-zinc-500 border border-white/5 hover:border-white/10 hover:text-zinc-300"
                        }`}
                        style={{ fontWeight: nicheFilter === niche ? 600 : 400 }}
                      >
                        {niche === "all" ? t("community.allNiches") : niche}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Founder list */}
                <div className="space-y-2.5">
                  {filteredFounders.map((founder, i) => (
                    <motion.div
                      key={founder.id}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.03 }}
                      className="p-4 rounded-xl border border-white/5 bg-white/[0.02] hover:border-white/10 transition-all"
                    >
                      <div className="flex items-start gap-3">
                        {/* Avatar */}
                        <div className="relative shrink-0 cursor-pointer" onClick={() => setViewProfile(founder)}>
                          <FounderAvatar founder={founder} />
                          {founder.online && (
                            <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-400 border-2 border-[#09090b]" />
                          )}
                        </div>

                        {/* Info */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-sm community-section-title" style={{ fontWeight: 600 }}>{founder.name}</span>
                            {founder.online && <span className="text-[9px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded-full">{t("community.online")}</span>}
                          </div>
                          <div className="text-xs text-zinc-500">{founder.role} @ {founder.company}</div>
                          <p className="text-xs text-zinc-400 mt-1 line-clamp-1">{founder.bio}</p>

                          {/* Skills */}
                          <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                            {founder.skills.map((skill) => (
                              <span key={skill} className="text-[10px] px-2 py-0.5 rounded-md bg-white/[0.03] border border-white/5 text-zinc-500">{skill}</span>
                            ))}
                            <span className="text-[10px] text-zinc-600 flex items-center gap-0.5 ml-1">
                              <Zap className="w-2.5 h-2.5" />{founder.launches} {t("community.launches")}
                            </span>
                            {founder.mutualFriends > 0 && (
                              <span className="text-[10px] text-purple-400/70 flex items-center gap-0.5">
                                <Users className="w-2.5 h-2.5" />{founder.mutualFriends}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex flex-col gap-1.5 shrink-0">
                          <button
                            onClick={() => toggleFriend(founder.id)}
                            className={`px-3 py-1.5 rounded-lg text-xs transition-all ${
                              friends.has(founder.id)
                                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/15"
                                : "bg-purple-500/10 text-purple-400 border border-purple-500/15 hover:bg-purple-500/15"
                            }`}
                          >
                            {friends.has(founder.id) ? (
                              <span className="flex items-center gap-1"><UserCheck className="w-3 h-3" />{t("community.removeFriend")}</span>
                            ) : (
                              <span className="flex items-center gap-1"><UserPlus className="w-3 h-3" />{t("community.addFriend")}</span>
                            )}
                          </button>
                          <button
                            onClick={() => setViewProfile(founder)}
                            className="px-3 py-1.5 rounded-lg text-xs text-zinc-400 border border-white/5 hover:border-white/10 hover:text-zinc-300 transition-all flex items-center gap-1 justify-center"
                          >
                            <Eye className="w-3 h-3" />{t("community.viewProfile")}
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  ))}

                  {filteredFounders.length === 0 && (
                    <div className="text-center py-12">
                      <Users className="w-8 h-8 text-zinc-700 mx-auto mb-3" />
                      <p className="text-sm text-zinc-500">{networkView === "friends" ? t("community.noFriends") : t("community.noFriends")}</p>
                      <p className="text-xs text-zinc-600 mt-1">{t("community.noFriendsSub")}</p>
                      <button
                        onClick={handleInviteFriend}
                        className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/15 hover:bg-emerald-500/15 transition-all active:scale-95"
                      >
                        <Link className="w-3.5 h-3.5" />{t("community.inviteFriend")}
                      </button>
                      {networkView === "friends" && (
                        <button onClick={() => setNetworkView("all")} className="mt-2 block mx-auto text-xs text-purple-400 hover:text-purple-300 transition-colors">
                          {t("community.allFounders")} &gt;
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* ═══════════ LAUNCHES ═══════════ */}
            {activeSection === "launches" && (
              <motion.div key="launches" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="space-y-3">
                <p className="text-xs text-zinc-500 flex items-center gap-1.5">
                  <ArrowUp className="w-3 h-3" />
                  {t("community.banner")}
                </p>

                <div className="space-y-2">
                  {sorted.map((project, i) => {
                    const isTop3 = i < 3;
                    return (
                      <motion.div
                        key={project.id}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.03 }}
                        className={`flex items-center gap-3 p-3 sm:p-3.5 rounded-xl border transition-all ${
                          isTop3
                            ? "border-amber-500/10 bg-amber-500/[0.03] hover:border-amber-500/20"
                            : "border-white/5 bg-white/[0.02] hover:border-white/10"
                        }`}
                      >
                        <div className={`w-6 text-center shrink-0 ${isTop3 ? placeColors[i] : "text-zinc-600"}`} style={{ fontWeight: 700 }}>
                          {isTop3 ? (
                            <div className="flex flex-col items-center">
                              {i === 0 ? <Crown className="w-4 h-4" /> : i === 1 ? <Medal className="w-4 h-4" /> : <Award className="w-4 h-4" />}
                            </div>
                          ) : (
                            <span className="text-sm">{i + 1}</span>
                          )}
                        </div>

                        <button
                          onClick={() => handleUpvote(project.id)}
                          className={`flex flex-col items-center gap-0.5 px-2.5 py-1.5 rounded-lg border transition-all shrink-0 active:scale-95 ${
                            project.voted
                              ? "border-purple-500/30 bg-purple-500/10 text-purple-400"
                              : "border-white/5 text-zinc-500 hover:border-white/10 hover:text-zinc-300"
                          }`}
                        >
                          <ArrowUp className="w-3.5 h-3.5" />
                          <span className="text-xs" style={{ fontWeight: 600 }}>{project.upvotes}</span>
                        </button>

                        <div className="flex items-center gap-2.5 flex-1 min-w-0">
                          <div className="relative shrink-0 cursor-pointer" onClick={() => { const f = getFounder(project.authorId); if (f) setViewProfile(f); }}>
                            {(() => {
                              const founder = getFounder(project.authorId);
                              return founder ? <FounderAvatar founder={founder} size="sm" /> : (
                                <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${project.gradient} flex items-center justify-center text-white text-xs shrink-0`} style={{ fontWeight: 700 }}>
                                  {project.name[0]}
                                </div>
                              );
                            })()}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span className="text-sm community-section-title truncate" style={{ fontWeight: 600 }}>{project.name}</span>
                              {project.featured && <Star className="w-3 h-3 text-amber-400 fill-amber-400 shrink-0" />}
                            </div>
                            <p className="text-xs text-zinc-500 truncate">{project.tagline}</p>
                          </div>
                        </div>

                        <div className="hidden sm:flex items-center gap-3 text-xs text-zinc-600 shrink-0">
                          <span className="px-2 py-0.5 rounded-md bg-white/[0.03] border border-white/5">{project.category}</span>
                          <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{project.launchTime}</span>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {/* ═══════════ FORUM ═══════════ */}
            {activeSection === "feed" && (
              <motion.div key="feed" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="space-y-4">

                {/* Forum toolbar: category pills + create button */}
                <div className="flex items-center gap-2">
                  <div className="flex-1 flex gap-1.5 overflow-x-auto scrollbar-hide -mx-4 px-4 sm:mx-0 sm:px-0">
                    {FORUM_CATEGORIES.map((cat) => {
                      const active = forumCategory === cat.key;
                      return (
                        <button
                          key={cat.key}
                          onClick={() => setForumCategory(cat.key)}
                          className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs transition-all whitespace-nowrap ${
                            active
                              ? "bg-purple-500/15 text-purple-300 border border-purple-500/20"
                              : "text-zinc-500 border border-white/5 hover:border-white/10 hover:text-zinc-300"
                          }`}
                          style={{ fontWeight: active ? 600 : 400 }}
                        >
                          <cat.icon className={`w-3 h-3 ${active ? cat.color : ""}`} />
                          {t(cat.labelKey)}
                        </button>
                      );
                    })}
                  </div>
                  <button
                    onClick={() => setShowCreateThread(true)}
                    className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-purple-600 hover:bg-purple-500 text-white transition-all"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">{t("forum.newThread")}</span>
                  </button>
                </div>

                {/* Thread list */}
                {filteredFeed.length === 0 && (
                  <div className="text-center py-12">
                    <MessageSquare className="w-8 h-8 text-zinc-700 mx-auto mb-3" />
                    <p className="text-sm text-zinc-500">{t("forum.allTopics")}</p>
                  </div>
                )}

                {filteredFeed.map((item, i) => {
                  const author = getFounder(item.authorId);
                  if (!author) return null;
                  const catMeta = FORUM_CATEGORIES.find((c) => c.key === item.category);
                  return (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.03 }}
                      className="p-4 rounded-xl border border-white/5 bg-white/[0.02] hover:border-white/10 transition-all"
                    >
                      {/* Author row */}
                      <div className="flex items-center gap-2.5 mb-2.5">
                        <div className="cursor-pointer" onClick={() => setViewProfile(author)}>
                          <FounderAvatar founder={author} size="sm" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-sm community-section-title" style={{ fontWeight: 600 }}>{author.name}</span>
                            {item.isOwn && (
                              <span className="text-[9px] text-purple-400 bg-purple-500/10 px-1.5 py-0.5 rounded-full">you</span>
                            )}
                            {item.type === "launch" && (
                              <span className="text-xs text-emerald-400">{t("community.launched")} {item.projectName}</span>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] text-zinc-600">{item.time}</span>
                            {catMeta && catMeta.key !== "all" && (
                              <span className={`text-[9px] ${catMeta.color} bg-white/[0.03] px-1.5 py-0.5 rounded flex items-center gap-0.5`}>
                                <catMeta.icon className="w-2.5 h-2.5" />
                                {t(catMeta.labelKey)}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Badges */}
                      {(item.pinned || item.likes >= 40) && (
                        <div className="flex items-center gap-1.5 mb-2">
                          {item.pinned && (
                            <span className="text-[9px] text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded-full flex items-center gap-0.5 border border-amber-500/15">
                              <Pin className="w-2.5 h-2.5" />{t("forum.pinned")}
                            </span>
                          )}
                          {item.likes >= 40 && (
                            <span className="text-[9px] text-pink-400 bg-pink-500/10 px-1.5 py-0.5 rounded-full flex items-center gap-0.5 border border-pink-500/15">
                              <Flame className="w-2.5 h-2.5" />{t("forum.popular")}
                            </span>
                          )}
                        </div>
                      )}

                      {/* Content */}
                      {item.title && (
                        <h3
                          className="text-sm community-section-title mb-1 cursor-pointer hover:text-purple-300 transition-colors"
                          style={{ fontWeight: 600 }}
                          onClick={() => setOpenThreadId(openThreadId === item.id ? null : item.id)}
                        >
                          {item.title}
                        </h3>
                      )}
                      {item.content && <p className="text-xs text-zinc-400 leading-relaxed mb-3">{item.content}</p>}

                      {/* Actions bar */}
                      <div className="flex items-center gap-4 pt-2 border-t border-white/5">
                        <button
                          onClick={() => handleLikeFeed(item.id)}
                          className={`flex items-center gap-1.5 text-xs transition-all ${item.liked ? "text-pink-400" : "text-zinc-600 hover:text-zinc-400"}`}
                        >
                          <ThumbsUp className={`w-3.5 h-3.5 ${item.liked ? "fill-pink-400" : ""}`} />
                          {item.likes}
                        </button>
                        <button
                          onClick={() => {
                            if (item.replies && item.replies.length > 0) {
                              setOpenThreadId(openThreadId === item.id ? null : item.id);
                            }
                            setReplyingTo(replyingTo === item.id ? null : item.id);
                          }}
                          className={`flex items-center gap-1.5 text-xs transition-all ${(replyingTo === item.id || openThreadId === item.id) ? "text-purple-400" : "text-zinc-600 hover:text-zinc-400"}`}
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          {item.commentsCount} {t("forum.replies")}
                        </button>
                        <button className="flex items-center gap-1.5 text-xs text-zinc-600 hover:text-zinc-400 transition-all">
                          <Share2 className="w-3.5 h-3.5" />{t("community.share")}
                        </button>
                      </div>

                      {/* Thread view — comment tree */}
                      <AnimatePresence>
                        {openThreadId === item.id && item.replies && item.replies.length > 0 && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden"
                          >
                            <div className="mt-3 space-y-2 pl-3 border-l-2 border-purple-500/15">
                              {item.replies.map((reply) => {
                                const replyAuthor = getFounder(reply.authorId);
                                if (!replyAuthor) return null;
                                return (
                                  <div key={reply.id} className="flex gap-2.5 p-2.5 rounded-lg bg-white/[0.015] hover:bg-white/[0.03] transition-all">
                                    <div className="cursor-pointer shrink-0" onClick={() => setViewProfile(replyAuthor)}>
                                      <FounderAvatar founder={replyAuthor} size="xs" />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                      <div className="flex items-center gap-2">
                                        <span className="text-xs text-zinc-300 cursor-pointer hover:text-purple-300 transition-colors" style={{ fontWeight: 600 }} onClick={() => setViewProfile(replyAuthor)}>{replyAuthor.name}</span>
                                        <span className="text-[9px] text-zinc-600">{reply.time}</span>
                                      </div>
                                      <p className="text-xs text-zinc-400 mt-0.5 leading-relaxed">{reply.text}</p>
                                      <button className="flex items-center gap-1 text-[10px] text-zinc-600 hover:text-pink-400 mt-1 transition-colors">
                                        <ThumbsUp className="w-2.5 h-2.5" /> {reply.likes}
                                      </button>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Inline reply */}
                      <AnimatePresence>
                        {replyingTo === item.id && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden"
                          >
                            <div className="flex gap-2 mt-3">
                              <input
                                value={replyText}
                                onChange={(e) => setReplyText(e.target.value)}
                                placeholder={t("forum.writeReply")}
                                className="flex-1 px-3 py-2 rounded-lg bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none text-xs transition-colors"
                                onKeyDown={(e) => { if (e.key === "Enter") handleReply(item.id); }}
                                autoFocus
                              />
                              <button
                                onClick={() => handleReply(item.id)}
                                disabled={!replyText.trim()}
                                className="px-3 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs transition-all disabled:opacity-30 disabled:cursor-not-allowed flex items-center gap-1"
                              >
                                <Send className="w-3 h-3" />
                              </button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  );
                })}
              </motion.div>
            )}

            {/* ═══════════ REFERRALS ═══════════ */}
            {activeSection === "referrals" && (
              <motion.div key="referrals" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
                <ReferralProgram />
              </motion.div>
            )}

          </AnimatePresence>

          {/* ═══════════ Create Thread Modal ═══════════ */}
          <AnimatePresence>
            {showCreateThread && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4"
                onClick={() => setShowCreateThread(false)}
              >
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: 20 }}
                  className="relative w-full max-w-md rounded-2xl border border-white/10 bg-[#18181b] p-6 space-y-4"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="flex items-center justify-between">
                    <h2 className="text-white" style={{ fontWeight: 700 }}>{t("forum.createThread")}</h2>
                    <button onClick={() => setShowCreateThread(false)} className="text-zinc-600 hover:text-zinc-300 transition-colors">
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Category selector */}
                  <div>
                    <label className="text-xs text-zinc-500 mb-2 block">{t("forum.category")}</label>
                    <div className="flex flex-wrap gap-1.5">
                      {FORUM_CATEGORIES.filter((c) => c.key !== "all").map((cat) => (
                        <button
                          key={cat.key}
                          onClick={() => setNewThreadCategory(cat.key)}
                          className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs transition-all ${
                            newThreadCategory === cat.key
                              ? "bg-purple-500/15 text-purple-300 border border-purple-500/20"
                              : "text-zinc-500 border border-white/5 hover:border-white/10"
                          }`}
                        >
                          <cat.icon className={`w-3 h-3 ${newThreadCategory === cat.key ? cat.color : ""}`} />
                          {t(cat.labelKey)}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Title */}
                  <input
                    value={newThreadTitle}
                    onChange={(e) => setNewThreadTitle(e.target.value)}
                    placeholder={t("forum.threadTitle")}
                    className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none text-sm transition-colors"
                  />

                  {/* Content */}
                  <textarea
                    value={newThreadContent}
                    onChange={(e) => setNewThreadContent(e.target.value)}
                    placeholder={t("forum.threadContent")}
                    rows={4}
                    className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none text-sm resize-none transition-colors"
                  />

                  <button
                    onClick={handleCreateThread}
                    disabled={!newThreadTitle.trim()}
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-sm transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                  >
                    <Send className="w-3.5 h-3.5" />
                    {t("forum.post")}
                  </button>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* ══════════ Apple-style Profile Modal ═══════════ */}
          <AnimatePresence>
            {viewProfile && (() => {
              const founderProjects = getFounderProjects(viewProfile.id);
              const progress = founderProgress[viewProfile.id] || { step: 1, label: "Start" };
              const joinDate = founderJoinDates[viewProfile.id] || "2025";
              const mutualList = getMutualFounders(viewProfile.id, founders);
              const totalUpvotes = founderProjects.reduce((s, p) => s + p.upvotes, 0);
              const level = Math.min(Math.floor(viewProfile.tokens / 500) + 1, 10);
              const activities = founderActivity[viewProfile.id] || [];
              const actKeys: Record<string, string> = { launch: "community.actLaunch", upvote: "community.actUpvote", join: "community.actJoin", badge: "community.actBadge", token: "community.actToken" };
              const pipelineLabels = ["Idea", "Package", "Channels", "Launch", "Growth"];
              const earnedBadgeIds = founderBadges[viewProfile.id] || [];
              const badges = allBadges.map((b) => ({ ...b, earned: earnedBadgeIds.includes(b.id) }));

              return (
                <motion.div
                  key="profile-modal"
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  className="fixed inset-0 bg-black/70 backdrop-blur-md z-[100] flex items-end sm:items-center justify-center"
                  onClick={closeProfile}
                >
                  {/* Profile card — swipe-down to dismiss on mobile */}
                  <motion.div
                    initial={{ y: "100%" }}
                    animate={{ y: 0 }}
                    exit={{ y: "100%" }}
                    transition={{ type: "spring", damping: 32, stiffness: 380, mass: 0.8 }}
                    drag="y"
                    dragConstraints={{ top: 0, bottom: 0 }}
                    dragElastic={{ top: 0, bottom: 0.6 }}
                    onDragEnd={(_: unknown, info: { offset: { y: number }; velocity: { y: number } }) => {
                      if (info.offset.y > 120 || info.velocity.y > 400) closeProfile();
                    }}
                    className="relative w-full max-w-[420px] rounded-t-[28px] sm:rounded-[24px] bg-[#1c1c1e] overflow-hidden max-h-[92vh] sm:max-h-[85vh] flex flex-col shadow-2xl"
                    style={{ boxShadow: "0 -8px 40px rgba(0,0,0,0.5)" }}
                    onClick={(e) => e.stopPropagation()}
                  >
                    {/* ─── Drag indicator (mobile) ─── */}
                    <div className="sm:hidden flex justify-center pt-2.5 pb-1 shrink-0">
                      <div className="w-9 h-[5px] rounded-full bg-white/20" />
                    </div>

                    {/* Confetti overlay */}
                    <ConfettiCanvas active={confettiActive} onComplete={() => setConfettiActive(false)} />

                    {/* ─── Sticky blur header (shows on scroll) ─── */}
                    <AnimatePresence>
                      {profileScrolled && (
                        <motion.div
                          initial={{ opacity: 0, y: -8 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -8 }}
                          transition={{ duration: 0.2 }}
                          className="absolute top-0 left-0 right-0 z-20 flex items-center gap-3 px-5 py-2.5 bg-[#1c1c1e]/80 backdrop-blur-xl border-b border-white/[0.04]"
                        >
                          <FounderAvatar founder={viewProfile} size="xs" className="rounded-lg" />
                          <span className="text-[14px] text-white truncate" style={{ fontWeight: 600 }}>{viewProfile.name}</span>
                          <div className="ml-auto flex items-center gap-2">
                            <button
                              onClick={() => handleShareProfile(viewProfile)}
                              className="w-7 h-7 rounded-full bg-white/[0.06] flex items-center justify-center text-zinc-400 hover:text-white transition-all active:scale-90"
                            >
                              <Share2 className="w-3 h-3" />
                            </button>
                            <button
                              onClick={closeProfile}
                              className="w-7 h-7 rounded-full bg-white/[0.06] flex items-center justify-center text-zinc-400 hover:text-white transition-all active:scale-90"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* ─── Gradient cover ─── */}
                    <div className={`h-24 bg-gradient-to-br ${viewProfile.gradient} relative shrink-0`}>
                      {/* Top-right actions */}
                      <div className="absolute top-3 right-3 flex items-center gap-2 z-10">
                        <button
                          onClick={() => handleShareProfile(viewProfile)}
                          className="w-8 h-8 rounded-full bg-black/30 backdrop-blur-xl flex items-center justify-center text-white/70 hover:text-white hover:bg-black/40 transition-all active:scale-90"
                        >
                          <Share2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={closeProfile}
                          className="w-8 h-8 rounded-full bg-black/30 backdrop-blur-xl flex items-center justify-center text-white/70 hover:text-white hover:bg-black/40 transition-all active:scale-90"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* ─── Scrollable body ─── */}
                    <div
                      ref={profileScrollRef}
                      className="overflow-y-auto flex-1 overscroll-contain"
                      onScroll={(e) => {
                        const scrollTop = (e.target as HTMLDivElement).scrollTop;
                        setProfileScrolled(scrollTop > 80);
                      }}
                    >
                      {/* Avatar + name block — avatar overlaps gradient, name below */}
                      <div className="px-6 -mt-9 relative z-10">
                        <div className="relative shrink-0 w-[72px] h-[72px]">
                          <FounderAvatar founder={viewProfile} size="lg" className="!w-[72px] !h-[72px] rounded-[20px] ring-[4px] ring-[#1c1c1e] shadow-lg" />
                          {viewProfile.online && (
                            <div className="absolute -bottom-0.5 -right-0.5 w-4.5 h-4.5 rounded-full bg-emerald-400 border-[3px] border-[#1c1c1e] shadow-sm" />
                          )}
                        </div>
                        <div className="mt-2.5">
                          <h3 className="text-white text-[20px]" style={{ fontWeight: 700, letterSpacing: "-0.02em" }}>{viewProfile.name}</h3>
                          <p className="text-[14px] text-zinc-400 mt-0.5" style={{ fontWeight: 400 }}>{viewProfile.role} @ {viewProfile.company}</p>
                        </div>
                      </div>

                      {/* Status pills */}
                      <div className="px-6 mt-2.5 flex items-center gap-2.5">
                        <span className="inline-flex items-center gap-1.5 text-[11px] text-zinc-500" style={{ fontWeight: 500 }}>
                          {viewProfile.online ? (
                            <><span className="w-[6px] h-[6px] rounded-full bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.5)]" />{t("community.activeNow")}</>
                          ) : (
                            <><Clock className="w-3 h-3" />{t("community.lastSeen")}</>
                          )}
                        </span>
                        <span className="text-zinc-700">·</span>
                        <span className="inline-flex items-center gap-1 text-[11px] text-zinc-500" style={{ fontWeight: 500 }}>
                          <Calendar className="w-3 h-3" />{t("community.memberSince")} {joinDate}
                        </span>
                      </div>

                      {/* Bio */}
                      <div className="px-6 mt-4">
                        <p className="text-[13px] text-zinc-300 leading-[1.6]" style={{ fontWeight: 400 }}>{viewProfile.bio}</p>
                      </div>

                      {/* Skills */}
                      <div className="px-6 mt-3 flex items-center gap-1.5 flex-wrap">
                        {viewProfile.skills.map((skill) => (
                          <span key={skill} className="text-[11px] px-2.5 py-1 rounded-lg bg-purple-500/8 border border-purple-500/12 text-purple-300" style={{ fontWeight: 500 }}>{skill}</span>
                        ))}
                      </div>

                      {/* ─── Stats grid ─── */}
                      <div className="px-6 mt-5">
                        <div className="grid grid-cols-4 gap-2">
                          {[
                            { value: viewProfile.launches, label: t("community.launches"), color: "text-purple-400", icon: null },
                            { value: viewProfile.tokens.toLocaleString(), label: t("community.tokens"), color: "text-amber-400", icon: <Coins className="w-3 h-3 mr-0.5" /> },
                            { value: totalUpvotes, label: t("community.upvotes"), color: "text-cyan-400", icon: null },
                            { value: `Lv.${level}`, label: t("community.level"), color: "text-emerald-400", icon: null },
                          ].map((stat, i) => (
                            <div key={i} className="py-3 rounded-2xl bg-white/[0.04] text-center">
                              <div className={`text-[15px] ${stat.color} flex items-center justify-center`} style={{ fontWeight: 700 }}>
                                {stat.icon}{stat.value}
                              </div>
                              <div className="text-[10px] text-zinc-500 mt-0.5" style={{ fontWeight: 500 }}>{stat.label}</div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* ─── Pipeline progress ─── */}
                      <div className="px-6 mt-5">
                        <div className="flex items-center justify-between mb-2.5">
                          <span className="text-[11px] text-zinc-500 flex items-center gap-1.5" style={{ fontWeight: 600 }}>
                            <Target className="w-3.5 h-3.5" />{t("community.progress")} — {progress.label}
                          </span>
                          <span className="text-[10px] text-purple-400/70" style={{ fontWeight: 600 }}>{progress.step}/5</span>
                        </div>
                        <div className="flex gap-[5px]">
                          {pipelineLabels.map((lbl, i) => (
                            <div key={i} className="flex-1">
                              <div className="h-[5px] rounded-full overflow-hidden bg-white/[0.06]">
                                <motion.div
                                  initial={{ width: 0 }}
                                  animate={{ width: i < progress.step ? "100%" : "0%" }}
                                  transition={{ delay: i * 0.08, duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
                                  className="h-full rounded-full bg-gradient-to-r from-purple-500 to-purple-400"
                                />
                              </div>
                              <div className="text-[8px] text-zinc-600 text-center mt-1" style={{ fontWeight: 500 }}>{lbl}</div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* ─── Tab switcher: Info / Activity ─── */}
                      <div className="px-6 mt-5">
                        <div className="flex gap-0 rounded-xl bg-white/[0.04] p-[3px]">
                          {(["info", "activity"] as const).map((tab) => (
                            <button
                              key={tab}
                              onClick={() => setProfileTab(tab)}
                              className={`flex-1 py-2 rounded-[10px] text-[12px] transition-all ${
                                profileTab === tab
                                  ? "bg-white/[0.08] text-white shadow-sm"
                                  : "text-zinc-500 hover:text-zinc-400"
                              }`}
                              style={{ fontWeight: 600 }}
                            >
                              {tab === "info" ? t("community.about") : t("community.activity")}
                            </button>
                          ))}
                        </div>
                      </div>

                      <AnimatePresence mode="wait">
                        {profileTab === "info" ? (
                          <motion.div
                            key="info-tab"
                            initial={{ opacity: 0, x: -12 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -12 }}
                            transition={{ duration: 0.2 }}
                          >
                            {/* Projects */}
                            <div className="px-6 mt-4">
                              <div className="text-[11px] text-zinc-500 mb-2.5 flex items-center gap-1.5" style={{ fontWeight: 600 }}>
                                <Sparkles className="w-3.5 h-3.5" />{t("community.projects")} ({founderProjects.length})
                              </div>
                              {founderProjects.length > 0 ? (
                                <div className="space-y-2">
                                  {founderProjects.map((proj) => (
                                    <button
                                      key={proj.id}
                                      onClick={() => setPreviewProject(proj)}
                                      className="w-full flex items-center gap-3 p-3 rounded-2xl bg-white/[0.03] hover:bg-white/[0.06] transition-all active:scale-[0.98] text-left"
                                    >
                                      <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${proj.gradient} flex items-center justify-center text-white text-sm shrink-0 shadow-sm`} style={{ fontWeight: 700 }}>
                                        {proj.name[0]}
                                      </div>
                                      <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-1.5">
                                          <span className="text-[13px] text-white truncate" style={{ fontWeight: 600 }}>{proj.name}</span>
                                          {proj.featured && <Star className="w-3 h-3 text-amber-400 fill-amber-400 shrink-0" />}
                                        </div>
                                        <p className="text-[11px] text-zinc-500 truncate">{proj.tagline}</p>
                                      </div>
                                      <div className="flex items-center gap-1 text-[11px] text-zinc-400 shrink-0 bg-white/[0.04] px-2 py-1 rounded-lg">
                                        <ArrowUp className="w-3 h-3" />{proj.upvotes}
                                      </div>
                                    </button>
                                  ))}
                                </div>
                              ) : (
                                <div className="text-center py-5 rounded-2xl bg-white/[0.02]">
                                  <Sparkles className="w-5 h-5 text-zinc-700 mx-auto mb-1.5" />
                                  <p className="text-[11px] text-zinc-600">{t("community.noProjects")}</p>
                                </div>
                              )}
                            </div>

                            {/* ─── Badges / Achievements ─── */}
                            <div className="px-6 mt-5">
                              <div className="text-[11px] text-zinc-500 mb-2.5 flex items-center gap-1.5" style={{ fontWeight: 600 }}>
                                <Award className="w-3.5 h-3.5" />{t("community.badges")} ({badges.filter((b) => b.earned).length}/{badges.length})
                              </div>
                              <div className="grid grid-cols-4 gap-2">
                                {badges.map((badge, bIdx) => (
                                  <motion.button
                                    key={badge.id}
                                    initial={{ opacity: 0, scale: 0.8 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    transition={{ delay: bIdx * 0.04 }}
                                    onClick={() => setSelectedBadge(selectedBadge?.id === badge.id ? null : badge)}
                                    className={`relative flex flex-col items-center py-3 px-1 rounded-2xl transition-all ${
                                      badge.earned
                                        ? "bg-white/[0.04] hover:bg-white/[0.07] active:scale-95"
                                        : "bg-white/[0.02] opacity-40"
                                    }`}
                                  >
                                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${badge.gradient} flex items-center justify-center text-lg mb-1.5 shadow-sm ${
                                      badge.earned ? "" : "grayscale opacity-60"
                                    }`}>
                                      {badge.earned ? (() => { const Ic = badgeIconMap[badge.icon]; return Ic ? <Ic className="w-5 h-5 text-white" /> : null; })() : <Lock className="w-4 h-4 text-white/60" />}
                                    </div>
                                    <span className={`text-[9px] text-center leading-tight truncate w-full px-0.5 ${badge.earned ? "text-zinc-400" : "text-zinc-600"}`} style={{ fontWeight: 600 }}>
                                      {badge.label}
                                    </span>
                                    {/* Progress bar for locked badges */}
                                    {!badge.earned && badgeProgress[badge.id] !== undefined && (
                                      <div className="w-full mt-1.5 px-1">
                                        <div className="h-[3px] rounded-full bg-white/[0.06] overflow-hidden">
                                          <motion.div
                                            initial={{ width: 0 }}
                                            animate={{ width: `${badgeProgress[badge.id]}%` }}
                                            transition={{ delay: 0.3, duration: 0.6, ease: "easeOut" }}
                                            className="h-full rounded-full bg-zinc-500"
                                          />
                                        </div>
                                        <div className="text-[7px] text-zinc-600 text-center mt-0.5" style={{ fontWeight: 600 }}>{badgeProgress[badge.id]}%</div>
                                      </div>
                                    )}
                                    {badge.earned && (
                                      <div className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 flex items-center justify-center shadow-sm">
                                        <BadgeCheck className="w-2.5 h-2.5 text-white" />
                                      </div>
                                    )}
                                  </motion.button>
                                ))}
                              </div>

                              {/* Badge detail popup */}
                              <AnimatePresence>
                                {selectedBadge && (
                                  <motion.div
                                    initial={{ opacity: 0, y: -8, height: 0 }}
                                    animate={{ opacity: 1, y: 0, height: "auto" }}
                                    exit={{ opacity: 0, y: -8, height: 0 }}
                                    className="overflow-hidden"
                                  >
                                    <div className="mt-2.5 p-3.5 rounded-2xl bg-white/[0.04] border border-white/[0.06]">
                                      <div className="flex items-center gap-3">
                                        <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${selectedBadge.gradient} flex items-center justify-center text-xl shadow-md ${
                                          !selectedBadge.earned ? "grayscale opacity-60" : ""
                                        }`}>
                                          {selectedBadge.earned ? (() => { const Ic = badgeIconMap[selectedBadge.icon]; return Ic ? <Ic className="w-5 h-5 text-white" /> : null; })() : <Lock className="w-4.5 h-4.5 text-white/60" />}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                          <div className="text-[13px] text-white" style={{ fontWeight: 700 }}>{selectedBadge.label}</div>
                                          <p className="text-[11px] text-zinc-400 mt-0.5">{selectedBadge.description}</p>
                                        </div>
                                      </div>
                                      <div className="flex items-center gap-2 mt-2.5 pt-2.5 border-t border-white/[0.04]">
                                        {selectedBadge.earned ? (
                                          <span className="text-[10px] text-emerald-400 flex items-center gap-1" style={{ fontWeight: 600 }}>
                                            <BadgeCheck className="w-3 h-3" />{t("community.badgeEarned")} · {badgeEarnedDates[selectedBadge.id] || "2025"}
                                          </span>
                                        ) : (
                                          <span className="text-[10px] text-zinc-500 flex items-center gap-1" style={{ fontWeight: 600 }}>
                                            <Lock className="w-3 h-3" />{t("community.badgeLocked")}
                                            {badgeProgress[selectedBadge.id] !== undefined && (
                                              <> · {badgeProgress[selectedBadge.id]}%</>
                                            )}
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                  </motion.div>
                                )}
                              </AnimatePresence>
                            </div>

                            {/* Mutual Friends */}
                            <div className="px-6 mt-4 pb-2">
                              <button
                                onClick={() => mutualList.length > 0 && setShowMutualFriends(true)}
                                className="w-full flex items-center gap-2 text-[11px] text-zinc-500 mb-2.5 hover:text-zinc-300 transition-colors"
                                style={{ fontWeight: 600 }}
                                disabled={mutualList.length === 0}
                              >
                                <Users className="w-3.5 h-3.5" />
                                {t("community.mutualFriends")} ({mutualList.length})
                                {mutualList.length > 0 && <ChevronRight className="w-3.5 h-3.5 ml-auto text-zinc-600" />}
                              </button>
                              {mutualList.length > 0 ? (
                                <button
                                  onClick={() => setShowMutualFriends(true)}
                                  className="flex items-center gap-2 p-3 rounded-2xl bg-white/[0.03] w-full hover:bg-white/[0.05] transition-colors"
                                >
                                  <div className="flex -space-x-2.5">
                                    {mutualList.slice(0, 5).map((mf) => (
                                      <FounderAvatar key={mf.id} founder={mf} size="xs" className="ring-[2px] ring-[#1c1c1e]" />
                                    ))}
                                  </div>
                                  <span className="text-[12px] text-zinc-400 ml-1" style={{ fontWeight: 500 }}>
                                    {mutualList.map((mf) => mf.name.split(" ")[0]).slice(0, 3).join(", ")}
                                    {mutualList.length > 3 && ` +${mutualList.length - 3}`}
                                  </span>
                                  <ChevronRight className="w-4 h-4 text-zinc-600 ml-auto" />
                                </button>
                              ) : (
                                <div className="text-center py-4 rounded-2xl bg-white/[0.02]">
                                  <p className="text-[11px] text-zinc-600">{t("community.noMutualFriends")}</p>
                                </div>
                              )}
                            </div>
                          </motion.div>
                        ) : (
                          <motion.div
                            key="activity-tab"
                            initial={{ opacity: 0, x: 12 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 12 }}
                            transition={{ duration: 0.2 }}
                            className="px-6 mt-4 pb-2"
                          >
                            {activities.length > 0 ? (
                              <div className="space-y-0">
                                {activities.map((act, i) => {
                                  const Icon = activityIcons[act.type];
                                  const colorClass = activityColors[act.type];
                                  return (
                                    <div key={act.id} className="flex items-start gap-3 relative">
                                      {/* Timeline line */}
                                      {i < activities.length - 1 && (
                                        <div className="absolute left-[14px] top-8 bottom-0 w-[1.5px] bg-white/[0.05]" />
                                      )}
                                      <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${colorClass}`}>
                                        <Icon className="w-3 h-3" />
                                      </div>
                                      <div className="flex-1 min-w-0 pb-4">
                                        <p className="text-[12px] text-zinc-300" style={{ fontWeight: 500 }}>
                                          {t(actKeys[act.type])} {act.text && <span className="text-white" style={{ fontWeight: 600 }}>{act.text}</span>}
                                        </p>
                                        <span className="text-[10px] text-zinc-600">{act.time}</span>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            ) : (
                              <div className="text-center py-8">
                                <Clock className="w-5 h-5 text-zinc-700 mx-auto mb-1.5" />
                                <p className="text-[11px] text-zinc-600">No activity yet</p>
                              </div>
                            )}
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* ─── Sticky action buttons ─── */}
                      <div className="px-6 pt-3 pb-5 space-y-2.5 mt-auto">
                        {/* Primary actions */}
                        <div className="flex gap-2.5">
                          <button
                            onClick={() => toggleFriend(viewProfile.id)}
                            className={`flex-[1.3] flex items-center justify-center gap-2 py-3.5 rounded-2xl text-[14px] transition-all active:scale-[0.97] ${
                              friends.has(viewProfile.id)
                                ? "bg-emerald-500/12 text-emerald-400"
                                : "bg-purple-500 hover:bg-purple-400 text-white shadow-lg shadow-purple-500/20"
                            }`}
                            style={{ fontWeight: 600 }}
                          >
                            {friends.has(viewProfile.id) ? (
                              <><UserCheck className="w-[18px] h-[18px]" />{t("community.removeFriend")}</>
                            ) : (
                              <><UserPlus className="w-[18px] h-[18px]" />{t("community.addFriend")}</>
                            )}
                          </button>
                          <button
                            onClick={() => { navigate("/dashboard/messages", { state: { founderId: viewProfile.id } }); closeProfile(); }}
                            className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-2xl text-[14px] bg-white/[0.06] text-zinc-300 hover:bg-white/[0.08] transition-all active:scale-[0.97]"
                            style={{ fontWeight: 600 }}
                          >
                            <MessageCircle className="w-[18px] h-[18px]" />{t("community.message")}
                          </button>
                        </div>

                        {/* Send tokens */}
                        {!showSendTokens ? (
                          <button
                            onClick={() => setShowSendTokens(true)}
                            className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl text-[13px] text-amber-400/80 bg-amber-500/6 hover:bg-amber-500/10 transition-all active:scale-[0.98]"
                            style={{ fontWeight: 600 }}
                          >
                            <Coins className="w-4 h-4" />{t("community.sendTokens")}
                          </button>
                        ) : (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            exit={{ opacity: 0, height: 0 }}
                            className="rounded-2xl bg-amber-500/6 p-3.5 space-y-2.5 overflow-hidden"
                          >
                            <div className="flex items-center gap-2">
                              <Coins className="w-3.5 h-3.5 text-amber-400" />
                              <span className="text-[12px] text-amber-400" style={{ fontWeight: 600 }}>{t("community.sendTokens")}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              {[10, 25, 50, 100].map((amt) => (
                                <button
                                  key={amt}
                                  onClick={() => setTokenAmount(amt)}
                                  className={`flex-1 py-2 rounded-xl text-[12px] transition-all ${
                                    tokenAmount === amt
                                      ? "bg-amber-500/20 text-amber-300"
                                      : "bg-white/[0.04] text-zinc-500 hover:bg-white/[0.06]"
                                  }`}
                                  style={{ fontWeight: 600 }}
                                >
                                  {amt}
                                </button>
                              ))}
                            </div>
                            <div className="flex gap-2">
                              <button
                                onClick={() => setShowSendTokens(false)}
                                className="flex-1 py-2.5 rounded-xl text-[12px] text-zinc-500 bg-white/[0.04] hover:bg-white/[0.06] transition-all"
                                style={{ fontWeight: 500 }}
                              >
                                ✕
                              </button>
                              <button
                                onClick={() => {
                                  setConfettiActive(true);
                                  playConfettiSound();
                                  sonnerToast.success(
                                    `${tokenAmount} tokens sent to ${viewProfile.name}`,
                                    { description: t("community.tokensSent"), duration: 3000 }
                                  );
                                  setShowSendTokens(false);
                                }}
                                className="flex-[2] flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-[12px] text-amber-300 bg-amber-500/15 hover:bg-amber-500/20 transition-all"
                                style={{ fontWeight: 600 }}
                              >
                                <Send className="w-3 h-3" />{t("community.sendTokens")} ({tokenAmount})
                              </button>
                            </div>
                          </motion.div>
                        )}
                      </div>
                    </div>
                  </motion.div>

                  {/* ──── Mutual Friends Sub-modal ──── */}
                  <AnimatePresence>
                    {showMutualFriends && (
                      <motion.div
                        key="mutual-modal"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 bg-black/50 backdrop-blur-md z-[110] flex items-end sm:items-center justify-center"
                        onClick={(e) => { e.stopPropagation(); setShowMutualFriends(false); }}
                      >
                        <motion.div
                          initial={{ y: "100%" }}
                          animate={{ y: 0 }}
                          exit={{ y: "100%" }}
                          transition={{ type: "spring", damping: 30, stiffness: 360 }}
                          className="w-full max-w-sm rounded-t-[24px] sm:rounded-[20px] bg-[#1c1c1e] overflow-hidden max-h-[55vh] flex flex-col shadow-2xl"
                          onClick={(e) => e.stopPropagation()}
                        >
                          {/* Drag indicator */}
                          <div className="sm:hidden flex justify-center pt-2.5 pb-0.5 shrink-0">
                            <div className="w-9 h-[5px] rounded-full bg-white/20" />
                          </div>
                          <div className="flex items-center justify-between px-5 py-3 border-b border-white/[0.04] shrink-0">
                            <h4 className="text-[15px] text-white" style={{ fontWeight: 600 }}>{t("community.mutualFriends")} ({mutualList.length})</h4>
                            <button onClick={() => setShowMutualFriends(false)} className="w-7 h-7 rounded-full bg-white/[0.06] flex items-center justify-center text-zinc-500 hover:text-zinc-300 transition-colors">
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <div className="overflow-y-auto flex-1 overscroll-contain">
                            {mutualList.map((mf) => (
                              <button
                                key={mf.id}
                                onClick={() => {
                                  setShowMutualFriends(false);
                                  setShowSendTokens(false);
                                  setProfileTab("info");
                                  setProfileScrolled(false);
                                  setSelectedBadge(null);
                                  setViewProfile(mf);
                                  if (profileScrollRef.current) profileScrollRef.current.scrollTop = 0;
                                }}
                                className="w-full flex items-center gap-3.5 px-5 py-3.5 hover:bg-white/[0.03] transition-all text-left border-b border-white/[0.03] active:bg-white/[0.05]"
                              >
                                <div className="relative shrink-0">
                                  <FounderAvatar founder={mf} size="sm" />
                                  {mf.online && (
                                    <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-[#1c1c1e]" />
                                  )}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="text-[14px] text-white" style={{ fontWeight: 600 }}>{mf.name}</div>
                                  <div className="text-[11px] text-zinc-500">{mf.role} @ {mf.company}</div>
                                </div>
                                <ChevronRight className="w-4 h-4 text-zinc-600 shrink-0" />
                              </button>
                            ))}
                          </div>
                        </motion.div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* ──── Project Preview Sub-modal ──── */}
                  <AnimatePresence>
                    {previewProject && (() => {
                      const desc = projectDescriptions[previewProject.id] || previewProject.tagline;
                      const metrics = projectMetrics[previewProject.id];
                      const author = founders.find((f) => f.id === previewProject.authorId);
                      return (
                        <motion.div
                          key="project-preview"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="fixed inset-0 bg-black/60 backdrop-blur-md z-[110] flex items-end sm:items-center justify-center"
                          onClick={(e) => { e.stopPropagation(); setPreviewProject(null); }}
                        >
                          <motion.div
                            initial={{ y: "100%" }}
                            animate={{ y: 0 }}
                            exit={{ y: "100%" }}
                            transition={{ type: "spring", damping: 30, stiffness: 360 }}
                            className="w-full max-w-sm rounded-t-[24px] sm:rounded-[20px] bg-[#1c1c1e] overflow-hidden max-h-[75vh] flex flex-col shadow-2xl"
                            onClick={(e) => e.stopPropagation()}
                          >
                            {/* Drag indicator */}
                            <div className="sm:hidden flex justify-center pt-2.5 pb-0.5 shrink-0">
                              <div className="w-9 h-[5px] rounded-full bg-white/20" />
                            </div>

                            {/* Project gradient header */}
                            <div className={`h-20 bg-gradient-to-br ${previewProject.gradient} relative shrink-0`}>
                              <div className="absolute inset-x-0 bottom-0 h-10 bg-gradient-to-t from-[#1c1c1e] to-transparent" />
                              <button
                                onClick={() => setPreviewProject(null)}
                                className="absolute top-3 right-3 w-7 h-7 rounded-full bg-black/30 backdrop-blur-xl flex items-center justify-center text-white/70 hover:text-white transition-all active:scale-90 z-10"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            {/* Content */}
                            <div className="overflow-y-auto flex-1 overscroll-contain px-5 pb-5 -mt-6 relative z-10">
                              {/* Project icon + name */}
                              <div className="flex items-end gap-3.5">
                                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${previewProject.gradient} flex items-center justify-center text-white text-xl shrink-0 shadow-lg ring-[3px] ring-[#1c1c1e]`} style={{ fontWeight: 700 }}>
                                  {previewProject.name[0]}
                                </div>
                                <div className="flex-1 min-w-0 pb-0.5">
                                  <div className="flex items-center gap-1.5">
                                    <h4 className="text-[17px] text-white truncate" style={{ fontWeight: 700 }}>{previewProject.name}</h4>
                                    {previewProject.featured && <Star className="w-4 h-4 text-amber-400 fill-amber-400 shrink-0" />}
                                  </div>
                                  <p className="text-[12px] text-zinc-500">{previewProject.category}</p>
                                </div>
                              </div>

                              {/* Tagline */}
                              <p className="text-[14px] text-zinc-300 mt-4 leading-relaxed" style={{ fontWeight: 500 }}>{previewProject.tagline}</p>

                              {/* Description */}
                              <p className="text-[12px] text-zinc-500 mt-2.5 leading-relaxed">{desc}</p>

                              {/* Author */}
                              {author && (
                                <div className="flex items-center gap-2.5 mt-4 p-3 rounded-2xl bg-white/[0.03]">
                                  <FounderAvatar founder={author} size="sm" className="rounded-lg" />
                                  <div className="flex-1 min-w-0">
                                    <div className="text-[12px] text-white" style={{ fontWeight: 600 }}>{author.name}</div>
                                    <div className="text-[10px] text-zinc-500">{author.role} @ {author.company}</div>
                                  </div>
                                  <span className="text-[10px] text-zinc-600" style={{ fontWeight: 500 }}>{t("community.projectBy")}</span>
                                </div>
                              )}

                              {/* Metrics */}
                              {metrics && (
                                <div className="grid grid-cols-3 gap-2 mt-4">
                                  {[
                                    { value: metrics.users, label: t("community.projectUsers"), color: "text-purple-400" },
                                    { value: metrics.mrr, label: t("community.projectMrr"), color: "text-emerald-400" },
                                    { value: metrics.growth, label: t("community.projectGrowth"), color: "text-cyan-400" },
                                  ].map((m, i) => (
                                    <div key={i} className="py-3 rounded-2xl bg-white/[0.04] text-center">
                                      <div className={`text-[15px] ${m.color}`} style={{ fontWeight: 700 }}>{m.value}</div>
                                      <div className="text-[9px] text-zinc-500 mt-0.5" style={{ fontWeight: 500 }}>{m.label}</div>
                                    </div>
                                  ))}
                                </div>
                              )}

                              {/* Upvotes + launch time */}
                              <div className="flex items-center justify-between mt-4 pt-3 border-t border-white/[0.04]">
                                <div className="flex items-center gap-1.5 text-[12px] text-zinc-400">
                                  <ArrowUp className="w-4 h-4 text-purple-400" />
                                  <span style={{ fontWeight: 600 }}>{previewProject.upvotes} {t("community.upvotes")}</span>
                                </div>
                                <span className="text-[11px] text-zinc-600">{previewProject.launchTime}</span>
                              </div>

                              {/* Visit button */}
                              <button
                                onClick={() => {
                                  sonnerToast.info(`Opening ${previewProject.name}...`);
                                  setPreviewProject(null);
                                }}
                                className="w-full flex items-center justify-center gap-2 py-3.5 mt-4 rounded-2xl bg-purple-500 hover:bg-purple-400 text-white text-[14px] shadow-lg shadow-purple-500/20 transition-all active:scale-[0.97]"
                                style={{ fontWeight: 600 }}
                              >
                                <ExternalLink className="w-4 h-4" />{t("community.projectVisit")}
                              </button>
                            </div>
                          </motion.div>
                        </motion.div>
                      );
                    })()}
                  </AnimatePresence>
                </motion.div>
              );
            })()}
          </AnimatePresence>
        </>
      )}
    </div>
  );
}