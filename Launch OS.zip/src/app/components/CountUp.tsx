import { useState, useEffect, useRef } from "react";

/** Animated number counter with easeOutExpo easing. Handles formats: "1,234", "32.2K", "3.8%", plain integers. */
export function CountUp({ value, duration = 1200 }: { value: string; duration?: number }) {
  const [display, setDisplay] = useState("0");
  const prevValue = useRef(value);

  useEffect(() => {
    const suffix = value.replace(/[\d,.\s]/g, "").trim(); // e.g. "K", "%", ""
    const cleaned = value.replace(/,/g, "").replace(suffix, "");
    const target = parseFloat(cleaned);
    if (isNaN(target)) {
      setDisplay(value);
      return;
    }
    const isFloat = cleaned.includes(".") || suffix === "K";
    const startTime = performance.now();

    const animate = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // easeOutExpo
      const eased = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      const current = target * eased;

      if (isFloat) {
        setDisplay(`${current.toFixed(1)}${suffix}`);
      } else {
        const formatted = Math.round(current)
          .toString()
          .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        setDisplay(`${formatted}${suffix}`);
      }

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setDisplay(value);
      }
    };

    requestAnimationFrame(animate);
    prevValue.current = value;
  }, [value, duration]);

  return <span>{display}</span>;
}
