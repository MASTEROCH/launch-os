import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react";

export type Theme = "dark" | "light";
export type AccentColor = "purple" | "blue" | "emerald" | "rose" | "amber";

export const ACCENT_COLORS: { id: AccentColor; label: string; hex: string }[] = [
  { id: "purple", label: "Purple", hex: "#8b5cf6" },
  { id: "blue", label: "Blue", hex: "#3b82f6" },
  { id: "emerald", label: "Emerald", hex: "#10b981" },
  { id: "rose", label: "Rose", hex: "#f43f5e" },
  { id: "amber", label: "Amber", hex: "#f59e0b" },
];

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;
  accent: AccentColor;
  setAccent: (accent: AccentColor) => void;
}

const ThemeContext = createContext<ThemeContextType>({
  theme: "dark",
  setTheme: () => {},
  toggleTheme: () => {},
  accent: "purple",
  setAccent: () => {},
});

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>(() => {
    try {
      const saved = localStorage.getItem("launchapp_theme");
      return saved === "light" ? "light" : "dark";
    } catch {
      return "dark";
    }
  });

  const [accent, setAccentState] = useState<AccentColor>(() => {
    try {
      const saved = localStorage.getItem("launchapp_accent");
      if (saved && ACCENT_COLORS.some((c) => c.id === saved)) return saved as AccentColor;
    } catch {}
    return "purple";
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === "light") {
      root.classList.add("light");
      root.classList.remove("dark");
    } else {
      root.classList.add("dark");
      root.classList.remove("light");
    }
  }, [theme]);

  // Apply accent color class
  useEffect(() => {
    const root = document.documentElement;
    // Remove all accent classes
    ACCENT_COLORS.forEach((c) => root.classList.remove(`accent-${c.id}`));
    // Add current accent (purple is default, no class needed)
    if (accent !== "purple") {
      root.classList.add(`accent-${accent}`);
    }
  }, [accent]);

  const setTheme = useCallback((newTheme: Theme) => {
    const root = document.documentElement;
    root.classList.add("theme-transitioning");
    setThemeState(newTheme);
    try {
      localStorage.setItem("launchapp_theme", newTheme);
    } catch {}
    setTimeout(() => root.classList.remove("theme-transitioning"), 350);
  }, []);

  const setAccent = useCallback((newAccent: AccentColor) => {
    const root = document.documentElement;
    root.classList.add("theme-transitioning");
    setAccentState(newAccent);
    try {
      localStorage.setItem("launchapp_accent", newAccent);
    } catch {}
    setTimeout(() => root.classList.remove("theme-transitioning"), 350);
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme(theme === "dark" ? "light" : "dark");
  }, [theme, setTheme]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme, toggleTheme, accent, setAccent }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}