import { useState, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Bell, Mail, Users, TrendingUp, Zap, DollarSign, Check,
  Smartphone, BellRing, Shield, GripVertical,
} from "lucide-react";
import { toast as sonnerToast } from "sonner";
import { useI18n } from "./i18n";
import { WhyBlock } from "./WhyBlock";

interface Milestone {
  id: string;
  icon: typeof Bell;
  titleKey: string;
  descKey: string;
  color: string;
  iconBg: string;
  enabled: boolean;
}

type PushStatus = "idle" | "requesting" | "granted" | "denied" | "unsupported";

export function MilestoneNotifications() {
  const { t } = useI18n();
  const [email, setEmail] = useState(() => {
    try { return localStorage.getItem("launchapp_milestone_email") || ""; } catch { return ""; }
  });
  const [saved, setSaved] = useState(false);
  const [milestones, setMilestones] = useState<Milestone[]>(() => {
    const defaults: Milestone[] = [
      { id: "first10", icon: Users, titleKey: "milestones.first10", descKey: "milestones.first10desc", color: "text-purple-400", iconBg: "bg-purple-500/15", enabled: true },
      { id: "first100", icon: Users, titleKey: "milestones.first100", descKey: "milestones.first100desc", color: "text-cyan-400", iconBg: "bg-cyan-500/15", enabled: true },
      { id: "firstViral", icon: TrendingUp, titleKey: "milestones.firstViral", descKey: "milestones.firstViraldesc", color: "text-emerald-400", iconBg: "bg-emerald-500/15", enabled: true },
      { id: "revenue", icon: DollarSign, titleKey: "milestones.revenue", descKey: "milestones.revenuedesc", color: "text-amber-400", iconBg: "bg-amber-500/15", enabled: false },
      { id: "first1k", icon: Zap, titleKey: "milestones.first1k", descKey: "milestones.first1kdesc", color: "text-rose-400", iconBg: "bg-rose-500/15", enabled: false },
    ];
    try {
      const savedOrder = localStorage.getItem("launchapp_milestone_order");
      if (savedOrder) {
        const order: string[] = JSON.parse(savedOrder);
        const sorted = order.map(id => defaults.find(m => m.id === id)).filter(Boolean) as Milestone[];
        defaults.forEach(m => { if (!sorted.find(s => s.id === m.id)) sorted.push(m); });
        return sorted;
      }
    } catch {}
    return defaults;
  });

  // ─── Drag-to-reorder state ───
  const dragItemRef = useRef<number | null>(null);
  const dragOverRef = useRef<number | null>(null);
  const [dragIdx, setDragIdx] = useState<number | null>(null);

  const handleDragStart = (idx: number) => {
    dragItemRef.current = idx;
    setDragIdx(idx);
  };

  const handleDragEnter = (idx: number) => {
    dragOverRef.current = idx;
  };

  const handleDragEnd = () => {
    if (dragItemRef.current !== null && dragOverRef.current !== null && dragItemRef.current !== dragOverRef.current) {
      setMilestones(prev => {
        const next = [...prev];
        const [moved] = next.splice(dragItemRef.current!, 1);
        next.splice(dragOverRef.current!, 0, moved);
        try {
          localStorage.setItem("launchapp_milestone_order", JSON.stringify(next.map(m => m.id)));
        } catch {}
        return next;
      });
    }
    dragItemRef.current = null;
    dragOverRef.current = null;
    setDragIdx(null);
  };

  // ─── Touch drag-to-reorder ───
  const touchStartY = useRef(0);
  const touchItemIdx = useRef<number | null>(null);

  const handleTouchDragStart = (idx: number, e: React.TouchEvent) => {
    touchItemIdx.current = idx;
    touchStartY.current = e.touches[0].clientY;
    setDragIdx(idx);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (touchItemIdx.current === null) return;
    const dy = e.touches[0].clientY - touchStartY.current;
    const itemHeight = 72; // approximate height of each item
    const offset = Math.round(dy / itemHeight);
    if (offset !== 0) {
      const newIdx = Math.max(0, Math.min(milestones.length - 1, touchItemIdx.current + offset));
      dragOverRef.current = newIdx;
    }
  };

  const handleTouchEnd = () => {
    if (touchItemIdx.current !== null && dragOverRef.current !== null && touchItemIdx.current !== dragOverRef.current) {
      dragItemRef.current = touchItemIdx.current;
      handleDragEnd();
    }
    touchItemIdx.current = null;
    setDragIdx(null);
  };

  // ─── Push notification state ───
  const [pushStatus, setPushStatus] = useState<PushStatus>(() => {
    if (typeof window === "undefined" || !("Notification" in window)) return "unsupported";
    try {
      const saved = localStorage.getItem("launchapp_push_status");
      if (saved === "granted") return "granted";
    } catch {}
    return "idle";
  });

  const handleRequestPush = useCallback(async () => {
    if (!("Notification" in window)) {
      setPushStatus("unsupported");
      sonnerToast.error(t("milestones.pushUnsupported"));
      return;
    }

    setPushStatus("requesting");

    try {
      const permission = await Notification.requestPermission();
      if (permission === "granted") {
        setPushStatus("granted");
        localStorage.setItem("launchapp_push_status", "granted");

        // Register real Service Worker
        if ("serviceWorker" in navigator) {
          try {
            const registration = await navigator.serviceWorker.register("/sw.js", { scope: "/" });
            console.log("[Launch OS] SW registered:", registration.scope);
            localStorage.setItem("launchapp_sw_registered", "true");
          } catch (err) {
            console.warn("[Launch OS] SW registration failed:", err);
            // Still usable without SW for basic notifications
          }
        }

        // Show a test notification
        try {
          new Notification("Launch OS", {
            body: t("milestones.pushTestBody"),
            icon: "/favicon.ico",
            tag: "milestone-test",
          });
        } catch {}

        sonnerToast.success(t("milestones.pushEnabled"));
      } else {
        setPushStatus("denied");
        sonnerToast.error(t("milestones.pushDenied"));
      }
    } catch {
      setPushStatus("denied");
      sonnerToast.error(t("milestones.pushDenied"));
    }
  }, [t]);

  const handleSimulatePush = useCallback(() => {
    const enabledMilestones = milestones.filter((m) => m.enabled);
    if (enabledMilestones.length === 0) {
      sonnerToast.error(t("milestones.noMilestonesEnabled"));
      return;
    }
    const randomMilestone = enabledMilestones[Math.floor(Math.random() * enabledMilestones.length)];

    if (pushStatus === "granted" && "Notification" in window) {
      try {
        new Notification("Launch OS — Milestone!", {
          body: t(randomMilestone.titleKey),
          icon: "/favicon.ico",
          tag: `milestone-${randomMilestone.id}`,
        });
      } catch {}
    }
    sonnerToast.success(t(randomMilestone.titleKey), {
      description: t(randomMilestone.descKey),
    });
  }, [milestones, pushStatus, t]);

  const toggleMilestone = (id: string) => {
    setMilestones((prev) => prev.map((m) => m.id === id ? { ...m, enabled: !m.enabled } : m));
  };

  const handleSave = () => {
    if (!email.includes("@")) {
      sonnerToast.error("Please enter a valid email");
      return;
    }
    localStorage.setItem("launchapp_milestone_email", email);
    const enabledIds = milestones.filter((m) => m.enabled).map((m) => m.id);
    localStorage.setItem("launchapp_milestones", JSON.stringify(enabledIds));
    setSaved(true);
    sonnerToast.success(t("milestones.saved"));
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-purple-500/15 flex items-center justify-center">
          <Bell className="w-5 h-5 text-purple-400" />
        </div>
        <div>
          <h3 className="text-white" style={{ fontWeight: 600 }}>{t("milestones.title")}</h3>
          <p className="text-sm text-zinc-500 mt-0.5">{t("milestones.subtitle")}</p>
        </div>
      </div>

      {/* Why block for beginners */}
      <WhyBlock label={t("milestones.whyLabel")} color="purple">
        {t("milestones.whyExplain")}
      </WhyBlock>

      {/* Push Notifications Card */}
      <div className={`p-4 rounded-xl border transition-all ${
        pushStatus === "granted"
          ? "border-emerald-500/20 bg-emerald-500/[0.03]"
          : "border-white/5 bg-white/[0.02]"
      }`}>
        <div className="flex items-center gap-3 mb-3">
          <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
            pushStatus === "granted" ? "bg-emerald-500/15" : "bg-purple-500/15"
          }`}>
            <BellRing className={`w-4 h-4 ${pushStatus === "granted" ? "text-emerald-400" : "text-purple-400"}`} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm text-white" style={{ fontWeight: 500 }}>{t("milestones.pushTitle")}</div>
            <div className="text-xs text-zinc-500 mt-0.5">{t("milestones.pushDesc")}</div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {pushStatus === "idle" && (
            <button
              onClick={handleRequestPush}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs bg-purple-600 hover:bg-purple-500 text-white transition-all"
            >
              <Smartphone className="w-3.5 h-3.5" />
              {t("milestones.enablePush")}
            </button>
          )}

          {pushStatus === "requesting" && (
            <div className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs text-purple-400 bg-purple-500/10 border border-purple-500/15">
              <div className="w-3.5 h-3.5 rounded-full border-2 border-purple-400 border-t-transparent animate-spin" />
              {t("milestones.pushRequesting")}
            </div>
          )}

          {pushStatus === "granted" && (
            <>
              <div className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/15">
                <Check className="w-3.5 h-3.5" />
                {t("milestones.pushActive")}
              </div>
              <button
                onClick={handleSimulatePush}
                className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-purple-400 bg-purple-500/10 border border-purple-500/15 hover:bg-purple-500/15 transition-all"
              >
                <Zap className="w-3.5 h-3.5" />
                {t("milestones.testPush")}
              </button>
            </>
          )}

          {pushStatus === "denied" && (
            <div className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs text-amber-400 bg-amber-500/10 border border-amber-500/15">
              <Shield className="w-3.5 h-3.5" />
              {t("milestones.pushBlocked")}
            </div>
          )}

          {pushStatus === "unsupported" && (
            <div className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs text-zinc-500 bg-white/[0.03] border border-white/5">
              <Smartphone className="w-3.5 h-3.5" />
              {t("milestones.pushUnsupported")}
            </div>
          )}
        </div>
      </div>

      {/* Email input */}
      <div>
        <label className="text-sm text-zinc-400 mb-2 block" style={{ fontWeight: 500 }}>{t("milestones.email")}</label>
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={t("milestones.emailPlaceholder")}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white text-sm placeholder:text-zinc-600 focus:border-purple-500/30 focus:outline-none transition-colors"
            />
          </div>
          <button
            onClick={handleSave}
            className={`px-5 py-2.5 rounded-xl text-sm transition-all flex items-center gap-2 shrink-0 ${
              saved
                ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/20"
                : "bg-purple-600 hover:bg-purple-500 text-white"
            }`}
          >
            {saved ? <><Check className="w-4 h-4" />{t("milestones.saved")}</> : t("milestones.save")}
          </button>
        </div>
      </div>

      {/* Milestone toggles — drag to reorder */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-zinc-500" style={{ fontWeight: 500 }}>{t("milestones.dragHint")}</span>
        </div>
        <div className="space-y-2" onTouchMove={handleTouchMove} onTouchEnd={handleTouchEnd}>
          {milestones.map((m, idx) => (
            <motion.div
              key={m.id}
              layout
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: dragIdx === idx ? 0.5 : 1, y: 0, scale: dragIdx === idx ? 0.98 : 1 }}
              transition={{ delay: idx * 0.03 }}
              draggable
              onDragStart={() => handleDragStart(idx)}
              onDragEnter={() => handleDragEnter(idx)}
              onDragEnd={handleDragEnd}
              onDragOver={(e) => e.preventDefault()}
              onTouchStart={(e) => handleTouchDragStart(idx, e)}
              className="flex items-center gap-3 p-4 rounded-xl border border-white/5 bg-white/[0.02] hover:border-white/10 transition-all"
            >
              {/* Drag handle */}
              <div className="cursor-grab active:cursor-grabbing text-zinc-700 hover:text-zinc-500 transition-colors shrink-0 touch-none">
                <GripVertical className="w-3.5 h-3.5" />
              </div>
              <div className={`w-9 h-9 rounded-lg ${m.iconBg} flex items-center justify-center shrink-0`}>
                <m.icon className={`w-4 h-4 ${m.color}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm text-white" style={{ fontWeight: 500 }}>{t(m.titleKey)}</div>
                <div className="text-xs text-zinc-500 mt-0.5">{t(m.descKey)}</div>
              </div>
              {/* iOS-style toggle */}
              <button
                onClick={() => toggleMilestone(m.id)}
                className={`w-12 h-7 rounded-full p-0.5 transition-colors shrink-0 ${
                  m.enabled ? "bg-purple-500" : "bg-white/10"
                }`}
              >
                <motion.div
                  animate={{ x: m.enabled ? 20 : 0 }}
                  transition={{ type: "spring", stiffness: 500, damping: 30 }}
                  className="w-6 h-6 rounded-full bg-white shadow-sm"
                />
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
