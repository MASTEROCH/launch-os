import { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Sparkles, Package, Compass, Zap, TrendingUp, Check,
} from "lucide-react";
import { useI18n } from "./i18n";

const colorMap: Record<string, { bg: string; text: string; glow: string }> = {
  purple: { bg: "bg-purple-500/15", text: "text-purple-400", glow: "shadow-purple-500/20" },
  violet: { bg: "bg-violet-500/15", text: "text-violet-400", glow: "shadow-violet-500/20" },
  cyan: { bg: "bg-cyan-500/15", text: "text-cyan-400", glow: "shadow-cyan-500/20" },
  emerald: { bg: "bg-emerald-500/15", text: "text-emerald-400", glow: "shadow-emerald-500/20" },
  amber: { bg: "bg-amber-500/15", text: "text-amber-400", glow: "shadow-amber-500/20" },
};

export function HeroPipeline() {
  const { t } = useI18n();
  const [activeIdx, setActiveIdx] = useState(0);
  const [typing, setTyping] = useState("");
  const [typingDone, setTypingDone] = useState(false);

  const steps = useMemo(() => [
    { icon: Sparkles, label: t("heroPipe.step1.label"), color: "purple", output: t("heroPipe.step1.output") },
    { icon: Package, label: t("heroPipe.step2.label"), color: "violet", output: t("heroPipe.step2.output") },
    { icon: Compass, label: t("heroPipe.step3.label"), color: "cyan", output: t("heroPipe.step3.output") },
    { icon: Zap, label: t("heroPipe.step4.label"), color: "emerald", output: t("heroPipe.step4.output") },
    { icon: TrendingUp, label: t("heroPipe.step5.label"), color: "amber", output: t("heroPipe.step5.output") },
  ], [t]);

  // Auto-cycle steps
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIdx((prev) => (prev + 1) % steps.length);
      setTyping("");
      setTypingDone(false);
    }, 3500);
    return () => clearInterval(interval);
  }, [steps.length]);

  // Typing effect for output
  useEffect(() => {
    setTyping("");
    setTypingDone(false);
    const output = steps[activeIdx].output;
    let i = 0;
    const interval = setInterval(() => {
      i++;
      setTyping(output.slice(0, i));
      if (i >= output.length) {
        clearInterval(interval);
        setTypingDone(true);
      }
    }, 25);
    return () => clearInterval(interval);
  }, [activeIdx, steps]);

  const current = steps[activeIdx];
  const cc = colorMap[current.color];

  const metrics = useMemo(() => [
    { label: t("heroPipe.metric.visitors"), value: "2,100", color: "text-purple-400" },
    { label: t("heroPipe.metric.signups"), value: "89", color: "text-cyan-400" },
    { label: t("heroPipe.metric.mrr"), value: "$1,140", color: "text-emerald-400" },
  ], [t]);

  return (
    <div className="vision-card rounded-2xl overflow-hidden max-w-2xl mx-auto">
      {/* Fake browser chrome */}
      <div className="flex items-center gap-2 px-4 py-2.5 border-b border-white/5 bg-white/[0.02]">
        <div className="flex gap-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-red-500/40" />
          <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/40" />
          <div className="w-2.5 h-2.5 rounded-full bg-green-500/40" />
        </div>
        <div className="flex-1 flex justify-center">
          <div className="px-4 py-1 rounded-md bg-white/[0.04] text-[10px] text-zinc-600">
            app.launchos.ai/dashboard
          </div>
        </div>
      </div>

      <div className="p-4 md:p-5">
        {/* Step indicators - horizontal pipeline */}
        <div className="flex items-center gap-1 mb-4">
          {steps.map((step, i) => {
            const done = i < activeIdx;
            const isCurrent = i === activeIdx;
            const sc = colorMap[step.color];
            return (
              <div key={i} className="flex items-center flex-1 min-w-0">
                <motion.div
                  animate={{
                    scale: isCurrent ? 1.1 : 1,
                  }}
                  transition={{ type: "spring", stiffness: 300, damping: 20 }}
                  className={`w-7 h-7 md:w-8 md:h-8 rounded-lg flex items-center justify-center shrink-0 transition-all ${
                    done ? "bg-emerald-500/15" :
                    isCurrent ? sc.bg :
                    "bg-white/[0.04]"
                  }`}
                >
                  {done ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <step.icon className={`w-3.5 h-3.5 ${isCurrent ? sc.text : "text-zinc-600"}`} />
                  )}
                </motion.div>
                {i < steps.length - 1 && (
                  <div className="flex-1 h-px mx-1 relative overflow-hidden">
                    <div className="absolute inset-0 bg-white/[0.06]" />
                    {done && (
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: "100%" }}
                        transition={{ duration: 0.3 }}
                        className="absolute inset-y-0 left-0 bg-emerald-500/40"
                      />
                    )}
                    {isCurrent && (
                      <motion.div
                        animate={{ width: ["0%", "100%"] }}
                        transition={{ duration: 3.5, ease: "linear" }}
                        className="absolute inset-y-0 left-0 bg-purple-500/40"
                      />
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Active step content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeIdx}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
          >
            <div className="flex items-center gap-2 mb-2">
              <div className={`w-5 h-5 rounded-md ${cc.bg} flex items-center justify-center`}>
                <current.icon className={`w-3 h-3 ${cc.text}`} />
              </div>
              <span className="text-xs text-zinc-500" style={{ fontWeight: 600 }}>
                {t("heroPipe.step")} {activeIdx + 1}: {current.label}
              </span>
            </div>

            {/* Output area */}
            <div className={`p-3 rounded-xl border ${cc.bg.replace("15", "5")} border-white/[0.06] min-h-[44px] flex items-center`}>
              <span className="text-sm text-white" style={{ fontWeight: 500 }}>
                {typing}
                {!typingDone && (
                  <motion.span
                    animate={{ opacity: [1, 0] }}
                    transition={{ duration: 0.5, repeat: Infinity }}
                    className={cc.text}
                  >
                    |
                  </motion.span>
                )}
              </span>
            </div>

            {/* Fake metrics for last step */}
            {activeIdx === 4 && typingDone && (
              <motion.div
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="grid grid-cols-3 gap-2 mt-2"
              >
                {metrics.map((m) => (
                  <div key={m.label} className="p-2 rounded-lg bg-white/[0.03] text-center">
                    <div className={`text-sm ${m.color}`} style={{ fontWeight: 700 }}>{m.value}</div>
                    <div className="text-[10px] text-zinc-600">{m.label}</div>
                  </div>
                ))}
              </motion.div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
