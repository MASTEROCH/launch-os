import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ArrowLeft, Send, Search, MessageCircle,
  Users, Gift, X, Eye,
} from "lucide-react";
import { toast as sonnerToast } from "sonner";
import { useLocation, useNavigate } from "react-router";
import { useI18n } from "./i18n";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { usePullToRefresh } from "./usePullToRefresh";
import { PullToRefreshIndicator } from "./PullToRefreshIndicator";
import { AVATAR_URLS } from "./avatars";

/* ═══════════════════════════════════════════
   Types
   ═══════════════════════════════════════════ */
interface Founder {
  id: string; name: string; avatar: string; gradient: string; online: boolean; company: string;
}

interface Message {
  id: string; senderId: string; text: string; time: string; isMe: boolean;
  type?: "text" | "tokens"; tokenAmount?: number;
}

interface Conversation {
  founderId: string; messages: Message[]; lastMessageTime: string;
}

/* ═══════════════════════════════════════════
   Mock Data
   ═══════════════════════════════════════════ */
const founders: Founder[] = [
  { id: "f1", name: "Alex Kowalski", avatar: "AK", gradient: "from-purple-500 to-violet-600", online: true, company: "DevSync" },
  { id: "f2", name: "Maria Sokolova", avatar: "MS", gradient: "from-cyan-500 to-blue-600", online: true, company: "AIWriter Pro" },
  { id: "f3", name: "John Drummond", avatar: "JD", gradient: "from-emerald-500 to-teal-600", online: false, company: "QuickLaunch" },
  { id: "f4", name: "Sarah Lee", avatar: "SL", gradient: "from-amber-500 to-orange-600", online: true, company: "TaskFlow AI" },
  { id: "f5", name: "Tom Rodriguez", avatar: "TR", gradient: "from-rose-500 to-pink-600", online: false, company: "PixelForge" },
  { id: "f6", name: "Lisa Martinez", avatar: "LM", gradient: "from-indigo-500 to-purple-600", online: true, company: "CodeReview AI" },
  { id: "f7", name: "David Wang", avatar: "DW", gradient: "from-sky-500 to-cyan-600", online: false, company: "MetricsHub" },
  { id: "f8", name: "Anna Petrova", avatar: "AP", gradient: "from-fuchsia-500 to-purple-600", online: true, company: "BotBuilder" },
];

const initialConversations: Conversation[] = [
  {
    founderId: "f2", lastMessageTime: "10 min ago",
    messages: [
      { id: "m1", senderId: "f2", text: "Hey! Saw your launch — great product! How did you get so many upvotes on day one?", time: "2:30 PM", isMe: false },
      { id: "m2", senderId: "me", text: "Thanks Maria! We spent 2 weeks building a waitlist before launch. Twitter threads helped a lot.", time: "2:35 PM", isMe: true },
      { id: "m3", senderId: "f2", text: "Smart! I should try that for my next launch. Want to do a cross-promotion?", time: "2:38 PM", isMe: false },
      { id: "m4", senderId: "me", text: "Absolutely! Let's plan it. I'll DM you the details.", time: "2:42 PM", isMe: true },
    ],
  },
  {
    founderId: "f6", lastMessageTime: "1h ago",
    messages: [
      { id: "m5", senderId: "f6", text: "Just sent you some tokens as a thank you for the feedback on my launch!", time: "1:15 PM", isMe: false, type: "tokens", tokenAmount: 50 },
      { id: "m6", senderId: "me", text: "Wow, that's so generous! Happy to help anytime. Your code review tool is amazing btw.", time: "1:20 PM", isMe: true },
    ],
  },
  {
    founderId: "f4", lastMessageTime: "3h ago",
    messages: [
      { id: "m7", senderId: "f4", text: "Hi! I noticed you're building in AI too. Would love to exchange ideas about distribution strategies.", time: "11:00 AM", isMe: false },
      { id: "m8", senderId: "me", text: "Hey Sarah! Sure, I'd be happy to chat. What channels have worked best for TaskFlow AI?", time: "11:15 AM", isMe: true },
      { id: "m9", senderId: "f4", text: "Reddit has been amazing for us. r/startups and r/SaaS drove most of our early traffic.", time: "11:22 AM", isMe: false },
    ],
  },
];

const getFounder = (id: string) => founders.find((f) => f.id === id);

/** Render founder avatar with photo or fallback */
function FounderAvatarMsg({ founder, size = "md" }: { founder: Founder; size?: "sm" | "md" | "lg" }) {
  const url = AVATAR_URLS[founder.id];
  const sizeClasses = { sm: "w-8 h-8", md: "w-9 h-9", lg: "w-11 h-11" };
  const s = sizeClasses[size];
  return url ? (
    <img src={url} alt={founder.name} className={`${s} rounded-xl object-cover shrink-0`} />
  ) : (
    <div className={`${s} rounded-xl bg-gradient-to-br ${founder.gradient} flex items-center justify-center text-white text-xs shrink-0`} style={{ fontWeight: 700 }}>
      {founder.avatar}
    </div>
  );
}

/* ═══════════════════════════════════════════
   Main Component
   ═══════════════════════════════════════════ */
export function Messages() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const location = useLocation();
  useDocumentTitle(t("community.tabMessages"));

  // Pull to refresh
  const { pullY, isRefreshing, handlers: pullHandlers } = usePullToRefresh(
    () => new Promise<void>((resolve) => setTimeout(resolve, 800))
  );

  const [conversations, setConversations] = useState<Conversation[]>(initialConversations);
  const [activeConvo, setActiveConvo] = useState<string | null>(null);
  const [messageInput, setMessageInput] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Open conversation if navigated with state
  useEffect(() => {
    const state = location.state as { founderId?: string } | null;
    if (state?.founderId) {
      setActiveConvo(state.founderId);
      // Create convo if doesn't exist
      if (!conversations.find((c) => c.founderId === state.founderId)) {
        setConversations((prev) => [...prev, { founderId: state.founderId!, messages: [], lastMessageTime: "now" }]);
      }
      // Clear navigation state
      window.history.replaceState({}, "");
    }
  }, []);  // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conversations, activeConvo]);

  const handleSendMessage = useCallback(() => {
    if (!messageInput.trim() || !activeConvo) return;
    const newMsg: Message = {
      id: `m${Date.now()}`,
      senderId: "me",
      text: messageInput.trim(),
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      isMe: true,
    };
    setConversations((prev) => {
      const existing = prev.find((c) => c.founderId === activeConvo);
      if (existing) {
        return prev.map((c) => c.founderId === activeConvo ? { ...c, messages: [...c.messages, newMsg], lastMessageTime: "just now" } : c);
      }
      return [...prev, { founderId: activeConvo, messages: [newMsg], lastMessageTime: "just now" }];
    });
    setMessageInput("");
  }, [messageInput, activeConvo]);

  const filteredConvos = conversations.filter((c) => {
    if (!searchQuery) return true;
    const founder = getFounder(c.founderId);
    return founder && (founder.name.toLowerCase().includes(searchQuery.toLowerCase()) || founder.company.toLowerCase().includes(searchQuery.toLowerCase()));
  });

  const activeConversation = conversations.find((c) => c.founderId === activeConvo);
  const activeFounder = activeConvo ? getFounder(activeConvo) : null;

  /* ─── Chat view (both mobile full-screen and desktop right panel) ─── */
  const ChatView = () => {
    if (!activeFounder || !activeConversation) return null;
    return (
      <div className="flex flex-col h-full">
        {/* Chat header */}
        <div className="flex items-center gap-3 p-3 sm:p-4 border-b border-white/5 shrink-0">
          <button onClick={() => setActiveConvo(null)} className="text-zinc-500 hover:text-zinc-300 transition-colors sm:hidden">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <button onClick={() => setActiveConvo(null)} className="text-zinc-500 hover:text-zinc-300 transition-colors hidden sm:block">
            <ArrowLeft className="w-4 h-4" />
          </button>
          <button className="relative shrink-0" onClick={() => navigate("/dashboard/community", { state: { viewProfileId: activeFounder.id } })}>
            <FounderAvatarMsg founder={activeFounder} />
            {activeFounder.online && (
              <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-[#18181b]" />
            )}
          </button>
          <div className="flex-1 min-w-0">
            <div className="text-sm messages-title" style={{ fontWeight: 600 }}>{activeFounder.name}</div>
            <div className="text-[10px] text-zinc-500">{activeFounder.company} · {activeFounder.online ? t("community.online") : "offline"}</div>
          </div>
          <button
            onClick={() => navigate("/dashboard/community", { state: { viewProfileId: activeFounder.id } })}
            className="shrink-0 flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] text-zinc-500 border border-white/5 hover:border-white/10 hover:text-zinc-300 transition-all"
          >
            <Eye className="w-3 h-3" /><span className="hidden sm:inline">{t("community.viewProfile")}</span>
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {activeConversation.messages.length === 0 && (
            <div className="text-center py-12">
              <MessageCircle className="w-8 h-8 text-zinc-700 mx-auto mb-2" />
              <p className="text-sm text-zinc-500">{t("community.startConversation")}</p>
            </div>
          )}
          {activeConversation.messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.isMe ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] sm:max-w-[70%] ${msg.isMe ? "order-2" : ""}`}>
                {msg.type === "tokens" && (
                  <div className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500/10 border border-amber-500/15 mb-1">
                    <Gift className="w-3.5 h-3.5 text-amber-400" />
                    <span className="text-xs text-amber-400" style={{ fontWeight: 600 }}>{msg.tokenAmount} {t("community.tokens")}</span>
                  </div>
                )}
                <div className={`px-3.5 py-2.5 rounded-2xl text-sm ${
                  msg.isMe
                    ? "bg-purple-600 text-white rounded-br-md"
                    : "bg-white/[0.05] text-zinc-300 rounded-bl-md"
                }`}>
                  {msg.text}
                </div>
                <div className={`text-[9px] text-zinc-600 mt-1 ${msg.isMe ? "text-right" : ""}`}>{msg.time}</div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-3 sm:p-4 border-t border-white/5 shrink-0">
          <div className="flex gap-2">
            <input
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
              placeholder={t("community.typeMessage")}
              className="flex-1 px-4 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none text-sm transition-colors"
            />
            <button
              onClick={handleSendMessage}
              disabled={!messageInput.trim()}
              className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-30 text-white transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto" {...pullHandlers}>
      <PullToRefreshIndicator pullY={pullY} isRefreshing={isRefreshing} />

      <div className="mb-5">
        <LargeTitle
          title={t("community.tabMessages")}
          subtitle={t("community.messagesSub")}
          actions={
            <button
              onClick={() => navigate("/dashboard/community")}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-zinc-400 border border-white/5 hover:border-white/10 hover:text-zinc-300 transition-all"
            >
              <Users className="w-3.5 h-3.5" />{t("community.tabNetwork")}
            </button>
          }
        />
      </div>

      {/* Mobile: full-screen chat when active */}
      {activeConvo ? (
        <div className="sm:hidden rounded-2xl border border-white/5 bg-white/[0.02] overflow-hidden" style={{ height: "calc(100vh - 220px)", minHeight: 400 }}>
          <ChatView />
        </div>
      ) : (
        /* Mobile: conversation list */
        <div className="sm:hidden space-y-3">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 text-zinc-600 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t("community.searchMessages")}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none text-sm transition-colors"
            />
          </div>

          {filteredConvos.length === 0 ? (
            <div className="text-center py-16">
              <MessageCircle className="w-10 h-10 text-zinc-700 mx-auto mb-3" />
              <p className="text-sm text-zinc-500">{t("community.noConversations")}</p>
              <p className="text-xs text-zinc-600 mt-1">{t("community.noConversationsSub")}</p>
            </div>
          ) : (
            filteredConvos.map((convo) => {
              const founder = getFounder(convo.founderId);
              if (!founder) return null;
              const lastMsg = convo.messages[convo.messages.length - 1];
              return (
                <div
                  key={convo.founderId}
                  className="w-full flex items-center gap-3 p-3.5 rounded-xl border border-white/5 bg-white/[0.02] hover:border-white/10 transition-all text-left"
                >
                  <button className="relative shrink-0" onClick={() => navigate("/dashboard/community", { state: { viewProfileId: founder.id } })}>
                    <FounderAvatarMsg founder={founder} size="lg" />
                    {founder.online && (
                      <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-400 border-2 border-[#09090b]" />
                    )}
                  </button>
                  <button className="flex-1 min-w-0 text-left" onClick={() => setActiveConvo(convo.founderId)}>
                    <div className="flex items-center justify-between">
                      <span className="text-sm messages-title" style={{ fontWeight: 600 }}>{founder.name}</span>
                      <span className="text-[10px] text-zinc-600 shrink-0">{convo.lastMessageTime}</span>
                    </div>
                    {lastMsg && (
                      <p className="text-xs text-zinc-500 truncate mt-0.5">
                        {lastMsg.isMe ? `${t("community.you")}: ` : ""}{lastMsg.text}
                      </p>
                    )}
                  </button>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* Desktop: split view */}
      <div className="hidden sm:grid sm:grid-cols-[280px_1fr] gap-4 rounded-2xl border border-white/5 bg-white/[0.02] overflow-hidden" style={{ height: "calc(100vh - 260px)", minHeight: 500 }}>
        {/* Left: conversation list */}
        <div className="border-r border-white/5 flex flex-col">
          <div className="p-3 border-b border-white/5">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-zinc-600 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t("community.searchMessages")}
                className="w-full pl-8 pr-3 py-2 rounded-lg bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none text-xs transition-colors"
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto">
            {filteredConvos.map((convo) => {
              const founder = getFounder(convo.founderId);
              if (!founder) return null;
              const lastMsg = convo.messages[convo.messages.length - 1];
              const isActive = activeConvo === convo.founderId;
              return (
                <div
                  key={convo.founderId}
                  className={`w-full flex items-center gap-2.5 px-3 py-3 text-left transition-all border-b border-white/[0.03] cursor-pointer ${
                    isActive ? "bg-purple-500/[0.06]" : "hover:bg-white/[0.02]"
                  }`}
                  onClick={() => setActiveConvo(convo.founderId)}
                >
                  <button className="relative shrink-0" onClick={(e) => { e.stopPropagation(); navigate("/dashboard/community", { state: { viewProfileId: founder.id } }); }}>
                    <FounderAvatarMsg founder={founder} />
                    {founder.online && (
                      <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-[#18181b]" />
                    )}
                  </button>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-xs messages-title" style={{ fontWeight: 600 }}>{founder.name}</span>
                      <span className="text-[9px] text-zinc-600 shrink-0">{convo.lastMessageTime}</span>
                    </div>
                    {lastMsg && (
                      <p className="text-[11px] text-zinc-500 truncate mt-0.5">
                        {lastMsg.isMe ? `${t("community.you")}: ` : ""}{lastMsg.text}
                      </p>
                    )}
                  </div>
                </div>
              );
            })}

            {filteredConvos.length === 0 && (
              <div className="text-center py-12 px-4">
                <MessageCircle className="w-8 h-8 text-zinc-700 mx-auto mb-2" />
                <p className="text-xs text-zinc-500">{t("community.noConversations")}</p>
              </div>
            )}
          </div>
        </div>

        {/* Right: chat area */}
        <div className="flex flex-col">
          {activeConvo ? (
            <ChatView />
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center px-8">
              <MessageCircle className="w-12 h-12 text-zinc-800 mb-4" />
              <p className="text-sm text-zinc-500">{t("community.selectConversation")}</p>
              <p className="text-xs text-zinc-600 mt-1">{t("community.selectConversationSub")}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}