/* ═══════════════════════════════════════════════════════════════
   Subscription & Trial Management (localStorage-based demo)
   ═══════════════════════════════════════════════════════════════ */

export interface Subscription {
  planId: string;        // "free" | "starter" | "growth" | "viral"
  status: "trial" | "active" | "cancelled" | "expired" | "free";
  trialStartDate: string; // ISO date string
  trialDays: number;      // 3 (or 4 if grace day purchased)
  cardLast4: string;      // "4242"
  cardBrand: string;      // "Visa"
  cardExpiry: string;     // "12/27"
  cancelledAt?: string;   // ISO date if cancelled
  gracePurchased?: boolean;  // true if user bought +1 grace day
  graceOfferedAt?: string;   // ISO date when grace modal was shown
  firstMonthDiscount?: number; // e.g. 0.20 = 20% off first month
  discountAppliedAt?: string;  // ISO date when discount was applied
}

const STORAGE_KEY = "launchapp_subscription";
const TRIAL_DAYS = 3;
export const GRACE_PRICE = 2.49;
export const GRACE_WINDOW_MS = 24 * 60 * 60 * 1000; // 24 hours
export const FIRST_MONTH_DISCOUNT = 0.20; // 20% off

export function loadSubscription(): Subscription | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return null;
}

export function saveSubscription(sub: Subscription): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(sub));
}

export function activateTrialSubscription(
  planId: string,
  card: { last4: string; brand: string; expiry: string }
): Subscription {
  const sub: Subscription = {
    planId,
    status: "trial",
    trialStartDate: new Date().toISOString(),
    trialDays: TRIAL_DAYS,
    cardLast4: card.last4,
    cardBrand: card.brand,
    cardExpiry: card.expiry,
  };
  saveSubscription(sub);
  return sub;
}

export function cancelSubscription(): Subscription | null {
  const sub = loadSubscription();
  if (!sub) return null;
  sub.status = "cancelled";
  sub.cancelledAt = new Date().toISOString();
  saveSubscription(sub);
  return sub;
}

export function reactivateSubscription(): Subscription | null {
  const sub = loadSubscription();
  if (!sub) return null;
  const remaining = getTrialDaysRemaining(sub);
  sub.status = remaining > 0 ? "trial" : "active";
  delete sub.cancelledAt;
  saveSubscription(sub);
  return sub;
}

export function getTrialDaysRemaining(sub: Subscription): number {
  if (sub.status !== "trial") return 0;
  const start = new Date(sub.trialStartDate);
  const now = new Date();
  const elapsed = Math.floor((now.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
  return Math.max(0, sub.trialDays - elapsed);
}

export function getTrialEndDate(sub: Subscription): Date {
  const start = new Date(sub.trialStartDate);
  return new Date(start.getTime() + sub.trialDays * 24 * 60 * 60 * 1000);
}

export function isTrialExpired(sub: Subscription): boolean {
  return sub.status === "trial" && getTrialDaysRemaining(sub) <= 0;
}

/**
 * Check trial status and auto-transition:
 * - trial expired + grace not offered → "grace_offer" (show modal)
 * - trial expired + grace already offered/purchased → "transitioned"
 * - trial with ≤1 day left → returns "warning"
 * - trial OK → returns "ok"
 * - not on trial → returns null
 */
export type TrialCheckResult =
  | { action: "transitioned"; sub: Subscription }
  | { action: "grace_offer"; sub: Subscription }
  | { action: "warning"; daysLeft: number; sub: Subscription }
  | { action: "ok"; daysLeft: number; sub: Subscription }
  | null;

const TRIAL_WARNED_KEY = "launchapp_trial_warned";

export function checkAndUpdateTrialStatus(): TrialCheckResult {
  const sub = loadSubscription();
  if (!sub || sub.status !== "trial") return null;

  const remaining = getTrialDaysRemaining(sub);

  if (remaining <= 0) {
    // Grace period logic: if grace was never offered AND not yet purchased
    if (!sub.gracePurchased && !sub.graceOfferedAt) {
      // Mark as offered so we don't show the modal again next time
      sub.graceOfferedAt = new Date().toISOString();
      saveSubscription(sub);
      return { action: "grace_offer", sub };
    }

    // Grace was already offered or purchased → auto-transition to active
    sub.status = "active";
    saveSubscription(sub);
    return { action: "transitioned", sub };
  }

  if (remaining <= 1) {
    // Check if we already warned this session
    const warned = sessionStorage.getItem(TRIAL_WARNED_KEY);
    if (!warned) {
      sessionStorage.setItem(TRIAL_WARNED_KEY, "1");
      return { action: "warning", daysLeft: remaining, sub };
    }
  }

  return { action: "ok", daysLeft: remaining, sub };
}

/**
 * Purchase grace day: extends trial by +1 day for $2.49.
 * Returns updated subscription.
 */
export function purchaseGraceDay(): Subscription | null {
  const sub = loadSubscription();
  if (!sub) return null;
  sub.trialDays = (sub.trialDays || TRIAL_DAYS) + 1;
  sub.gracePurchased = true;
  sub.status = "trial"; // keep on trial with extra day
  saveSubscription(sub);
  return sub;
}

/**
 * Dismiss grace offer → activate with first-month discount.
 */
export function dismissGraceOffer(withDiscount = true): Subscription | null {
  const sub = loadSubscription();
  if (!sub) return null;
  sub.status = "active";
  if (withDiscount) {
    sub.firstMonthDiscount = FIRST_MONTH_DISCOUNT;
    sub.discountAppliedAt = new Date().toISOString();
  }
  saveSubscription(sub);
  return sub;
}

/**
 * Returns milliseconds remaining in the 24-hour grace window.
 * 0 if grace wasn't offered or already expired.
 */
export function getGraceTimeRemainingMs(sub: Subscription): number {
  if (!sub.graceOfferedAt) return GRACE_WINDOW_MS; // fresh — full 24h
  const offered = new Date(sub.graceOfferedAt).getTime();
  const deadline = offered + GRACE_WINDOW_MS;
  return Math.max(0, deadline - Date.now());
}

/**
 * Compute discounted price for first month.
 */
export function getDiscountedPrice(planId: string): { original: number; discounted: number; savings: number } {
  const original = PLAN_PRICES[planId] || 59;
  const discounted = Math.round((original * (1 - FIRST_MONTH_DISCOUNT)) * 100) / 100;
  return { original, discounted, savings: Math.round((original - discounted) * 100) / 100 };
}

export function clearSubscription(): void {
  localStorage.removeItem(STORAGE_KEY);
}

/** Plan token allocations */
export const PLAN_TOKENS: Record<string, number> = {
  free: 0,
  starter: 100,
  growth: 300,
  viral: 1000,
};

/** Plan prices */
export const PLAN_PRICES: Record<string, number> = {
  free: 0,
  starter: 29,
  growth: 59,
  viral: 149,
};

/** Plan project limits (Infinity = unlimited) */
export const PLAN_PROJECT_LIMITS: Record<string, number> = {
  free: 1,
  starter: 1,
  growth: 5,
  viral: Infinity,
};

/** Free plan feature flags */
export const FREE_PLAN_FEATURES = {
  canCreateProfile: true,
  canPostUpdates: true,     // forum/feed posts
  canSearchFounders: true,  // networking search
  canMessage: false,        // requires starter+
  canAddGrowthUsers: false, // requires growth+
  canDistribute: false,     // requires starter+ (needs tokens)
  canViewROI: false,        // requires growth+
  canRecruitAccess: false,  // separate recruiter plan
  canPromoteProject: false, // paid per-project boost
} as const;

/** Get feature access for current plan */
export function getPlanFeatures(planId?: string): typeof FREE_PLAN_FEATURES {
  const id = planId || loadSubscription()?.planId || "free";
  if (id === "free") return FREE_PLAN_FEATURES;
  if (id === "starter") return { ...FREE_PLAN_FEATURES, canMessage: true, canDistribute: true };
  if (id === "growth") return { ...FREE_PLAN_FEATURES, canMessage: true, canAddGrowthUsers: true, canDistribute: true, canViewROI: true };
  // viral
  return { ...FREE_PLAN_FEATURES, canMessage: true, canAddGrowthUsers: true, canDistribute: true, canViewROI: true, canPromoteProject: true };
}

/** Recruiter plan pricing */
export const RECRUITER_PLAN = {
  annual: 4990,
  monthly: 499,
  features: [
    "Full access to active founder & developer profiles",
    "Advanced search filters (skills, stage, location)",
    "Direct outreach via LaunchOS messaging",
    "Candidate pipeline & CRM (coming soon)",
    "Weekly talent digest email",
    "Priority support",
  ],
} as const;

/** Get current plan's project limit */
export function getProjectLimit(): { limit: number; planId: string } {
  const sub = loadSubscription();
  const planId = sub?.planId || "free";
  return { limit: PLAN_PROJECT_LIMITS[planId] ?? 1, planId };
}