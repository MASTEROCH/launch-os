import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { HelpCircle, ChevronDown, Lightbulb } from "lucide-react";

interface WhyBlockProps {
  /** Short label, e.g. "What is this?" */
  label?: string;
  /** The explanation text */
  children: React.ReactNode;
  /** Visual style */
  variant?: "inline" | "collapsible" | "banner";
  /** Color theme */
  color?: "purple" | "cyan" | "amber" | "emerald" | "violet";
  /** Icon override */
  icon?: typeof HelpCircle;
}

const colorClasses: Record<string, { bg: string; border: string; text: string; iconBg: string }> = {
  purple: { bg: "bg-purple-500/[0.04]", border: "border-purple-500/10", text: "text-purple-300/80", iconBg: "bg-purple-500/10 text-purple-400" },
  cyan: { bg: "bg-cyan-500/[0.04]", border: "border-cyan-500/10", text: "text-cyan-300/80", iconBg: "bg-cyan-500/10 text-cyan-400" },
  amber: { bg: "bg-amber-500/[0.04]", border: "border-amber-500/10", text: "text-amber-300/80", iconBg: "bg-amber-500/10 text-amber-400" },
  emerald: { bg: "bg-emerald-500/[0.04]", border: "border-emerald-500/10", text: "text-emerald-300/80", iconBg: "bg-emerald-500/10 text-emerald-400" },
  violet: { bg: "bg-violet-500/[0.04]", border: "border-violet-500/10", text: "text-violet-300/80", iconBg: "bg-violet-500/10 text-violet-400" },
};

/**
 * WhyBlock — contextual explanation component for beginners.
 * Use this everywhere you introduce a concept that a first-time founder
 * might not understand. Think: "teaching a child."
 *
 * Three variants:
 * - `inline`: always visible, small hint block
 * - `collapsible`: tap to expand explanation (default)
 * - `banner`: prominent educational banner
 */
export function WhyBlock({
  label,
  children,
  variant = "collapsible",
  color = "purple",
  icon: Icon,
}: WhyBlockProps) {
  const [open, setOpen] = useState(false);
  const c = colorClasses[color] || colorClasses.purple;

  if (variant === "inline") {
    return (
      <div className={`flex items-start gap-2 p-3 rounded-xl ${c.bg} border ${c.border}`}>
        <div className={`w-6 h-6 rounded-md ${c.iconBg} flex items-center justify-center shrink-0 mt-0.5`}>
          {Icon ? <Icon className="w-3 h-3" /> : <Lightbulb className="w-3 h-3" />}
        </div>
        <div className="text-xs text-zinc-400 leading-relaxed">{children}</div>
      </div>
    );
  }

  if (variant === "banner") {
    return (
      <div className={`p-4 rounded-xl ${c.bg} border ${c.border}`}>
        <div className="flex items-center gap-2 mb-2">
          <div className={`w-7 h-7 rounded-lg ${c.iconBg} flex items-center justify-center shrink-0`}>
            {Icon ? <Icon className="w-3.5 h-3.5" /> : <Lightbulb className="w-3.5 h-3.5" />}
          </div>
          {label && <span className={`text-sm ${c.text}`} style={{ fontWeight: 600 }}>{label}</span>}
        </div>
        <div className="text-xs text-zinc-400 leading-relaxed ml-9">{children}</div>
      </div>
    );
  }

  // Collapsible (default)
  return (
    <div className={`rounded-xl border ${c.border} overflow-hidden transition-all ${open ? c.bg : "bg-transparent"}`}>
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-2 px-3 py-2.5 text-left transition-all hover:bg-white/[0.02]"
      >
        <div className={`w-5 h-5 rounded-md ${c.iconBg} flex items-center justify-center shrink-0`}>
          <HelpCircle className="w-3 h-3" />
        </div>
        <span className="flex-1 text-xs text-zinc-500" style={{ fontWeight: 500 }}>
          {label || "What does this mean?"}
        </span>
        <motion.div animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown className="w-3.5 h-3.5 text-zinc-600" />
        </motion.div>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-3 pb-3 text-xs text-zinc-400 leading-relaxed ml-7">
              {children}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
