/* ═══════════════════════════════════════════════════════════════
   Stripe Payment Links — Central Configuration
   ═══════════════════════════════════════════════════════════════
   
   HOW TO SET UP:
   1. Go to Stripe Dashboard → Payment Links → Create
   2. Create a link for each plan × billing period
   3. Set the "After payment" redirect URL to:
      https://YOUR_DOMAIN/dashboard/tokens?success=true&plan=PLAN_ID&tokens=TOKEN_COUNT&period=monthly
   4. Replace the placeholder URLs below with your real Stripe Payment Links
   
   WEBHOOK (for production):
   Create a Stripe Webhook endpoint for `checkout.session.completed`
   In your backend (Supabase Edge Function / API route):
   - Verify the event signature
   - Read metadata.plan and metadata.tokens  
   - Credit the user's token balance in the database
   
   Token allocation per plan:
     Starter  → 100 tokens
     Growth   → 300 tokens  
     Viral    → 1,000 tokens
   ═══════════════════════════════════════════════════════════════ */

export interface StripePlan {
  id: string;
  tokens: number;
  monthlyPrice: number;
  annualPrice: number;
  stripeMonthlyUrl: string;
  stripeAnnualUrl: string;
}

// ─── Return URL base (change to your domain in production) ───
const RETURN_BASE = `${typeof window !== "undefined" ? window.location.origin : ""}/dashboard/tokens`;

function buildReturnUrl(planId: string, tokens: number, period: "monthly" | "annual") {
  return `${RETURN_BASE}?success=true&plan=${planId}&tokens=${tokens}&period=${period}`;
}

// ─── Plan definitions ───
export const STRIPE_PLANS: Record<string, StripePlan> = {
  starter: {
    id: "starter",
    tokens: 100,
    monthlyPrice: 29,
    annualPrice: 23,
    // Replace with real Stripe Payment Links:
    stripeMonthlyUrl: `https://buy.stripe.com/test_starter_monthly?success_url=${encodeURIComponent(buildReturnUrl("starter", 100, "monthly"))}`,
    stripeAnnualUrl: `https://buy.stripe.com/test_starter_annual?success_url=${encodeURIComponent(buildReturnUrl("starter", 100, "annual"))}`,
  },
  growth: {
    id: "growth",
    tokens: 300,
    monthlyPrice: 59,
    annualPrice: 47,
    stripeMonthlyUrl: `https://buy.stripe.com/test_growth_monthly?success_url=${encodeURIComponent(buildReturnUrl("growth", 300, "monthly"))}`,
    stripeAnnualUrl: `https://buy.stripe.com/test_growth_annual?success_url=${encodeURIComponent(buildReturnUrl("growth", 300, "annual"))}`,
  },
  viral: {
    id: "viral",
    tokens: 1000,
    monthlyPrice: 149,
    annualPrice: 119,
    stripeMonthlyUrl: `https://buy.stripe.com/test_viral_monthly?success_url=${encodeURIComponent(buildReturnUrl("viral", 1000, "monthly"))}`,
    stripeAnnualUrl: `https://buy.stripe.com/test_viral_annual?success_url=${encodeURIComponent(buildReturnUrl("viral", 1000, "annual"))}`,
  },
};

// ─── Token pack Stripe links (one-time purchases) ───
export const STRIPE_TOKEN_PACKS: Record<string, { tokens: number; price: number; stripeUrl: string }> = {
  starter: {
    tokens: 200,
    price: 9,
    stripeUrl: `https://buy.stripe.com/test_tokens_200?success_url=${encodeURIComponent(buildReturnUrl("tokens_200", 200, "monthly"))}`,
  },
  growth: {
    tokens: 600,
    price: 19,
    stripeUrl: `https://buy.stripe.com/test_tokens_600?success_url=${encodeURIComponent(buildReturnUrl("tokens_600", 600, "monthly"))}`,
  },
  viral: {
    tokens: 1500,
    price: 39,
    stripeUrl: `https://buy.stripe.com/test_tokens_1500?success_url=${encodeURIComponent(buildReturnUrl("tokens_1500", 1500, "monthly"))}`,
  },
};

/** Get the Stripe checkout URL for a subscription plan */
export function getStripeCheckoutUrl(planId: string, annual: boolean): string {
  const plan = STRIPE_PLANS[planId];
  if (!plan) return "#";
  return annual ? plan.stripeAnnualUrl : plan.stripeMonthlyUrl;
}

/** Get the Stripe checkout URL for a token pack */
export function getStripeTokenUrl(packId: string): string {
  const pack = STRIPE_TOKEN_PACKS[packId];
  if (!pack) return "#";
  return pack.stripeUrl;
}

/** Parse success params from URL after Stripe redirect */
export function parseStripeReturn(): { success: boolean; plan: string; tokens: number; period: string } | null {
  if (typeof window === "undefined") return null;
  const params = new URLSearchParams(window.location.search);
  if (params.get("success") !== "true") return null;
  return {
    success: true,
    plan: params.get("plan") || "",
    tokens: parseInt(params.get("tokens") || "0", 10),
    period: params.get("period") || "monthly",
  };
}

/** Clean up URL params after processing */
export function clearStripeParams() {
  if (typeof window === "undefined") return;
  const url = new URL(window.location.href);
  url.searchParams.delete("success");
  url.searchParams.delete("plan");
  url.searchParams.delete("tokens");
  url.searchParams.delete("period");
  window.history.replaceState({}, "", url.pathname);
}
