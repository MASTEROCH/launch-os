import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Rocket, TrendingUp, Users, Eye, MessageSquare, Zap,
  ArrowUpRight, ArrowRight, Activity, Plus, Sparkles,
  Check, ChevronRight, Coins, Globe, Crown,
  Package, Clock, AlertCircle, X, Radio, GripVertical,
  RefreshCw, Compass, Lightbulb, Play, ExternalLink,
  CalendarDays, BarChart3, RefreshCcw,
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar,
} from "recharts";
import { useNavigate } from "react-router";
import { useI18n } from "./i18n";
import {
  type UserProgress, DEFAULT_PROGRESS,
  loadProgress, saveProgress, resetProgress,
} from "./user-progress";
import { DndProvider, useDrag, useDrop } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { TouchBackend } from "react-dnd-touch-backend";
import { CountUp } from "./CountUp";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { WhyBlock } from "./WhyBlock";
import { OnboardingVideo, useOnboardingVideo } from "./OnboardingVideo";
import { MetricTooltip } from "./MetricTooltip";
import { toast } from "sonner";
import { updateProgress as globalUpdateProgress } from "./user-progress";

// Detect touch-only devices for DnD backend selection
const isTouchDevice = () =>
  typeof window !== "undefined" &&
  ("ontouchstart" in window || navigator.maxTouchPoints > 0) &&
  !window.matchMedia("(pointer: fine)").matches;

/* ─── Simulated data that grows with launch day ─── */
function getTrafficData(day: number) {
  if (day === 0) return [];
  const base = [
    { day: "Day 1", visitors: 12, engagement: 3 },
    { day: "Day 2", visitors: 48, engagement: 11 },
    { day: "Day 3", visitors: 134, engagement: 38 },
    { day: "Day 4", visitors: 287, engagement: 72 },
    { day: "Day 5", visitors: 412, engagement: 98 },
    { day: "Day 6", visitors: 589, engagement: 134 },
    { day: "Day 7", visitors: 823, engagement: 201 },
  ];
  return base.slice(0, Math.min(day, 7));
}

function getPlatformData(day: number) {
  if (day === 0) return [];
  const multiplier = Math.min(day / 7, 1);
  return [
    { platform: "Reddit", reach: Math.round(2400 * multiplier) },
    { platform: "Twitter", reach: Math.round(1800 * multiplier) },
    { platform: "LinkedIn", reach: Math.round(1200 * multiplier) },
    { platform: "PH", reach: Math.round(900 * multiplier) },
    { platform: "Forums", reach: Math.round(600 * multiplier) },
  ];
}

function getStats(day: number, t: (k: string) => string) {
  if (day === 0) return [];
  const m = Math.min(day / 7, 1);
  return [
    { icon: Rocket, label: t("dash.activeProjectsHuman"), value: "1", change: t("dash.justLaunched"), color: "purple", tip: t("dash.tipActive") },
    { icon: TrendingUp, label: t("dash.launchScoreHuman"), value: String(Math.round(87 * m)), change: `+${Math.round(12 * m)}%`, color: "emerald", tip: t("dash.tipScore") },
    { icon: Users, label: t("dash.communityReachHuman"), value: m < 0.5 ? String(Math.round(24800 * m)) : `${(24.8 * m).toFixed(1)}K`, change: `+${(3.2 * m).toFixed(1)}K`, color: "cyan", tip: t("dash.tipReach") },
    { icon: Eye, label: t("dash.trafficEstimateHuman"), value: String(Math.round(8420 * m)).replace(/\B(?=(\d{3})+(?!\d))/g, ","), change: `+${Math.round(18 * m)}%`, color: "amber", tip: t("dash.tipTraffic") },
    { icon: MessageSquare, label: t("dash.engagementHuman"), value: String(Math.round(1247 * m)).replace(/\B(?=(\d{3})+(?!\d))/g, ","), change: `+${Math.round(340 * m)}`, color: "rose", tip: t("dash.tipEng") },
    { icon: Zap, label: t("dash.mentionsHuman"), value: String(Math.round(89 * m)), change: `+${Math.round(23 * m)}`, color: "violet", tip: t("dash.tipMentions") },
  ];
}

function getActivities(day: number, t: (k: string) => string) {
  if (day === 0) return [];
  const all = [
    { text: t("dash.activity1"), time: "2 min" },
    { text: t("dash.activity2"), time: "15 min" },
    { text: t("dash.activity3"), time: "1 hr" },
    { text: t("dash.activity4"), time: "2 hrs" },
    { text: t("dash.activity5"), time: "3 hrs" },
    { text: t("dash.activity6"), time: "5 hrs" },
  ];
  return all.slice(0, Math.min(day, all.length));
}

const colorMap: Record<string, string> = {
  purple: "bg-purple-500/10 text-purple-400",
  emerald: "bg-emerald-500/10 text-emerald-400",
  cyan: "bg-cyan-500/10 text-cyan-400",
  amber: "bg-amber-500/10 text-amber-400",
  rose: "bg-rose-500/10 text-rose-400",
  violet: "bg-violet-500/10 text-violet-400",
};

/* ─── Tour tooltip ─── */
function TourTooltip({ step, total, title, desc, onNext, onSkip, skipLabel, nextLabel, doneLabel }: {
  step: number; total: number; title: string; desc: string;
  onNext: () => void; onSkip: () => void;
  skipLabel: string; nextLabel: string; doneLabel: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -10, scale: 0.96 }}
      className="fixed z-[100] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90vw] max-w-sm"
    >
      <div className="relative p-5 rounded-2xl bg-zinc-900 border border-purple-500/30 shadow-2xl shadow-purple-500/10">
        <button onClick={onSkip} className="absolute top-3 right-3 text-zinc-600 hover:text-zinc-400 transition-colors">
          <X className="w-3.5 h-3.5" />
        </button>
        <div className="text-xs text-purple-400 mb-2" style={{ fontWeight: 600 }}>{step + 1}/{total}</div>
        <div className="text-sm text-white mb-1" style={{ fontWeight: 600 }}>{title}</div>
        <p className="text-xs text-zinc-400 mb-4 leading-relaxed">{desc}</p>
        <div className="flex items-center gap-1.5 mb-4">
          {Array.from({ length: total }).map((_, i) => (
            <div key={i} className={`h-1 rounded-full transition-all ${i < step ? "w-5 bg-purple-500/50" : i === step ? "w-7 bg-purple-500" : "w-3 bg-white/[0.08]"}`} />
          ))}
        </div>
        <div className="flex items-center justify-between">
          <button onClick={onSkip} className="text-xs text-zinc-600 hover:text-zinc-400 transition-colors">{skipLabel}</button>
          <button onClick={onNext} className="text-xs text-white bg-purple-600 hover:bg-purple-500 px-4 py-2 rounded-lg transition-colors">
            {step < total - 1 ? nextLabel : doneLabel}
          </button>
        </div>
      </div>
    </motion.div>
  );
}

const STEP_DND_TYPE = "CHECKLIST_STEP";

/* ─── Draggable checklist step ─── */
interface StepItem {
  key: string;
  icon: typeof Rocket;
  title: string;
  desc: string;
  done: boolean;
  cta: string;
  action: () => void;
  color: string;
  locked?: boolean;
  extra?: string;
}

function DraggableStep({ step, index, moveStep, t }: {
  step: StepItem;
  index: number;
  moveStep: (from: number, to: number) => void;
  t: (k: string) => string;
}) {
  const stepRef = useRef<HTMLDivElement>(null);

  const [{ isDragging }, drag, preview] = useDrag({
    type: STEP_DND_TYPE,
    item: { index },
    collect: (monitor) => ({ isDragging: monitor.isDragging() }),
  });

  const [{ isOver }, drop] = useDrop({
    accept: STEP_DND_TYPE,
    hover(item: { index: number }) {
      if (item.index === index) return;
      moveStep(item.index, index);
      item.index = index;
    },
    collect: (monitor) => ({ isOver: monitor.isOver() }),
  });

  preview(drop(stepRef));

  return (
    <div
      ref={stepRef}
      style={{ opacity: isDragging ? 0.4 : 1 }}
      className={`flex items-start sm:items-center gap-2 sm:gap-3 p-3 sm:p-4 rounded-xl border transition-all ${
        isOver ? "border-purple-500/30 bg-purple-500/[0.04]" :
        step.done
          ? "border-emerald-500/15 bg-emerald-500/[0.03]"
          : step.locked
          ? "border-white/[0.03] bg-white/[0.01] opacity-50"
          : "border-white/5 bg-white/[0.02] hover:border-purple-500/20"
      }`}
    >
      {/* Drag handle */}
      <div ref={(node) => { drag(node); }} aria-label={t("a11y.dragHandle")} role="button" tabIndex={0} className="cursor-grab active:cursor-grabbing text-zinc-700 hover:text-zinc-500 transition-colors shrink-0 touch-none mt-1 sm:mt-0">
        <GripVertical className="w-3.5 h-3.5" />
      </div>
      <div className={`w-9 h-9 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center shrink-0 ${
        step.done
          ? "bg-emerald-500/15"
          : step.locked
          ? "bg-white/[0.03]"
          : step.color === "purple" ? "bg-purple-500/10" : step.color === "cyan" ? "bg-cyan-500/10" : step.color === "amber" ? "bg-amber-500/10" : "bg-emerald-500/10"
      }`}>
        {step.done ? (
          <Check className="w-4 h-4 text-emerald-400" />
        ) : (
          <step.icon className={`w-4 h-4 ${step.locked ? "text-zinc-600" : step.color === "purple" ? "text-purple-400" : step.color === "cyan" ? "text-cyan-400" : step.color === "amber" ? "text-amber-400" : "text-emerald-400"}`} />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div className={`text-sm ${step.done ? "text-emerald-300/80 line-through" : "text-white"}`} style={{ fontWeight: 500 }}>
          {step.title}
        </div>
        <div className="text-xs text-zinc-600 mt-0.5 hidden sm:block">{step.desc}</div>
      </div>
      {!step.done && !step.locked && (
        <button
          onClick={step.action}
          className="shrink-0 inline-flex items-center gap-1.5 text-xs text-purple-400 hover:text-purple-300 px-3 py-2 sm:py-1.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/15 transition-all active:scale-95"
        >
          {step.cta}<ChevronRight className="w-3 h-3" />
        </button>
      )}
      {step.locked && !step.done && (
        <span className="shrink-0 text-xs text-zinc-600 flex items-center gap-1"><AlertCircle className="w-3 h-3" /><span className="hidden sm:inline">{t("dash.locked")}</span></span>
      )}
    </div>
  );
}

/* ─── Unified Pipeline + Core Loop Block ─── */
function CoreLoopBlock({ progress, packageDone, t, navigate }: {
  progress: UserProgress;
  packageDone: boolean;
  t: (k: string) => string;
  navigate: (to: string) => void;
}) {
  const loopSteps = [
    { n: 1, label: t("pipeline.clarify"), desc: t("pipeline.clarifyDesc"), icon: Sparkles, color: "purple", done: progress.projectCreated, path: "/dashboard/new-project" },
    { n: 2, label: t("pipeline.package"), desc: t("pipeline.packageDesc"), icon: Package, color: "violet", done: packageDone, path: "/dashboard/package" },
    { n: 3, label: t("pipeline.route"), desc: t("pipeline.routeDesc"), icon: Compass, color: "cyan", done: progress.channelsConnected > 0, path: "/dashboard/growth" },
    { n: 4, label: t("pipeline.launch"), desc: t("pipeline.launchDesc"), icon: Zap, color: "emerald", done: progress.launched, path: "/dashboard/launch" },
    { n: 5, label: t("pipeline.improve"), desc: t("pipeline.improveDesc"), icon: TrendingUp, color: "amber", done: progress.launched && progress.launchDay >= 3, path: "/dashboard/tracker" },
  ];
  const allDone = loopSteps.every(s => s.done);
  const cycleCount = allDone ? Math.max(1, Math.ceil(progress.launchDay / 7)) : 0;
  const doneCount = loopSteps.filter(s => s.done).length;
  const activeIdx = loopSteps.findIndex(s => !s.done);
  const clrMap: Record<string, { text: string; bg: string; numBg: string; numText: string; border: string; hex: string; shadow: string }> = {
    purple:  { text: "text-purple-400",  bg: "bg-purple-500/[0.06]",  numBg: "bg-purple-500",  numText: "text-white",    border: "border-purple-500/20", hex: "#a855f7", shadow: "shadow-purple-500/25" },
    violet:  { text: "text-violet-400",  bg: "bg-violet-500/[0.06]",  numBg: "bg-violet-500",  numText: "text-white",    border: "border-violet-500/20", hex: "#8b5cf6", shadow: "shadow-violet-500/25" },
    cyan:    { text: "text-cyan-400",    bg: "bg-cyan-500/[0.06]",    numBg: "bg-cyan-500",    numText: "text-white",    border: "border-cyan-500/20",   hex: "#06b6d4", shadow: "shadow-cyan-500/25" },
    emerald: { text: "text-emerald-400", bg: "bg-emerald-500/[0.06]", numBg: "bg-emerald-500", numText: "text-white",    border: "border-emerald-500/20",hex: "#10b981", shadow: "shadow-emerald-500/25" },
    amber:   { text: "text-amber-400",   bg: "bg-amber-500/[0.06]",   numBg: "bg-amber-500",   numText: "text-white",    border: "border-amber-500/20",  hex: "#f59e0b", shadow: "shadow-amber-500/25" },
  };

  const tools = [
    { icon: CalendarDays, label: t("sidebar.contentPlan"), desc: t("dash.coreLoop.toolContentPlanDesc"), path: "/dashboard/content-plan", iconColor: "text-purple-400", bgColor: "bg-purple-500/[0.08] hover:bg-purple-500/15 border-purple-500/10" },
    { icon: BarChart3, label: t("sidebar.analytics"), desc: t("dash.coreLoop.toolAnalyticsDesc"), path: "/dashboard/analytics", iconColor: "text-cyan-400", bgColor: "bg-cyan-500/[0.08] hover:bg-cyan-500/15 border-cyan-500/10" },
    { icon: Users, label: t("sidebar.community"), desc: t("dash.coreLoop.toolCommunityDesc"), path: "/dashboard/community", iconColor: "text-emerald-400", bgColor: "bg-emerald-500/[0.08] hover:bg-emerald-500/15 border-emerald-500/10" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.05 }}
      className="p-4 sm:p-5 rounded-[18px] sm:rounded-2xl border border-white/5 bg-white/[0.02] relative overflow-hidden"
    >
      {/* Ambient glow */}
      <div className="absolute -top-24 -right-24 w-48 h-48 bg-purple-500/[0.04] rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-20 -left-20 w-40 h-40 bg-cyan-500/[0.03] rounded-full blur-3xl pointer-events-none" />

      {/* ── Header ── */}
      <div className="relative flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-purple-500/15 to-cyan-500/15 flex items-center justify-center">
            <RefreshCcw className="w-4 h-4 text-purple-400" />
          </div>
          <div className="flex items-center gap-2">
            <div>
              <span className="text-sm text-white block" style={{ fontWeight: 600 }}>{t("dash.coreLoop.title")}</span>
              <span className="text-[11px] text-zinc-500">{t("dash.coreLoop.subtitle")}</span>
            </div>
            {cycleCount > 0 && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 400, damping: 20 }}
                className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-gradient-to-r from-cyan-500/15 to-purple-500/15 border border-cyan-500/20 self-start"
              >
                <RefreshCw className="w-3 h-3 text-cyan-400" />
                <span className="text-[10px] text-cyan-400" style={{ fontWeight: 600 }}>{cycleCount}</span>
              </motion.div>
            )}
          </div>
        </div>
        <button
          type="button"
          onClick={() => navigate("/dashboard/roadmap")}
          className="text-[11px] text-purple-400 hover:text-purple-300 flex items-center gap-1 transition-colors px-2.5 py-1.5 rounded-lg hover:bg-purple-500/5"
        >
          {t("dash.coreLoop.seeRoadmap")}<ArrowRight className="w-3 h-3" />
        </button>
      </div>

      {/* ── Progress bar ── */}
      <div className="relative mb-4 px-0.5">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[10px] text-zinc-500" style={{ fontWeight: 500 }}>{doneCount}/5 {t("dash.coreLoop.newCycle")}</span>
          {allDone && <span className="text-[10px] text-emerald-400" style={{ fontWeight: 600 }}>{t("dash.coreLoop.iterate")}</span>}
        </div>
        <div className="h-1 rounded-full bg-white/[0.04] overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${(doneCount / 5) * 100}%` }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="h-full rounded-full bg-gradient-to-r from-purple-500 via-cyan-500 to-emerald-500"
          />
        </div>
      </div>

      {/* ── Step list ── */}
      <div className="relative space-y-1.5">
        {loopSteps.map((s, i) => {
          const cs = clrMap[s.color];
          const isActive = activeIdx === i;
          return (
            <motion.button
              key={s.n}
              type="button"
              onClick={() => navigate(s.path)}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.08 + i * 0.06 }}
              whileHover={{ x: 2 }}
              whileTap={{ scale: 0.98 }}
              className={`w-full flex items-center gap-3 p-3 sm:p-3.5 rounded-xl border transition-all text-left group ${
                s.done
                  ? "border-emerald-500/10 bg-emerald-500/[0.03] hover:bg-emerald-500/[0.06]"
                  : isActive
                  ? `${cs.border} ${cs.bg} hover:bg-white/[0.04]`
                  : "border-white/[0.04] bg-white/[0.01] hover:bg-white/[0.03] opacity-50 hover:opacity-70"
              }`}
            >
              {/* Numbered circle */}
              <div className={`relative w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center shrink-0 transition-all ${
                s.done
                  ? "bg-emerald-500 shadow-lg shadow-emerald-500/25"
                  : isActive
                  ? `${cs.numBg} shadow-lg ${cs.shadow}`
                  : "bg-white/[0.06]"
              }`}>
                {s.done ? (
                  <Check className="w-4 h-4 text-white" />
                ) : (
                  <span className={`text-sm ${isActive ? cs.numText : "text-zinc-600"}`} style={{ fontWeight: 700 }}>{s.n}</span>
                )}
                {isActive && !s.done && (
                  <span className={`absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full ${cs.numBg} core-loop-active-pulse`} />
                )}
              </div>

              {/* Text */}
              <div className="flex-1 min-w-0">
                <div className={`text-sm ${s.done ? "text-emerald-400" : isActive ? "text-white" : "text-zinc-500"}`} style={{ fontWeight: 600 }}>
                  {s.label}
                </div>
                <div className={`text-[11px] mt-0.5 ${s.done ? "text-zinc-600" : isActive ? "text-zinc-400" : "text-zinc-600"}`}>
                  {s.desc}
                </div>
              </div>

              {/* Right icon + arrow */}
              <div className="flex items-center gap-1.5 shrink-0">
                <s.icon className={`w-4 h-4 ${s.done ? "text-emerald-500/40" : isActive ? cs.text : "text-zinc-700"}`} />
                <ArrowRight className={`w-3 h-3 transition-all ${
                  s.done ? "text-emerald-500/30" : isActive ? "text-zinc-500 group-hover:text-zinc-300 group-hover:translate-x-0.5" : "text-zinc-700"
                }`} />
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* ── Return arrow: new cycle ── */}
      <div className="mt-2 mx-1 sm:mx-2 relative">
        <svg width="100%" height="20" viewBox="0 0 400 20" preserveAspectRatio="xMidYMid meet" fill="none" className="block">
          <defs>
            <linearGradient id="returnGrad" x1="380" y1="10" x2="20" y2="10" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity={allDone ? "0.5" : "0.12"} />
              <stop offset="50%" stopColor="#06b6d4" stopOpacity={allDone ? "0.4" : "0.08"} />
              <stop offset="100%" stopColor="#a855f7" stopOpacity={allDone ? "0.5" : "0.12"} />
            </linearGradient>
          </defs>
          <motion.path
            d="M 370 3 C 370 12, 360 17, 340 17 L 60 17 C 40 17, 30 12, 30 5"
            stroke="url(#returnGrad)"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeDasharray={allDone ? "0" : "3 5"}
            fill="none"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 1 }}
            transition={{ duration: 1.2, delay: 0.6, ease: "easeInOut" }}
          />
          <motion.path
            d="M 34 1 L 28 6 L 34 11"
            stroke="#a855f7"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
            initial={{ opacity: 0 }}
            animate={{ opacity: allDone ? 0.7 : 0.25 }}
            transition={{ delay: 1.6 }}
          />
        </svg>
        <motion.span
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="absolute left-1/2 -translate-x-1/2 top-0 text-[8px] tracking-widest uppercase text-zinc-600"
          style={{ fontWeight: 600 }}
        >
          {t("dash.coreLoop.newCycle")}
        </motion.span>
      </div>

      {/* ── Tool shortcuts ── */}
      <div className="mt-3 pt-3 border-t border-white/[0.04]">
        <div className="flex items-center gap-1.5 mb-2.5">
          <span className="text-[10px] text-zinc-600 uppercase tracking-wider" style={{ fontWeight: 600 }}>{t("dash.coreLoop.toolsHint")}</span>
          <ArrowRight className="w-2.5 h-2.5 text-zinc-700" />
        </div>
        <div className="grid grid-cols-3 gap-2">
          {tools.map((tool) => (
            <button
              key={tool.path}
              onClick={() => navigate(tool.path)}
              className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl border transition-all text-left ${tool.bgColor}`}
            >
              <tool.icon className={`w-4 h-4 ${tool.iconColor} shrink-0`} />
              <div className="min-w-0">
                <div className="text-[11px] text-zinc-300 truncate" style={{ fontWeight: 500 }}>{tool.label}</div>
                <div className="text-[9px] text-zinc-600 truncate hidden sm:block">{tool.desc}</div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

/* ─── Component ─── */
export function Dashboard() {
  const navigate = useNavigate();
  const { t } = useI18n();
  useDocumentTitle(t("sidebar.dashboard"));
  const [progress, setProgress] = useState<UserProgress>(loadProgress);
  const [tourStep, setTourStep] = useState<number>(-1);
  const [tourDismissed, setTourDismissed] = useState(false);
  const [loading, setLoading] = useState(true);
  const { show: showVideo, dismiss: dismissVideo } = useOnboardingVideo();

  // ─── Pull-to-refresh (mobile) ───
  const [pullY, setPullY] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const pullStartY = useRef(0);
  const isPulling = useRef(false);
  const mainRef = useRef<HTMLDivElement>(null);

  const onPullStart = useCallback((e: React.TouchEvent) => {
    // Only start pull if scrolled to top
    const el = mainRef.current?.closest("main");
    if (el && el.scrollTop <= 0) {
      pullStartY.current = e.touches[0].clientY;
      isPulling.current = true;
    }
  }, []);

  const onPullMove = useCallback((e: React.TouchEvent) => {
    if (!isPulling.current || isRefreshing) return;
    const dy = e.touches[0].clientY - pullStartY.current;
    if (dy > 0) {
      // Rubber-band effect: diminishing return
      setPullY(Math.min(dy * 0.45, 120));
    }
  }, [isRefreshing]);

  const onPullEnd = useCallback(() => {
    isPulling.current = false;
    if (pullY > 70 && !isRefreshing) {
      setIsRefreshing(true);
      setPullY(60);
      // Simulate refresh
      setTimeout(() => {
        setProgress(loadProgress());
        setIsRefreshing(false);
        setPullY(0);
      }, 1200);
    } else {
      setPullY(0);
    }
  }, [pullY, isRefreshing]);

  // ─── Checklist order (persisted) ───
  const [stepOrder, setStepOrder] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("launchapp_stepOrder");
      if (saved) return JSON.parse(saved);
    } catch {}
    return ["project", "tokens", "channels", "launch"];
  });

  const moveStep = useCallback((from: number, to: number) => {
    setStepOrder((prev) => {
      const next = [...prev];
      const [moved] = next.splice(from, 1);
      next.splice(to, 0, moved);
      localStorage.setItem("launchapp_stepOrder", JSON.stringify(next));
      return next;
    });
  }, []);

  // Simulate loading
  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 700);
    return () => clearTimeout(timer);
  }, []);

  // Reload progress from localStorage on mount (navigating back from wizard/tokens)
  // Also detect step completions for micro-celebrations
  useEffect(() => {
    const fresh = loadProgress();
    setProgress(fresh);

    // Detect step completions by comparing against last known state
    try {
      const prevRaw = sessionStorage.getItem("launchapp_dash_prev");
      if (prevRaw) {
        const prev = JSON.parse(prevRaw) as Partial<UserProgress>;
        if (!prev.projectCreated && fresh.projectCreated) {
          setTimeout(() => toast.success(t("dash.stepDone"), { description: `${t("dash.nextUp")}: ${t("pipeline.package")}`, duration: 4000 }), 600);
        } else if ((prev.channelsConnected || 0) === 0 && fresh.channelsConnected > 0) {
          setTimeout(() => toast.success(t("dash.stepDone"), { description: `${t("dash.nextUp")}: ${t("pipeline.launch")}`, duration: 4000 }), 600);
        }
      }
    } catch { /* ignore */ }
    // Save current state for next comparison
    try { sessionStorage.setItem("launchapp_dash_prev", JSON.stringify({ projectCreated: fresh.projectCreated, channelsConnected: fresh.channelsConnected, launched: fresh.launched })); } catch {}

    // Update lastVisit timestamp
    globalUpdateProgress({ lastVisit: Date.now() });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    saveProgress(progress);
    // Dispatch progress event so Layout sidebar/mobile progress bar updates in real-time
    try {
      document.dispatchEvent(new CustomEvent("launchapp:progress", { detail: progress }));
    } catch { /* SSR-safe */ }
  }, [progress]);

  // Start tour for completely new users
  useEffect(() => {
    if (!progress.projectCreated && !progress.tourCompleted && !tourDismissed) {
      const timer = setTimeout(() => setTourStep(0), 800);
      return () => clearTimeout(timer);
    }
  }, [progress.projectCreated, progress.tourCompleted, tourDismissed]);

  const doUpdate = (patch: Partial<UserProgress>) =>
    setProgress((p) => ({ ...p, ...patch }));

  const advanceDay = () =>
    doUpdate({ launchDay: Math.min(progress.launchDay + 1, 7) });

  const resetDemo = () => {
    setProgress(DEFAULT_PROGRESS);
    resetProgress();
    setTourStep(-1);
    setTourDismissed(false);
    // Dispatch reset event so Layout updates immediately
    try {
      document.dispatchEvent(new CustomEvent("launchapp:progress", { detail: DEFAULT_PROGRESS }));
    } catch { /* SSR-safe */ }
  };

  const closeTour = () => {
    setTourStep(-1);
    setTourDismissed(true);
    doUpdate({ tourCompleted: true });
  };

  const nextTourStep = () => {
    if (tourStep < 2) setTourStep(tourStep + 1);
    else closeTour();
  };

  const tourSteps = [
    { title: t("tour.step1Title"), desc: t("tour.step1Desc") },
    { title: t("tour.step2Title"), desc: t("tour.step2Desc") },
    { title: t("tour.step3Title"), desc: t("tour.step3Desc") },
  ];

  /* Checklist steps */
  const steps: StepItem[] = [
    {
      key: "project",
      icon: Package,
      title: t("dash.step1Title"),
      desc: t("dash.step1Desc"),
      done: progress.projectCreated,
      cta: t("dash.step1Cta"),
      action: () => navigate("/dashboard/new-project"),
      color: "purple",
    },
    {
      key: "tokens",
      icon: Coins,
      title: t("dash.step2Title"),
      desc: t("dash.step2Desc"),
      done: progress.tokensAvailable > 0,
      cta: t("dash.step2Cta"),
      action: () => navigate("/dashboard/tokens"),
      color: "cyan",
      locked: !progress.projectCreated,
    },
    {
      key: "channels",
      icon: Radio,
      title: t("dash.step4Title"),
      desc: t("dash.step4Desc"),
      done: progress.channelsConnected > 0,
      cta: t("dash.step4Cta"),
      action: () => navigate("/dashboard/growth"),
      color: "amber",
      locked: !progress.projectCreated,
      extra: progress.channelsConnected > 0 ? `${progress.channelsConnected} ${t("dash.channelsReady")}` : undefined,
    },
    {
      key: "launch",
      icon: Rocket,
      title: t("dash.step3Title"),
      desc: t("dash.step3Desc"),
      done: progress.launched,
      cta: t("dash.step3Cta"),
      action: () => navigate("/dashboard/launch"),
      color: "emerald",
      locked: !progress.projectCreated || progress.tokensAvailable === 0,
    },
  ];

  const completedSteps = steps.filter((s) => s.done).length;
  const isNewUser = !progress.launched;

  // Compute pipeline completion for unified journey view
  const packageDone = (() => { try { return !!localStorage.getItem("launchapp_package_generated"); } catch { return false; } })();
  const pipelineSteps = [
    { done: progress.projectCreated, label: t("pipeline.clarify"), path: "/dashboard/new-project", icon: Sparkles, color: "purple", estMin: 3 },
    { done: packageDone, label: t("pipeline.package"), path: "/dashboard/package", icon: Package, color: "violet", estMin: 2 },
    { done: progress.channelsConnected > 0, label: t("pipeline.route"), path: "/dashboard/growth", icon: Compass, color: "cyan", estMin: 3 },
    { done: progress.launched, label: t("pipeline.launch"), path: "/dashboard/launch", icon: Zap, color: "emerald", estMin: 1 },
    { done: progress.launched && progress.launchDay >= 3, label: t("pipeline.improve"), path: "/dashboard/tracker", icon: TrendingUp, color: "amber", estMin: 5 },
  ];
  const pipelineCompleted = pipelineSteps.filter((s) => s.done).length;
  const nextPipelineStep = pipelineSteps.find((s) => !s.done);
  const isOnboarded = progress.onboardingCompleted;
  const displayName = progress.userName?.split(" ")[0] || "";

  // Sort steps by saved order
  const orderedSteps = stepOrder
    .map((key) => steps.find((s) => s.key === key))
    .filter(Boolean) as StepItem[];
  // Add any steps not in saved order (safety)
  steps.forEach((s) => { if (!orderedSteps.find((o) => o.key === s.key)) orderedSteps.push(s); });

  const stats = getStats(progress.launchDay, t);
  const trafficData = getTrafficData(progress.launchDay);
  const platformData = getPlatformData(progress.launchDay);
  const activities = getActivities(progress.launchDay, t);

  if (loading) {
    return (
      <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6 animate-pulse">
        {/* Header skeleton */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="h-7 w-48 rounded-lg bg-white/[0.06]" />
            <div className="h-4 w-64 rounded-lg bg-white/[0.04] mt-2" />
          </div>
          <div className="h-10 w-36 rounded-xl bg-white/[0.06]" />
        </div>
        {/* Checklist skeleton */}
        <div className="p-6 rounded-2xl border border-white/5 bg-white/[0.02]">
          <div className="flex items-center gap-2 mb-5">
            <div className="h-4 w-4 rounded bg-white/[0.06]" />
            <div className="h-5 w-36 rounded-lg bg-white/[0.06]" />
          </div>
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex items-center gap-4 p-4 rounded-xl border border-white/[0.03] bg-white/[0.01]">
                <div className="w-9 h-9 rounded-xl bg-white/[0.05]" />
                <div className="flex-1">
                  <div className="h-4 w-40 rounded bg-white/[0.06] mb-1.5" />
                  <div className="h-3 w-56 rounded bg-white/[0.04]" />
                </div>
                <div className="h-7 w-20 rounded-lg bg-white/[0.05]" />
              </div>
            ))}
          </div>
        </div>
        {/* Stats skeleton */}
        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="p-4 rounded-xl border border-white/[0.03] bg-white/[0.01]">
              <div className="w-8 h-8 rounded-lg bg-white/[0.05] mb-3" />
              <div className="h-6 w-12 rounded bg-white/[0.06] mb-1" />
              <div className="h-3 w-20 rounded bg-white/[0.04]" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <DndProvider backend={isTouchDevice() ? TouchBackend : HTML5Backend} options={isTouchDevice() ? { enableMouseEvents: true } : undefined}>
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-4 sm:space-y-6" ref={mainRef} onTouchStart={onPullStart} onTouchMove={onPullMove} onTouchEnd={onPullEnd}>
      {/* Onboarding video for brand new users */}
      <AnimatePresence>
        {showVideo && <OnboardingVideo onClose={dismissVideo} />}
      </AnimatePresence>

      {/* Pull-to-refresh indicator (mobile only) */}
      <AnimatePresence>
        {(pullY > 10 || isRefreshing) && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: Math.max(pullY, isRefreshing ? 48 : 0) }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="flex items-center justify-center overflow-hidden md:hidden -mt-4 -mx-4 sm:-mx-6"
          >
            <motion.div
              animate={{ rotate: isRefreshing ? 360 : pullY * 3 }}
              transition={isRefreshing ? { repeat: Infinity, duration: 0.8, ease: "linear" } : { type: "spring" }}
            >
              <RefreshCw className={`w-5 h-5 ${pullY > 70 || isRefreshing ? "text-purple-400" : "text-zinc-600"}`} />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Tour overlay backdrop */}
      <AnimatePresence>
        {tourStep >= 0 && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 z-40"
            onClick={closeTour}
          />
        )}
      </AnimatePresence>

      {/* Header — iOS Large Title */}
      <LargeTitle
        title={t("dash.title")}
        subtitle={t("dash.subtitle")}
        actions={
          <div className="flex items-center gap-2">
            {progress.launched && progress.launchDay < 7 && (
              <button onClick={advanceDay} className="text-xs text-zinc-600 hover:text-zinc-400 px-3 py-2.5 sm:py-2 rounded-lg border border-white/5 hover:border-white/10 transition-colors flex items-center gap-1.5 active:scale-95">
                <Clock className="w-3.5 h-3.5 sm:w-3 sm:h-3" />{t("dash.simDay")}
              </button>
            )}
            {(progress.projectCreated || progress.launched) && (
              <button onClick={resetDemo} className="text-xs text-zinc-600 hover:text-zinc-400 px-3 py-2.5 sm:py-2 rounded-lg border border-white/5 hover:border-white/10 transition-colors active:scale-95">
                {t("dash.reset")}
              </button>
            )}
            {/* "New Launch" button with tour tooltip */}
            <div className="relative">
              <button onClick={() => navigate("/dashboard/new-project")} className={`inline-flex items-center gap-2 bg-purple-600 hover:bg-purple-500 text-white px-4 sm:px-5 py-2.5 rounded-xl text-sm transition-colors active:scale-95 ${tourStep === 0 ? "relative z-50 ring-2 ring-purple-400/50 ring-offset-2 ring-offset-zinc-950" : ""}`}>
                <Plus className="w-4 h-4" />{t("dash.newLaunch")}
              </button>
              <AnimatePresence>
                {tourStep === 0 && (
                  <TourTooltip step={0} total={3} title={tourSteps[0].title} desc={tourSteps[0].desc} onNext={nextTourStep} onSkip={closeTour} skipLabel={t("tour.skip")} nextLabel={t("tour.next")} doneLabel={t("tour.done")} />
                )}
              </AnimatePresence>
            </div>
          </div>
        }
      />

      {/* ─── Smart Welcome Banner (for returning onboarded users) ─── */}
      {isOnboarded && isNewUser && nextPipelineStep && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.03 }}
          className="relative overflow-hidden p-4 sm:p-5 rounded-[18px] sm:rounded-2xl border border-purple-500/15 bg-gradient-to-br from-purple-500/[0.06] via-transparent to-cyan-500/[0.04]"
        >
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-purple-400/30 to-transparent" />
          <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4">
            <div className="flex-1 min-w-0">
              <h3 className="text-white mb-0.5" style={{ fontWeight: 600 }}>
                {displayName
                  ? t("dash.welcomeBack").replace("{name}", displayName)
                  : t("dash.welcomeNew")}
              </h3>
              <p className="text-xs text-zinc-500">
                {t("dash.completedOf").replace("{n}", String(pipelineCompleted)).replace("{total}", "5")}
                {" · "}
                {t("dash.continueJourney")}
              </p>
            </div>
            <motion.button
              whileTap={{ scale: 0.96 }}
              onClick={() => navigate(nextPipelineStep.path)}
              className="shrink-0 inline-flex items-center gap-2 bg-purple-600 hover:bg-purple-500 text-white px-5 py-2.5 rounded-xl text-sm transition-all shadow-lg shadow-purple-500/15 active:scale-95"
              style={{ fontWeight: 500 }}
            >
              <Play className="w-3.5 h-3.5" />
              {nextPipelineStep.label}
              <span className="text-purple-200/70 text-xs">{t("dash.estimatedTime").replace("{n}", String(nextPipelineStep.estMin))}</span>
            </motion.button>
          </div>
          {/* Mini progress dots */}
          <div className="flex items-center gap-1.5 mt-3">
            {pipelineSteps.map((s, i) => (
              <div key={i} className={`h-1 rounded-full transition-all ${s.done ? "w-6 bg-emerald-500/60" : s === nextPipelineStep ? "w-8 bg-purple-500" : "w-4 bg-white/[0.06]"}`} />
            ))}
          </div>
        </motion.div>
      )}

      {/* ─── Unified Pipeline + Core Loop ─── */}
      <CoreLoopBlock progress={progress} packageDone={packageDone} t={t} navigate={navigate} />

      {/* ─── Getting Started Checklist ─── */}
      {isNewUser && (
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className={`p-4 sm:p-6 rounded-[18px] sm:rounded-2xl border border-white/5 bg-white/[0.02] ${tourStep === 1 ? "relative z-50 ring-2 ring-purple-400/50 ring-offset-2 ring-offset-zinc-950" : ""}`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
            <div>
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <h2 className="text-white" style={{ fontWeight: 600 }}>{t("dash.getStarted")}</h2>
              </div>
              <p className="text-xs text-zinc-500 mt-1">{t("dash.getStartedSub")}</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="text-xs text-zinc-500">{completedSteps}/{steps.length}</div>
              <div className="w-24 h-1.5 rounded-full bg-white/5 overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${(completedSteps / steps.length) * 100}%` }}
                  transition={{ duration: 0.6, ease: "easeOut" }}
                  className="h-full rounded-full bg-gradient-to-r from-purple-500 to-violet-500"
                />
              </div>
            </div>
          </div>

          <div className="space-y-3 relative">
            {orderedSteps.map((step, i) => (
              <DraggableStep key={step.key} step={step} index={i} moveStep={moveStep} t={t} />
            ))}

            {/* Tour tooltip for checklist */}
            <AnimatePresence>
              {tourStep === 1 && (
                <TourTooltip step={1} total={3} title={tourSteps[1].title} desc={tourSteps[1].desc} onNext={nextTourStep} onSkip={closeTour} skipLabel={t("tour.skip")} nextLabel={t("tour.next")} doneLabel={t("tour.done")} />
              )}
            </AnimatePresence>
          </div>

          {/* Quick Start — single clean button replacing cluttered demo shortcuts */}
          {!progress.projectCreated && (
            <div className="mt-4 pt-4 border-t border-white/5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-zinc-500" style={{ fontWeight: 500 }}>{t("dash.quickStart")}</p>
                  <p className="text-[11px] text-zinc-600 mt-0.5">{t("dash.quickStartDesc")}</p>
                </div>
                <button
                  onClick={() => {
                    doUpdate({
                      projectCreated: true, projectName: "AI Task Manager", projectCategory: "SaaS",
                      tokensAvailable: 300, channelsConnected: 8, launched: true, launchDay: 3,
                      userName: "Alex", onboardingCompleted: true, lastCompletedStep: 4, lastVisit: Date.now(),
                    });
                    const chState: Record<string, string> = { twitter: "connected", linkedin: "connected", producthunt: "connected", reddit: "connected", hackernews: "connected", "email-pr": "active", catalogs: "active", seo: "active", newsletters: "active", forums: "active" };
                    localStorage.setItem("launchapp_channels", JSON.stringify(chState));
                    try { localStorage.setItem("launchapp_package_generated", JSON.stringify(["oneLiner","elevatorPitch","landingCopy","offer","faq"])); } catch {}
                    toast.success(t("dash.quickStart"), { description: t("dash.quickStartDesc") });
                    setTimeout(() => setProgress(loadProgress()), 100);
                  }}
                  className="ios-press inline-flex items-center gap-1.5 text-xs text-purple-400 hover:text-purple-300 px-3.5 py-2 rounded-xl bg-purple-500/10 hover:bg-purple-500/15 border border-purple-500/10 transition-all active:scale-95"
                >
                  <Zap className="w-3 h-3" />
                  {t("dash.quickStart")}
                </button>
              </div>
            </div>
          )}
        </motion.div>
      )}

      {/* ─── Ready to Launch Hero (project + tokens ready) ─── */}
      {progress.projectCreated && !progress.launched && progress.tokensAvailable > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="relative overflow-hidden p-5 sm:p-6 rounded-[18px] sm:rounded-2xl border border-emerald-500/30 bg-gradient-to-br from-emerald-500/10 via-purple-500/5 to-violet-500/10"
        >
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-emerald-400/40 to-transparent" />
          <motion.div
            className="absolute -top-20 -right-20 w-40 h-40 rounded-full bg-purple-500/10 blur-3xl"
            animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.6, 0.3] }}
            transition={{ duration: 4, repeat: Infinity }}
          />
          <div className="relative flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <motion.div
              animate={{ y: [0, -4, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-purple-500/20 border border-emerald-500/20 flex items-center justify-center shrink-0"
            >
              <Rocket className="w-7 h-7 text-emerald-400" />
            </motion.div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="text-white" style={{ fontWeight: 700 }}>{t("dash.readyToLaunch") || "Ready to launch!"}</h3>
                <motion.span
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                  className="text-xs text-emerald-400 bg-emerald-500/15 px-2 py-0.5 rounded-full border border-emerald-500/20"
                  style={{ fontWeight: 600 }}
                >
                  <Check className="w-3 h-3 inline-block mr-0.5" /> {t("dash.allReady") || "All set"}
                </motion.span>
              </div>
              <p className="text-sm text-zinc-400">
                <span style={{ fontWeight: 600 }} className="text-white">{progress.projectName}</span> · {progress.tokensAvailable} {t("dash.tokens")} · {t("dash.readyDesc") || "Your content is ready for distribution across all channels"}
              </p>
            </div>
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => navigate("/dashboard/launch")}
              className="relative shrink-0 inline-flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-purple-600 hover:from-emerald-500 hover:to-purple-500 text-white px-6 py-3 rounded-xl text-sm transition-all shadow-lg shadow-purple-500/20"
              style={{ fontWeight: 600 }}
            >
              <motion.div
                className="absolute inset-0 rounded-xl border-2 border-emerald-400/40"
                animate={{ scale: [1, 1.1, 1], opacity: [0.6, 0, 0.6] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              <Rocket className="w-4 h-4" />
              {t("dash.launchNow")}
              <ArrowRight className="w-3.5 h-3.5" />
            </motion.button>
          </div>
        </motion.div>
      )}

      {/* ─── Project card (when project exists but needs tokens) ─── */}
      {progress.projectCreated && !progress.launched && progress.tokensAvailable === 0 && (
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <div className="p-4 sm:p-5 rounded-[18px] sm:rounded-2xl border border-white/5 bg-white/[0.02]">
            <div className="flex items-center justify-between mb-3 sm:mb-4">
              <h3 className="text-white" style={{ fontWeight: 600 }}>{t("dash.yourProject")}</h3>
              <span className="text-[10px] sm:text-xs text-amber-400 px-2 sm:px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/15 flex items-center gap-1">
                <Clock className="w-3 h-3" />{t("dash.draftStatus")}
              </span>
            </div>
            <div className="flex flex-col gap-3 sm:gap-4 p-3 sm:p-4 rounded-xl border border-white/5 bg-white/[0.01]">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-purple-500/20 to-violet-500/20 border border-purple-500/10 flex items-center justify-center shrink-0">
                  <Rocket className="w-5 h-5 text-purple-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-white" style={{ fontWeight: 600 }}>{progress.projectName || "My Project"}</div>
                  <div className="text-xs text-zinc-500 mt-0.5 flex items-center gap-2">
                    <span>{progress.projectCategory || "Startup"}</span>
                    <span className="flex items-center gap-1"><Coins className="w-3 h-3" />{progress.tokensAvailable} {t("dash.tokens")}</span>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => navigate("/dashboard/tokens")} className="ios-press flex-1 inline-flex items-center justify-center gap-1.5 bg-cyan-600 hover:bg-cyan-500 text-white px-4 py-2.5 rounded-xl text-sm transition-all">
                  <Coins className="w-3.5 h-3.5" />{t("dash.getTokens")}
                </button>
              </div>
            </div>
            <div className="mt-3 flex items-start gap-2 p-3 rounded-xl bg-amber-500/5 border border-amber-500/10">
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <p className="text-xs text-zinc-400">{t("dash.needTokens")}</p>
            </div>
          </div>
        </motion.div>
      )}

      {/* ─── Stats grid (only after launch) ─── */}
      {progress.launched && stats.length > 0 && (
        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3 sm:gap-4">
          {stats.map((stat, i) => (
            <motion.div key={stat.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="liquid-glass-card p-3.5 sm:p-4 rounded-[14px] sm:rounded-xl ios-press">
              <div className="flex items-center justify-between mb-2.5 sm:mb-3">
                <div className={`w-8 h-8 rounded-[10px] ${colorMap[stat.color]} flex items-center justify-center`}><stat.icon className="w-4 h-4" /></div>
                <MetricTooltip text={stat.tip} color={stat.color as any} />
              </div>
              <div className="text-lg sm:text-xl text-white" style={{ fontWeight: 700 }}><CountUp value={stat.value} /></div>
              <div className="text-[11px] sm:text-xs text-zinc-500 mt-0.5 truncate">{stat.label}</div>
              <div className="text-[11px] sm:text-xs text-emerald-400 mt-1 flex items-center gap-0.5"><ArrowUpRight className="w-3 h-3" />{stat.change}</div>
            </motion.div>
          ))}
        </div>
      )}

      {/* ─── Smart "Next Step" Banner (before launch) ─── */}
      {!progress.launched && (() => {
        const packageDone = (() => { try { return !!localStorage.getItem("launchapp_package_generated"); } catch { return false; } })();
        const nextStep = !progress.projectCreated
          ? { n: 1, title: t("next.clarifyTitle"), desc: t("next.clarifyDesc"), why: t("next.clarifyWhy"), cta: t("next.clarifyCta"), path: "/dashboard/new-project", icon: Sparkles, color: "purple", gradient: "from-purple-500/15 to-violet-500/15", border: "border-purple-500/20" }
          : !packageDone
          ? { n: 2, title: t("next.packageTitle"), desc: t("next.packageDesc"), why: t("next.packageWhy"), cta: t("next.packageCta"), path: "/dashboard/package", icon: Package, color: "violet", gradient: "from-violet-500/15 to-purple-500/15", border: "border-violet-500/20" }
          : progress.channelsConnected === 0
          ? { n: 3, title: t("next.routeTitle"), desc: t("next.routeDesc"), why: t("next.routeWhy"), cta: t("next.routeCta"), path: "/dashboard/growth", icon: Compass, color: "cyan", gradient: "from-cyan-500/15 to-blue-500/15", border: "border-cyan-500/20" }
          : { n: 4, title: t("next.launchTitle"), desc: t("next.launchDesc"), why: t("next.launchWhy"), cta: t("next.launchCta"), path: "/dashboard/launch", icon: Zap, color: "emerald", gradient: "from-emerald-500/15 to-teal-500/15", border: "border-emerald-500/20" };

        const iconColorMap: Record<string, string> = { purple: "text-purple-400", violet: "text-violet-400", cyan: "text-cyan-400", emerald: "text-emerald-400" };
        const bgColorMap: Record<string, string> = { purple: "bg-purple-500/15", violet: "bg-violet-500/15", cyan: "bg-cyan-500/15", emerald: "bg-emerald-500/15" };
        const btnColorMap: Record<string, string> = { purple: "from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 shadow-purple-500/20", violet: "from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 shadow-violet-500/20", cyan: "from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 shadow-cyan-500/20", emerald: "from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 shadow-emerald-500/20" };

        return (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className={`relative overflow-hidden p-5 sm:p-6 rounded-[18px] sm:rounded-2xl border ${nextStep.border} bg-gradient-to-br ${nextStep.gradient} ${tourStep === 2 ? "z-50 ring-2 ring-purple-400/50 ring-offset-2 ring-offset-zinc-950" : ""}`}
          >
            {/* Step indicator */}
            <div className="flex items-center gap-2 mb-4">
              <span className="text-[10px] uppercase tracking-widest text-zinc-500" style={{ fontWeight: 600 }}>{t("next.label")}</span>
              <span className="text-[10px] text-zinc-600 px-2 py-0.5 rounded-full bg-white/[0.05] border border-white/[0.06]" style={{ fontWeight: 600 }}>
                {t("next.stepOf").replace("{n}", String(nextStep.n))}
              </span>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 sm:gap-5">
              {/* Icon */}
              <div className={`w-12 h-12 sm:w-14 sm:h-14 rounded-2xl ${bgColorMap[nextStep.color]} flex items-center justify-center shrink-0`}>
                <nextStep.icon className={`w-6 h-6 ${iconColorMap[nextStep.color]}`} />
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <h3 className="text-white mb-1.5" style={{ fontWeight: 600 }}>{nextStep.title}</h3>
                <p className="text-sm text-zinc-400 leading-relaxed mb-2">{nextStep.desc}</p>
                <p className="text-xs text-zinc-500 leading-relaxed mb-4 flex items-start gap-1.5">
                  <Lightbulb className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-500/60" />
                  {nextStep.why}
                </p>
                <button
                  onClick={() => navigate(nextStep.path)}
                  className={`ios-press inline-flex items-center gap-2 bg-gradient-to-r ${btnColorMap[nextStep.color]} text-white px-5 py-2.5 rounded-xl text-sm transition-all shadow-lg active:scale-95`}
                >
                  <nextStep.icon className="w-4 h-4" />
                  {nextStep.cta}
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Completion dots */}
            <div className="flex items-center gap-1.5 mt-5">
              {[1, 2, 3, 4, 5].map((s) => (
                <div key={s} className={`h-1 rounded-full transition-all ${s < nextStep.n ? "w-6 bg-emerald-500/50" : s === nextStep.n ? "w-8 bg-purple-500/60" : "w-4 bg-white/[0.06]"}`} />
              ))}
            </div>

            {/* Tour tooltip for stats area */}
            <AnimatePresence>
              {tourStep === 2 && (
                <TourTooltip step={2} total={3} title={tourSteps[2].title} desc={tourSteps[2].desc} onNext={nextTourStep} onSkip={closeTour} skipLabel={t("tour.skip")} nextLabel={t("tour.next")} doneLabel={t("tour.done")} />
              )}
            </AnimatePresence>
          </motion.div>
        );
      })()}

      {/* ─── Charts (after launch) ─── */}
      {progress.launched && trafficData.length > 0 && (
        <div className="grid lg:grid-cols-3 gap-4 sm:gap-6">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="lg:col-span-2 p-4 sm:p-6 rounded-xl border border-white/5 bg-white/[0.02]">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 sm:mb-6 gap-2">
              <div><h3 className="text-white" style={{ fontWeight: 600 }}>{t("dash.trafficGrowth")}</h3><p className="text-xs text-zinc-500 mt-0.5">{t("dash.trafficGrowthSub")}</p></div>
              <div className="flex items-center gap-4 text-xs">
                <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-purple-500" /><span className="text-zinc-500">{t("dash.visitors")}</span></div>
                <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-cyan-500" /><span className="text-zinc-500">{t("dash.engagement")}</span></div>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={trafficData}>
                <defs>
                  <linearGradient id="grad1" x1="0" y1="0" x2="0" y2="1"><stop key="g1s0" offset="0%" stopColor="#8b5cf6" stopOpacity={0.3} /><stop key="g1s1" offset="100%" stopColor="#8b5cf6" stopOpacity={0} /></linearGradient>
                  <linearGradient id="grad2" x1="0" y1="0" x2="0" y2="1"><stop key="g2s0" offset="0%" stopColor="#06b6d4" stopOpacity={0.3} /><stop key="g2s1" offset="100%" stopColor="#06b6d4" stopOpacity={0} /></linearGradient>
                </defs>
                <CartesianGrid key="cg" stroke="rgba(255,255,255,0.03)" strokeDasharray="3 3" />
                <XAxis key="xa" dataKey="day" axisLine={false} tickLine={false} tick={{ fill: "#52525b", fontSize: 12 }} />
                <YAxis key="ya" axisLine={false} tickLine={false} tick={{ fill: "#52525b", fontSize: 12 }} />
                <Tooltip key="tt" contentStyle={{ background: "#18181b", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", fontSize: "12px" }} />
                <Area key="visitors" type="monotone" dataKey="visitors" stroke="#8b5cf6" fill="url(#grad1)" strokeWidth={2} />
                <Area key="engagement" type="monotone" dataKey="engagement" stroke="#06b6d4" fill="url(#grad2)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="p-4 sm:p-6 rounded-xl border border-white/5 bg-white/[0.02]">
            <h3 className="text-white mb-1" style={{ fontWeight: 600 }}>{t("dash.platformReach")}</h3>
            <p className="text-xs text-zinc-500 mb-4 sm:mb-6">{t("dash.platformReachSub")}</p>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={platformData} layout="vertical">
                <CartesianGrid key="bcg" stroke="rgba(255,255,255,0.03)" horizontal={false} />
                <XAxis key="bxa" type="number" axisLine={false} tickLine={false} tick={{ fill: "#52525b", fontSize: 12 }} />
                <YAxis key="bya" type="category" dataKey="platform" axisLine={false} tickLine={false} tick={{ fill: "#a1a1aa", fontSize: 12 }} width={60} />
                <Tooltip key="btt" contentStyle={{ background: "#18181b", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", fontSize: "12px" }} />
                <Bar key="reach" dataKey="reach" fill="#8b5cf6" radius={[0, 4, 4, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        </div>
      )}

      {/* ─── How it works — Pipeline explained (before launch, after checklist) ─── */}
      {!progress.launched && !progress.projectCreated && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="p-5 sm:p-6 rounded-[18px] sm:rounded-2xl border border-white/5 bg-white/[0.02]">
          <div className="flex items-center gap-2 mb-4">
            <Compass className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-white" style={{ fontWeight: 600 }}>{t("how.title")}</span>
          </div>
          <WhyBlock label={t("why.howItWorksLabel")} color="purple" variant="inline">
            {t("why.howItWorks")}
          </WhyBlock>
          <div className="grid sm:grid-cols-5 gap-3 mt-4">
            {[
              { icon: Sparkles, label: t("pipeline.clarify"), desc: t("pipeline.clarifyWhy"), color: "purple" },
              { icon: Package, label: t("pipeline.package"), desc: t("pipeline.packageWhy"), color: "violet" },
              { icon: Compass, label: t("pipeline.route"), desc: t("pipeline.routeWhy"), color: "cyan" },
              { icon: Zap, label: t("pipeline.launch"), desc: t("pipeline.launchWhy"), color: "emerald" },
              { icon: TrendingUp, label: t("pipeline.improve"), desc: t("pipeline.improveWhy"), color: "amber" },
            ].map((s, i) => {
              const iconColors: Record<string, string> = { purple: "text-purple-400 bg-purple-500/10", violet: "text-violet-400 bg-violet-500/10", cyan: "text-cyan-400 bg-cyan-500/10", emerald: "text-emerald-400 bg-emerald-500/10", amber: "text-amber-400 bg-amber-500/10" };
              return (
                <div key={i} className="flex sm:flex-col items-start sm:items-center gap-3 sm:gap-2 p-3 sm:p-3 rounded-xl border border-white/[0.04] bg-white/[0.01] sm:text-center">
                  <div className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center shrink-0 ${iconColors[s.color]}`}>
                    <s.icon className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs text-white" style={{ fontWeight: 600 }}>{s.label}</div>
                    <div className="text-[11px] text-zinc-500 mt-0.5 leading-relaxed">{s.desc}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>
      )}

      {/* ─── Activity + Project (after launch) ─── */}
      {progress.launched && (
        <div className="grid lg:grid-cols-2 gap-4 sm:gap-6">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="p-4 sm:p-6 rounded-xl border border-white/5 bg-white/[0.02]">
            <h3 className="text-white mb-4" style={{ fontWeight: 600 }}>{t("dash.recentActivity")}</h3>
            {activities.length > 0 ? (
              <div className="space-y-3">
                {activities.map((a, i) => (
                  <div key={i} className="flex items-start gap-3 p-3 rounded-lg hover:bg-white/[0.02] transition-colors">
                    <div className="w-2 h-2 rounded-full bg-purple-500 mt-1.5 shrink-0" />
                    <div className="flex-1 min-w-0"><p className="text-sm text-zinc-300">{a.text}</p><p className="text-xs text-zinc-600 mt-0.5">{a.time}</p></div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <Activity className="w-8 h-8 text-zinc-700 mb-2" />
                <p className="text-xs text-zinc-600">{t("dash.noActivity")}</p>
              </div>
            )}
            {/* Distribution overview link */}
            <button
              onClick={() => navigate("/dashboard/distribution-live")}
              className="mt-4 w-full flex items-center gap-3 p-3 rounded-xl border border-cyan-500/15 bg-cyan-500/[0.04] hover:bg-cyan-500/[0.08] hover:border-cyan-500/25 transition-all group"
            >
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-cyan-500/15 to-purple-500/15 flex items-center justify-center shrink-0">
                <Radio className="w-4 h-4 text-cyan-400" />
              </div>
              <div className="flex-1 min-w-0 text-left">
                <div className="text-sm text-white" style={{ fontWeight: 500 }}>{t("sidebar.distribution")}</div>
                <div className="text-[11px] text-zinc-500">{t("dash.distributionDesc")}</div>
              </div>
              <ExternalLink className="w-3.5 h-3.5 text-zinc-600 group-hover:text-cyan-400 transition-colors shrink-0" />
            </button>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="p-4 sm:p-6 rounded-xl border border-white/5 bg-white/[0.02]">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white" style={{ fontWeight: 600 }}>{t("dash.activeProjectsList")}</h3>
              <button onClick={() => navigate("/dashboard/new-project")} className="text-xs text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-1">
                {t("dash.new")} <ArrowRight className="w-3 h-3" />
              </button>
            </div>
            <div className="space-y-3">
              <div className="p-4 rounded-xl border border-purple-500/15 bg-purple-500/[0.03] hover:border-purple-500/25 transition-all cursor-pointer" onClick={() => navigate("/dashboard/tracker")}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500/20 to-violet-500/20 flex items-center justify-center"><Activity className="w-4 h-4 text-purple-400" /></div>
                    <div><div className="text-sm text-white" style={{ fontWeight: 500 }}>{progress.projectName}</div><div className="text-xs text-zinc-600">{progress.projectCategory}</div></div>
                  </div>
                  <span className="text-xs text-emerald-400 px-2 py-0.5 rounded-full bg-emerald-500/10">{t("dash.distributing")}</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-white/5 overflow-hidden">
                  <motion.div initial={{ width: 0 }} animate={{ width: `${Math.min((progress.launchDay / 7) * 100, 100)}%` }} transition={{ duration: 1, ease: "easeOut" }} className="h-full rounded-full bg-gradient-to-r from-purple-500 to-violet-500" />
                </div>
                <div className="text-xs text-zinc-600 mt-1.5 text-right">{t("dash.dayOf").replace("{n}", String(progress.launchDay)).replace("{total}", "7")}</div>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* ─── Founder level (after launch) ─── */}
      {progress.launched && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }} className="p-4 sm:p-6 rounded-xl border border-white/5 bg-gradient-to-r from-purple-500/5 to-cyan-500/5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Crown className="w-4 h-4 text-purple-400" />
                <span className="text-sm text-purple-400" style={{ fontWeight: 600 }}>{t("dash.founderLevel")}</span>
                <span className="text-xs text-zinc-600">{t("dash.level")} {Math.min(progress.launchDay, 3)}</span>
              </div>
              <p className="text-xs text-zinc-500">{Math.round(progress.launchDay * 350)} / 5,000 {t("dash.pointsToNext")}</p>
            </div>
            <div className="flex-1 max-w-md">
              <div className="w-full h-2 rounded-full bg-white/5 overflow-hidden">
                <motion.div initial={{ width: 0 }} animate={{ width: `${Math.min((progress.launchDay * 350) / 5000 * 100, 100)}%` }} transition={{ duration: 1 }} className="h-full rounded-full bg-gradient-to-r from-purple-500 to-cyan-500" />
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </div>
    </DndProvider>
  );
}