import { useEffect } from "react";

export function useDocumentTitle(title: string) {
  useEffect(() => {
    const prev = document.title;
    document.title = title ? `${title} | Launch OS` : "Launch OS";
    return () => {
      document.title = prev;
    };
  }, [title]);
}