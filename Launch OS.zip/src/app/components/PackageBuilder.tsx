import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Package, Sparkles, Copy, Check, RefreshCw,
  FileText, MessageSquare, HelpCircle, User,
  Twitter, Linkedin, Send, Mail, Rocket,
  ChevronRight, ChevronDown, Zap, Globe,
  Coins,
} from "lucide-react";
import { useNavigate } from "react-router";
import { useI18n } from "./i18n";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { loadProgress } from "./user-progress";
import { usePullToRefresh } from "./usePullToRefresh";
import { PullToRefreshIndicator } from "./PullToRefreshIndicator";
import { toast } from "sonner";
import { WhyBlock } from "./WhyBlock";
import { VideoTutorial } from "./VideoTutorial";
import { copyToClipboard } from "./clipboard";

/* ─── Mock AI-generated content ─── */
const MOCK_CONTENT: Record<string, { en: string; ru: string }> = {
  oneLiner: {
    en: "AI Task Manager — the smart way to organize work for small teams that hate complexity.",
    ru: "AI Task Manager — умный способ организовать работу для небольших команд, которые не любят сложности.",
  },
  elevatorPitch: {
    en: "Small teams waste 5+ hours a week managing tasks across scattered tools. AI Task Manager uses AI to auto-prioritize, auto-assign, and auto-schedule tasks — so your team focuses on building, not organizing. One dashboard. Zero overhead. Built for teams of 2–15.",
    ru: "Маленькие команды тратят 5+ часов в неделю, жонглируя задачами между разными инструментами. AI Task Manager использует AI для авто-приоритизации, авто-назначения и авто-планирования задач — чтобы ваша команда строила, а не организовывалась. Один дашборд. Ноль overhead. Для команд от 2 до 15 человек.",
  },
  landingCopy: {
    en: "Hero: Stop managing tasks. Start shipping.\nSubline: AI Task Manager auto-organizes your team's work so you can focus on what matters — building great products.\n\nProblem: Your team juggles Trello, Slack, Notion, and spreadsheets. Tasks fall through cracks. Nobody knows what's priority.\n\nSolution: One AI-powered dashboard that reads your tasks, understands context, and auto-organizes everything. Daily priorities appear in your inbox every morning.\n\nHow it works:\n1. Connect your tools (Slack, GitHub, email)\n2. AI scans and categorizes all tasks\n3. Get a prioritized daily plan automatically\n\nSocial proof: 500+ teams already ship faster with AI Task Manager.\n\nCTA: Start free — no credit card needed.",
    ru: "Заголовок: Хватит управлять задачами. Начните отправлять продукт.\nПодзаголовок: AI Task Manager авто-организует работу вашей команды, чтобы вы могли сфокусироваться на главном — создании отличных продуктов.\n\nПроблема: Ваша команда жонглирует Trello, Slack, Notion и таблицами. Задачи теряются. Никто не знает приоритеты.\n\nРешение: Один AI-дашборд, который читает задачи, понимает контекст и авто-организует всё. Дневные приоритеты приходят в inbox каждое утро.\n\nКак это работает:\n1. Подключите инструменты (Slack, GitHub, email)\n2. AI сканирует и категоризирует задачи\n3. Получите приоритизированный план на день автоматически\n\nСоц. доказательство: 500+ команд уже быстрее отправляют продукт с AI Task Manager.\n\nCTA: Начните бесплатно — карта не нужна.",
  },
  offer: {
    en: "Free: Up to 5 team members, 100 tasks/month, basic AI prioritization.\nPro ($12/user/mo): Unlimited tasks, advanced AI, integrations, daily digest emails.\nTeam ($29/user/mo): Everything in Pro + custom workflows, analytics, priority support.\n\nAll plans include 14-day free trial. No credit card required. Cancel anytime.",
    ru: "Бесплатно: До 5 участников, 100 задач/мес, базовая AI-приоритизация.\nPro ($12/юзер/мес): Безлимит задач, продвинутый AI, интеграции, дайджест по email.\nTeam ($29/юзер/мес): Всё из Pro + кастомные воркфлоу, аналитика, приоритетная поддержка.\n\nВсе планы включают 14-дневный триал. Карта не нужна. Отмена в любой момент.",
  },
  faq: {
    en: "Q: How is this different from Asana/Trello?\nA: Those tools require manual organization. AI Task Manager auto-prioritizes and auto-assigns based on context.\n\nQ: How does the AI work?\nA: We analyze task descriptions, deadlines, team workload, and project dependencies to generate daily priority lists.\n\nQ: Can I integrate with existing tools?\nA: Yes — Slack, GitHub, Linear, Notion, Gmail, and 20+ other tools.\n\nQ: Is my data secure?\nA: SOC2 compliant, end-to-end encryption, data never leaves your region.\n\nQ: What if the AI gets it wrong?\nA: You can always override. The AI learns from your corrections and gets smarter over time.",
    ru: "В: Чем это отличается от Asana/Trello?\nО: Те инструменты требуют ручной организации. AI Task Manager авто-приоритизирует и авто-назначает на основе контекста.\n\nВ: Как работает AI?\nО: Мы анализируем описания задач, дедлайны, загрузку команды и зависимости проектов для генерации дневных приоритетов.\n\nВ: Можно интегрировать с существующими инструментами?\nО: Да — Slack, GitHub, Linear, Notion, Gmail и 20+ других.\n\nВ: Мои данные в безопасности?\nО: SOC2, end-to-end шифрование, данные не покидают ваш регион.\n\nВ: Что если AI ошибётся?\nО: Вы всегда можете скорректировать. AI учится на ваших поправках.",
  },
  founderBio: {
    en: "Building AI Task Manager — helping small teams ship faster without the chaos. Previously engineering at [Company]. Passionate about developer tools and productivity. Based in [City]. Let's connect: @handle",
    ru: "Строю AI Task Manager — помогаю маленьким командам быстрее отправлять продукт без хаоса. Ранее инженер в [Company]. Фанат dev-инструментов и продуктивности. @handle",
  },
  productHunt: {
    en: "AI Task Manager — Stop managing tasks. Start shipping.\n\nHey Product Hunt! We built AI Task Manager because we were tired of spending more time organizing work than actually doing it.\n\nWhat it does:\n- Auto-prioritizes tasks using AI\n- Generates daily focus lists for each team member\n- Connects to your existing tools (Slack, GitHub, Notion)\n\nWe're live and offering 3 months free for early supporters!\n\nWould love your feedback — what's the biggest task management pain point for your team?",
    ru: "AI Task Manager — Хватит управлять задачами. Начните отправлять.\n\nПривет, Product Hunt! Мы создали AI Task Manager, потому что устали тратить больше времени на организацию работы, чем на саму работу.\n\nЧто делает:\n- Авто-приоритизирует задачи с помощью AI\n- Генерирует дневные фокус-листы для каждого участника\n- Подключается к вашим инструментам (Slack, GitHub, Notion)\n\nМы запустились и дарим 3 месяца бесплатно ранним саппортерам!\n\nБудем рады фидбеку — какая самая большая боль в управлении задачами у вашей команды?",
  },
  twitter: {
    en: "We just launched AI Task Manager\n\nSmall teams waste 5+ hrs/week managing tasks.\n\nWe built an AI that:\n- Auto-prioritizes your backlog\n- Creates daily focus lists\n- Connects Slack, GitHub, Notion\n\nResult: ship faster, organize less.\n\nTry free -> [link]\n\nHere's what we learned building it...",
    ru: "Мы только что запустили AI Task Manager\n\nМаленькие команды тратят 5+ часов/нед на управление задачами.\n\nМы сделали AI, который:\n- Авто-приоритизирует бэклог\n- Создаёт дневные фокус-листы\n- Подключает Slack, GitHub, Notion\n\nРезультат: отправляйте быстрее, организовывайте меньше.\n\nПопробуйте бесплатно -> [ссылка]",
  },
  linkedin: {
    en: "I spent 6 months building something I wish existed when I was leading a small dev team.\n\nThe problem: We had tasks in Trello, messages in Slack, docs in Notion, and code in GitHub. Every morning started with 30 min figuring out what to work on.\n\nSo I built AI Task Manager — an AI-powered dashboard that connects all your tools and generates a prioritized daily plan for each team member.\n\nEarly results:\n• Teams report 40% less time on task management\n• 90% say daily priorities are more accurate than their manual lists\n\nWe're live today. If you lead a small team (2-15 people), I'd love for you to try it.\n\nLink in comments below.",
    ru: "Я потратил 6 месяцев на создание того, что хотел бы иметь, когда руководил маленькой dev-командой.\n\nПроблема: Задачи в Trello, сообщения в Slack, документы в Notion, код в GitHub. Каждое утро начиналось с 30 минут разбора — что делать.\n\nПоэтому я создал AI Task Manager — AI-дашборд, который подключает все инструменты и генерирует приоритизированный дневной план для каждого участника.\n\nПервые результаты:\n- Команды тратят на 40% меньше времени на менеджмент\n- 90% говорят, что дневные приоритеты точнее их ручных списков\n\nМы запустились сегодня. Если вы руководите небольшой командой (2-15 человек), буду рад вашему фидбеку.\n\nСсылка в комментариях.",
  },
  telegram: {
    en: "Launched: AI Task Manager\n\nTired of juggling tasks across 5 tools? We built an AI that auto-prioritizes your team's work.\n\n+ Connects Slack, GitHub, Notion\n+ Daily AI-generated focus lists\n+ Free for up to 5 people\n\nTry it -> [link]",
    ru: "Запустили: AI Task Manager\n\nУстали жонглировать задачами в 5 инструментах? Мы сделали AI, который авто-приоритизирует работу команды.\n\n+ Подключает Slack, GitHub, Notion\n+ Дневные AI фокус-листы\n+ Бесплатно до 5 человек\n\nПопробуйте -> [ссылка]",
  },
  emailOutreach: {
    en: "Subject: Quick question about [Company] task management\n\nHi [Name],\n\nI noticed your team at [Company] is growing fast — congrats!\n\nQuick question: how does your team handle task prioritization as you scale?\n\nWe built AI Task Manager specifically for teams of 2-15 that are outgrowing simple todo lists but don't need enterprise project management.\n\nIt auto-prioritizes tasks and generates daily focus lists using AI — teams report saving 5+ hrs/week on task management.\n\nWould you be open to a 15-min demo? No commitment.\n\nBest,\n[Your Name]",
    ru: "Тема: Быстрый вопрос об управлении задачами в [Company]\n\nПривет, [Name]!\n\nЗаметил, что ваша команда в [Company] быстро растёт — поздравляю!\n\nБыстрый вопрос: как ваша команда справляется с приоритизацией задач по мере роста?\n\nМы создали AI Task Manager специально для команд из 2-15 человек, которые переросли простые todo-листы, но которым не нужен enterprise project management.\n\nОн авто-приоритизирует задачи и генерирует дневные фокус-листы с помощью AI — команды экономят 5+ часов/неделю.\n\nГотовы ли вы на 15-минутное демо? Без обязательств.\n\nС уважением,\n[Ваше имя]",
  },
};

type ContentKey = keyof typeof MOCK_CONTENT;

interface ContentSection {
  key: ContentKey;
  label: string;
  icon: typeof Package;
  color: string;
}

export function PackageBuilder() {
  const { t, lang } = useI18n();
  const navigate = useNavigate();
  useDocumentTitle(t("sidebar.package"));
  const progress = loadProgress();

  // ─── Guided tour state ───
  const [tourStep, setTourStep] = useState<number>(() => {
    try {
      if (localStorage.getItem("launchapp_pkg_tour_done")) return -1;
      return 0;
    } catch { return -1; }
  });
  const closeTour = () => {
    setTourStep(-1);
    try { localStorage.setItem("launchapp_pkg_tour_done", "1"); } catch {}
  };
  const nextTour = () => {
    if (tourStep < 4) setTourStep(tourStep + 1);
    else closeTour();
  };

  const tourStepData = [
    { title: t("pkgTour.step1Title"), desc: t("pkgTour.step1Desc") },
    { title: t("pkgTour.step2Title"), desc: t("pkgTour.step2Desc") },
    { title: t("pkgTour.step3Title"), desc: t("pkgTour.step3Desc") },
    { title: t("pkgTour.step4Title"), desc: t("pkgTour.step4Desc") },
    { title: t("pkgTour.step5Title"), desc: t("pkgTour.step5Desc") },
  ];

  // Load wizard-generated keys from localStorage on mount
  const [generated, setGenerated] = useState<Set<ContentKey>>(() => {
    try {
      const saved = localStorage.getItem("launchapp_package_generated");
      if (saved) {
        const keys = JSON.parse(saved) as string[];
        return new Set(keys.filter((k) => k in MOCK_CONTENT) as ContentKey[]);
      }
    } catch {}
    return new Set();
  });
  const [generating, setGenerating] = useState<ContentKey | null>(null);
  const [copiedKey, setCopiedKey] = useState<ContentKey | null>(null);
  const [expanded, setExpanded] = useState<ContentKey | null>(null);
  const [loading, setLoading] = useState(true);

  // ─── Pull to refresh ───
  const { pullY, isRefreshing, handlers: pullHandlers } = usePullToRefresh(
    () => new Promise<void>((resolve) => setTimeout(resolve, 1200))
  );

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(timer);
  }, []);

  const sections: ContentSection[] = [
    { key: "oneLiner", label: t("pkg.oneLiner"), icon: Zap, color: "purple" },
    { key: "elevatorPitch", label: t("pkg.elevatorPitch"), icon: Rocket, color: "violet" },
    { key: "landingCopy", label: t("pkg.landingCopy"), icon: FileText, color: "cyan" },
    { key: "offer", label: t("pkg.offer"), icon: Package, color: "emerald" },
    { key: "faq", label: t("pkg.faq"), icon: HelpCircle, color: "amber" },
    { key: "founderBio", label: t("pkg.founderBio"), icon: User, color: "pink" },
  ];

  const platformSections: ContentSection[] = [
    { key: "productHunt", label: t("pkg.productHunt"), icon: Globe, color: "orange" },
    { key: "twitter", label: t("pkg.twitter"), icon: Twitter, color: "sky" },
    { key: "linkedin", label: t("pkg.linkedin"), icon: Linkedin, color: "blue" },
    { key: "telegram", label: t("pkg.telegram"), icon: Send, color: "cyan" },
    { key: "emailOutreach", label: t("pkg.email"), icon: Mail, color: "rose" },
  ];

  // Persist generated keys to localStorage so wizard and builder stay in sync
  const persistGenerated = useCallback((newSet: Set<ContentKey>) => {
    try {
      localStorage.setItem("launchapp_package_generated", JSON.stringify([...newSet]));
    } catch {}
  }, []);

  // Notify Layout sidebar/mobile bottom sheet (deferred to avoid setState-during-render)
  const notifyProgress = useCallback(() => {
    queueMicrotask(() => {
      document.dispatchEvent(new CustomEvent("launchapp:progress", { detail: {} }));
    });
  }, []);

  const handleGenerate = useCallback((key: ContentKey) => {
    setGenerating(key);
    setTimeout(() => {
      setGenerated((prev) => {
        const next = new Set([...prev, key]);
        persistGenerated(next);
        return next;
      });
      setGenerating(null);
      setExpanded(key);
      notifyProgress();
    }, 1200 + Math.random() * 800);
  }, [persistGenerated, notifyProgress]);

  const handleGenerateAll = useCallback(() => {
    const allKeys = [...sections, ...platformSections].map((s) => s.key);
    let delay = 0;
    allKeys.forEach((key) => {
      if (!generated.has(key)) {
        setTimeout(() => {
          setGenerating(key);
          setTimeout(() => {
            setGenerated((prev) => {
              const next = new Set([...prev, key]);
              persistGenerated(next);
              return next;
            });
            setGenerating(null);
            notifyProgress();
          }, 800);
        }, delay);
        delay += 400;
      }
    });
  }, [generated, sections, platformSections, persistGenerated, notifyProgress]);

  const handleCopy = useCallback((key: ContentKey) => {
    const content = MOCK_CONTENT[key]?.[lang] || MOCK_CONTENT[key]?.en || "";
    copyToClipboard(content);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  }, [lang]);

  const handleRegenerate = useCallback((key: ContentKey) => {
    setGenerated((prev) => {
      const next = new Set(prev);
      next.delete(key);
      return next;
    });
    handleGenerate(key);
  }, [handleGenerate]);

  // Export all generated content to clipboard
  const handleExportAll = useCallback(() => {
    const allContent = [...sections, ...platformSections]
      .filter((s) => generated.has(s.key))
      .map((s) => {
        const content = MOCK_CONTENT[s.key]?.[lang] || MOCK_CONTENT[s.key]?.en || "";
        return `═══ ${s.label} ═══\n\n${content}`;
      })
      .join("\n\n\n");
    if (allContent) {
      copyToClipboard(allContent);
      toast.success(t("pkg.copied"));
    }
  }, [generated, sections, platformSections, lang, t]);

  const colorMap: Record<string, { bg: string; text: string; border: string }> = {
    purple: { bg: "bg-purple-500/10", text: "text-purple-400", border: "border-purple-500/20" },
    violet: { bg: "bg-violet-500/10", text: "text-violet-400", border: "border-violet-500/20" },
    cyan: { bg: "bg-cyan-500/10", text: "text-cyan-400", border: "border-cyan-500/20" },
    emerald: { bg: "bg-emerald-500/10", text: "text-emerald-400", border: "border-emerald-500/20" },
    amber: { bg: "bg-amber-500/10", text: "text-amber-400", border: "border-amber-500/20" },
    pink: { bg: "bg-pink-500/10", text: "text-pink-400", border: "border-pink-500/20" },
    orange: { bg: "bg-orange-500/10", text: "text-orange-400", border: "border-orange-500/20" },
    sky: { bg: "bg-sky-500/10", text: "text-sky-400", border: "border-sky-500/20" },
    blue: { bg: "bg-blue-500/10", text: "text-blue-400", border: "border-blue-500/20" },
    rose: { bg: "bg-rose-500/10", text: "text-rose-400", border: "border-rose-500/20" },
  };

  // If no project created, show prompt to go to Clarify
  if (!progress.projectCreated && !loading) {
    return (
      <div className="p-4 sm:p-6 max-w-4xl mx-auto">
        <LargeTitle title={t("pkg.title")} subtitle={t("pkg.subtitle")} />
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-8 p-8 rounded-2xl border border-dashed border-white/5 bg-white/[0.01] flex flex-col items-center justify-center text-center"
        >
          <div className="w-16 h-16 rounded-2xl bg-purple-500/10 border border-purple-500/10 flex items-center justify-center mb-4">
            <Package className="w-7 h-7 text-purple-500/40" />
          </div>
          <h3 className="text-zinc-400 text-sm" style={{ fontWeight: 600 }}>{t("pkg.noProject")}</h3>
          <button
            onClick={() => navigate("/dashboard/new-project")}
            className="mt-4 inline-flex items-center gap-2 bg-purple-600 hover:bg-purple-500 text-white px-5 py-2.5 rounded-xl text-sm transition-all"
          >
            <Sparkles className="w-4 h-4" />{t("pkg.goToClarify")}
          </button>
        </motion.div>
      </div>
    );
  }

  const allKeys = [...sections, ...platformSections].map((s) => s.key);
  const generatedCount = allKeys.filter((k) => generated.has(k)).length;
  const allGenerated = generatedCount === allKeys.length;

  const renderSection = (section: ContentSection, idx: number) => {
    const isGenerated = generated.has(section.key);
    const isGenerating = generating === section.key;
    const isExpanded = expanded === section.key;
    const c = colorMap[section.color] || colorMap.purple;
    const content = MOCK_CONTENT[section.key]?.[lang] || MOCK_CONTENT[section.key]?.en || "";

    return (
      <motion.div
        key={section.key}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: idx * 0.04 }}
        className={`rounded-xl border transition-all ${isGenerated ? c.border : "border-white/5"} bg-white/[0.02]`}
      >
        <div className="flex items-center gap-3 p-4">
          <div className={`w-9 h-9 rounded-xl ${c.bg} flex items-center justify-center shrink-0`}>
            <section.icon className={`w-4 h-4 ${c.text}`} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm text-white" style={{ fontWeight: 500 }}>{section.label}</div>
            {isGenerated && (
              <div className="text-[11px] text-emerald-400 mt-0.5 flex items-center gap-1">
                <Check className="w-3 h-3" />{t("pipeline.completed")}
              </div>
            )}
          </div>
          <div className="flex items-center gap-1.5">
            {isGenerated && (
              <>
                <button
                  onClick={() => handleCopy(section.key)}
                  className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 transition-all"
                  title={t("pkg.copy")}
                >
                  {copiedKey === section.key ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5 text-zinc-500" />
                  )}
                </button>
                <button
                  onClick={() => handleRegenerate(section.key)}
                  className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 transition-all"
                  title={t("pkg.regenerate")}
                >
                  <RefreshCw className="w-3.5 h-3.5 text-zinc-500" />
                </button>
                <button
                  onClick={() => setExpanded(isExpanded ? null : section.key)}
                  className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 transition-all"
                >
                  {isExpanded ? (
                    <ChevronDown className={`w-4 h-4 ${c.text}`} />
                  ) : (
                    <ChevronRight className="w-4 h-4 text-zinc-500" />
                  )}
                </button>
              </>
            )}
            {!isGenerated && !isGenerating && (
              <button
                onClick={() => handleGenerate(section.key)}
                className={`inline-flex items-center gap-1.5 text-xs px-3 py-2 rounded-lg ${c.bg} ${c.text} hover:opacity-80 transition-all`}
              >
                <Sparkles className="w-3 h-3" />{t("pkg.generate")}
              </button>
            )}
            {isGenerating && (
              <div className="flex items-center gap-1.5 text-xs text-zinc-500 px-3 py-2">
                <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                  <Sparkles className="w-3 h-3 text-purple-400" />
                </motion.div>
                {t("pkg.generating")}
              </div>
            )}
          </div>
        </div>

        <AnimatePresence>
          {isExpanded && isGenerated && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="overflow-hidden"
            >
              <div className="px-4 pb-4 pt-0">
                <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5">
                  <pre className="text-xs text-zinc-300 whitespace-pre-wrap leading-relaxed" style={{ fontFamily: "inherit" }}>
                    {content}
                  </pre>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    );
  };

  if (loading) {
    return (
      <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-6 animate-pulse">
        <div><div className="h-7 w-40 rounded-lg bg-white/[0.06]" /><div className="h-4 w-64 rounded-lg bg-white/[0.04] mt-2" /></div>
        <div className="space-y-3">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="p-4 rounded-xl border border-white/[0.03] bg-white/[0.01] flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-white/[0.05]" />
              <div className="flex-1"><div className="h-4 w-32 rounded bg-white/[0.06]" /></div>
              <div className="h-8 w-28 rounded-lg bg-white/[0.04]" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-6" {...pullHandlers}>
      <PullToRefreshIndicator pullY={pullY} isRefreshing={isRefreshing} />
      {/* ─── Guided Tour Overlay ─── */}
      <AnimatePresence>
        {tourStep >= 0 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/40 z-40" onClick={closeTour} />
        )}
      </AnimatePresence>
      <AnimatePresence>
        {tourStep >= 0 && (
          <motion.div
            key={`tour-${tourStep}`}
            initial={{ opacity: 0, y: 10, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.96 }}
            className="fixed z-[100] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90vw] max-w-sm"
          >
            <div className="p-5 rounded-2xl bg-zinc-900 border border-purple-500/30 shadow-2xl shadow-purple-500/10">
              <div className="text-xs text-purple-400 mb-2" style={{ fontWeight: 600 }}>{tourStep + 1}/5</div>
              <div className="text-white mb-1" style={{ fontWeight: 600 }}>
                {tourStepData[tourStep]?.title}
              </div>
              <p className="text-sm text-zinc-400 mb-4 leading-relaxed">
                {tourStepData[tourStep]?.desc}
              </p>
              {/* Step dots */}
              <div className="flex items-center gap-1.5 mb-4">
                {[0, 1, 2, 3, 4].map((i) => (
                  <div key={i} className={`h-1 rounded-full transition-all ${i < tourStep ? "w-5 bg-purple-500/50" : i === tourStep ? "w-7 bg-purple-500" : "w-3 bg-white/[0.08]"}`} />
                ))}
              </div>
              <div className="flex items-center justify-between">
                <button onClick={closeTour} className="text-xs text-zinc-600 hover:text-zinc-400 transition-colors">{t("pkgTour.skip")}</button>
                <button onClick={nextTour} className="text-xs text-white bg-purple-600 hover:bg-purple-500 px-4 py-2 rounded-lg transition-colors">
                  {tourStep < 4 ? t("pkgTour.next") : t("pkgTour.done")}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <LargeTitle
        title={t("pkg.title")}
        subtitle={t("pkg.subtitle")}
        badge={
          allGenerated ? (
            <span className="text-xs bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full" style={{ fontWeight: 600 }}>
              <Check className="w-3 h-3 inline mr-1" />{t("pkg.allGenerated")}
            </span>
          ) : generatedCount > 0 ? (
            <span className="text-xs bg-purple-500/10 text-purple-400 px-2 py-0.5 rounded-full" style={{ fontWeight: 600 }}>
              {generatedCount}/{allKeys.length}
            </span>
          ) : undefined
        }
        actions={
          !allGenerated ? (
            <button
              onClick={handleGenerateAll}
              disabled={!!generating}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 disabled:opacity-50 text-white px-4 py-2.5 rounded-xl text-sm transition-all"
            >
              <Sparkles className="w-4 h-4" />{t("pkg.generate")}
            </button>
          ) : (
            <button
              onClick={handleExportAll}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 disabled:opacity-50 text-white px-4 py-2.5 rounded-xl text-sm transition-all"
            >
              <Copy className="w-4 h-4" />{t("pkg.exportAll")}
            </button>
          )
        }
      />

      {/* Beginner explanation */}
      <WhyBlock label={t("why.packageLabel")} color="violet" variant="collapsible">
        {t("why.package")}
      </WhyBlock>

      {/* Video tutorial */}
      <VideoTutorial title={t("pkg.videoTitle")} duration="2 min" />

      {/* Progress bar */}
      {generatedCount > 0 && !allGenerated && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex items-center gap-3"
        >
          <div className="flex-1 h-1.5 rounded-full bg-white/[0.04] overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-purple-500 to-violet-500 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${(generatedCount / allKeys.length) * 100}%` }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
            />
          </div>
          <span className="text-[11px] text-zinc-500 shrink-0" style={{ fontWeight: 600 }}>{generatedCount}/{allKeys.length}</span>
        </motion.div>
      )}

      {/* Token cost info */}
      {generatedCount > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 5 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/[0.02] border border-white/5"
        >
          <Coins className="w-3.5 h-3.5 text-purple-400" />
          <span className="text-xs text-zinc-500">{t("pkg.tokenCost")}:</span>
          <span className="text-xs text-purple-400" style={{ fontWeight: 600 }}>{generatedCount * 15} tokens</span>
          <span className="text-xs text-zinc-600">({generatedCount} {t("pkg.tokensUsed")})</span>
        </motion.div>
      )}

      {/* Project context */}
      {progress.projectCreated && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-3 p-3 rounded-xl border border-purple-500/10 bg-purple-500/[0.03]"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-500/20 to-violet-500/20 flex items-center justify-center">
            <Rocket className="w-4 h-4 text-purple-400" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm text-white" style={{ fontWeight: 500 }}>{progress.projectName || "My Project"}</div>
            <div className="text-xs text-zinc-500">{progress.projectCategory || "Startup"}</div>
          </div>
          <button
            onClick={() => navigate("/dashboard/new-project")}
            className="text-xs text-purple-400 hover:text-purple-300 transition-colors"
          >
            {t("engine.edit")}
          </button>
        </motion.div>
      )}

      {/* Core materials */}
      <div>
        <div className="text-[11px] text-zinc-500 uppercase tracking-widest mb-3 px-1" style={{ fontWeight: 600 }}>
          {t("pkg.coreMaterials")}
        </div>
        <div className="space-y-2">
          {sections.map((s, i) => renderSection(s, i))}
        </div>
      </div>

      {/* Platform content */}
      <div>
        <div className="text-[11px] text-zinc-500 uppercase tracking-widest mb-3 px-1" style={{ fontWeight: 600 }}>
          {t("pkg.platformContent")}
        </div>
        <div className="space-y-2">
          {platformSections.map((s, i) => renderSection(s, i + sections.length))}
        </div>
      </div>

      {/* Next step prompt when all content is generated */}
      {allGenerated && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-5 rounded-2xl border border-emerald-500/20 bg-gradient-to-br from-emerald-500/10 to-teal-500/10"
        >
          <div className="flex items-start gap-4">
            <div className="w-11 h-11 rounded-xl bg-emerald-500/15 flex items-center justify-center shrink-0">
              <ChevronRight className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="flex-1">
              <h3 className="text-sm text-white" style={{ fontWeight: 600 }}>
                {t("pkg.contentReady")}
              </h3>
              <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
                {t("pkg.contentReadyDesc")}
              </p>
              <button
                onClick={() => navigate("/dashboard/growth")}
                className="mt-3 inline-flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white px-4 py-2 rounded-xl text-sm transition-all"
              >
                <Globe className="w-3.5 h-3.5" />
                {t("pkg.setupChannels")}
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}