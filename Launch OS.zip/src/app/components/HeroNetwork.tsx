import React, { useMemo, useState, useEffect, useCallback, useRef } from "react";

/**
 * HeroNetwork — ultra-subtle animated SVG background.
 * "Information Flow" concept with mouse parallax and purple→cyan dot gradient.
 */

function sr(s: number) {
  const x = Math.sin(s * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
}

/** Lerp between two [r,g,b,a] colors */
function lerpColor(
  a: [number, number, number, number],
  b: [number, number, number, number],
  t: number,
): string {
  const r = a[0] + (b[0] - a[0]) * t;
  const g = a[1] + (b[1] - a[1]) * t;
  const bl = a[2] + (b[2] - a[2]) * t;
  const al = a[3] + (b[3] - a[3]) * t;
  return `rgba(${Math.round(r)},${Math.round(g)},${Math.round(bl)},${al.toFixed(3)})`;
}

/* Purple & cyan endpoints for dot-grid gradient */
const COL_PURPLE: [number, number, number, number] = [139, 92, 246, 0.070];
const COL_CYAN: [number, number, number, number] = [6, 182, 212, 0.061];

/* ── Organic flow paths ── */
function flowPaths(count: number) {
  const paths: { d: string; delay: number }[] = [];
  for (let i = 0; i < count; i++) {
    const angle = (i / count) * Math.PI * 2 + sr(i) * 0.3;
    const reach = 38 + sr(i + 50) * 14;
    const sx = 50, sy = 50;
    const ex = 50 + Math.cos(angle) * reach;
    const ey = 50 + Math.sin(angle) * reach;
    const perp = angle + Math.PI / 2;
    const bend = (sr(i + 77) - 0.5) * 18;
    const md = reach * 0.45;
    const c1x = 50 + Math.cos(angle) * md * 0.5 + Math.cos(perp) * bend * 0.6;
    const c1y = 50 + Math.sin(angle) * md * 0.5 + Math.sin(perp) * bend * 0.6;
    const c2x = 50 + Math.cos(angle) * md + Math.cos(perp) * bend;
    const c2y = 50 + Math.sin(angle) * md + Math.sin(perp) * bend;
    paths.push({
      d: `M${sx},${sy} C${c1x.toFixed(1)},${c1y.toFixed(1)} ${c2x.toFixed(1)},${c2y.toFixed(1)} ${ex.toFixed(1)},${ey.toFixed(1)}`,
      delay: i * 1.8,
    });
  }
  return paths;
}

/* ── Dot grid with purple→cyan gradient ── */
function dotGrid(cols: number, rows: number) {
  const dots: { x: number; y: number; color: string }[] = [];
  const maxDist = 50; // approx max distance from center
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const x = 4 + (c / (cols - 1)) * 92;
      const y = 4 + (r / (rows - 1)) * 92;
      const dx = x - 50, dy = y - 50;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const t = Math.min(1, dist / maxDist); // 0 = center (purple), 1 = edge (cyan)
      // Opacity also fades slightly toward edges
      const opCenter = 0.070;
      const opEdge = 0.035;
      const op = opCenter + (opEdge - opCenter) * t;
      const col = lerpColor(
        [COL_PURPLE[0], COL_PURPLE[1], COL_PURPLE[2], op],
        [COL_CYAN[0], COL_CYAN[1], COL_CYAN[2], op * 0.85],
        t,
      );
      dots.push({ x, y, color: col });
    }
  }
  return dots;
}

export function HeroNetwork({ scrollY = 0 }: { scrollY?: number }) {
  const paths = useMemo(() => flowPaths(10), []);
  const dots = useMemo(() => dotGrid(18, 14), []);
  const rings = [10, 18, 27, 37, 47];

  /* ── Mouse parallax state ── */
  const containerRef = useRef<HTMLDivElement>(null);
  const [mouse, setMouse] = useState({ x: 0, y: 0 }); // -1..1
  const rafRef = useRef(0);
  const targetRef = useRef({ x: 0, y: 0 });
  const currentRef = useRef({ x: 0, y: 0 });

  const handleMouseMove = useCallback((e: MouseEvent) => {
    const el = containerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    // Only respond if mouse is over the hero area
    if (
      e.clientX < rect.left || e.clientX > rect.right ||
      e.clientY < rect.top || e.clientY > rect.bottom
    ) {
      targetRef.current = { x: 0, y: 0 };
      return;
    }
    targetRef.current = {
      x: ((e.clientX - rect.left) / rect.width - 0.5) * 2,
      y: ((e.clientY - rect.top) / rect.height - 0.5) * 2,
    };
  }, []);

  const handleMouseLeave = useCallback(() => {
    targetRef.current = { x: 0, y: 0 };
  }, []);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    // Listen on window so pointer-events:none on container doesn't block
    window.addEventListener("mousemove", handleMouseMove, { passive: true });
    el.addEventListener("mouseleave", handleMouseLeave);

    // Smooth lerp loop
    let running = true;
    const tick = () => {
      if (!running) return;
      const lerp = 0.06;
      currentRef.current.x += (targetRef.current.x - currentRef.current.x) * lerp;
      currentRef.current.y += (targetRef.current.y - currentRef.current.y) * lerp;
      // Only update state when meaningful change occurs
      const dx = Math.abs(currentRef.current.x - mouse.x);
      const dy = Math.abs(currentRef.current.y - mouse.y);
      if (dx > 0.002 || dy > 0.002) {
        setMouse({ x: currentRef.current.x, y: currentRef.current.y });
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);

    return () => {
      running = false;
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener("mousemove", handleMouseMove);
      el.removeEventListener("mouseleave", handleMouseLeave);
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  /* Parallax offsets per layer (px) */
  const scrollPy = scrollY * 0.025;
  const p = {
    dots:  { x: mouse.x * 1.5,  y: mouse.y * 1.5 + scrollPy },
    rings: { x: mouse.x * 2.5,  y: mouse.y * 2.5 + scrollPy },
    flows: { x: mouse.x * 4,    y: mouse.y * 4 + scrollPy },
    motes: { x: mouse.x * 6,    y: mouse.y * 6 + scrollPy },
  };

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 overflow-hidden pointer-events-none"
      aria-hidden="true"
    >
      {/* Invisible hit area for mouse, clicks pass through child content */}
      <svg
        viewBox="0 0 100 100"
        preserveAspectRatio="xMidYMid slice"
        className="absolute inset-0 w-full h-full pointer-events-none"
      >
        <defs>
          <filter id="hfSoft" x="-200%" y="-200%" width="500%" height="500%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="0.3" />
          </filter>
          <linearGradient id="flowStroke" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="rgba(139,92,246,0.0)" />
            <stop offset="30%" stopColor="rgba(139,92,246,0.070)" />
            <stop offset="70%" stopColor="rgba(167,139,250,0.053)" />
            <stop offset="100%" stopColor="rgba(139,92,246,0.0)" />
          </linearGradient>
          <radialGradient id="particleGrad">
            <stop offset="0%" stopColor="rgba(167,139,250,0.608)" />
            <stop offset="100%" stopColor="rgba(139,92,246,0.0)" />
          </radialGradient>
        </defs>

        {/* ── Layer 1: Dot grid (purple→cyan gradient, slowest parallax) ── */}
        <g style={{ transform: `translate(${p.dots.x}px, ${p.dots.y}px)` }}>
          {dots.map((d, i) => (
            <circle
              key={`d-${i}`}
              cx={d.x} cy={d.y} r="0.15"
              fill={d.color}
              className="hf-dot"
              style={{ animationDelay: `${(d.x * 0.1 + d.y * 0.07) % 8}s` }}
            />
          ))}
        </g>

        {/* ── Layer 2: Concentric pulse rings ── */}
        <g style={{ transform: `translate(${p.rings.x}px, ${p.rings.y}px)` }}>
          {rings.map((r, i) => (
            <circle
              key={`ring-${i}`}
              cx="50" cy="50" r={r}
              fill="none"
              stroke="rgba(139,92,246,0.044)"
              strokeWidth="0.08"
              className="hf-ring"
              style={{
                transformOrigin: "50px 50px",
                animationDelay: `${i * 3}s`,
                animationDuration: `${15 + i * 2}s`,
              }}
            />
          ))}

          {/* Center hub */}
          <circle cx="50" cy="50" r="2.5"
            fill="rgba(139,92,246,0.053)"
            filter="url(#hfSoft)"
            className="hf-center"
          />
          <circle cx="50" cy="50" r="0.6"
            fill="rgba(167,139,250,0.105)"
            className="hf-center-dot"
          />

          {/* Broadcast waves */}
          {[0, 1, 2].map((i) => (
            <circle
              key={`wave-${i}`}
              cx="50" cy="50" r="3"
              fill="none"
              stroke="rgba(139,92,246,0.105)"
              strokeWidth="0.06"
              className="hf-wave"
              style={{
                transformOrigin: "50px 50px",
                animationDelay: `${i * 5}s`,
              }}
            />
          ))}
        </g>

        {/* ── Layer 3: Flow paths + data particles (stronger parallax) ── */}
        <g style={{ transform: `translate(${p.flows.x}px, ${p.flows.y}px)` }}>
          {paths.map((fp, i) => {
            const dur = 8 + sr(i + 99) * 6;
            return (
              <g key={`fl-${i}`}>
                <path
                  d={fp.d}
                  fill="none"
                  stroke="url(#flowStroke)"
                  strokeWidth="0.06"
                  strokeLinecap="round"
                />
                {/* Primary particle */}
                <circle r="0.35" fill="url(#particleGrad)" filter="url(#hfSoft)">
                  <animateMotion
                    dur={`${dur}s`}
                    begin={`${fp.delay}s`}
                    repeatCount="indefinite"
                    path={fp.d}
                  />
                  <animate
                    attributeName="opacity"
                    values="0;0.5;0.7;0.5;0"
                    dur={`${dur}s`}
                    begin={`${fp.delay}s`}
                    repeatCount="indefinite"
                  />
                  <animate
                    attributeName="r"
                    values="0.2;0.4;0.35;0.2"
                    dur={`${dur}s`}
                    begin={`${fp.delay}s`}
                    repeatCount="indefinite"
                  />
                </circle>
                {/* Secondary cyan particle on every 3rd path */}
                {i % 3 === 0 && (
                  <circle r="0.25" fill="rgba(6,182,212,0.351)" filter="url(#hfSoft)">
                    <animateMotion
                      dur={`${12 + sr(i + 200) * 5}s`}
                      begin={`${fp.delay + 4}s`}
                      repeatCount="indefinite"
                      path={fp.d}
                    />
                    <animate
                      attributeName="opacity"
                      values="0;0.3;0.5;0.3;0"
                      dur={`${12 + sr(i + 200) * 5}s`}
                      begin={`${fp.delay + 4}s`}
                      repeatCount="indefinite"
                    />
                  </circle>
                )}
              </g>
            );
          })}
        </g>

        {/* ── Layer 4: Ambient motes (most parallax) ── */}
        <g style={{ transform: `translate(${p.motes.x}px, ${p.motes.y}px)` }}>
          {Array.from({ length: 12 }).map((_, i) => {
            const x = 8 + sr(i + 800) * 84;
            const y = 8 + sr(i + 900) * 84;
            return (
              <circle
                key={`m-${i}`}
                cx={x} cy={y}
                r="0.18"
                fill={i % 3 === 0 ? "rgba(6,182,212,0.105)" : "rgba(139,92,246,0.089)"}
                className="hf-mote"
                style={{
                  animationDelay: `${sr(i + 700) * 12}s`,
                  animationDuration: `${18 + sr(i + 750) * 14}s`,
                }}
              />
            );
          })}
        </g>
      </svg>

      {/* ── Edge fades ── */}
      <div className="absolute top-0 left-0 right-0 h-[20%] pointer-events-none"
        style={{ background: "linear-gradient(to bottom, var(--app-bg, #09090b), transparent)" }} />
      <div className="absolute bottom-0 left-0 right-0 h-[25%] pointer-events-none"
        style={{ background: "linear-gradient(to top, var(--app-bg, #09090b), transparent)" }} />
      <div className="absolute top-0 bottom-0 left-0 w-[12%] pointer-events-none"
        style={{ background: "linear-gradient(to right, var(--app-bg, #09090b), transparent)" }} />
      <div className="absolute top-0 bottom-0 right-0 w-[12%] pointer-events-none"
        style={{ background: "linear-gradient(to left, var(--app-bg, #09090b), transparent)" }} />

      {/* ── Keyframes ── */}
      <style>{`
        @keyframes hfDotWave {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.3; }
        }
        .hf-dot {
          animation: hfDotWave 10s ease-in-out infinite;
        }

        @keyframes hfRingPulse {
          0%, 100% { opacity: 0.6; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.03); }
        }
        .hf-ring {
          animation: hfRingPulse 15s ease-in-out infinite;
          transform-origin: 50px 50px;
        }

        @keyframes hfCenterBreathe {
          0%, 100% { opacity: 0.5; }
          50% { opacity: 0.9; }
        }
        .hf-center {
          animation: hfCenterBreathe 6s ease-in-out infinite;
        }
        .hf-center-dot {
          animation: hfCenterBreathe 4s ease-in-out 1s infinite;
        }

        @keyframes hfWave {
          0% { transform: scale(1); opacity: 0.5; }
          100% { transform: scale(14); opacity: 0; }
        }
        .hf-wave {
          animation: hfWave 15s ease-out infinite;
          transform-origin: 50px 50px;
        }

        @keyframes hfMoteFloat {
          0%   { transform: translate(0, 0); opacity: 0; }
          15%  { opacity: 1; }
          85%  { opacity: 1; }
          100% { transform: translate(3px, -4px); opacity: 0; }
        }
        .hf-mote {
          animation: hfMoteFloat 20s ease-in-out infinite;
        }

        @media (prefers-reduced-motion: reduce) {
          .hf-dot, .hf-ring, .hf-center, .hf-center-dot,
          .hf-wave, .hf-mote {
            animation: none !important;
          }
          .hf-wave { display: none; }
        }
      `}</style>
    </div>
  );
}