import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Play, X, Rocket, Package, Compass, Zap, TrendingUp,
  ChevronRight, CheckCircle, Sparkles, ArrowRight,
} from "lucide-react";
import { useI18n } from "./i18n";

const STORAGE_KEY = "launchapp_onboarding_video_seen";

interface OnboardingSlide {
  icon: typeof Rocket;
  titleKey: string;
  descKey: string;
  color: string;
  gradient: string;
  durationMs: number;
}

const slides: OnboardingSlide[] = [
  {
    icon: Rocket,
    titleKey: "video.slide1Title",
    descKey: "video.slide1Desc",
    color: "text-purple-400",
    gradient: "from-purple-500/20 to-violet-500/20",
    durationMs: 6000,
  },
  {
    icon: Package,
    titleKey: "video.slide2Title",
    descKey: "video.slide2Desc",
    color: "text-violet-400",
    gradient: "from-violet-500/20 to-purple-500/20",
    durationMs: 6000,
  },
  {
    icon: Compass,
    titleKey: "video.slide3Title",
    descKey: "video.slide3Desc",
    color: "text-cyan-400",
    gradient: "from-cyan-500/20 to-blue-500/20",
    durationMs: 6000,
  },
  {
    icon: Zap,
    titleKey: "video.slide4Title",
    descKey: "video.slide4Desc",
    color: "text-emerald-400",
    gradient: "from-emerald-500/20 to-teal-500/20",
    durationMs: 6000,
  },
  {
    icon: TrendingUp,
    titleKey: "video.slide5Title",
    descKey: "video.slide5Desc",
    color: "text-amber-400",
    gradient: "from-amber-500/20 to-orange-500/20",
    durationMs: 6000,
  },
];

const TOTAL_DURATION = slides.reduce((sum, s) => sum + s.durationMs, 0);

export function OnboardingVideo({ onClose }: { onClose: () => void }) {
  const { t } = useI18n();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [completed, setCompleted] = useState(false);

  // Auto-advance slides
  useEffect(() => {
    if (!playing || completed) return;
    const interval = setInterval(() => {
      setProgress((prev) => {
        const next = prev + 50;
        const slideDuration = slides[currentSlide].durationMs;
        // Calculate cumulative time for current slide
        const slideStart = slides.slice(0, currentSlide).reduce((sum, s) => sum + s.durationMs, 0);
        const slideEnd = slideStart + slideDuration;
        const currentTime = (next / 100) * TOTAL_DURATION;

        if (currentTime >= TOTAL_DURATION) {
          setCompleted(true);
          setPlaying(false);
          return 100;
        }

        if (currentTime >= slideEnd && currentSlide < slides.length - 1) {
          setCurrentSlide((prev) => prev + 1);
        }

        return Math.min(next, 100);
      });
    }, 50);
    return () => clearInterval(interval);
  }, [playing, currentSlide, completed]);

  const handleStart = () => {
    setPlaying(true);
    setCurrentSlide(0);
    setProgress(0);
    setCompleted(false);
  };

  const handleSkipToSlide = (idx: number) => {
    setCurrentSlide(idx);
    const slideStart = slides.slice(0, idx).reduce((sum, s) => sum + s.durationMs, 0);
    setProgress((slideStart / TOTAL_DURATION) * 100);
  };

  const handleDismiss = useCallback(() => {
    try { localStorage.setItem(STORAGE_KEY, "true"); } catch {}
    onClose();
  }, [onClose]);

  const slide = slides[currentSlide];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[100] flex items-center justify-center p-4"
      onClick={handleDismiss}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 30 }}
        transition={{ type: "spring", damping: 28, stiffness: 300 }}
        className="relative w-full max-w-lg rounded-2xl border border-white/10 bg-[#0f0f11] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={handleDismiss}
          className="absolute top-4 right-4 z-10 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4 text-zinc-400" />
        </button>

        {/* Video area */}
        <div className={`relative aspect-video bg-gradient-to-br ${slide.gradient} flex items-center justify-center overflow-hidden`}>
          {/* Animated background dots */}
          <div className="absolute inset-0" style={{ backgroundImage: "radial-gradient(rgba(255,255,255,0.05) 1px, transparent 1px)", backgroundSize: "24px 24px" }} />

          {/* Floating orbs */}
          <motion.div
            key={currentSlide}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 0.15 }}
            transition={{ duration: 0.8 }}
            className="absolute w-64 h-64 rounded-full blur-3xl"
            style={{ background: `radial-gradient(circle, var(--tw-gradient-from, rgba(139,92,246,0.3)), transparent)` }}
          />

          {!playing && !completed ? (
            /* Play button */
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleStart}
              className="relative z-10 flex flex-col items-center gap-4"
            >
              <div className="w-20 h-20 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center hover:bg-white/15 transition-all">
                <Play className="w-8 h-8 text-white ml-1" />
              </div>
              <div className="text-center">
                <div className="text-white text-sm" style={{ fontWeight: 600 }}>{t("video.watchTitle")}</div>
                <div className="text-zinc-400 text-xs mt-0.5">30 {t("video.seconds")}</div>
              </div>
            </motion.button>
          ) : completed ? (
            /* Completion state */
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative z-10 text-center"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1, rotate: [0, 10, -10, 0] }}
                transition={{ type: "spring", delay: 0.2 }}
                className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center mx-auto mb-4"
              >
                <CheckCircle className="w-8 h-8 text-emerald-400" />
              </motion.div>
              <div className="text-white" style={{ fontWeight: 600 }}>{t("video.completed")}</div>
              <p className="text-xs text-zinc-400 mt-1">{t("video.completedDesc")}</p>
            </motion.div>
          ) : (
            /* Current slide content */
            <AnimatePresence mode="wait">
              <motion.div
                key={currentSlide}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4 }}
                className="relative z-10 text-center px-8"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", delay: 0.1 }}
                  className="w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center mx-auto mb-4"
                >
                  <slide.icon className={`w-7 h-7 ${slide.color}`} />
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <div className="text-xs text-zinc-400 uppercase tracking-widest mb-2" style={{ fontWeight: 600 }}>
                    {t("video.stepLabel")} {currentSlide + 1}/5
                  </div>
                  <h3 className="text-white text-lg mb-2" style={{ fontWeight: 700 }}>{t(slide.titleKey)}</h3>
                  <p className="text-sm text-zinc-300 leading-relaxed max-w-sm mx-auto">{t(slide.descKey)}</p>
                </motion.div>
              </motion.div>
            </AnimatePresence>
          )}

          {/* Slide dots (clickable) */}
          {playing && !completed && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2">
              {slides.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSkipToSlide(idx)}
                  className={`h-1.5 rounded-full transition-all ${
                    idx === currentSlide ? "w-6 bg-white/80" : idx < currentSlide ? "w-3 bg-white/40" : "w-3 bg-white/15"
                  }`}
                />
              ))}
            </div>
          )}
        </div>

        {/* Progress bar */}
        {(playing || completed) && (
          <div className="h-1 bg-white/5">
            <motion.div
              className="h-full bg-gradient-to-r from-purple-500 to-violet-500 rounded-r-full"
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.1 }}
            />
          </div>
        )}

        {/* Bottom section */}
        <div className="p-5">
          {!playing && !completed ? (
            <div className="space-y-3">
              <div className="text-center">
                <h3 className="text-white" style={{ fontWeight: 600 }}>{t("video.introTitle")}</h3>
                <p className="text-xs text-zinc-500 mt-1">{t("video.introDesc")}</p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleStart}
                  className="flex-1 flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-500 text-white py-3 rounded-xl text-sm transition-all"
                >
                  <Play className="w-4 h-4" />
                  {t("video.watchNow")}
                </button>
                <button
                  onClick={handleDismiss}
                  className="px-4 py-3 rounded-xl text-sm text-zinc-500 border border-white/5 hover:border-white/10 hover:text-zinc-300 transition-all"
                >
                  {t("video.skip")}
                </button>
              </div>
            </div>
          ) : completed ? (
            <div className="flex gap-2">
              <button
                onClick={handleDismiss}
                className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white py-3 rounded-xl text-sm transition-all"
              >
                <Sparkles className="w-4 h-4" />
                {t("video.startLaunch")}
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-between">
              <button
                onClick={handleDismiss}
                className="text-xs text-zinc-600 hover:text-zinc-400 transition-colors"
              >
                {t("video.skip")}
              </button>
              <button
                onClick={() => {
                  if (currentSlide < slides.length - 1) {
                    handleSkipToSlide(currentSlide + 1);
                  } else {
                    setCompleted(true);
                    setPlaying(false);
                    setProgress(100);
                  }
                }}
                className="text-xs text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-1"
              >
                {currentSlide < slides.length - 1 ? t("video.nextSlide") : t("video.finish")}
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}

/** Hook to check if onboarding video should show */
export function useOnboardingVideo() {
  const [show, setShow] = useState(false);

  // Auto-show is disabled — onboarding is now triggered manually from Settings
  const open = useCallback(() => {
    setShow(true);
  }, []);

  const dismiss = useCallback(() => {
    setShow(false);
    try { localStorage.setItem(STORAGE_KEY, "true"); } catch {}
  }, []);

  return { show, dismiss, open };
}