import { useState, useCallback, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { User, Bell, CreditCard, Award, Check, Plug, ExternalLink, TrendingUp, Coins, Rocket, BarChart3, ArrowUpRight, Calendar, ChevronRight, ChevronDown, Download, X, Sparkles, Zap, Crown, AlertTriangle, Gift, Pause, Heart, Play, Camera, Bug, SkipForward, Trash2, RefreshCw, FileDown, Clock, Database, RotateCcw, Plus, Minus, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "./i18n";
import { useNavigate, useSearchParams } from "react-router";
import { loadProgress, updateProgress, resetAllData, LS_KEYS } from "./user-progress";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { usePullToRefresh } from "./usePullToRefresh";
import { PullToRefreshIndicator } from "./PullToRefreshIndicator";
import jsPDF from "jspdf";

import { MilestoneNotifications } from "./MilestoneNotifications";
import { OnboardingVideo } from "./OnboardingVideo";
import { getUserAvatar, setUserAvatar, AVATAR_OPTIONS } from "./avatars";
import { loadSubscription, cancelSubscription, reactivateSubscription, getTrialDaysRemaining, getTrialEndDate, getDiscountedPrice, type Subscription } from "./subscription";
import { useTheme, ACCENT_COLORS } from "./ThemeProvider";

const levels = [
  { name: "New Founder", points: 0 },
  { name: "Builder", points: 500 },
  { name: "Growth Hacker", points: 2000, current: true },
  { name: "Launch Architect", points: 5000 },
  { name: "Global Founder", points: 10000 },
];

const PLANS = [
  { id: "starter", price: 29, tokens: 100, projects: 1, channels: "50", icon: Zap, gradient: "from-blue-500/20 to-cyan-500/15", border: "border-blue-500/20", iconColor: "text-blue-400" },
  { id: "growth", price: 59, tokens: 300, projects: 5, channels: "All", icon: TrendingUp, gradient: "from-cyan-500/20 to-purple-500/15", border: "border-cyan-500/20", iconColor: "text-cyan-400" },
  { id: "viral", price: 149, tokens: 1000, projects: 999, channels: "All", icon: Crown, gradient: "from-purple-500/20 to-pink-500/15", border: "border-purple-500/20", iconColor: "text-purple-400" },
] as const;

export function SettingsPage() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const isDebugMode = searchParams.get("debug") === "1";

  // ─── Ctrl+Shift+D keyboard shortcut to toggle debug ───
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === "D") {
        e.preventDefault();
        setSearchParams((prev) => {
          const next = new URLSearchParams(prev);
          if (next.get("debug") === "1") {
            next.delete("debug");
            queueMicrotask(() => setActiveTab((cur) => cur === "debug" ? "profile" : cur));
          } else {
            next.set("debug", "1");
            queueMicrotask(() => setActiveTab("debug"));
          }
          return next;
        }, { replace: true });
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [setSearchParams]);

  useDocumentTitle(t("sidebar.settings"));
  const [activeTab, setActiveTab] = useState("profile");
  const [notifications, setNotifications] = useState({ launches: true, analytics: true, community: false, marketing: false });

  // ─── Plan change state ───
  const [currentPlan, setCurrentPlan] = useState<string>(() => {
    try { return localStorage.getItem("launchapp_plan") || "growth"; } catch { return "growth"; }
  });
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);

  // ── Subscription / trial state ───
  const [subscription, setSubscription] = useState<Subscription | null>(() => loadSubscription());
  const trialDaysLeft = subscription ? getTrialDaysRemaining(subscription) : 0;
  const trialEndDate = subscription ? getTrialEndDate(subscription) : null;

  // ─── Cancel subscription state ───
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelStep, setCancelStep] = useState<"reason" | "retention" | "final">("reason");
  const [cancelReason, setCancelReason] = useState<string | null>(null);
  const [retentionChoice, setRetentionChoice] = useState<"discount" | "pause" | null>(null);

  // ─── Onboarding video replay state ───
  const [showOnboarding, setShowOnboarding] = useState(false);

  // ─── Avatar state ───
  const [avatarUrl, setAvatarUrl] = useState(() => getUserAvatar());
  const [showAvatarPicker, setShowAvatarPicker] = useState(false);

  // ─── Accent color state ───
  const { accent, setAccent: applyAccent } = useTheme();

  const handleSaveProfile = useCallback(() => {
    toast.success(t("settings.saved"));
  }, [t]);

  const handleAvatarChange = useCallback((url: string) => {
    setAvatarUrl(url);
    setUserAvatar(url);
    setShowAvatarPicker(false);
    toast.success(t("settings.avatarChanged"));
  }, [t]);

  const handleAvatarUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setAvatarUrl(result);
      setUserAvatar(result);
      setShowAvatarPicker(false);
      toast.success(t("settings.avatarChanged"));
    };
    reader.readAsDataURL(file);
  }, [t]);

  const handleChangePlan = useCallback((planId: string) => {
    setCurrentPlan(planId);
    localStorage.setItem("launchapp_plan", planId);
    setShowPlanModal(false);
    setSelectedPlan(null);
    toast.success(t("settings.planChanged"));
  }, [t]);

  const currentPlanData = PLANS.find((p) => p.id === currentPlan) || PLANS[1];
  const planNameKey = currentPlan === "starter" ? "settings.starterPlan" : currentPlan === "viral" ? "settings.viralPlan" : "settings.growthPlan";

  // ─── Cancel subscription handlers ───
  const handleOpenCancel = useCallback(() => {
    setShowCancelModal(true);
    setCancelStep("reason");
    setCancelReason(null);
    setRetentionChoice(null);
  }, []);

  const handleAcceptRetention = useCallback(() => {
    if (retentionChoice === "discount") {
      toast.success(t("settings.discountApplied"));
    } else {
      toast.success(t("settings.pauseApplied"));
    }
    setShowCancelModal(false);
  }, [retentionChoice, t]);

  const handleConfirmCancel = useCallback(() => {
    cancelSubscription();
    setSubscription(loadSubscription());
    toast.success(t("settings.cancelledSuccess"));
    setShowCancelModal(false);
  }, [t]);

  const handleReactivate = useCallback(() => {
    reactivateSubscription();
    setSubscription(loadSubscription());
    toast.success(t("settings.reactivate") + " — done");
  }, [t]);

  // ─── PDF Invoice export ───
  const handleDownloadInvoice = useCallback((date: string, amount: string, invoiceId: string) => {
    const doc = new jsPDF();
    doc.setFillColor(17, 17, 20);
    doc.rect(0, 0, 210, 297, "F");

    doc.setTextColor(168, 85, 247);
    doc.setFontSize(22);
    doc.text("Launch OS", 20, 30);

    doc.setTextColor(255, 255, 255);
    doc.setFontSize(16);
    doc.text("INVOICE", 150, 30);

    doc.setTextColor(160, 160, 180);
    doc.setFontSize(9);
    doc.text(invoiceId, 150, 37);

    doc.setDrawColor(60, 60, 80);
    doc.line(20, 42, 190, 42);

    doc.setTextColor(160, 160, 180);
    doc.setFontSize(10);
    doc.text("Invoice No:", 20, 56);
    doc.text("Invoice Date:", 20, 64);
    doc.text("Plan:", 20, 72);
    doc.text("Amount:", 20, 80);
    doc.text("Status:", 20, 88);
    doc.text("Payment Method:", 20, 96);

    doc.setTextColor(255, 255, 255);
    doc.text(invoiceId, 80, 56);
    doc.text(date, 80, 64);
    doc.text(t(planNameKey), 80, 72);
    doc.text(amount, 80, 80);
    doc.text("Paid", 80, 88);
    doc.text("Visa •••• 4242", 80, 96);

    doc.setDrawColor(60, 60, 80);
    doc.line(20, 105, 190, 105);

    doc.setTextColor(160, 160, 180);
    doc.setFontSize(9);
    doc.text("Bill To:", 20, 118);
    doc.setTextColor(255, 255, 255);
    doc.text("Launch OS User", 20, 126);
    doc.text("user@launchos.com", 20, 133);

    doc.setTextColor(160, 160, 180);
    doc.setFontSize(9);
    doc.text("From:", 120, 118);
    doc.setTextColor(255, 255, 255);
    doc.text("Launch OS Inc.", 120, 126);
    doc.text("hello@launchos.com", 120, 133);

    // Table
    doc.setFillColor(30, 30, 40);
    doc.rect(20, 148, 170, 12, "F");
    doc.setTextColor(160, 160, 180);
    doc.setFontSize(9);
    doc.text("Description", 25, 156);
    doc.text("Qty", 120, 156);
    doc.text("Amount", 155, 156);

    doc.setTextColor(255, 255, 255);
    doc.text(`${t(planNameKey)} — Monthly`, 25, 170);
    doc.text("1", 120, 170);
    doc.text(amount, 155, 170);

    doc.setDrawColor(60, 60, 80);
    doc.line(20, 178, 190, 178);

    doc.setTextColor(168, 85, 247);
    doc.setFontSize(11);
    doc.text(`Total: ${amount}`, 155, 190);

    doc.setTextColor(100, 100, 120);
    doc.setFontSize(8);
    doc.text("Thank you for your business! This invoice was generated automatically.", 20, 270);
    doc.text(`Launch OS · launchos.com · ${invoiceId}`, 20, 278);

    doc.save(`LaunchOS-${invoiceId}.pdf`);
    toast.success(t("settings.invoiceGenerated"));
  }, [t, planNameKey]);

  const { pullY, isRefreshing, handlers: pullHandlers } = usePullToRefresh(
    () => new Promise<void>((resolve) => setTimeout(resolve, 1200))
  );

  // ─── Integration state (persisted) ───
  const [integrations, setIntegrations] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem("launchapp_integrations");
      if (saved) return JSON.parse(saved);
    } catch {}
    return { slack: false, notion: false, telegram: false };
  });

  const toggleIntegration = (id: string) => {
    setIntegrations((prev) => {
      const next = { ...prev, [id]: !prev[id] };
      // Side-effects deferred outside setState updater
      queueMicrotask(() => {
        localStorage.setItem("launchapp_integrations", JSON.stringify(next));
        if (next[id]) {
          toast.success(`${id.charAt(0).toUpperCase() + id.slice(1)} ${t("settings.connected").toLowerCase()}`);
        }
      });
      return next;
    });
  };

  // ─── Debug panel state ───
  const [debugProgress, setDebugProgress] = useState(() => loadProgress());
  const refreshDebug = useCallback(() => setDebugProgress(loadProgress()), []);
  // Refresh debug state when tab switches to debug
  useEffect(() => {
    if (activeTab === "debug") refreshDebug();
  }, [activeTab, refreshDebug]);

  const debugSkipToStep = useCallback((step: number) => {
    const patch: Record<string, unknown> = {};
    // Step 1: project created
    if (step >= 1) {
      patch.projectCreated = true;
      patch.projectName = debugProgress.projectName || "Demo Project";
      patch.projectCategory = debugProgress.projectCategory || "SaaS";
      patch.projectUrl = debugProgress.projectUrl || "https://demo.launchos.com";
      patch.projectDescription = debugProgress.projectDescription || "AI-powered launch automation platform";
      patch.audience = debugProgress.audience || "Indie hackers & startup founders";
      patch.goal = debugProgress.goal || "1000 users in 30 days";
    }
    // Step 2: package generated
    if (step >= 2) {
      try {
        const allPackKeys = ["oneLiner", "elevatorPitch", "landingCopy", "offer", "faq", "founderBio", "productHunt", "twitter", "linkedin", "telegram", "emailOutreach"];
        localStorage.setItem(LS_KEYS.packageGenerated, JSON.stringify(allPackKeys));
      } catch {}
    }
    // Step 3: channels connected
    if (step >= 3) {
      patch.channelsConnected = 6;
      try {
        const channels: Record<string, string> = { twitter: "connected", linkedin: "connected", reddit: "connected", producthunt: "connected", telegram: "connected", devto: "connected" };
        localStorage.setItem("launchapp_channels", JSON.stringify(channels));
      } catch {}
    }
    // Step 4: launched
    if (step >= 4) {
      patch.launched = true;
      patch.launchDay = step >= 5 ? 5 : 1;
    }
    // Step 5: advanced day
    if (step >= 5) {
      patch.launchDay = 5;
    }

    updateProgress(patch as any);
    refreshDebug();
    toast.success(`Skipped to step ${step}`);
  }, [debugProgress, refreshDebug]);

  const debugSetDay = useCallback((day: number) => {
    updateProgress({ launchDay: day });
    refreshDebug();
    toast.success(`launchDay set to ${day}`);
  }, [refreshDebug]);

  // ─── E2E Runner ───
  type E2ELogEntry = { step: number; label: string; status: "pass" | "fail" | "abort" | "running"; time: string; durationMs: number; snapshot: Record<string, unknown> };
  const [e2eRunning, setE2eRunning] = useState(false);
  const [e2eStep, setE2eStep] = useState(0); // 0 = idle, 1-5 = running step, 6 = done
  const [e2eLog, setE2eLog] = useState<E2ELogEntry[]>([]);
  const [e2eExpandedSnap, setE2eExpandedSnap] = useState<number | null>(null);
  const [restoreConfirmIdx, setRestoreConfirmIdx] = useState<number | null>(null);
  const [compareMode, setCompareMode] = useState(false);
  const [compareA, setCompareA] = useState<number>(0);
  const [compareB, setCompareB] = useState<number>(1);
  const e2eAbortRef = useRef(false);

  const captureSnapshot = useCallback((): Record<string, unknown> => {
    const snap: Record<string, unknown> = {};
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith("launchapp")) {
        try { snap[key] = JSON.parse(localStorage.getItem(key)!); } catch { snap[key!] = localStorage.getItem(key); }
      }
    }
    return snap;
  }, []);

  type DiffEntry = { key: string; type: "added" | "removed" | "changed"; oldVal?: unknown; newVal?: unknown };
  const computeSnapshotDiff = useCallback((prev: Record<string, unknown>, curr: Record<string, unknown>): DiffEntry[] => {
    const diff: DiffEntry[] = [];
    const allKeys = new Set([...Object.keys(prev), ...Object.keys(curr)]);
    for (const key of Array.from(allKeys).sort()) {
      const inPrev = key in prev;
      const inCurr = key in curr;
      if (!inPrev && inCurr) {
        diff.push({ key, type: "added", newVal: curr[key] });
      } else if (inPrev && !inCurr) {
        diff.push({ key, type: "removed", oldVal: prev[key] });
      } else if (JSON.stringify(prev[key]) !== JSON.stringify(curr[key])) {
        diff.push({ key, type: "changed", oldVal: prev[key], newVal: curr[key] });
      }
    }
    return diff;
  }, []);

  const doRestoreSnapshot = useCallback((snapshot: Record<string, unknown>) => {
    const keysToRemove: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith("launchapp")) keysToRemove.push(k);
    }
    keysToRemove.forEach((k) => localStorage.removeItem(k));
    for (const [k, v] of Object.entries(snapshot)) {
      localStorage.setItem(k, typeof v === "string" ? v : JSON.stringify(v));
    }
    queueMicrotask(() => {
      refreshDebug();
      document.dispatchEvent(new CustomEvent("launchapp:progress", { detail: loadProgress() }));
      toast.success("Snapshot restored -- state rewound");
    });
  }, [refreshDebug]);

  const confirmRestore = useCallback((idx: number) => {
    setRestoreConfirmIdx(idx);
  }, []);

  const executeRestore = useCallback(() => {
    if (restoreConfirmIdx !== null && e2eLog[restoreConfirmIdx]) {
      doRestoreSnapshot(e2eLog[restoreConfirmIdx].snapshot);
      setRestoreConfirmIdx(null);
    }
  }, [restoreConfirmIdx, e2eLog, doRestoreSnapshot]);

  const renderDiffBlock = useCallback((diff: DiffEntry[]) => {
    if (diff.length === 0) return (
      <div className="text-[10px] text-zinc-600 py-2 text-center italic">No changes detected</div>
    );
    return (
      <div className="space-y-1">
        {diff.map((d) => (
          <div key={d.key} className={`rounded-lg px-2.5 py-2 text-[10px] backdrop-blur-sm ${
            d.type === "added" ? "bg-emerald-500/[0.06] border border-emerald-500/15" :
            d.type === "removed" ? "bg-red-500/[0.06] border border-red-500/15" :
            "bg-amber-500/[0.06] border border-amber-500/15"
          }`}>
            <div className="flex items-center gap-1.5">
              <span className={`w-4 h-4 rounded flex items-center justify-center shrink-0 ${
                d.type === "added" ? "bg-emerald-500/20" :
                d.type === "removed" ? "bg-red-500/20" : "bg-amber-500/20"
              }`}>
                {d.type === "added" && <Plus className="w-2.5 h-2.5 text-emerald-400" />}
                {d.type === "removed" && <Minus className="w-2.5 h-2.5 text-red-400" />}
                {d.type === "changed" && <ArrowRight className="w-2.5 h-2.5 text-amber-400" />}
              </span>
              <code className={`${
                d.type === "added" ? "text-emerald-300" :
                d.type === "removed" ? "text-red-300" : "text-amber-300"
              }`} style={{ fontWeight: 600 }}>{d.key}</code>
              <span className={`ml-auto text-[9px] px-1.5 py-0.5 rounded-full ${
                d.type === "added" ? "bg-emerald-500/10 text-emerald-500" :
                d.type === "removed" ? "bg-red-500/10 text-red-500" : "bg-amber-500/10 text-amber-500"
              }`} style={{ fontWeight: 600 }}>{d.type}</span>
            </div>
            {d.type === "changed" && (
              <div className="ml-5.5 mt-1.5 grid grid-cols-[auto_1fr] gap-x-2 gap-y-0.5">
                <span className="text-red-500/60 select-none">-</span>
                <code className="text-red-400/70 line-through break-all">
                  {typeof d.oldVal === "object" ? JSON.stringify(d.oldVal) : String(d.oldVal)}
                </code>
                <span className="text-emerald-500/60 select-none">+</span>
                <code className="text-emerald-400/90 break-all">
                  {typeof d.newVal === "object" ? JSON.stringify(d.newVal) : String(d.newVal)}
                </code>
              </div>
            )}
            {d.type === "added" && (
              <div className="ml-5.5 mt-1 flex gap-2">
                <span className="text-emerald-500/60 select-none">+</span>
                <code className="text-emerald-400/80 break-all">
                  {typeof d.newVal === "object" ? JSON.stringify(d.newVal) : String(d.newVal)}
                </code>
              </div>
            )}
            {d.type === "removed" && (
              <div className="ml-5.5 mt-1 flex gap-2">
                <span className="text-red-500/60 select-none">-</span>
                <code className="text-red-400/60 line-through break-all">
                  {typeof d.oldVal === "object" ? JSON.stringify(d.oldVal) : String(d.oldVal)}
                </code>
              </div>
            )}
          </div>
        ))}
      </div>
    );
  }, []);

  const e2eStepLabels = ["", "Creating project...", "Generating package...", "Connecting channels...", "Launching...", "Tracking (day 1-5)..."];

  const exportE2ELog = useCallback(() => {
    if (e2eLog.length === 0) return;
    const blob = new Blob([JSON.stringify(e2eLog, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `e2e-log-${new Date().toISOString().slice(0, 19).replace(/:/g, "-")}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("E2E log exported");
  }, [e2eLog]);

  const runFullE2E = useCallback(async () => {
    e2eAbortRef.current = false;
    setE2eRunning(true);
    setE2eStep(0);
    setE2eLog([]);
    const log: E2ELogEntry[] = [];
    const runStart = Date.now();

    // Reset first
    resetAllData(true);
    refreshDebug();
    await new Promise((r) => setTimeout(r, 600));

    const delay = (ms: number) => new Promise<void>((resolve) => {
      const t = setTimeout(resolve, ms);
      const check = setInterval(() => {
        if (e2eAbortRef.current) { clearTimeout(t); clearInterval(check); resolve(); }
      }, 100);
    });

    for (let step = 1; step <= 5; step++) {
      if (e2eAbortRef.current) {
        log.push({ step, label: e2eStepLabels[step], status: "abort", time: new Date().toISOString(), durationMs: 0, snapshot: captureSnapshot() });
        break;
      }
      setE2eStep(step);
      const stepStart = Date.now();

      const stepDelay = step === 5 ? 2500 : 1500;
      try {
        debugSkipToStep(step);

        if (step === 5 && !e2eAbortRef.current) {
          for (let day = 1; day <= 5; day++) {
            if (e2eAbortRef.current) break;
            updateProgress({ launchDay: day });
            refreshDebug();
            await delay(500);
          }
        }

        await delay(stepDelay);
        if (e2eAbortRef.current) {
          log.push({ step, label: e2eStepLabels[step], status: "abort", time: new Date().toISOString(), durationMs: Date.now() - stepStart, snapshot: captureSnapshot() });
          break;
        }
        log.push({ step, label: e2eStepLabels[step], status: "pass", time: new Date().toISOString(), durationMs: Date.now() - stepStart, snapshot: captureSnapshot() });
      } catch {
        log.push({ step, label: e2eStepLabels[step], status: "fail", time: new Date().toISOString(), durationMs: Date.now() - stepStart, snapshot: captureSnapshot() });
        break;
      }
      setE2eLog([...log]);
    }

    if (!e2eAbortRef.current) {
      setE2eStep(6);
      refreshDebug();
      const totalMs = Date.now() - runStart;
      toast.success(`E2E complete -- all 5 steps passed in ${(totalMs / 1000).toFixed(1)}s`);
      document.dispatchEvent(new CustomEvent("launchapp:progress", { detail: loadProgress() }));
    } else {
      toast("E2E aborted");
    }

    setE2eLog([...log]);
    setE2eRunning(false);
  }, [debugSkipToStep, refreshDebug, captureSnapshot]);

  const abortE2E = useCallback(() => {
    e2eAbortRef.current = true;
    setE2eRunning(false);
    setE2eStep(0);
  }, []);

  const baseTabs = [
    { id: "profile", label: t("settings.profile"), icon: User },
    { id: "notifications", label: t("settings.notifications"), icon: Bell },
    { id: "integrations", label: t("settings.integrations"), icon: Plug },
    { id: "billing", label: t("settings.billing"), icon: CreditCard },
    { id: "levels", label: t("settings.founderLevel"), icon: Award },
  ];
  const tabs = isDebugMode ? [...baseTabs, { id: "debug", label: "Debug", icon: Bug }] : baseTabs;

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-4 sm:space-y-6" {...pullHandlers}>
      <PullToRefreshIndicator pullY={pullY} isRefreshing={isRefreshing} />
      <LargeTitle title={t("settings.title")} subtitle={t("settings.subtitle")} />

      <div className="liquid-glass-card flex gap-1 p-1 rounded-xl w-fit overflow-x-auto">
        {tabs.map((tb) => (
          <button key={tb.id} onClick={() => setActiveTab(tb.id)} className={`relative flex items-center gap-2 px-4 py-2 rounded-lg text-sm transition-all ${activeTab === tb.id ? "text-purple-400" : "text-zinc-500 hover:text-zinc-300"}`}>
            {activeTab === tb.id && (
              <motion.div
                layoutId="settings-tab-bg"
                className="absolute inset-0 rounded-lg bg-purple-500/10"
                transition={{ type: "spring", damping: 25, stiffness: 300 }}
              />
            )}
            <span className="relative z-10 flex items-center gap-2">
              <tb.icon className="w-4 h-4" /><span className="hidden sm:inline">{tb.label}</span>
            </span>
          </button>
        ))}
      </div>

      {activeTab === "profile" && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="p-6 rounded-xl border border-white/5 bg-white/[0.02] space-y-5">
          <div className="flex items-center gap-4 mb-6">
            {/* ─── Avatar with change button ─── */}
            <div className="relative group">
              <img
                src={avatarUrl}
                alt="Profile"
                className="w-16 h-16 rounded-2xl object-cover"
              />
              <button
                onClick={() => setShowAvatarPicker(true)}
                className="absolute inset-0 rounded-2xl bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all cursor-pointer"
              >
                <Camera className="w-5 h-5 text-white" />
              </button>
            </div>
            <div>
              <div className="text-white" style={{ fontWeight: 600 }}>Launch OS User</div>
              <div className="flex items-center gap-2 mt-0.5">
                <span className={`text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/15 text-cyan-400 border border-cyan-500/20 flex items-center gap-1`} style={{ fontWeight: 600 }}>
                  <currentPlanData.icon className="w-2.5 h-2.5" />
                  {t(planNameKey)}
                </span>
                <span className="text-xs text-zinc-600">${currentPlanData.price}{t("settings.perMonth")}</span>
              </div>
              <button
                onClick={() => setShowAvatarPicker(true)}
                className="text-[11px] text-purple-400 hover:text-purple-300 mt-1 transition-colors"
              >
                {t("settings.changeAvatar")}
              </button>
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div><label className="text-sm text-zinc-400 mb-1.5 block">{t("settings.fullName")}</label><input defaultValue="Launch OS User" className="w-full px-4 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white focus:border-purple-500/50 focus:outline-none transition-colors" /></div>
            <div><label className="text-sm text-zinc-400 mb-1.5 block">{t("settings.email")}</label><input defaultValue="user@launchos.com" className="w-full px-4 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white focus:border-purple-500/50 focus:outline-none transition-colors" /></div>
            <div><label className="text-sm text-zinc-400 mb-1.5 block">{t("settings.company")}</label><input defaultValue="My Startup" className="w-full px-4 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white focus:border-purple-500/50 focus:outline-none transition-colors" /></div>
            <div><label className="text-sm text-zinc-400 mb-1.5 block">{t("settings.website")}</label><input defaultValue="https://mystartup.com" className="w-full px-4 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white focus:border-purple-500/50 focus:outline-none transition-colors" /></div>
          </div>
          {/* ─── Accent Color Picker ─── */}
          <div className="pt-4 border-t border-white/5">
            <label className="text-sm text-zinc-400 mb-3 block">{t("settings.accentColor")}</label>
            <div className="flex items-center gap-3">
              {ACCENT_COLORS.map((c) => {
                const isSelected = accent === c.id;
                return (
                  <button
                    key={c.id}
                    onClick={() => applyAccent(c.id)}
                    className={`relative w-10 h-10 rounded-xl transition-all ${isSelected ? "ring-2 ring-offset-2 ring-offset-zinc-950 scale-110" : "hover:scale-105"}`}
                    style={{
                      backgroundColor: c.hex,
                      ringColor: c.hex,
                      ...(isSelected ? { boxShadow: `0 0 0 2px var(--app-bg), 0 0 0 4px ${c.hex}` } : {}),
                    }}
                    title={c.label}
                  >
                    {isSelected && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="absolute inset-0 flex items-center justify-center"
                      >
                        <Check className="w-4 h-4 text-white drop-shadow-md" />
                      </motion.div>
                    )}
                  </button>
                );
              })}
            </div>
            <p className="text-[11px] text-zinc-600 mt-2">{t("settings.accentColorDesc")}</p>
          </div>

          <button
            onClick={handleSaveProfile}
            className="bg-purple-600 hover:bg-purple-500 text-white px-5 py-2.5 rounded-xl text-sm transition-colors inline-flex items-center gap-2"
          >
            <Check className="w-4 h-4" />
            {t("settings.saveChanges")}
          </button>

          {/* ─── Replay Onboarding ─── */}
          <div className="pt-3 border-t border-white/5">
            <button
              onClick={() => setShowOnboarding(true)}
              className="flex items-center gap-2.5 px-4 py-3 rounded-xl border border-white/5 bg-white/[0.02] hover:border-purple-500/20 hover:bg-purple-500/[0.04] transition-all w-full text-left group"
            >
              <div className="w-9 h-9 rounded-xl bg-purple-500/10 flex items-center justify-center shrink-0 group-hover:bg-purple-500/15 transition-colors">
                <Play className="w-4 h-4 text-purple-400" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm text-white" style={{ fontWeight: 500 }}>{t("settings.replayOnboarding")}</div>
                <div className="text-[11px] text-zinc-500">{t("settings.replayOnboardingDesc")}</div>
              </div>
              <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-purple-400 transition-colors" />
            </button>
          </div>
        </motion.div>
      )}

      {activeTab === "notifications" && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          <div className="p-6 rounded-xl border border-white/5 bg-white/[0.02] space-y-4">
            {([
              { key: "launches" as const, title: t("settings.launchUpdates"), desc: t("settings.launchUpdatesSub") },
              { key: "analytics" as const, title: t("settings.analyticsReports"), desc: t("settings.analyticsReportsSub") },
              { key: "community" as const, title: t("settings.communityActivity"), desc: t("settings.communityActivitySub") },
              { key: "marketing" as const, title: t("settings.productUpdates"), desc: t("settings.productUpdatesSub") },
            ]).map((n) => (
              <div key={n.key} className="flex items-center justify-between py-3 border-b border-white/5 last:border-0">
                <div><div className="text-sm text-white" style={{ fontWeight: 500 }}>{n.title}</div><div className="text-xs text-zinc-500">{n.desc}</div></div>
                <button onClick={() => setNotifications((p) => ({ ...p, [n.key]: !p[n.key] }))} className={`w-10 h-6 rounded-full transition-colors relative ${notifications[n.key] ? "bg-purple-600" : "bg-zinc-700"}`}>
                  <div className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-all ${notifications[n.key] ? "left-5" : "left-1"}`} />
                </button>
              </div>
            ))}
          </div>

          {/* Milestone Notifications */}
          <div className="p-6 rounded-xl border border-white/5 bg-white/[0.02]">
            <MilestoneNotifications />
          </div>
        </motion.div>
      )}

      {activeTab === "integrations" && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <p className="text-xs text-zinc-500">{t("settings.integrationsDesc")}</p>

          {[
            {
              id: "slack",
              name: "Slack",
              desc: t("settings.slackDesc"),
              color: "bg-[#4A154B]",
              textColor: "text-white",
              letter: "S",
              webhook: "https://hooks.slack.com/services/T0K...XyZ",
              configLabel: t("settings.configureWebhook"),
            },
            {
              id: "notion",
              name: "Notion",
              desc: t("settings.notionDesc"),
              color: "bg-white/90",
              textColor: "text-black",
              letter: "N",
              webhook: "workspace: Launch OS Hub",
              configLabel: t("settings.selectWorkspace"),
            },
            {
              id: "telegram",
              name: "Telegram",
              desc: t("settings.telegramDesc"),
              color: "bg-[#0088cc]",
              textColor: "text-white",
              letter: "T",
              webhook: "@launchos_bot — Chat ID: -100183...",
              configLabel: t("settings.setBotToken"),
            },
          ].map((integ) => {
            const connected = integrations[integ.id];
            return (
              <div
                key={integ.id}
                className={`p-5 rounded-xl border transition-all ${
                  connected
                    ? "border-emerald-500/20 bg-emerald-500/[0.03]"
                    : "border-white/5 bg-white/[0.02]"
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className={`w-10 h-10 rounded-xl ${integ.color} ${integ.textColor} flex items-center justify-center shrink-0 text-sm`} style={{ fontWeight: 700 }}>
                    {integ.letter}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-white" style={{ fontWeight: 600 }}>{integ.name}</span>
                      {connected && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                          <Check className="w-2.5 h-2.5" />
                          {t("settings.connected")}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-zinc-500 mt-0.5">{integ.desc}</p>

                    <AnimatePresence>
                      {connected && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                          className="mt-3 space-y-2"
                        >
                          <div className="flex items-center gap-2 p-2.5 rounded-lg bg-white/[0.03] border border-white/5">
                            <code className="text-[11px] text-zinc-400 truncate flex-1 font-mono">{integ.webhook}</code>
                            <button className="text-[10px] text-purple-400 hover:text-purple-300 shrink-0 flex items-center gap-1">
                              <ExternalLink className="w-2.5 h-2.5" />
                              {integ.configLabel}
                            </button>
                          </div>
                          <div className="flex items-center gap-3 text-[11px] text-zinc-600">
                            <span>{t("settings.lastSync")}: 2 min ago</span>
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                  <button
                    onClick={() => toggleIntegration(integ.id)}
                    className={`shrink-0 text-xs px-4 py-2 rounded-lg transition-all ${
                      connected
                        ? "text-red-400/70 border border-red-500/15 hover:bg-red-500/5 hover:text-red-400"
                        : "text-purple-400 bg-purple-500/10 hover:bg-purple-500/15 border border-purple-500/20"
                    }`}
                  >
                    {connected ? t("settings.disconnect") : t("settings.connect")}
                  </button>
                </div>
              </div>
            );
          })}
        </motion.div>
      )}

      {activeTab === "billing" && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          {/* ─── Current Plan Hero Card ─── */}
          <div className={`relative overflow-hidden rounded-2xl border ${currentPlanData.border} bg-gradient-to-br ${currentPlanData.gradient.replace(/\/20/g, "/[0.06]").replace(/\/15/g, "/[0.04]")}`}>
            <div className="absolute -top-20 -right-20 w-40 h-40 rounded-full bg-cyan-500/10 blur-3xl" />
            <div className="absolute -bottom-10 -left-10 w-32 h-32 rounded-full bg-purple-500/8 blur-2xl" />
            <div className="relative p-6">
              <div className="flex items-start justify-between mb-5">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${currentPlanData.gradient} border ${currentPlanData.border} flex items-center justify-center`}>
                    <currentPlanData.icon className={`w-6 h-6 ${currentPlanData.iconColor}`} />
                  </div>
                  <div>
                    <div className="text-xs text-zinc-500">{t("settings.currentPlan")}</div>
                    <div className="text-xl text-white" style={{ fontWeight: 700 }}>{t(planNameKey)}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {subscription?.status === "trial" ? (
                    <span className="text-[10px] px-2.5 py-1 rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/20 flex items-center gap-1" style={{ fontWeight: 600 }}>
                      <Calendar className="w-3 h-3" />
                      {t("settings.trialActive")} · {trialDaysLeft} {t("settings.trialDaysLeft")}
                    </span>
                  ) : subscription?.status === "cancelled" ? (
                    <span className="text-[10px] px-2.5 py-1 rounded-full bg-red-500/15 text-red-400 border border-red-500/20" style={{ fontWeight: 600 }}>
                      Cancelled
                    </span>
                  ) : (
                    <span className="text-[10px] px-2.5 py-1 rounded-full bg-cyan-500/15 text-cyan-400 border border-cyan-500/20" style={{ fontWeight: 600 }}>Active</span>
                  )}
                  <button onClick={() => { setShowPlanModal(true); setSelectedPlan(null); }} className="text-xs text-purple-400 border border-purple-500/20 px-3 py-1.5 rounded-lg hover:bg-purple-500/10 transition-colors flex items-center gap-1">
                    <ArrowUpRight className="w-3 h-3" />
                    {t("settings.changePlan")}
                  </button>
                </div>
              </div>

              <div className="flex items-baseline gap-2 mb-1">
                {subscription?.firstMonthDiscount ? (
                  <>
                    <span className="text-3xl text-white" style={{ fontWeight: 700 }}>${getDiscountedPrice(subscription.planId).discounted}</span>
                    <span className="text-sm text-zinc-500 line-through">${currentPlanData.price}</span>
                    <span className="text-sm text-zinc-500">{t("settings.perMonth")}</span>
                  </>
                ) : (
                  <>
                    <span className="text-3xl text-white" style={{ fontWeight: 700 }}>${currentPlanData.price}</span>
                    <span className="text-sm text-zinc-500">{t("settings.perMonth")}</span>
                  </>
                )}
              </div>
              {/* First-month discount banner */}
              {subscription?.status === "active" && subscription.firstMonthDiscount && (() => {
                const disc = getDiscountedPrice(subscription.planId);
                const pct = Math.round(subscription.firstMonthDiscount * 100);
                return (
                  <div className="mb-4 p-3 rounded-xl bg-cyan-500/[0.05] border border-cyan-500/15">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-cyan-500/15 flex items-center justify-center">
                          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                        </div>
                        <div>
                          <p className="text-xs text-cyan-400" style={{ fontWeight: 600 }}>
                            {t("settings.discountActive").replace("{pct}", `${pct}`)}
                          </p>
                          <p className="text-[10px] text-zinc-500">
                            {t("settings.discountDesc")}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-[10px] text-emerald-400/70">{t("grace.save")} ${disc.savings}/{t("grace.perMonth")}</p>
                      </div>
                    </div>
                  </div>
                );
              })()}
              {subscription?.status === "trial" && trialEndDate && (
                <div className="mb-4 p-3 rounded-xl bg-amber-500/[0.06] border border-amber-500/15">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-amber-400 flex items-center gap-1" style={{ fontWeight: 600 }}>
                      <Calendar className="w-3 h-3" />
                      {t("settings.trialEnds")}: {trialEndDate.toLocaleDateString()}
                    </span>
                    <span className="text-xs text-zinc-500">{trialDaysLeft}/{subscription.trialDays} {t("settings.trialDaysLeft")}</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-white/5 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${((subscription.trialDays - trialDaysLeft) / subscription.trialDays) * 100}%` }}
                      transition={{ duration: 0.8, ease: "easeOut" }}
                      className="h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-500"
                    />
                  </div>
                  <div className="flex items-center justify-between mt-1.5">
                    <span className="text-[10px] text-zinc-500">
                      {t("settings.afterTrial")}: ${currentPlanData.price}/mo
                    </span>
                    {subscription.gracePurchased && (
                      <span className="text-[10px] text-emerald-400/70 flex items-center gap-1">
                        <Gift className="w-2.5 h-2.5" />
                        {t("settings.gracePurchased")}
                      </span>
                    )}
                  </div>
                </div>
              )}
              <div className="flex items-center gap-3 text-xs text-zinc-500 mb-5">
                <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{t("settings.renewsOn")} {trialEndDate ? trialEndDate.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "Apr 15, 2026"}</span>
                <span>•</span>
                <span>{t("settings.nextInvoice")}: ${subscription?.firstMonthDiscount ? getDiscountedPrice(subscription.planId).discounted.toFixed(2) : `${currentPlanData.price}.00`}</span>
              </div>

              {/* Usage Stats */}
              <div className="grid grid-cols-3 gap-3">
                {(() => {
                  const progress = loadProgress();
                  const maxTokens = currentPlanData.tokens;
                  const tokensUsed = maxTokens - progress.tokensAvailable;
                  const maxProjects = currentPlanData.projects;
                  return [
                    { label: t("settings.tokensUsed"), value: `${Math.max(0, tokensUsed)}`, max: `${maxTokens}`, pct: Math.max(0, (tokensUsed / maxTokens) * 100), color: "from-purple-500 to-violet-500", icon: Coins },
                    { label: t("settings.projectsActive"), value: progress.projectCreated ? "1" : "0", max: maxProjects === 999 ? "∞" : `${maxProjects}`, pct: progress.projectCreated ? (1 / maxProjects) * 100 : 0, color: "from-cyan-500 to-blue-500", icon: Rocket },
                    { label: t("settings.channelsUsed"), value: progress.channelsConnected > 0 ? "12" : "0", max: currentPlanData.channels, pct: progress.channelsConnected > 0 ? 2.4 : 0, color: "from-emerald-500 to-green-500", icon: BarChart3 },
                  ];
                })().map((stat) => (
                  <div key={stat.label} className="p-3 rounded-xl bg-white/[0.03] border border-white/5">
                    <div className="flex items-center gap-1.5 mb-2">
                      <stat.icon className="w-3 h-3 text-zinc-500" />
                      <span className="text-[10px] text-zinc-500 truncate">{stat.label}</span>
                    </div>
                    <div className="flex items-baseline gap-1 mb-2">
                      <span className="text-sm text-white" style={{ fontWeight: 600 }}>{stat.value}</span>
                      <span className="text-[10px] text-zinc-600">/ {stat.max}</span>
                    </div>
                    <div className="w-full h-1 rounded-full bg-white/5 overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min(stat.pct, 100)}%` }}
                        transition={{ duration: 0.8, ease: "easeOut" }}
                        className={`h-full rounded-full bg-gradient-to-r ${stat.color}`}
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 pt-4 border-t border-white/5">
                <div className="text-[10px] text-zinc-600 mb-2" style={{ fontWeight: 600 }}>{t("settings.planIncludes")}</div>
                <div className="flex flex-wrap gap-1.5">
                  {[1, 2, 3].map((n) => {
                    const key = `pricing.${currentPlan}.f${n}` as any;
                    return <span key={n} className="text-[10px] px-2 py-0.5 rounded-full bg-white/[0.04] border border-white/5 text-zinc-400">{t(key)}</span>;
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* ─── Payment Method Card ─── */}
          <div className="p-5 rounded-xl border border-white/5 bg-white/[0.02]">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm text-white" style={{ fontWeight: 600 }}>{t("settings.paymentMethod")}</h3>
              <button className="text-xs text-purple-400 hover:text-purple-300 transition-colors">Edit</button>
            </div>
            <div className="flex items-center gap-3 p-3.5 rounded-xl bg-white/[0.03] border border-white/5">
              <div className="w-10 h-7 rounded-md bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center">
                <CreditCard className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm text-zinc-300" style={{ fontWeight: 500 }}>•••• •••• •••• {subscription?.cardLast4 || "4242"}</div>
                <div className="text-[10px] text-zinc-600">{subscription?.cardBrand || "Visa"} · {t("settings.expires")} {subscription?.cardExpiry || "12/27"}</div>
              </div>
              <Check className="w-4 h-4 text-emerald-400" />
            </div>
          </div>

          {/* ─── Billing History ─── */}
          <div className="p-5 rounded-xl border border-white/5 bg-white/[0.02]">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm text-white" style={{ fontWeight: 600 }}>{t("settings.billingHistory")}</h3>
            </div>
            <div className="space-y-2">
              {[
                { date: "Mar 15, 2026", amount: `$${currentPlanData.price}.00`, status: "Paid", id: "LOS-2026-003" },
                { date: "Feb 15, 2026", amount: `$${currentPlanData.price}.00`, status: "Paid", id: "LOS-2026-002" },
                { date: "Jan 15, 2026", amount: `$${currentPlanData.price}.00`, status: "Paid", id: "LOS-2026-001" },
              ].map((inv) => (
                <div key={inv.id} className="flex items-center justify-between py-2.5 px-3 rounded-lg hover:bg-white/[0.02] transition-colors group">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-zinc-300" style={{ fontWeight: 500 }}>{t(planNameKey)}</span>
                        <span className="text-[10px] text-zinc-600 font-mono">{inv.id}</span>
                      </div>
                      <div className="text-[10px] text-zinc-600">{inv.date}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-white" style={{ fontWeight: 500 }}>{inv.amount}</span>
                    <button
                      onClick={() => handleDownloadInvoice(inv.date, inv.amount, inv.id)}
                      className="w-7 h-7 rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100 hover:bg-purple-500/10 transition-all"
                      title={t("settings.downloadInvoice")}
                    >
                      <Download className="w-3.5 h-3.5 text-purple-400" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ─── Cancel / Reactivate Subscription ─── */}
          <div className="p-5 rounded-xl border border-white/5 bg-white/[0.02]">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm text-zinc-400" style={{ fontWeight: 500 }}>{t("settings.cancelSubscription")}</h3>
              </div>
              {subscription?.status === "cancelled" ? (
                <button
                  onClick={handleReactivate}
                  className="text-xs text-emerald-400 border border-emerald-500/20 px-3.5 py-2 rounded-lg hover:bg-emerald-500/5 transition-all flex items-center gap-1"
                >
                  <Play className="w-3 h-3" />
                  {t("settings.reactivate")}
                </button>
              ) : (
                <button
                  onClick={handleOpenCancel}
                  className="text-xs text-red-400/70 border border-red-500/15 px-3.5 py-2 rounded-lg hover:bg-red-500/5 hover:text-red-400 transition-all"
                >
                  {t("settings.cancelSubscription")}
                </button>
              )}
            </div>
          </div>

          {/* ─── Cancel Subscription Modal ─── */}
          <AnimatePresence>
            {showCancelModal && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
                onClick={() => setShowCancelModal(false)}
                role="dialog"
                aria-modal="true"
                aria-label={t("settings.cancelSubscription")}
              >
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: 20 }}
                  className="w-full max-w-md rounded-2xl border border-white/10 bg-zinc-900 p-6 space-y-5"
                  onClick={(e) => e.stopPropagation()}
                >
                  {/* Step 1: Reason */}
                  {cancelStep === "reason" && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center">
                            <AlertTriangle className="w-5 h-5 text-red-400" />
                          </div>
                          <div>
                            <h2 className="text-white" style={{ fontWeight: 700 }}>{t("settings.cancelTitle")}</h2>
                            <p className="text-xs text-zinc-500 mt-0.5">{t("settings.cancelDesc")}</p>
                          </div>
                        </div>
                        <button onClick={() => setShowCancelModal(false)} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 transition-colors">
                          <X className="w-4 h-4 text-zinc-500" />
                        </button>
                      </div>

                      <div>
                        <div className="text-xs text-zinc-400 mb-3" style={{ fontWeight: 500 }}>{t("settings.cancelReason")}</div>
                        <div className="space-y-2">
                          {(["cancelReason1", "cancelReason2", "cancelReason3", "cancelReason4", "cancelReason5"] as const).map((rKey) => (
                            <button
                              key={rKey}
                              onClick={() => setCancelReason(rKey)}
                              className={`w-full text-left px-4 py-3 rounded-xl border text-sm transition-all ${
                                cancelReason === rKey
                                  ? "border-red-500/30 bg-red-500/[0.05] text-red-300"
                                  : "border-white/5 bg-white/[0.02] text-zinc-400 hover:border-white/10"
                              }`}
                            >
                              {t(`settings.${rKey}`)}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="flex gap-2 pt-2">
                        <button
                          onClick={() => setShowCancelModal(false)}
                          className="flex-1 py-2.5 rounded-xl border border-white/10 text-sm text-zinc-400 hover:text-zinc-200 hover:bg-white/5 transition-all"
                        >
                          {t("settings.keepSubscription")}
                        </button>
                        <button
                          onClick={() => cancelReason && setCancelStep("retention")}
                          disabled={!cancelReason}
                          className="flex-1 py-2.5 rounded-xl bg-red-600/80 hover:bg-red-600 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm transition-all"
                        >
                          {t("settings.continueCancelling")}
                        </button>
                      </div>
                    </motion.div>
                  )}

                  {/* Step 2: Retention offer */}
                  {cancelStep === "retention" && (
                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
                            <Gift className="w-5 h-5 text-purple-400" />
                          </div>
                          <div>
                            <h2 className="text-white" style={{ fontWeight: 700 }}>{t("settings.retentionTitle")}</h2>
                          </div>
                        </div>
                        <button onClick={() => setShowCancelModal(false)} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 transition-colors">
                          <X className="w-4 h-4 text-zinc-500" />
                        </button>
                      </div>

                      <div className="space-y-3">
                        {/* Discount offer */}
                        <button
                          onClick={() => setRetentionChoice("discount")}
                          className={`w-full text-left p-4 rounded-xl border transition-all ${
                            retentionChoice === "discount"
                              ? "border-purple-500/30 bg-purple-500/[0.05]"
                              : "border-white/5 bg-white/[0.02] hover:border-white/10"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-lg bg-emerald-500/10 flex items-center justify-center shrink-0">
                              <Heart className="w-4 h-4 text-emerald-400" />
                            </div>
                            <div>
                              <div className="text-sm text-white" style={{ fontWeight: 600 }}>{t("settings.retentionDiscount")}</div>
                              <div className="text-xs text-zinc-500 mt-0.5">{t("settings.retentionDiscountDesc")}</div>
                              <div className="flex items-center gap-2 mt-2">
                                <span className="text-xs text-zinc-600 line-through">${currentPlanData.price}/mo</span>
                                <span className="text-sm text-emerald-400" style={{ fontWeight: 700 }}>${Math.round(currentPlanData.price / 2)}/mo</span>
                                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20" style={{ fontWeight: 600 }}>-50%</span>
                              </div>
                            </div>
                          </div>
                        </button>

                        {/* Pause offer */}
                        <button
                          onClick={() => setRetentionChoice("pause")}
                          className={`w-full text-left p-4 rounded-xl border transition-all ${
                            retentionChoice === "pause"
                              ? "border-purple-500/30 bg-purple-500/[0.05]"
                              : "border-white/5 bg-white/[0.02] hover:border-white/10"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-lg bg-amber-500/10 flex items-center justify-center shrink-0">
                              <Pause className="w-4 h-4 text-amber-400" />
                            </div>
                            <div>
                              <div className="text-sm text-white" style={{ fontWeight: 600 }}>{t("settings.retentionPause")}</div>
                              <div className="text-xs text-zinc-500 mt-0.5">{t("settings.retentionPauseDesc")}</div>
                            </div>
                          </div>
                        </button>
                      </div>

                      <div className="flex gap-2 pt-2">
                        <button
                          onClick={() => setCancelStep("final")}
                          className="flex-1 py-2.5 rounded-xl border border-white/10 text-sm text-zinc-500 hover:text-zinc-300 hover:bg-white/5 transition-all"
                        >
                          {t("settings.continueCancelling")}
                        </button>
                        <button
                          onClick={handleAcceptRetention}
                          disabled={!retentionChoice}
                          className="flex-1 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm transition-all flex items-center justify-center gap-2"
                        >
                          <Sparkles className="w-4 h-4" />
                          {t("settings.acceptOffer")}
                        </button>
                      </div>
                    </motion.div>
                  )}

                  {/* Step 3: Final confirmation */}
                  {cancelStep === "final" && (
                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center">
                            <AlertTriangle className="w-5 h-5 text-red-400" />
                          </div>
                          <div>
                            <h2 className="text-white" style={{ fontWeight: 700 }}>{t("settings.cancelFinalTitle")}</h2>
                          </div>
                        </div>
                        <button onClick={() => setShowCancelModal(false)} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 transition-colors">
                          <X className="w-4 h-4 text-zinc-500" />
                        </button>
                      </div>

                      <p className="text-sm text-zinc-400">{t("settings.cancelFinalDesc")}</p>

                      <div className="p-4 rounded-xl border border-white/5 bg-white/[0.02]">
                        <div className="flex items-center gap-3">
                          <currentPlanData.icon className={`w-5 h-5 ${currentPlanData.iconColor}`} />
                          <div>
                            <div className="text-sm text-white" style={{ fontWeight: 500 }}>{t(planNameKey)}</div>
                            <div className="text-xs text-zinc-500">{t("settings.renewsOn")} Apr 15, 2026</div>
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-2 pt-2">
                        <button
                          onClick={() => setCancelStep("retention")}
                          className="flex-1 py-2.5 rounded-xl border border-white/10 text-sm text-zinc-400 hover:text-zinc-200 hover:bg-white/5 transition-all flex items-center justify-center gap-1"
                        >
                          {t("settings.goBack")}
                        </button>
                        <button
                          onClick={handleConfirmCancel}
                          className="flex-1 py-2.5 rounded-xl bg-red-600/80 hover:bg-red-600 text-white text-sm transition-all"
                        >
                          {t("settings.confirmCancel")}
                        </button>
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* ─── Plan Change Modal ─── */}
          <AnimatePresence>
            {showPlanModal && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
                onClick={() => setShowPlanModal(false)}
                role="dialog"
                aria-modal="true"
                aria-label={t("pricing.title")}
              >
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: 20 }}
                  className="w-full max-w-lg rounded-2xl border border-white/10 bg-zinc-900 p-6 space-y-5"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-white" style={{ fontWeight: 700 }}>{t("settings.changePlan")}</h2>
                      <p className="text-xs text-zinc-500 mt-0.5">{t("settings.changePlanDesc")}</p>
                    </div>
                    <button onClick={() => setShowPlanModal(false)} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 transition-colors">
                      <X className="w-4 h-4 text-zinc-500" />
                    </button>
                  </div>

                  <div className="space-y-3">
                    {PLANS.map((plan) => {
                      const isCurrent = plan.id === currentPlan;
                      const isSelected = selectedPlan === plan.id;
                      const pName = plan.id === "starter" ? t("pricing.starter") : plan.id === "viral" ? t("pricing.viral") : t("pricing.growth");
                      const isDowngrade = plan.price < currentPlanData.price;
                      const isUpgrade = plan.price > currentPlanData.price;

                      return (
                        <button
                          key={plan.id}
                          onClick={() => !isCurrent && setSelectedPlan(plan.id)}
                          disabled={isCurrent}
                          className={`w-full p-4 rounded-xl border text-left transition-all ${
                            isCurrent
                              ? "border-emerald-500/20 bg-emerald-500/[0.03] cursor-default"
                              : isSelected
                              ? "border-purple-500/30 bg-purple-500/[0.05]"
                              : "border-white/5 bg-white/[0.02] hover:border-white/10"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${plan.gradient} border ${plan.border} flex items-center justify-center`}>
                              <plan.icon className={`w-5 h-5 ${plan.iconColor}`} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="text-sm text-white" style={{ fontWeight: 600 }}>{pName}</span>
                                {isCurrent && (
                                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20" style={{ fontWeight: 600 }}>
                                    {t("settings.currentPlanBadge")}
                                  </span>
                                )}
                                {!isCurrent && isUpgrade && (
                                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/15 text-purple-400 border border-purple-500/20" style={{ fontWeight: 600 }}>
                                    {t("settings.upgrade")}
                                  </span>
                                )}
                                {!isCurrent && isDowngrade && (
                                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/20" style={{ fontWeight: 600 }}>
                                    {t("settings.downgrade")}
                                  </span>
                                )}
                              </div>
                              <div className="text-xs text-zinc-500 mt-0.5">{plan.tokens} tokens · {plan.projects === 999 ? "∞" : plan.projects} projects · {plan.channels} channels</div>
                            </div>
                            <div className="text-right shrink-0">
                              <span className="text-white" style={{ fontWeight: 700 }}>${plan.price}</span>
                              <span className="text-xs text-zinc-500">{t("settings.perMonth")}</span>
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  <AnimatePresence>
                    {selectedPlan && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="space-y-3"
                      >
                        <div className="flex items-center gap-2 p-3 rounded-lg bg-white/[0.02] border border-white/5">
                          <Calendar className="w-3.5 h-3.5 text-zinc-500" />
                          <span className="text-xs text-zinc-400">{t("settings.priceAdjust")}</span>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setShowPlanModal(false)}
                            className="flex-1 py-2.5 rounded-xl border border-white/10 text-sm text-zinc-400 hover:text-zinc-200 hover:bg-white/5 transition-all"
                          >
                            {t("settings.cancelChange")}
                          </button>
                          <button
                            onClick={() => handleChangePlan(selectedPlan)}
                            className="flex-1 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-sm transition-all flex items-center justify-center gap-2"
                          >
                            <Sparkles className="w-4 h-4" />
                            {t("settings.confirmChange")}
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}

      {activeTab === "levels" && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <div className="p-6 rounded-xl border border-white/5 bg-white/[0.02]">
            <div className="flex items-center gap-3 mb-4">
              <Award className="w-6 h-6 text-purple-400" />
              <div><div className="text-white" style={{ fontWeight: 600 }}>Growth Hacker — {t("dash.level")} 3</div><div className="text-xs text-zinc-500">2,450 / 5,000 {t("settings.pointsToNext")}</div></div>
            </div>
            <div className="w-full h-2 rounded-full bg-white/5 overflow-hidden mb-6"><div className="h-full rounded-full bg-gradient-to-r from-purple-500 to-cyan-500 w-[49%]" /></div>
            <div className="space-y-3">
              {levels.map((level, i) => (
                <div key={level.name} className={`flex items-center gap-3 p-3 rounded-lg ${level.current ? "bg-purple-500/10 border border-purple-500/20" : "border border-transparent"}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs ${levels.findIndex((l) => l.current) >= i ? "bg-purple-500/20 text-purple-400" : "bg-white/5 text-zinc-600"}`} style={{ fontWeight: 700 }}>{i + 1}</div>
                  <div className="flex-1"><div className={`text-sm ${level.current ? "text-purple-400" : "text-zinc-400"}`} style={{ fontWeight: 500 }}>{level.name}</div><div className="text-xs text-zinc-600">{level.points.toLocaleString()} {t("settings.pointsRequired")}</div></div>
                  {levels.findIndex((l) => l.current) >= i && <Check className="w-4 h-4 text-emerald-400" />}
                </div>
              ))}
            </div>
          </div>
          <div className="p-5 rounded-xl border border-white/5 bg-white/[0.02]">
            <h3 className="text-sm text-white mb-3" style={{ fontWeight: 600 }}>{t("settings.howToEarn")}</h3>
            <div className="grid sm:grid-cols-3 gap-3 text-xs">
              {[
                { action: t("settings.launchProject"), points: "+100" },
                { action: t("settings.get50upvotes"), points: "+200" },
                { action: t("settings.generateTraffic"), points: "+50/1K" },
              ].map((item) => (
                <div key={item.action} className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02] border border-white/5">
                  <span className="text-zinc-400">{item.action}</span><span className="text-purple-400" style={{ fontWeight: 600 }}>{item.points}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {activeTab === "debug" && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          {/* Skip to Step */}
          <div className="p-5 rounded-xl border border-amber-500/15 bg-amber-500/[0.03]">
            <div className="flex items-center gap-2 mb-3">
              <SkipForward className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm text-amber-300" style={{ fontWeight: 600 }}>Skip to Step</h3>
            </div>
            <p className="text-xs text-zinc-500 mb-4">Instantly populate localStorage with mock data up to the selected step. Useful for testing any step in isolation.</p>
            <div className="grid grid-cols-5 gap-2">
              {[
                { step: 1, label: "Project" },
                { step: 2, label: "Package" },
                { step: 3, label: "Channels" },
                { step: 4, label: "Launch" },
                { step: 5, label: "Track" },
              ].map(({ step, label }) => (
                <button
                  key={step}
                  onClick={() => debugSkipToStep(step)}
                  className="flex flex-col items-center gap-1.5 p-3 rounded-xl border border-white/5 hover:border-purple-500/30 hover:bg-purple-500/[0.05] transition-all group"
                >
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-white/[0.05] group-hover:bg-purple-500/15 text-zinc-400 group-hover:text-purple-400 text-sm transition-all" style={{ fontWeight: 700 }}>{step}</div>
                  <span className="text-[10px] text-zinc-500 group-hover:text-zinc-300 transition-colors">{label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Run full E2E */}
          <div className="p-5 rounded-xl border border-emerald-500/15 bg-emerald-500/[0.03]">
            <div className="flex items-center gap-2 mb-3">
              <Play className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm text-emerald-300" style={{ fontWeight: 600 }}>Run Full E2E</h3>
            </div>
            <p className="text-xs text-zinc-500 mb-4">Resets all data, then walks through steps 1-5 with animated delays. Watch the sidebar progress update in real-time.</p>

            {/* Progress visualisation */}
            {e2eRunning && (
              <div className="mb-4 space-y-3">
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <div key={s} className="flex-1 h-1.5 rounded-full overflow-hidden bg-white/[0.06]">
                      <motion.div
                        initial={{ width: "0%" }}
                        animate={{
                          width: e2eStep > s ? "100%" : e2eStep === s ? "60%" : "0%",
                        }}
                        transition={{ duration: 0.4, ease: "easeOut" }}
                        className={`h-full rounded-full ${
                          e2eStep > s
                            ? "bg-emerald-500"
                            : e2eStep === s
                            ? "bg-emerald-500/60"
                            : ""
                        }`}
                      />
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-2">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                    className="w-4 h-4 rounded-full border-2 border-emerald-500/30 border-t-emerald-400"
                  />
                  <span className="text-xs text-emerald-300" style={{ fontWeight: 500 }}>
                    Step {Math.min(e2eStep, 5)}/5: {e2eStepLabels[Math.min(e2eStep, 5)] || ""}
                  </span>
                </div>
              </div>
            )}

            {e2eStep === 6 && !e2eRunning && (
              <div className="mb-4 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs text-emerald-300" style={{ fontWeight: 600 }}>All 5 steps completed successfully</span>
                </div>
              </div>
            )}

            {/* E2E Log entries */}
            {e2eLog.length > 0 && (
              <div className="mb-4 space-y-1">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-zinc-500" />
                    <span className="text-[11px] text-zinc-500" style={{ fontWeight: 600 }}>Run Log</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-white/5 text-zinc-600" style={{ fontWeight: 600 }}>
                      {e2eLog.length}/5
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {e2eLog.length >= 2 && (
                      <button
                        onClick={() => { setCompareMode(!compareMode); setCompareA(0); setCompareB(Math.min(1, e2eLog.length - 1)); }}
                        className={`flex items-center gap-1.5 text-[11px] transition-colors ${
                          compareMode ? "text-purple-400" : "text-zinc-500 hover:text-zinc-300"
                        }`}
                      >
                        <ArrowRight className="w-3 h-3" />
                        Compare
                      </button>
                    )}
                    <button
                      onClick={exportE2ELog}
                      className="flex items-center gap-1.5 text-[11px] text-zinc-500 hover:text-emerald-400 transition-colors"
                    >
                      <FileDown className="w-3 h-3" />
                      Export
                    </button>
                  </div>
                </div>

                {/* Step rows */}
                {e2eLog.map((entry, i) => (
                  <div key={i}>
                    <button
                      onClick={() => setE2eExpandedSnap(e2eExpandedSnap === i ? null : i)}
                      className={`w-full flex items-center gap-2 py-2 px-3 rounded-xl text-xs transition-all cursor-pointer ${
                        e2eExpandedSnap === i
                          ? "bg-white/[0.04] border border-white/10"
                          : "bg-white/[0.02] border border-transparent hover:bg-white/[0.04] hover:border-white/5"
                      }`}
                    >
                      <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] ${
                        entry.status === "pass" ? "bg-emerald-500/15 text-emerald-400" :
                        entry.status === "fail" ? "bg-red-500/15 text-red-400" :
                        "bg-amber-500/15 text-amber-400"
                      }`} style={{ fontWeight: 700 }}>{entry.step}</span>
                      <span className="flex-1 text-zinc-300 text-left">{entry.label.replace("...", "")}</span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                        entry.status === "pass" ? "bg-emerald-500/10 text-emerald-400" :
                        entry.status === "fail" ? "bg-red-500/10 text-red-400" :
                        "bg-amber-500/10 text-amber-400"
                      }`} style={{ fontWeight: 600 }}>{entry.status.toUpperCase()}</span>
                      <span className="text-zinc-600 tabular-nums text-[10px]">{(entry.durationMs / 1000).toFixed(1)}s</span>
                      <ChevronDown className={`w-3 h-3 text-zinc-600 transition-transform ${e2eExpandedSnap === i ? "" : "-rotate-90"}`} />
                    </button>

                    <AnimatePresence>
                      {e2eExpandedSnap === i && (() => {
                        const prevSnap = i > 0 ? e2eLog[i - 1].snapshot : {};
                        const diff = computeSnapshotDiff(prevSnap, entry.snapshot);
                        return (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.25, ease: [0.4, 0, 0.2, 1] }}
                            className="overflow-hidden"
                          >
                            <div className="ml-3 mr-1 mt-1.5 mb-2 p-3 rounded-xl bg-black/30 border border-white/[0.06] backdrop-blur-sm">
                              {/* Header */}
                              <div className="flex items-center justify-between mb-3">
                                <div className="flex items-center gap-2">
                                  <Database className="w-3 h-3 text-zinc-500" />
                                  <span className="text-[10px] text-zinc-400" style={{ fontWeight: 600 }}>
                                    {diff.length > 0 ? `Changes vs ${i === 0 ? "initial" : `Step ${i}`}` : "Snapshot (no changes)"}
                                  </span>
                                  {diff.length > 0 && (
                                    <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 tabular-nums" style={{ fontWeight: 600 }}>
                                      {diff.filter(x => x.type === "added").length > 0 && `+${diff.filter(x => x.type === "added").length}`}
                                      {diff.filter(x => x.type === "changed").length > 0 && ` ~${diff.filter(x => x.type === "changed").length}`}
                                      {diff.filter(x => x.type === "removed").length > 0 && ` -${diff.filter(x => x.type === "removed").length}`}
                                    </span>
                                  )}
                                </div>
                                <button
                                  onClick={(ev) => { ev.stopPropagation(); confirmRestore(i); }}
                                  className="flex items-center gap-1 text-[10px] px-2 py-1 rounded-lg text-violet-400 hover:text-violet-300 hover:bg-violet-500/10 transition-all"
                                  title="Restore this snapshot to localStorage"
                                >
                                  <RotateCcw className="w-3 h-3" />
                                  Restore
                                </button>
                              </div>

                              {/* Diff entries */}
                              <div className="max-h-52 overflow-y-auto pr-1">
                                {renderDiffBlock(diff)}
                              </div>

                              {/* Raw JSON toggle */}
                              {diff.length === 0 && (
                                <pre className="text-[10px] text-zinc-600 whitespace-pre-wrap break-all max-h-32 overflow-y-auto leading-relaxed mt-2 p-2 rounded-lg bg-black/20">
                                  {JSON.stringify(entry.snapshot, null, 2)}
                                </pre>
                              )}
                            </div>
                          </motion.div>
                        );
                      })()}
                    </AnimatePresence>
                  </div>
                ))}

                {/* Footer stats */}
                {!e2eRunning && (
                  <div className="pt-2 flex items-center justify-between text-[10px] text-zinc-600 px-3">
                    <span className="tabular-nums">
                      {e2eLog.filter(e => e.status === "pass").length} passed
                      {e2eLog.filter(e => e.status === "fail").length > 0 && `, ${e2eLog.filter(e => e.status === "fail").length} failed`}
                      {e2eLog.filter(e => e.status === "abort").length > 0 && `, ${e2eLog.filter(e => e.status === "abort").length} aborted`}
                    </span>
                    <span className="tabular-nums">{(e2eLog.reduce((s, e) => s + e.durationMs, 0) / 1000).toFixed(1)}s total</span>
                  </div>
                )}
              </div>
            )}

            {/* Compare Any Two Steps */}
            <AnimatePresence>
              {compareMode && e2eLog.length >= 2 && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.25 }}
                  className="overflow-hidden"
                >
                  <div className="mb-4 p-4 rounded-xl border border-purple-500/15 bg-purple-500/[0.03]">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <ArrowRight className="w-4 h-4 text-purple-400" />
                        <h4 className="text-sm text-purple-300" style={{ fontWeight: 600 }}>Compare Steps</h4>
                      </div>
                      <button
                        onClick={() => setCompareMode(false)}
                        className="w-6 h-6 rounded-lg flex items-center justify-center hover:bg-white/5 transition-colors"
                      >
                        <X className="w-3.5 h-3.5 text-zinc-500" />
                      </button>
                    </div>

                    <div className="flex items-center gap-3 mb-4">
                      <div className="flex-1">
                        <label className="text-[10px] text-zinc-500 mb-1 block" style={{ fontWeight: 600 }}>Step A (base)</label>
                        <select
                          value={compareA}
                          onChange={(ev) => setCompareA(Number(ev.target.value))}
                          className="w-full bg-black/30 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-zinc-300 outline-none focus:border-purple-500/30 transition-colors"
                        >
                          {e2eLog.map((entry, idx) => (
                            <option key={idx} value={idx}>
                              Step {entry.step}: {entry.label.replace("...", "")}
                            </option>
                          ))}
                        </select>
                      </div>
                      <ArrowRight className="w-4 h-4 text-purple-500/50 mt-4 shrink-0" />
                      <div className="flex-1">
                        <label className="text-[10px] text-zinc-500 mb-1 block" style={{ fontWeight: 600 }}>Step B (target)</label>
                        <select
                          value={compareB}
                          onChange={(ev) => setCompareB(Number(ev.target.value))}
                          className="w-full bg-black/30 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-zinc-300 outline-none focus:border-purple-500/30 transition-colors"
                        >
                          {e2eLog.map((entry, idx) => (
                            <option key={idx} value={idx}>
                              Step {entry.step}: {entry.label.replace("...", "")}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {compareA === compareB ? (
                      <div className="text-[11px] text-zinc-600 text-center py-3 italic">Select two different steps to compare</div>
                    ) : (() => {
                      const cDiff = computeSnapshotDiff(e2eLog[compareA].snapshot, e2eLog[compareB].snapshot);
                      return (
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-[10px] text-zinc-500" style={{ fontWeight: 600 }}>
                              Step {e2eLog[compareA].step} vs Step {e2eLog[compareB].step}
                            </span>
                            {cDiff.length > 0 && (
                              <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-purple-500/10 text-purple-400" style={{ fontWeight: 600 }}>
                                {cDiff.length} {cDiff.length === 1 ? "change" : "changes"}
                              </span>
                            )}
                          </div>
                          <div className="max-h-60 overflow-y-auto pr-1">
                            {renderDiffBlock(cDiff)}
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex gap-3">
              {!e2eRunning ? (
                <button
                  onClick={runFullE2E}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 hover:bg-emerald-500/15 hover:border-emerald-500/30 text-sm text-emerald-400 transition-all"
                >
                  <Play className="w-4 h-4" />
                  Run E2E Sequence
                </button>
              ) : (
                <button
                  onClick={abortE2E}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-red-500/10 border border-red-500/20 hover:bg-red-500/15 hover:border-red-500/30 text-sm text-red-400 transition-all"
                >
                  <Pause className="w-4 h-4" />
                  Abort
                </button>
              )}
            </div>
          </div>

          {/* LaunchDay Control */}
          <div className="p-5 rounded-xl border border-cyan-500/15 bg-cyan-500/[0.03]">
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm text-cyan-300" style={{ fontWeight: 600 }}>Launch Day Simulator</h3>
            </div>
            <p className="text-xs text-zinc-500 mb-4">Set launchDay to any value (0-7). Auto-advances +1 every 2 min in demo mode when launched.</p>
            <div className="flex gap-2 flex-wrap">
              {[0, 1, 2, 3, 4, 5, 6, 7].map((d) => (
                <button
                  key={d}
                  onClick={() => debugSetDay(d)}
                  className={`px-3.5 py-2 rounded-lg text-xs transition-all border ${
                    debugProgress.launchDay === d
                      ? "bg-cyan-500/15 border-cyan-500/30 text-cyan-300"
                      : "bg-white/[0.02] border-white/5 text-zinc-400 hover:border-cyan-500/20 hover:text-cyan-400"
                  }`}
                  style={{ fontWeight: 600 }}
                >
                  Day {d}
                </button>
              ))}
            </div>
          </div>

          {/* Current State Inspector */}
          <div className="p-5 rounded-xl border border-white/5 bg-white/[0.02]">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Bug className="w-4 h-4 text-zinc-400" />
                <h3 className="text-sm text-white" style={{ fontWeight: 600 }}>State Inspector</h3>
              </div>
              <button onClick={refreshDebug} className="text-[11px] text-purple-400 hover:text-purple-300 flex items-center gap-1 transition-colors">
                <RefreshCw className="w-3 h-3" />
                Refresh
              </button>
            </div>
            <div className="space-y-2 text-xs">
              {[
                { key: "projectCreated", value: String(debugProgress.projectCreated) },
                { key: "projectName", value: debugProgress.projectName || "(empty)" },
                { key: "channelsConnected", value: String(debugProgress.channelsConnected) },
                { key: "launched", value: String(debugProgress.launched) },
                { key: "launchDay", value: String(debugProgress.launchDay) },
                { key: "tokensAvailable", value: String(debugProgress.tokensAvailable) },
                { key: "onboardingCompleted", value: String(debugProgress.onboardingCompleted) },
                { key: "lastCompletedStep", value: String(debugProgress.lastCompletedStep) },
              ].map(({ key, value }) => (
                <div key={key} className="flex items-center justify-between py-1.5 px-3 rounded-lg bg-white/[0.02]">
                  <code className="text-zinc-500">{key}</code>
                  <code className={`${value === "true" ? "text-emerald-400" : value === "false" || value === "0" || value === "(empty)" ? "text-zinc-600" : "text-purple-300"}`}>{value}</code>
                </div>
              ))}
              <div className="flex items-center justify-between py-1.5 px-3 rounded-lg bg-white/[0.02]">
                <code className="text-zinc-500">package_generated</code>
                <code className={localStorage.getItem(LS_KEYS.packageGenerated) ? "text-emerald-400" : "text-zinc-600"}>{localStorage.getItem(LS_KEYS.packageGenerated) ? "yes" : "no"}</code>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex gap-3 flex-wrap">
            <button
              onClick={() => {
                updateProgress({ tokensAvailable: 5000 });
                refreshDebug();
                toast.success("Tokens set to 5000");
              }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-purple-500/20 hover:border-purple-500/40 hover:bg-purple-500/[0.05] text-sm text-purple-400 transition-all"
            >
              <Coins className="w-4 h-4" />
              +5000 Tokens
            </button>
            <button
              onClick={() => {
                // Fire progress event to refresh Layout sidebar
                document.dispatchEvent(new CustomEvent("launchapp:progress", { detail: loadProgress() }));
                toast.success("Layout refreshed");
              }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-cyan-500/20 hover:border-cyan-500/40 hover:bg-cyan-500/[0.05] text-sm text-cyan-400 transition-all"
            >
              <RefreshCw className="w-4 h-4" />
              Force Layout Refresh
            </button>
          </div>
        </motion.div>
      )}

      {/* ─── Restore Confirmation Dialog ─── */}
      <AnimatePresence>
        {restoreConfirmIdx !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            onClick={() => setRestoreConfirmIdx(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="w-full max-w-sm rounded-2xl border border-white/10 bg-[#0f0f11] p-5 space-y-4"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <h3 className="text-white" style={{ fontWeight: 600 }}>Restore Snapshot</h3>
                  <p className="text-xs text-zinc-500 mt-0.5">Step {e2eLog[restoreConfirmIdx]?.step || "?"}</p>
                </div>
              </div>
              <p className="text-sm text-zinc-400">
                This will replace all <code className="text-purple-400 bg-purple-500/10 px-1 rounded text-xs">launchapp_*</code> keys in localStorage with this snapshot. Current state will be lost.
              </p>
              <div className="flex gap-2 justify-end pt-1">
                <button
                  onClick={() => setRestoreConfirmIdx(null)}
                  className="px-4 py-2 rounded-xl text-sm text-zinc-400 hover:text-zinc-300 hover:bg-white/5 transition-all"
                >
                  Cancel
                </button>
                <button
                  onClick={executeRestore}
                  className="px-4 py-2 rounded-xl text-sm text-violet-300 bg-violet-500/15 border border-violet-500/20 hover:bg-violet-500/25 hover:border-violet-500/30 transition-all flex items-center gap-2"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Restore
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── Onboarding Video Modal ─── */}
      <AnimatePresence>
        {showOnboarding && (
          <OnboardingVideo onClose={() => setShowOnboarding(false)} />
        )}
      </AnimatePresence>

      {/* ─── Avatar Picker Modal ─── */}
      <AnimatePresence>
        {showAvatarPicker && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowAvatarPicker(false)}
            role="dialog"
            aria-modal="true"
            aria-label={t("settings.changeAvatar")}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="w-full max-w-sm rounded-2xl border border-white/10 bg-[#0f0f11] p-5 sm:p-6 space-y-4"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-white" style={{ fontWeight: 700 }}>{t("settings.changeAvatar")}</h2>
                  <p className="text-xs text-zinc-500 mt-0.5">{t("settings.changeAvatarDesc")}</p>
                </div>
                <button onClick={() => setShowAvatarPicker(false)} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 transition-colors">
                  <X className="w-4 h-4 text-zinc-500" />
                </button>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-xl bg-purple-500/[0.05] border border-purple-500/15">
                <img src={avatarUrl} alt="Current" className="w-12 h-12 rounded-xl object-cover" />
                <div>
                  <div className="text-sm text-white" style={{ fontWeight: 500 }}>{t("settings.currentAvatar")}</div>
                  <div className="text-[11px] text-zinc-500">{t("settings.tapToChange")}</div>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2.5">
                {AVATAR_OPTIONS.map((url, i) => (
                  <button
                    key={i}
                    onClick={() => handleAvatarChange(url)}
                    className={`relative rounded-xl overflow-hidden aspect-square transition-all ${
                      avatarUrl === url
                        ? "ring-2 ring-purple-500 ring-offset-2 ring-offset-[#0f0f11]"
                        : "hover:ring-1 hover:ring-white/20"
                    }`}
                  >
                    <img src={url} alt={`Avatar ${i + 1}`} className="w-full h-full object-cover" />
                    {avatarUrl === url && (
                      <div className="absolute inset-0 bg-purple-500/20 flex items-center justify-center">
                        <Check className="w-5 h-5 text-white drop-shadow" />
                      </div>
                    )}
                  </button>
                ))}
              </div>

              <label className="flex items-center gap-3 p-3.5 rounded-xl border border-dashed border-white/10 hover:border-purple-500/30 hover:bg-purple-500/[0.03] transition-all cursor-pointer">
                <div className="w-9 h-9 rounded-xl bg-white/[0.05] flex items-center justify-center shrink-0">
                  <Camera className="w-4 h-4 text-zinc-400" />
                </div>
                <div>
                  <div className="text-sm text-zinc-300" style={{ fontWeight: 500 }}>{t("settings.uploadAvatar")}</div>
                  <div className="text-[10px] text-zinc-600">JPG, PNG, max 5MB</div>
                </div>
                <input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />
              </label>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── Reset All Data (Danger) ─── */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="p-5 rounded-xl border border-red-500/10 bg-red-500/[0.02]"
      >
        <h3 className="text-sm text-red-400 mb-1" style={{ fontWeight: 600 }}>{t("settings.resetAll")}</h3>
        <p className="text-xs text-zinc-500 mb-4">{t("settings.resetAllDesc")}</p>
        <button
          onClick={() => {
            if (window.confirm(t("settings.resetAllConfirm"))) {
              resetAllData(true);
              toast.success(t("settings.resetAllDone"));
              setTimeout(() => window.location.replace("/"), 500);
            }
          }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-red-500/20 hover:border-red-500/40 hover:bg-red-500/5 text-sm text-red-400 transition-all"
        >
          <AlertTriangle className="w-4 h-4" />
          {t("settings.resetAll")}
        </button>
      </motion.div>
    </div>
  );
}