import { motion } from "motion/react";

/**
 * iOS-style skeleton shimmer system for page/section transitions.
 * Uses CSS class `skeleton-shimmer` from theme.css for light-mode compat,
 * plus motion for staggered reveal.
 */

/* ── Base shimmer bar ── */
function Shimmer({ className = "", style }: { className?: string; style?: React.CSSProperties }) {
  return (
    <div
      className={`relative overflow-hidden rounded-[14px] bg-white/[0.03] skeleton-shimmer ${className}`}
      style={style}
    />
  );
}

/* ── Staggered wrapper ── */
function Stagger({
  children,
  className = "",
  stagger = 0.06,
}: {
  children: React.ReactNode;
  className?: string;
  stagger?: number;
}) {
  const items = Array.isArray(children) ? children : [children];
  return (
    <div className={className}>
      {items.map((child, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * stagger, duration: 0.3, ease: "easeOut" }}
        >
          {child}
        </motion.div>
      ))}
    </div>
  );
}

/* ═══════════════════════════════════════════
   Full-page skeleton (used by Layout Suspense)
   ═══════════════════════════════════════════ */
export function PageSkeleton() {
  return (
    <Stagger className="p-4 sm:p-6 max-w-7xl mx-auto space-y-4 sm:space-y-6">
      {/* Title */}
      <div className="space-y-2 pt-2">
        <Shimmer className="h-8 w-48" />
        <Shimmer className="h-4 w-72" />
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[1, 2, 3, 4].map((i) => (
          <Shimmer key={i} className="h-24" />
        ))}
      </div>

      {/* Content cards */}
      <div className="grid md:grid-cols-3 gap-4">
        {[1, 2, 3].map((i) => (
          <Shimmer key={i} className="h-40" />
        ))}
      </div>

      {/* List items */}
      <div className="space-y-3">
        {[1, 2, 3, 4].map((i) => (
          <Shimmer key={i} className="h-16" />
        ))}
      </div>
    </Stagger>
  );
}

/* ═══════════════════════════════════════════
   Section-level skeletons
   ═══════════════════════════════════════════ */

/** Stat cards row skeleton */
export function StatsSkeleton({ count = 6, cols = "grid-cols-2 lg:grid-cols-3 xl:grid-cols-6" }: { count?: number; cols?: string }) {
  return (
    <div className={`grid ${cols} gap-3 sm:gap-4`}>
      {Array.from({ length: count }).map((_, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: i * 0.05, duration: 0.3 }}
          className="p-4 rounded-xl border border-white/[0.03] bg-white/[0.01]"
        >
          <Shimmer className="w-8 h-8 rounded-lg mb-3" />
          <Shimmer className="h-6 w-14 rounded mb-1.5" />
          <Shimmer className="h-3 w-20 rounded" />
        </motion.div>
      ))}
    </div>
  );
}

/** Channel/feature card grid skeleton */
export function CardGridSkeleton({ count = 6, cols = "sm:grid-cols-2 lg:grid-cols-3" }: { count?: number; cols?: string }) {
  return (
    <div className={`grid ${cols} gap-3`}>
      {Array.from({ length: count }).map((_, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.06, duration: 0.3 }}
          className="p-4 rounded-[14px] border border-white/[0.03] bg-white/[0.01]"
        >
          <div className="flex items-start gap-3 mb-3">
            <Shimmer className="w-10 h-10 rounded-xl shrink-0" />
            <div className="flex-1 space-y-1.5">
              <Shimmer className="h-4 w-28 rounded" />
              <Shimmer className="h-3 w-20 rounded" />
            </div>
          </div>
          <div className="space-y-2">
            <Shimmer className="h-3 w-full rounded" />
            <Shimmer className="h-3 w-3/4 rounded" />
          </div>
          <Shimmer className="h-8 w-full rounded-lg mt-4" />
        </motion.div>
      ))}
    </div>
  );
}

/** Token package card skeleton */
export function TokenCardSkeleton({ count = 3 }: { count?: number }) {
  return (
    <div className="grid md:grid-cols-3 gap-4">
      {Array.from({ length: count }).map((_, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.08, duration: 0.3 }}
          className="p-6 rounded-[14px] border border-white/[0.03] bg-white/[0.01]"
        >
          <Shimmer className="w-10 h-10 rounded-xl mb-4" />
          <Shimmer className="h-4 w-24 rounded mb-2" />
          <Shimmer className="h-8 w-20 rounded mb-1" />
          <Shimmer className="h-3 w-32 rounded mb-4" />
          <div className="space-y-2 mb-5">
            {[1, 2, 3].map((j) => (
              <Shimmer key={j} className="h-3 w-full rounded" />
            ))}
          </div>
          <Shimmer className="h-10 w-full rounded-lg" />
        </motion.div>
      ))}
    </div>
  );
}

/** Checklist / list items skeleton */
export function ListSkeleton({ count = 4 }: { count?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: count }).map((_, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, x: -8 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: i * 0.07, duration: 0.25 }}
          className="flex items-center gap-4 p-4 rounded-xl border border-white/[0.03] bg-white/[0.01]"
        >
          <Shimmer className="w-9 h-9 rounded-xl shrink-0" />
          <div className="flex-1 space-y-1.5">
            <Shimmer className="h-4 w-40 rounded" />
            <Shimmer className="h-3 w-56 rounded" />
          </div>
          <Shimmer className="h-7 w-20 rounded-lg" />
        </motion.div>
      ))}
    </div>
  );
}

/** Big feature card skeleton (e.g. balance card) */
export function HeroCardSkeleton() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.35 }}
      className="p-6 rounded-xl border border-white/[0.05] bg-white/[0.01]"
    >
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Shimmer className="w-12 h-12 rounded-xl" />
          <div className="space-y-1.5">
            <Shimmer className="h-3 w-20 rounded" />
            <Shimmer className="h-8 w-28 rounded" />
          </div>
        </div>
        <Shimmer className="h-8 w-32 rounded-lg" />
      </div>
    </motion.div>
  );
}

/** Section header skeleton */
export function SectionHeaderSkeleton() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="flex items-center justify-between"
    >
      <Shimmer className="h-5 w-36 rounded" />
      <Shimmer className="h-4 w-20 rounded" />
    </motion.div>
  );
}

/** Compact card grid (for inline use) */
export function CardSkeleton({ count = 3 }: { count?: number }) {
  return (
    <div className="grid md:grid-cols-3 gap-4">
      {Array.from({ length: count }).map((_, i) => (
        <Shimmer key={i} className="h-36" />
      ))}
    </div>
  );
}

/** Inline skeleton bar */
export function LineSkeleton({ width = "100%", height = 16 }: { width?: string | number; height?: number }) {
  return <Shimmer style={{ width, height }} />;
}

/* ═══════════════════════════════════════════
   Inline section skeletons (charts, timelines)
   ═══════════════════════════════════════════ */

/** Chart area skeleton — mimics a Recharts AreaChart with fake axes + area wave */
export function ChartSkeleton({
  height = 280,
  className = "",
}: {
  height?: number;
  className?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.35 }}
      className={`p-6 rounded-xl border border-white/[0.03] bg-white/[0.01] ${className}`}
    >
      {/* Title + subtitle */}
      <Shimmer className="h-4 w-40 rounded mb-1.5" />
      <Shimmer className="h-3 w-56 rounded mb-6" />

      {/* Chart area */}
      <div className="relative" style={{ height }}>
        {/* Y-axis labels */}
        <div className="absolute left-0 top-0 bottom-6 flex flex-col justify-between w-8">
          {[1, 2, 3, 4, 5].map((i) => (
            <Shimmer key={i} className="h-2.5 w-6 rounded" />
          ))}
        </div>

        {/* Grid lines */}
        <div className="absolute left-10 right-0 top-0 bottom-6 flex flex-col justify-between">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-px bg-white/[0.03]" />
          ))}
        </div>

        {/* Wave area (fake chart shape) */}
        <div className="absolute left-10 right-0 bottom-6 overflow-hidden" style={{ height: height - 24 }}>
          <svg viewBox="0 0 400 200" preserveAspectRatio="none" className="w-full h-full">
            <defs>
              <linearGradient id="skelGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="currentColor" stopOpacity="0.06" />
                <stop offset="100%" stopColor="currentColor" stopOpacity="0" />
              </linearGradient>
            </defs>
            <path
              d="M0,160 C40,140 80,80 120,100 C160,120 200,60 240,70 C280,80 320,40 360,50 C380,55 400,45 400,45 L400,200 L0,200 Z"
              fill="url(#skelGrad)"
              className="text-zinc-500"
            />
            <path
              d="M0,160 C40,140 80,80 120,100 C160,120 200,60 240,70 C280,80 320,40 360,50 C380,55 400,45 400,45"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeOpacity="0.08"
              className="text-zinc-500"
            />
          </svg>
          {/* Shimmer sweep over chart */}
          <div className="absolute inset-0 skeleton-shimmer" />
        </div>

        {/* X-axis labels */}
        <div className="absolute left-10 right-0 bottom-0 flex justify-between">
          {[1, 2, 3, 4, 5, 6, 7].map((i) => (
            <Shimmer key={i} className="h-2.5 w-8 rounded" />
          ))}
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-6 mt-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="flex items-center gap-1.5">
            <Shimmer className="w-2 h-2 rounded-full" />
            <Shimmer className="h-2.5 w-12 rounded" />
          </div>
        ))}
      </div>
    </motion.div>
  );
}

/** Bar chart skeleton */
export function BarChartSkeleton({
  bars = 7,
  height = 200,
  className = "",
}: {
  bars?: number;
  height?: number;
  className?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.35 }}
      className={`p-6 rounded-xl border border-white/[0.03] bg-white/[0.01] ${className}`}
    >
      <Shimmer className="h-4 w-36 rounded mb-1.5" />
      <Shimmer className="h-3 w-48 rounded mb-6" />

      <div className="flex items-end gap-2 justify-between" style={{ height }}>
        {Array.from({ length: bars }).map((_, i) => {
          const h = 30 + Math.sin(i * 1.2) * 25 + Math.random() * 40;
          return (
            <motion.div
              key={i}
              initial={{ scaleY: 0 }}
              animate={{ scaleY: 1 }}
              transition={{ delay: i * 0.05, duration: 0.4, ease: "easeOut" }}
              style={{ height: `${h}%`, transformOrigin: "bottom" }}
              className="flex-1 rounded-t-md bg-white/[0.04] skeleton-shimmer relative overflow-hidden"
            />
          );
        })}
      </div>

      {/* X-axis labels */}
      <div className="flex justify-between mt-3">
        {Array.from({ length: bars }).map((_, i) => (
          <Shimmer key={i} className="h-2.5 flex-1 mx-1 rounded" />
        ))}
      </div>
    </motion.div>
  );
}

/** Radar/polar chart skeleton (circular) */
export function RadarChartSkeleton({ className = "" }: { className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.35 }}
      className={`p-6 rounded-xl border border-white/[0.03] bg-white/[0.01] ${className}`}
    >
      <Shimmer className="h-4 w-32 rounded mb-1.5" />
      <Shimmer className="h-3 w-44 rounded mb-6" />

      <div className="flex items-center justify-center" style={{ height: 220 }}>
        <div className="relative w-44 h-44">
          {/* Concentric circles */}
          {[1, 0.75, 0.5, 0.25].map((scale, i) => (
            <div
              key={i}
              className="absolute rounded-full border border-white/[0.04]"
              style={{
                width: `${scale * 100}%`,
                height: `${scale * 100}%`,
                top: `${(1 - scale) * 50}%`,
                left: `${(1 - scale) * 50}%`,
              }}
            />
          ))}
          {/* Axis lines */}
          {[0, 60, 120].map((deg) => (
            <div
              key={deg}
              className="absolute top-1/2 left-1/2 h-px bg-white/[0.04]"
              style={{
                width: "100%",
                transformOrigin: "0 0",
                transform: `rotate(${deg}deg)`,
              }}
            />
          ))}
          {/* Center shimmer pulse */}
          <div className="absolute inset-4 rounded-full skeleton-shimmer overflow-hidden bg-white/[0.02]" />
        </div>
      </div>
    </motion.div>
  );
}

/** Timeline skeleton — vertical line with event nodes */
export function TimelineSkeleton({ count = 5 }: { count?: number }) {
  return (
    <div className="relative pl-8 space-y-6">
      {/* Vertical line */}
      <div className="absolute left-3 top-2 bottom-2 w-px bg-white/[0.05]" />

      {Array.from({ length: count }).map((_, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, x: -12 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: i * 0.08, duration: 0.3 }}
          className="relative flex gap-4"
        >
          {/* Node dot */}
          <div className="absolute -left-8 top-1 w-6 h-6 rounded-full border-2 border-white/[0.06] bg-white/[0.02] flex items-center justify-center">
            <Shimmer className="w-2.5 h-2.5 rounded-full" />
          </div>

          {/* Event card */}
          <div className="flex-1 p-4 rounded-xl border border-white/[0.03] bg-white/[0.01]">
            <div className="flex items-center justify-between mb-2">
              <Shimmer className="h-4 w-32 rounded" />
              <Shimmer className="h-3 w-16 rounded" />
            </div>
            <Shimmer className="h-3 w-full rounded mb-1.5" />
            <Shimmer className="h-3 w-2/3 rounded" />
          </div>
        </motion.div>
      ))}
    </div>
  );
}

/** Progress tracker skeleton (step-by-step) */
export function ProgressSkeleton({ steps = 4 }: { steps?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="p-5 rounded-xl border border-white/[0.03] bg-white/[0.01]"
    >
      {/* Progress bar header */}
      <div className="flex items-center justify-between mb-3">
        <Shimmer className="h-3.5 w-28 rounded" />
        <Shimmer className="h-3.5 w-10 rounded" />
      </div>
      <Shimmer className="h-2 w-full rounded-full mb-6" />

      {/* Steps */}
      <div className="space-y-3">
        {Array.from({ length: steps }).map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06, duration: 0.25 }}
            className="flex items-center gap-4 p-3 rounded-xl border border-white/[0.03] bg-white/[0.01]"
          >
            <Shimmer className="w-8 h-8 rounded-lg shrink-0" />
            <div className="flex-1 space-y-1">
              <Shimmer className="h-3.5 w-36 rounded" />
              <Shimmer className="h-2.5 w-52 rounded" />
            </div>
            <Shimmer className="w-4 h-4 rounded-full shrink-0" />
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}