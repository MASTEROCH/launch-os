import { useMemo } from "react";
import { useTheme, type AccentColor } from "./ThemeProvider";

interface Orb {
  size: number;
  x: number;
  y: number;
  duration: number;
  delay: number;
  moveX: number;
  moveY: number;
}

const PALETTES: Record<AccentColor, string[]> = {
  purple: [
    "rgba(168, 85, 247, 0.08)",
    "rgba(217, 70, 239, 0.06)",
    "rgba(236, 72, 153, 0.05)",
    "rgba(249, 115, 22, 0.05)",
    "rgba(139, 92, 246, 0.07)",
  ],
  blue: [
    "rgba(59, 130, 246, 0.08)",
    "rgba(56, 189, 248, 0.06)",
    "rgba(99, 102, 241, 0.05)",
    "rgba(14, 165, 233, 0.05)",
    "rgba(37, 99, 235, 0.07)",
  ],
  emerald: [
    "rgba(16, 185, 129, 0.08)",
    "rgba(52, 211, 153, 0.06)",
    "rgba(6, 182, 212, 0.05)",
    "rgba(20, 184, 166, 0.05)",
    "rgba(5, 150, 105, 0.07)",
  ],
  rose: [
    "rgba(244, 63, 94, 0.08)",
    "rgba(251, 113, 133, 0.06)",
    "rgba(236, 72, 153, 0.05)",
    "rgba(217, 70, 239, 0.05)",
    "rgba(225, 29, 72, 0.07)",
  ],
  amber: [
    "rgba(245, 158, 11, 0.08)",
    "rgba(251, 191, 36, 0.06)",
    "rgba(249, 115, 22, 0.05)",
    "rgba(234, 179, 8, 0.05)",
    "rgba(217, 119, 6, 0.07)",
  ],
};

const LIGHT_PALETTES: Record<AccentColor, string[]> = {
  purple: [
    "rgba(168, 85, 247, 0.05)",
    "rgba(217, 70, 239, 0.04)",
    "rgba(236, 72, 153, 0.04)",
    "rgba(249, 115, 22, 0.03)",
    "rgba(139, 92, 246, 0.04)",
  ],
  blue: [
    "rgba(59, 130, 246, 0.05)",
    "rgba(56, 189, 248, 0.04)",
    "rgba(99, 102, 241, 0.04)",
    "rgba(14, 165, 233, 0.03)",
    "rgba(37, 99, 235, 0.04)",
  ],
  emerald: [
    "rgba(16, 185, 129, 0.05)",
    "rgba(52, 211, 153, 0.04)",
    "rgba(6, 182, 212, 0.04)",
    "rgba(20, 184, 166, 0.03)",
    "rgba(5, 150, 105, 0.04)",
  ],
  rose: [
    "rgba(244, 63, 94, 0.05)",
    "rgba(251, 113, 133, 0.04)",
    "rgba(236, 72, 153, 0.04)",
    "rgba(217, 70, 239, 0.03)",
    "rgba(225, 29, 72, 0.04)",
  ],
  amber: [
    "rgba(245, 158, 11, 0.05)",
    "rgba(251, 191, 36, 0.04)",
    "rgba(249, 115, 22, 0.04)",
    "rgba(234, 179, 8, 0.03)",
    "rgba(217, 119, 6, 0.04)",
  ],
};

function seededRandom(seed: number) {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

export function FloatingOrbs({ count = 5 }: { count?: number }) {
  const { accent, theme } = useTheme();
  const palette = theme === "light" ? LIGHT_PALETTES[accent] : PALETTES[accent];

  const orbs = useMemo<Orb[]>(() => {
    return Array.from({ length: count }, (_, i) => ({
      size: 160 + seededRandom(i + 1) * 180,
      x: seededRandom(i + 10) * 100,
      y: seededRandom(i + 20) * 100,
      duration: 18 + seededRandom(i + 30) * 22,
      delay: -(seededRandom(i + 40) * 20),
      moveX: 40 + seededRandom(i + 50) * 50,
      moveY: 25 + seededRandom(i + 60) * 40,
    }));
  }, [count]);

  return (
    <div
      className="fixed inset-0 pointer-events-none overflow-hidden"
      style={{ zIndex: 0 }}
      aria-hidden="true"
    >
      {orbs.map((orb, i) => (
        <div
          key={i}
          className="absolute rounded-full orb-float"
          style={{
            width: orb.size,
            height: orb.size,
            left: `${orb.x}%`,
            top: `${orb.y}%`,
            background: palette[i % palette.length],
            filter: `blur(${Math.round(orb.size * 0.18)}px)`,
            opacity: 1,
            animationDuration: `${orb.duration}s`,
            animationDelay: `${orb.delay}s`,
            ["--orb-move-x" as string]: `${orb.moveX}px`,
            ["--orb-move-y" as string]: `${orb.moveY}px`,
            transform: "translate(-50%, -50%)",
            transition: "background 0.6s ease",
          }}
        />
      ))}
    </div>
  );
}
