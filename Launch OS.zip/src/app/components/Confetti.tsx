import { useEffect, useCallback } from "react";
import confetti from "canvas-confetti";

/**
 * Fires a burst of confetti.
 * Inspired by iOS celebration haptics — two waves with staggered timing.
 */
export function fireConfetti() {
  const defaults = {
    spread: 55,
    ticks: 80,
    gravity: 1.2,
    decay: 0.94,
    startVelocity: 30,
    colors: ["#8b5cf6", "#a78bfa", "#c4b5fd", "#06b6d4", "#fbbf24", "#f472b6", "#34d399"],
    zIndex: 9999,
  };

  // Left burst
  confetti({
    ...defaults,
    particleCount: 50,
    origin: { x: 0.3, y: 0.6 },
    angle: 60,
  });

  // Right burst
  confetti({
    ...defaults,
    particleCount: 50,
    origin: { x: 0.7, y: 0.6 },
    angle: 120,
  });

  // Delayed center shower
  setTimeout(() => {
    confetti({
      ...defaults,
      particleCount: 35,
      spread: 100,
      origin: { x: 0.5, y: 0.35 },
      startVelocity: 40,
      gravity: 0.8,
    });
  }, 200);
}

/**
 * Fires a smaller, more subtle confetti burst for minor bonuses.
 */
export function fireConfettiSmall() {
  confetti({
    particleCount: 30,
    spread: 60,
    origin: { x: 0.5, y: 0.5 },
    colors: ["#8b5cf6", "#a78bfa", "#06b6d4", "#fbbf24"],
    ticks: 60,
    gravity: 1.5,
    startVelocity: 20,
    zIndex: 9999,
  });
}

/**
 * Dispatch a bonus event — triggers bell notification in Layout
 * and can optionally trigger confetti.
 */
export function dispatchBonusEvent(detail: {
  message: string;
  tokens?: number;
  type?: "purchase" | "launch" | "reward" | "referral";
}) {
  try {
    document.dispatchEvent(
      new CustomEvent("launchapp:bonus", { detail })
    );
  } catch { /* SSR-safe */ }
}

/**
 * Hook to listen for bonus events and auto-fire confetti.
 */
export function useBonusConfetti() {
  const handler = useCallback((e: Event) => {
    const detail = (e as CustomEvent).detail as {
      tokens?: number;
      type?: string;
    };
    if (detail?.tokens && detail.tokens >= 100) {
      fireConfetti();
    } else {
      fireConfettiSmall();
    }
  }, []);

  useEffect(() => {
    document.addEventListener("launchapp:bonus", handler);
    return () => document.removeEventListener("launchapp:bonus", handler);
  }, [handler]);
}
