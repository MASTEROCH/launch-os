import { useEffect } from "react";

/**
 * Temporarily forces dark mode by removing the `light` class from <html>
 * while this component is mounted. Restores on unmount.
 *
 * Use on pages that are always dark-themed (Landing, Auth, Onboarding, etc.)
 */
export function useForceDarkMode() {
  useEffect(() => {
    const html = document.documentElement;
    const wasLight = html.classList.contains("light");
    if (wasLight) {
      html.classList.remove("light");
      html.classList.add("dark");
    }
    return () => {
      if (wasLight) {
        html.classList.remove("dark");
        html.classList.add("light");
      }
    };
  }, []);
}
