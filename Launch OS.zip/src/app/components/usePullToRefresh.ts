import { useState, useRef, useCallback } from "react";

export interface PullToRefreshState {
  pullY: number;
  isRefreshing: boolean;
  handlers: {
    onTouchStart: (e: React.TouchEvent) => void;
    onTouchMove: (e: React.TouchEvent) => void;
    onTouchEnd: () => void;
  };
}

/**
 * Reusable pull-to-refresh hook with rubber-band physics.
 * @param onRefresh - async callback; resolves when data is refreshed
 * @param opts - threshold (default 70), resistance (default 0.45)
 */
export function usePullToRefresh(
  onRefresh: () => void | Promise<void>,
  opts?: { threshold?: number; resistance?: number }
): PullToRefreshState {
  const threshold = opts?.threshold ?? 70;
  const resistance = opts?.resistance ?? 0.45;

  const [pullY, setPullY] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const startY = useRef(0);
  const pulling = useRef(false);

  const onTouchStart = useCallback((e: React.TouchEvent) => {
    // Only pull if scrolled to top
    const scrollParent = (e.currentTarget as HTMLElement).closest("main");
    if (scrollParent && scrollParent.scrollTop <= 0) {
      startY.current = e.touches[0].clientY;
      pulling.current = true;
    }
  }, []);

  const onTouchMove = useCallback(
    (e: React.TouchEvent) => {
      if (!pulling.current || isRefreshing) return;
      const dy = e.touches[0].clientY - startY.current;
      if (dy > 0) {
        setPullY(Math.min(dy * resistance, 120));
      }
    },
    [isRefreshing, resistance]
  );

  const onTouchEnd = useCallback(() => {
    pulling.current = false;
    if (pullY > threshold && !isRefreshing) {
      setIsRefreshing(true);
      setPullY(60);
      // Haptic feedback
      try { navigator?.vibrate?.([10, 30, 10]); } catch {}
      const result = onRefresh();
      if (result && typeof (result as Promise<void>).then === "function") {
        (result as Promise<void>).finally(() => {
          setIsRefreshing(false);
          setPullY(0);
        });
      } else {
        setTimeout(() => {
          setIsRefreshing(false);
          setPullY(0);
        }, 1200);
      }
    } else {
      setPullY(0);
    }
  }, [pullY, isRefreshing, threshold, onRefresh]);

  return {
    pullY,
    isRefreshing,
    handlers: { onTouchStart, onTouchMove, onTouchEnd },
  };
}
