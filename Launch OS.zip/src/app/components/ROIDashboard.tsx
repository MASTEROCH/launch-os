import { useState, useEffect } from "react";
import { motion } from "motion/react";
import {
  DollarSign, Users, TrendingUp, ArrowUpRight, ArrowDownRight,
  Target, CreditCard, BarChart3,
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer,
} from "recharts";
import { useI18n } from "./i18n";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { usePullToRefresh } from "./usePullToRefresh";
import { PullToRefreshIndicator } from "./PullToRefreshIndicator";
import { loadProgress } from "./user-progress";
import { useNavigate } from "react-router";
import { CountUp } from "./CountUp";

/* ─── Mock ROI Data ─── */
const revenueTimeline = [
  { week: "W1", revenue: 420, signups: 34, mrr: 420 },
  { week: "W2", revenue: 1180, signups: 89, mrr: 1600 },
  { week: "W3", revenue: 2340, signups: 156, mrr: 3940 },
  { week: "W4", revenue: 3890, signups: 234, mrr: 7830 },
  { week: "W5", revenue: 5200, signups: 312, mrr: 13030 },
  { week: "W6", revenue: 4800, signups: 287, mrr: 17830 },
  { week: "W7", revenue: 6100, signups: 378, mrr: 23930 },
  { week: "W8", revenue: 7400, signups: 412, mrr: 31330 },
];

const funnelData = [
  { name: "Impressions", value: 248000, fill: "#8b5cf6" },
  { name: "Clicks", value: 18400, fill: "#a78bfa" },
  { name: "Signups", value: 2847, fill: "#c4b5fd" },
  { name: "Trials", value: 1234, fill: "#7c3aed" },
  { name: "Paid", value: 467, fill: "#6d28d9" },
];

interface ChannelROI {
  channel: string;
  icon: string;
  gradient: string;
  visitors: number;
  signups: number;
  paid: number;
  revenue: number;
  cost: number; // tokens * est. cost
  roi: number; // percentage
}

const channelROIData: ChannelROI[] = [
  { channel: "Reddit", icon: "R", gradient: "from-orange-500 to-red-600", visitors: 4200, signups: 890, paid: 134, revenue: 8940, cost: 45, roi: 19767 },
  { channel: "Twitter / X", icon: "X", gradient: "from-sky-500 to-blue-600", visitors: 3800, signups: 567, paid: 89, revenue: 5340, cost: 30, roi: 17700 },
  { channel: "Product Hunt", icon: "PH", gradient: "from-orange-500 to-amber-600", visitors: 2100, signups: 456, paid: 78, revenue: 4680, cost: 75, roi: 6140 },
  { channel: "LinkedIn", icon: "in", gradient: "from-blue-600 to-blue-800", visitors: 1800, signups: 345, paid: 56, revenue: 3360, cost: 36, roi: 9233 },
  { channel: "Hacker News", icon: "Y", gradient: "from-orange-600 to-orange-800", visitors: 3200, signups: 234, paid: 45, revenue: 2700, cost: 24, roi: 11150 },
  { channel: "Dev.to", icon: "DEV", gradient: "from-zinc-600 to-zinc-800", visitors: 890, signups: 123, paid: 23, revenue: 1380, cost: 24, roi: 5650 },
  { channel: "Indie Hackers", icon: "IH", gradient: "from-blue-500 to-indigo-700", visitors: 670, signups: 98, paid: 18, revenue: 1080, cost: 30, roi: 3500 },
  { channel: "Discord", icon: "DC", gradient: "from-indigo-500 to-purple-700", visitors: 1200, signups: 134, paid: 24, revenue: 1440, cost: 15, roi: 9500 },
];

const utmSources = [
  { source: "utm_reddit_saas", visitors: 2840, signups: 567, paid: 89, revenue: 5340 },
  { source: "utm_twitter_thread_1", visitors: 1920, signups: 312, paid: 52, revenue: 3120 },
  { source: "utm_ph_launch", visitors: 2100, signups: 456, paid: 78, revenue: 4680 },
  { source: "utm_hn_showhn", visitors: 3200, signups: 234, paid: 45, revenue: 2700 },
  { source: "utm_linkedin_post", visitors: 1200, signups: 189, paid: 34, revenue: 2040 },
  { source: "utm_medium_article", visitors: 680, signups: 89, paid: 15, revenue: 900 },
];

export function ROIDashboard() {
  const { t } = useI18n();
  const navigate = useNavigate();
  useDocumentTitle(t("roi.title"));
  const progress = loadProgress();

  const { pullY, isRefreshing, handlers: pullHandlers } = usePullToRefresh(
    () => new Promise<void>((r) => setTimeout(r, 800))
  );

  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 600);
    return () => clearTimeout(timer);
  }, []);

  /* Empty state */
  if (!progress.launched) {
    return (
      <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6" {...pullHandlers}>
        <PullToRefreshIndicator pullY={pullY} isRefreshing={isRefreshing} />
        <LargeTitle title={t("roi.title")} subtitle={t("roi.subtitle")} />
        <div className="flex flex-col items-center text-center py-16">
          <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mb-5">
            <DollarSign className="w-7 h-7 text-emerald-500/50" />
          </div>
          <h3 className="text-zinc-300 mb-2" style={{ fontWeight: 600 }}>{t("roi.emptyTitle")}</h3>
          <p className="text-sm text-zinc-600 mb-6 max-w-md">{t("roi.emptyDesc")}</p>
          <button
            onClick={() => navigate("/dashboard/launch")}
            className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white px-6 py-2.5 rounded-xl text-sm transition-all shadow-lg shadow-emerald-500/20"
            style={{ fontWeight: 600 }}
          >
            {t("dash.launchNow")}
          </button>
        </div>
      </div>
    );
  }

  // Computed metrics
  const totalRevenue = revenueTimeline.reduce((s, w) => s + w.revenue, 0);
  const totalSignups = revenueTimeline.reduce((s, w) => s + w.signups, 0);
  const currentMRR = revenueTimeline[revenueTimeline.length - 1].mrr;
  const paidCustomers = 467;
  const cac = Math.round((totalRevenue * 0.12) / paidCustomers); // estimated
  const ltv = Math.round(currentMRR / paidCustomers * 18); // 18 month LTV
  const conversionRate = ((paidCustomers / totalSignups) * 100).toFixed(1);
  const trialToPaid = "37.8";

  const statCards = [
    { label: t("roi.totalRevenue"), value: `$${(totalRevenue / 1000).toFixed(1)}K`, change: "+34%", up: true, icon: DollarSign, color: "emerald" },
    { label: t("roi.mrr"), value: `$${(currentMRR / 1000).toFixed(1)}K`, change: "+18%", up: true, icon: TrendingUp, color: "purple" },
    { label: t("roi.signups"), value: totalSignups.toLocaleString(), change: "+412 this week", up: true, icon: Users, color: "cyan" },
    { label: t("roi.cac"), value: `$${cac}`, change: "-12%", up: true, icon: Target, color: "amber" },
    { label: t("roi.ltv"), value: `$${ltv}`, change: `${t("roi.ltvCacRatio")}: ${(ltv / cac).toFixed(1)}x`, up: true, icon: CreditCard, color: "violet" },
    { label: t("roi.conversionRate"), value: `${conversionRate}%`, change: `${t("roi.trialToPayd")}: ${trialToPaid}%`, up: true, icon: BarChart3, color: "rose" },
  ];

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6" {...pullHandlers}>
      <PullToRefreshIndicator pullY={pullY} isRefreshing={isRefreshing} />
      <LargeTitle title={t("roi.title")} subtitle={t("roi.subtitle")} />

      {/* ═══ Key Metrics ═══ */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {statCards.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06 }}
            className="p-4 rounded-xl border border-white/5 bg-white/[0.02]"
          >
            <div className={`w-8 h-8 rounded-lg bg-${stat.color}-500/10 flex items-center justify-center mb-2`}>
              <stat.icon className={`w-4 h-4 text-${stat.color}-400`} />
            </div>
            <div className="text-[10px] text-zinc-500 mb-1" style={{ fontWeight: 500 }}>{stat.label}</div>
            <div className="text-lg text-white" style={{ fontWeight: 700 }}>{stat.value}</div>
            <div className={`text-[10px] mt-0.5 flex items-center gap-0.5 ${stat.up ? "text-emerald-400" : "text-red-400"}`}>
              {stat.up ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
              {stat.change}
            </div>
          </motion.div>
        ))}
      </div>

      {/* ═══ Revenue Growth Chart + Funnel ═══ */}
      <div className="grid gap-4 lg:grid-cols-[1fr,380px]">
        {/* Revenue chart */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="p-4 sm:p-6 rounded-xl border border-white/5 bg-white/[0.02]"
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm text-white" style={{ fontWeight: 700 }}>{t("roi.revenueGrowth")}</h3>
              <p className="text-[11px] text-zinc-500">{t("roi.period")}</p>
            </div>
            <div className="flex items-center gap-4 text-[10px]">
              <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-emerald-500" />Revenue</div>
              <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-purple-500" />MRR</div>
            </div>
          </div>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueTimeline}>
                <defs>
                  <linearGradient id="gradRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="gradMRR" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.2} />
                    <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.03)" />
                <XAxis dataKey="week" tick={{ fill: "#52525b", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#52525b", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v: number) => `$${(v / 1000).toFixed(0)}K`} />
                <Tooltip
                  contentStyle={{ background: "#18181b", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12, fontSize: 12 }}
                  labelStyle={{ color: "#a1a1aa" }}
                  formatter={(value: number, name: string) => [`$${value.toLocaleString()}`, name]}
                />
                <Area type="monotone" dataKey="revenue" stroke="#10b981" fill="url(#gradRevenue)" strokeWidth={2} />
                <Area type="monotone" dataKey="mrr" stroke="#8b5cf6" fill="url(#gradMRR)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Conversion Funnel */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="p-4 sm:p-6 rounded-xl border border-white/5 bg-white/[0.02]"
        >
          <h3 className="text-sm text-white mb-4" style={{ fontWeight: 700 }}>{t("roi.funnelTitle")}</h3>
          <div className="space-y-3">
            {funnelData.map((stage, i) => {
              const maxVal = funnelData[0].value;
              const pct = (stage.value / maxVal) * 100;
              const convFromPrev = i > 0 ? ((stage.value / funnelData[i - 1].value) * 100).toFixed(1) : "100";
              return (
                <div key={stage.name}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[11px] text-zinc-400" style={{ fontWeight: 500 }}>{stage.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-white" style={{ fontWeight: 600 }}>{stage.value.toLocaleString()}</span>
                      {i > 0 && (
                        <span className="text-[9px] text-zinc-600 bg-white/[0.04] px-1.5 py-0.5 rounded">
                          {convFromPrev}%
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="h-3 rounded-full bg-white/[0.03] overflow-hidden">
                    <motion.div
                      className="h-full rounded-full"
                      style={{ background: stage.fill }}
                      initial={{ width: 0 }}
                      animate={{ width: `${pct}%` }}
                      transition={{ delay: 0.5 + i * 0.1, type: "spring", stiffness: 80 }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-[11px]">
            <span className="text-zinc-500">Overall conversion</span>
            <span className="text-emerald-400" style={{ fontWeight: 700 }}>
              {((funnelData[funnelData.length - 1].value / funnelData[0].value) * 100).toFixed(2)}%
            </span>
          </div>
        </motion.div>
      </div>

      {/* ═══ Channel ROI Table ═══ */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="p-4 sm:p-6 rounded-xl border border-white/5 bg-white/[0.02]"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm text-white" style={{ fontWeight: 700 }}>{t("roi.topChannels")}</h3>
          <span className="text-[10px] text-zinc-500">{t("roi.period")}</span>
        </div>

        {/* Desktop table */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full text-[12px]">
            <thead>
              <tr className="border-b border-white/5">
                <th className="text-left py-2 text-zinc-500" style={{ fontWeight: 500 }}>{t("roi.source")}</th>
                <th className="text-right py-2 text-zinc-500" style={{ fontWeight: 500 }}>{t("roi.visitors")}</th>
                <th className="text-right py-2 text-zinc-500" style={{ fontWeight: 500 }}>{t("roi.signupsCol")}</th>
                <th className="text-right py-2 text-zinc-500" style={{ fontWeight: 500 }}>{t("roi.paid")}</th>
                <th className="text-right py-2 text-zinc-500" style={{ fontWeight: 500 }}>{t("roi.revenue")}</th>
                <th className="text-right py-2 text-zinc-500" style={{ fontWeight: 500 }}>{t("roi.roiPercent")}</th>
              </tr>
            </thead>
            <tbody>
              {channelROIData.map((ch, i) => (
                <motion.tr
                  key={ch.channel}
                  initial={{ opacity: 0, x: -5 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + i * 0.04 }}
                  className="border-b border-white/[0.02] hover:bg-white/[0.02] transition-colors"
                >
                  <td className="py-3">
                    <div className="flex items-center gap-2">
                      <div className={`w-7 h-7 rounded-md bg-gradient-to-br ${ch.gradient} flex items-center justify-center text-white text-[10px] shrink-0`} style={{ fontWeight: 700 }}>
                        {ch.icon}
                      </div>
                      <span className="text-white" style={{ fontWeight: 600 }}>{ch.channel}</span>
                    </div>
                  </td>
                  <td className="text-right text-zinc-400 py-3">{ch.visitors.toLocaleString()}</td>
                  <td className="text-right text-zinc-300 py-3" style={{ fontWeight: 500 }}>{ch.signups.toLocaleString()}</td>
                  <td className="text-right text-zinc-300 py-3" style={{ fontWeight: 500 }}>{ch.paid}</td>
                  <td className="text-right py-3">
                    <span className="text-emerald-400" style={{ fontWeight: 600 }}>${ch.revenue.toLocaleString()}</span>
                  </td>
                  <td className="text-right py-3">
                    <span className={`inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md text-[10px] ${
                      ch.roi > 10000 ? "bg-emerald-500/10 text-emerald-400" : "bg-amber-500/10 text-amber-400"
                    }`} style={{ fontWeight: 700 }}>
                      <TrendingUp className="w-3 h-3" />
                      {ch.roi.toLocaleString()}%
                    </span>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile cards */}
        <div className="sm:hidden space-y-2">
          {channelROIData.map((ch, i) => (
            <motion.div
              key={ch.channel}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 + i * 0.04 }}
              className="p-3 rounded-lg border border-white/[0.03] bg-white/[0.01]"
            >
              <div className="flex items-center gap-2 mb-2">
                <div className={`w-7 h-7 rounded-md bg-gradient-to-br ${ch.gradient} flex items-center justify-center text-white text-[10px]`} style={{ fontWeight: 700 }}>
                  {ch.icon}
                </div>
                <span className="text-[13px] text-white flex-1" style={{ fontWeight: 600 }}>{ch.channel}</span>
                <span className="text-emerald-400 text-xs" style={{ fontWeight: 700 }}>${ch.revenue.toLocaleString()}</span>
              </div>
              <div className="flex items-center gap-3 text-[10px] text-zinc-500">
                <span>{ch.visitors.toLocaleString()} visits</span>
                <span>{ch.signups} signups</span>
                <span>{ch.paid} paid</span>
                <span className="ml-auto text-emerald-400" style={{ fontWeight: 600 }}>{ch.roi.toLocaleString()}% ROI</span>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* ═══ UTM Attribution Table ═══ */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="p-4 sm:p-6 rounded-xl border border-white/5 bg-white/[0.02]"
      >
        <h3 className="text-sm text-white mb-4" style={{ fontWeight: 700 }}>{t("roi.utmTitle")}</h3>
        <div className="space-y-2">
          {utmSources.map((utm, i) => {
            const maxVis = Math.max(...utmSources.map((u) => u.visitors));
            const barWidth = (utm.visitors / maxVis) * 100;
            return (
              <motion.div
                key={utm.source}
                initial={{ opacity: 0, x: -5 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.8 + i * 0.04 }}
                className="flex items-center gap-3"
              >
                <code className="text-[11px] text-purple-400 bg-purple-500/[0.06] px-2 py-1 rounded-md w-48 truncate shrink-0">
                  {utm.source}
                </code>
                <div className="flex-1 h-6 rounded-md bg-white/[0.02] overflow-hidden relative">
                  <motion.div
                    className="h-full rounded-md bg-gradient-to-r from-purple-500/30 to-violet-500/20"
                    initial={{ width: 0 }}
                    animate={{ width: `${barWidth}%` }}
                    transition={{ delay: 0.9 + i * 0.05, type: "spring", stiffness: 80 }}
                  />
                  <div className="absolute inset-0 flex items-center px-2 gap-4 text-[10px]">
                    <span className="text-zinc-400">{utm.visitors.toLocaleString()} visits</span>
                    <span className="text-zinc-500">{utm.signups} signups</span>
                    <span className="text-emerald-400 ml-auto" style={{ fontWeight: 600 }}>${utm.revenue.toLocaleString()}</span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>

      {/* ═══ ARR Projection Card ═══ */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9 }}
        className="p-6 rounded-xl border border-emerald-500/20 bg-gradient-to-r from-emerald-500/[0.05] to-teal-500/[0.03]"
      >
        <div className="flex items-center gap-4 flex-wrap">
          <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 flex items-center justify-center shrink-0">
            <TrendingUp className="w-6 h-6 text-emerald-400" />
          </div>
          <div className="flex-1">
            <div className="text-sm text-zinc-400 mb-1">{t("roi.arr")} Projection (12mo)</div>
            <div className="text-3xl text-white" style={{ fontWeight: 800 }}>
              $<CountUp value={(currentMRR * 12).toLocaleString()} duration={2000} />
            </div>
            <div className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              Based on current MRR of ${currentMRR.toLocaleString()}/mo
            </div>
          </div>
          <div className="grid grid-cols-3 gap-6 shrink-0">
            <div className="text-center">
              <div className="text-xs text-zinc-500 mb-0.5">Paying</div>
              <div className="text-lg text-white" style={{ fontWeight: 700 }}>{paidCustomers}</div>
            </div>
            <div className="text-center">
              <div className="text-xs text-zinc-500 mb-0.5">ARPU</div>
              <div className="text-lg text-white" style={{ fontWeight: 700 }}>${Math.round(currentMRR / paidCustomers)}</div>
            </div>
            <div className="text-center">
              <div className="text-xs text-zinc-500 mb-0.5">Churn</div>
              <div className="text-lg text-emerald-400" style={{ fontWeight: 700 }}>2.1%</div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default ROIDashboard;