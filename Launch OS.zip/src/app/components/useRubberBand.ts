import { useRef, useCallback, useState } from "react";

/**
 * iOS-style rubber band overscroll effect with:
 * - Diminishing return elastic curve
 * - Haptic buzz at ~88% of limit
 * - Spring-physics bounce on snap-back (not linear ease)
 */

const LIMIT = 140;
const HAPTIC_THRESHOLD = 0.88;

function hapticBuzz(intensity: number = 12) {
  try { navigator?.vibrate?.(intensity); } catch {}
}

/** Pure math — iOS rubber band formula */
function rubberBand(distance: number): number {
  const d = Math.abs(distance);
  const clamped = Math.min(d, LIMIT);
  const ratio = clamped / LIMIT;
  return Math.sign(distance) * clamped * (1 - ratio / 2.2);
}

/**
 * Spring-physics snap-back animation.
 * Uses critically-damped spring model for iOS-feel bounce.
 */
function springSnapBack(
  from: number,
  onUpdate: (value: number) => void,
  onComplete: () => void,
) {
  const startTime = performance.now();
  const duration = 480; // ms total
  const stiffness = 220;
  const damping = 22;
  const mass = 0.8;
  // Compute angular frequency
  const omega = Math.sqrt(stiffness / mass);
  const zeta = damping / (2 * Math.sqrt(stiffness * mass)); // damping ratio

  function tick(now: number) {
    const elapsed = (now - startTime) / 1000; // seconds
    // Under-damped spring: x(t) = A * e^(-zeta*omega*t) * cos(omega_d * t + phi)
    const omegaD = omega * Math.sqrt(Math.max(0, 1 - zeta * zeta));
    const decay = Math.exp(-zeta * omega * elapsed);
    const value = from * decay * Math.cos(omegaD * elapsed);

    if (elapsed * 1000 > duration || Math.abs(value) < 0.3) {
      onUpdate(0);
      onComplete();
      return;
    }

    onUpdate(value);
    requestAnimationFrame(tick);
  }

  requestAnimationFrame(tick);
}

export function useRubberBand(scrollRef: React.RefObject<HTMLElement | null>) {
  const [overscrollY, setOverscrollY] = useState(0);
  const touchStartY = useRef(0);
  const isOverscrolling = useRef(false);
  const direction = useRef<"top" | "bottom" | null>(null);
  const hapticFired = useRef(false);
  const lastOverscroll = useRef(0);
  const isAnimating = useRef(false);

  const onTouchStart = useCallback((e: React.TouchEvent) => {
    // Cancel any ongoing spring animation
    if (isAnimating.current) {
      isAnimating.current = false;
      setOverscrollY(0);
    }
    const el = scrollRef.current;
    if (!el) return;
    touchStartY.current = e.touches[0].clientY;
    hapticFired.current = false;

    const atTop = el.scrollTop <= 0;
    const atBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - 1;

    if (atTop || atBottom) {
      direction.current = atTop ? "top" : "bottom";
    } else {
      direction.current = null;
    }
  }, [scrollRef]);

  const onTouchMove = useCallback((e: React.TouchEvent) => {
    if (!direction.current) return;
    const el = scrollRef.current;
    if (!el) return;

    const dy = e.touches[0].clientY - touchStartY.current;
    const absDy = Math.abs(dy);

    if (direction.current === "top" && dy > 0 && el.scrollTop <= 0) {
      isOverscrolling.current = true;
      const offset = rubberBand(dy);
      lastOverscroll.current = offset;
      setOverscrollY(offset);

      if (!hapticFired.current && absDy >= LIMIT * HAPTIC_THRESHOLD) {
        hapticFired.current = true;
        hapticBuzz(15);
      }
    } else if (direction.current === "bottom" && dy < 0) {
      const atBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - 1;
      if (atBottom) {
        isOverscrolling.current = true;
        const offset = rubberBand(dy);
        lastOverscroll.current = offset;
        setOverscrollY(offset);

        if (!hapticFired.current && absDy >= LIMIT * HAPTIC_THRESHOLD) {
          hapticFired.current = true;
          hapticBuzz(15);
        }
      }
    } else if (isOverscrolling.current) {
      isOverscrolling.current = false;
      hapticFired.current = false;
      lastOverscroll.current = 0;
      setOverscrollY(0);
      direction.current = null;
    }
  }, [scrollRef]);

  const onTouchEnd = useCallback(() => {
    if (isOverscrolling.current) {
      isOverscrolling.current = false;
      hapticFired.current = false;
      direction.current = null;

      const snapFrom = lastOverscroll.current;
      lastOverscroll.current = 0;

      if (Math.abs(snapFrom) > 4) {
        // Light haptic on release
        if (Math.abs(snapFrom) > 20) hapticBuzz(8);
        // Spring-animated snap-back
        isAnimating.current = true;
        springSnapBack(
          snapFrom,
          (value) => {
            if (isAnimating.current) setOverscrollY(value);
          },
          () => { isAnimating.current = false; },
        );
      } else {
        setOverscrollY(0);
      }
    }
  }, []);

  return {
    overscrollY,
    isOverscrolling: overscrollY !== 0,
    onRubberTouchStart: onTouchStart,
    onRubberTouchMove: onTouchMove,
    onRubberTouchEnd: onTouchEnd,
  };
}
