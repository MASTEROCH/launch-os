import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { HelpCircle } from "lucide-react";

interface MetricTooltipProps {
  /** Tooltip explanation text */
  text: string;
  /** Color theme */
  color?: "purple" | "cyan" | "emerald" | "amber" | "rose" | "violet";
  /** Unique key for first-show pulse tracking (if omitted, uses text hash) */
  pulseKey?: string;
}

const dotColors: Record<string, string> = {
  purple: "bg-purple-400",
  cyan: "bg-cyan-400",
  emerald: "bg-emerald-400",
  amber: "bg-amber-400",
  rose: "bg-rose-400",
  violet: "bg-violet-400",
};

const borderColors: Record<string, string> = {
  purple: "border-purple-500/20",
  cyan: "border-cyan-500/20",
  emerald: "border-emerald-500/20",
  amber: "border-amber-500/20",
  rose: "border-rose-500/20",
  violet: "border-violet-500/20",
};

const pulseRingColors: Record<string, string> = {
  purple: "bg-purple-400/30",
  cyan: "bg-cyan-400/30",
  emerald: "bg-emerald-400/30",
  amber: "bg-amber-400/30",
  rose: "bg-rose-400/30",
  violet: "bg-violet-400/30",
};

const PULSE_STORAGE_KEY = "launchapp_tooltip_seen";

function hasSeenPulse(): boolean {
  try { return !!localStorage.getItem(PULSE_STORAGE_KEY); } catch { return false; }
}

function markPulseSeen() {
  try { localStorage.setItem(PULSE_STORAGE_KEY, "1"); } catch {}
}

/**
 * Small "?" icon that shows an explanation tooltip on hover (desktop)
 * or on tap (mobile). Auto-hides on outside click/tap.
 * Shows animated pulse ring on first visit to attract attention.
 */
export function MetricTooltip({ text, color = "purple" }: MetricTooltipProps) {
  const [open, setOpen] = useState(false);
  const [showPulse, setShowPulse] = useState(!hasSeenPulse());
  const ref = useRef<HTMLDivElement>(null);

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent | TouchEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    document.addEventListener("touchstart", handler);
    return () => {
      document.removeEventListener("mousedown", handler);
      document.removeEventListener("touchstart", handler);
    };
  }, [open]);

  // Auto-close after 4 seconds
  useEffect(() => {
    if (!open) return;
    const timer = setTimeout(() => setOpen(false), 4000);
    return () => clearTimeout(timer);
  }, [open]);

  // Stop pulse after first interaction or after 6 seconds
  useEffect(() => {
    if (!showPulse) return;
    const timer = setTimeout(() => {
      setShowPulse(false);
      markPulseSeen();
    }, 6000);
    return () => clearTimeout(timer);
  }, [showPulse]);

  const handleOpen = () => {
    setOpen((v) => !v);
    if (showPulse) {
      setShowPulse(false);
      markPulseSeen();
    }
  };

  return (
    <div ref={ref} className="relative inline-flex">
      {/* Animated pulse ring (first visit only) */}
      {showPulse && (
        <span className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <span className={`absolute w-6 h-6 rounded-full ${pulseRingColors[color]} animate-ping`} />
          <span className={`absolute w-4 h-4 rounded-full ${pulseRingColors[color]} animate-pulse`} />
        </span>
      )}
      <button
        onClick={(e) => { e.stopPropagation(); handleOpen(); }}
        onMouseEnter={() => setOpen(true)}
        onMouseLeave={() => setOpen(false)}
        className={`relative z-10 w-4 h-4 rounded-full flex items-center justify-center transition-colors ${
          showPulse ? "text-zinc-400" : "text-zinc-600 hover:text-zinc-400"
        }`}
        aria-label="Explain metric"
      >
        <HelpCircle className="w-3 h-3" />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 4, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 4, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className={`absolute z-50 bottom-full left-1/2 -translate-x-1/2 mb-2 w-52 sm:w-56`}
          >
            <div className={`relative p-3 rounded-xl bg-zinc-900 border ${borderColors[color]} shadow-xl shadow-black/30`}>
              {/* Arrow */}
              <div className={`absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 rotate-45 bg-zinc-900 border-r border-b ${borderColors[color]}`} />
              <div className="flex items-start gap-2">
                <div className={`w-1.5 h-1.5 rounded-full ${dotColors[color]} mt-1.5 shrink-0`} />
                <p className="text-[11px] text-zinc-400 leading-relaxed">{text}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
