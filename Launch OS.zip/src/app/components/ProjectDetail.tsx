import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import {
  ArrowLeft, Pencil, Trash2, Rocket, Package, Globe, BarChart3,
  CheckCircle, Clock, Pause, FileText, Link2, Users, Zap, AlertTriangle,
  X, Save, ExternalLink,
} from "lucide-react";
import { useI18n } from "./i18n";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { loadProjects, updateProject, deleteProject, type Project } from "./user-progress";
import { toast } from "sonner";

const STATUS_CONFIG: Record<string, { icon: typeof Rocket; color: string; bg: string }> = {
  draft: { icon: FileText, color: "text-zinc-400", bg: "bg-zinc-500/10" },
  ready: { icon: CheckCircle, color: "text-emerald-400", bg: "bg-emerald-500/10" },
  launched: { icon: Rocket, color: "text-purple-400", bg: "bg-purple-500/10" },
  paused: { icon: Pause, color: "text-amber-400", bg: "bg-amber-500/10" },
};

const COLOR_MAP: Record<string, string> = {
  purple: "from-purple-500 to-violet-600",
  blue: "from-blue-500 to-cyan-600",
  emerald: "from-emerald-500 to-teal-600",
  rose: "from-rose-500 to-pink-600",
  amber: "from-amber-500 to-orange-600",
  cyan: "from-cyan-500 to-sky-600",
  violet: "from-violet-500 to-purple-600",
  orange: "from-orange-500 to-red-600",
};

export function ProjectDetail() {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [project, setProject] = useState<Project | null>(null);
  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState({ name: "", category: "", url: "", description: "", audience: "" });
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [loading, setLoading] = useState(true);

  useDocumentTitle(project?.name || t("projDetail.overview"));

  useEffect(() => {
    const projects = loadProjects();
    const found = projects.find((p) => p.id === projectId);
    setProject(found || null);
    if (found) {
      setEditForm({
        name: found.name,
        category: found.category,
        url: found.url,
        description: found.description,
        audience: found.audience,
      });
    }
    setTimeout(() => setLoading(false), 400);
  }, [projectId]);

  if (loading) {
    return (
      <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-6">
        <div className="h-8 w-48 rounded-lg bg-white/[0.06] animate-pulse" />
        <div className="h-48 rounded-2xl bg-white/[0.04] animate-pulse" />
        <div className="grid sm:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => <div key={i} className="h-24 rounded-xl bg-white/[0.04] animate-pulse" />)}
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="p-4 sm:p-6 max-w-4xl mx-auto">
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="w-16 h-16 rounded-2xl bg-zinc-500/10 flex items-center justify-center mb-4">
            <AlertTriangle className="w-7 h-7 text-zinc-500" />
          </div>
          <h2 className="text-white mb-2" style={{ fontWeight: 700 }}>{t("projDetail.notFound")}</h2>
          <p className="text-sm text-zinc-500 mb-6">{t("projDetail.notFoundDesc")}</p>
          <button
            onClick={() => navigate("/dashboard")}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-sm transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            {t("projDetail.back")}
          </button>
        </div>
      </div>
    );
  }

  const statusCfg = STATUS_CONFIG[project.status] || STATUS_CONFIG.draft;
  const StatusIcon = statusCfg.icon;
  const gradientClass = COLOR_MAP[project.color] || COLOR_MAP.purple;

  const handleSave = () => {
    const updated = updateProject(project.id, editForm);
    if (updated) {
      setProject(updated);
      setEditing(false);
      toast.success(t("projDetail.saved"));
    }
  };

  const handleDelete = () => {
    deleteProject(project.id);
    toast.success(t("projects.deleted"));
    navigate("/dashboard");
  };

  const handleStatusChange = (status: Project["status"]) => {
    const updated = updateProject(project.id, { status });
    if (updated) setProject(updated);
  };

  const stats = [
    { label: t("projDetail.channelsConnected"), value: project.channelsConnected, icon: Globe, color: "text-cyan-400", bg: "bg-cyan-500/10" },
    { label: t("projDetail.contentGenerated"), value: `${project.contentGenerated}%`, icon: Package, color: "text-violet-400", bg: "bg-violet-500/10" },
    { label: t("projDetail.tokensUsed"), value: project.tokensUsed, icon: Zap, color: "text-amber-400", bg: "bg-amber-500/10" },
    { label: t("projDetail.launchDay"), value: project.launchDay > 0 ? `${t("projects.day")} ${project.launchDay}` : "—", icon: Rocket, color: "text-emerald-400", bg: "bg-emerald-500/10" },
  ];

  const quickActions = [
    { label: t("projDetail.goToPackage"), icon: Package, path: "/dashboard/package", color: "text-violet-400" },
    { label: t("projDetail.goToChannels"), icon: Globe, path: "/dashboard/growth", color: "text-cyan-400" },
    { label: t("projDetail.goToLaunch"), icon: Rocket, path: "/dashboard/launch", color: "text-emerald-400" },
    { label: t("projDetail.goToAnalytics"), icon: BarChart3, path: "/dashboard/analytics", color: "text-purple-400" },
  ];

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => navigate("/dashboard")}
          className="w-8 h-8 rounded-lg border border-white/10 flex items-center justify-center hover:bg-white/5 transition-colors shrink-0"
        >
          <ArrowLeft className="w-4 h-4 text-zinc-400" />
        </button>
        <div className="flex-1 min-w-0">
          <LargeTitle title={project.name} subtitle={t("projDetail.overview")} />
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setEditing(!editing)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/10 hover:border-white/20 text-xs text-zinc-400 hover:text-white transition-all"
          >
            <Pencil className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{t("projects.edit")}</span>
          </button>
        </div>
      </div>

      {/* Project Hero Card */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-2xl border border-white/5 bg-white/[0.02]"
      >
        {/* Gradient stripe */}
        <div className={`h-2 bg-gradient-to-r ${gradientClass}`} />

        <div className="p-5 sm:p-6">
          <div className="flex items-start justify-between gap-4 mb-5">
            {/* Status badge */}
            <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs ${statusCfg.bg} ${statusCfg.color}`} style={{ fontWeight: 600 }}>
              <StatusIcon className="w-3.5 h-3.5" />
              {t(`projects.${project.status}`)}
            </div>
            {/* Status dropdown */}
            <div className="flex items-center gap-1.5">
              {(["draft", "ready", "launched", "paused"] as const).map((s) => {
                const cfg = STATUS_CONFIG[s];
                const Icon = cfg.icon;
                const isActive = project.status === s;
                return (
                  <button
                    key={s}
                    onClick={() => handleStatusChange(s)}
                    className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all ${
                      isActive ? `${cfg.bg} ${cfg.color}` : "text-zinc-600 hover:text-zinc-400 hover:bg-white/5"
                    }`}
                    title={t(`projects.${s}`)}
                  >
                    <Icon className="w-3.5 h-3.5" />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Edit form or display */}
          <AnimatePresence mode="wait">
            {editing ? (
              <motion.div key="edit" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
                <div>
                  <label className="text-xs text-zinc-500 mb-1 block">{t("projDetail.name")}</label>
                  <input
                    value={editForm.name}
                    onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-white/[0.03] border border-white/10 text-white text-sm focus:border-purple-500/50 focus:outline-none transition-colors"
                  />
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-zinc-500 mb-1 block">{t("projDetail.category")}</label>
                    <input
                      value={editForm.category}
                      onChange={(e) => setEditForm({ ...editForm, category: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-white/[0.03] border border-white/10 text-white text-sm focus:border-purple-500/50 focus:outline-none transition-colors"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-zinc-500 mb-1 block">{t("projDetail.audience")}</label>
                    <input
                      value={editForm.audience}
                      onChange={(e) => setEditForm({ ...editForm, audience: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-white/[0.03] border border-white/10 text-white text-sm focus:border-purple-500/50 focus:outline-none transition-colors"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs text-zinc-500 mb-1 block">{t("projDetail.url")}</label>
                  <input
                    value={editForm.url}
                    onChange={(e) => setEditForm({ ...editForm, url: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-white/[0.03] border border-white/10 text-white text-sm focus:border-purple-500/50 focus:outline-none transition-colors"
                    placeholder="https://"
                  />
                </div>
                <div>
                  <label className="text-xs text-zinc-500 mb-1 block">{t("projDetail.description")}</label>
                  <textarea
                    value={editForm.description}
                    onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                    rows={3}
                    className="w-full px-3 py-2 rounded-lg bg-white/[0.03] border border-white/10 text-white text-sm focus:border-purple-500/50 focus:outline-none transition-colors resize-none"
                  />
                </div>
                <div className="flex items-center gap-3 pt-2">
                  <button onClick={handleSave} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-sm transition-all" style={{ fontWeight: 600 }}>
                    <Save className="w-4 h-4" />{t("projDetail.save")}
                  </button>
                  <button onClick={() => setEditing(false)} className="text-sm text-zinc-500 hover:text-zinc-300 transition-colors">
                    {t("projDetail.cancel")}
                  </button>
                </div>
              </motion.div>
            ) : (
              <motion.div key="display" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-3">
                {project.description && (
                  <p className="text-sm text-zinc-400">{project.description}</p>
                )}
                <div className="flex flex-wrap gap-x-6 gap-y-2 text-xs text-zinc-500">
                  {project.category && (
                    <span className="inline-flex items-center gap-1.5"><FileText className="w-3.5 h-3.5" />{project.category}</span>
                  )}
                  {project.audience && (
                    <span className="inline-flex items-center gap-1.5"><Users className="w-3.5 h-3.5" />{project.audience}</span>
                  )}
                  {project.url && (
                    <a href={project.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-purple-400 hover:text-purple-300 transition-colors">
                      <Link2 className="w-3.5 h-3.5" />{project.url.replace(/https?:\/\//, "")}<ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
                <div className="flex gap-3 text-[10px] text-zinc-600 pt-1">
                  <span>{t("projects.created")}: {new Date(project.createdAt).toLocaleDateString()}</span>
                  <span>{t("projects.updated")}: {new Date(project.updatedAt).toLocaleDateString()}</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 + i * 0.05 }}
            className="p-4 rounded-xl border border-white/5 bg-white/[0.02]"
          >
            <div className={`w-8 h-8 rounded-lg ${s.bg} flex items-center justify-center mb-3`}>
              <s.icon className={`w-4 h-4 ${s.color}`} />
            </div>
            <div className="text-lg text-white" style={{ fontWeight: 700 }}>{s.value}</div>
            <div className="text-[11px] text-zinc-500 mt-0.5">{s.label}</div>
          </motion.div>
        ))}
      </div>

      {/* Progress Bar */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="p-5 rounded-xl border border-white/5 bg-white/[0.02]"
      >
        <h3 className="text-sm text-white mb-3" style={{ fontWeight: 600 }}>{t("projDetail.launchProgress")}</h3>
        <div className="w-full h-2 rounded-full bg-white/[0.06] overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${Math.min(100, (project.contentGenerated * 0.4) + (project.channelsConnected > 0 ? 30 : 0) + (project.launchDay > 0 ? 30 : 0))}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
            className={`h-full rounded-full bg-gradient-to-r ${gradientClass}`}
          />
        </div>
      </motion.div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.35 }}
      >
        <h3 className="text-sm text-white mb-3" style={{ fontWeight: 600 }}>{t("projDetail.quickActions")}</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {quickActions.map((a) => (
            <button
              key={a.path}
              onClick={() => navigate(a.path)}
              className="p-4 rounded-xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.04] hover:border-white/10 transition-all text-left group ios-press"
            >
              <a.icon className={`w-5 h-5 ${a.color} mb-2 group-hover:scale-110 transition-transform`} />
              <div className="text-xs text-zinc-300" style={{ fontWeight: 500 }}>{a.label}</div>
            </button>
          ))}
        </div>
      </motion.div>

      {/* Danger Zone */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="p-5 rounded-xl border border-red-500/10 bg-red-500/[0.02]"
      >
        <h3 className="text-sm text-red-400 mb-1" style={{ fontWeight: 600 }}>{t("projDetail.danger")}</h3>
        <p className="text-xs text-zinc-500 mb-4">{t("projDetail.deleteDesc")}</p>
        <button
          onClick={() => setShowDeleteConfirm(true)}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-red-500/20 hover:border-red-500/40 hover:bg-red-500/5 text-sm text-red-400 transition-all"
        >
          <Trash2 className="w-4 h-4" />
          {t("projDetail.deleteProject")}
        </button>
      </motion.div>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60"
            onClick={() => setShowDeleteConfirm(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="liquid-glass-modal w-full max-w-sm rounded-2xl p-6 text-center"
              role="dialog"
              aria-modal="true"
              aria-label={t("projDetail.deleteProject")}
            >
              <div className="w-12 h-12 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-5 h-5 text-red-400" />
              </div>
              <h3 className="text-white mb-2" style={{ fontWeight: 700 }}>{t("projDetail.deleteProject")}</h3>
              <p className="text-sm text-zinc-400 mb-6">{t("projects.deleteConfirm")}</p>
              <div className="flex gap-3 justify-center">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-5 py-2 rounded-xl border border-white/10 text-sm text-zinc-400 hover:text-white transition-all"
                >
                  {t("projDetail.cancel")}
                </button>
                <button
                  onClick={handleDelete}
                  className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-sm transition-all"
                >
                  {t("projects.delete")}
                </button>
              </div>
              <button onClick={() => setShowDeleteConfirm(false)} className="absolute top-3 right-3 text-zinc-500 hover:text-zinc-300 transition-colors">
                <X className="w-5 h-5" />
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
