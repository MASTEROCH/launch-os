import { useState, useEffect, useRef } from "react";
import { useNavigate, useSearchParams } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import {
  Rocket, Mail, Lock, Eye, EyeOff, User, ArrowRight, Check, Loader, Sparkles,
  Sun, Moon,
} from "lucide-react";
import { useI18n, LangSwitcher } from "./i18n";
import { useTheme } from "./ThemeProvider";
import { FloatingOrbs } from "./FloatingOrbs";
import { LaunchLogo } from "./LaunchLogo";
import { useForceDarkMode } from "./useForceDarkMode";

/* ── social provider icons (inline SVG) ── */

function MetaIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
      <path d="M12 2.04c-5.5 0-10 4.49-10 10.02 0 5 3.66 9.15 8.44 9.9v-7H7.9v-2.9h2.54V9.85c0-2.51 1.49-3.89 3.78-3.89 1.09 0 2.24.2 2.24.2v2.46h-1.26c-1.24 0-1.63.77-1.63 1.56v1.88h2.78l-.45 2.9h-2.33v7a10.04 10.04 0 0 0 8.44-9.9c0-5.53-4.5-10.02-10-10.02Z" />
    </svg>
  );
}

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1Z" fill="#4285F4" />
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23Z" fill="#34A853" />
      <path d="M5.84 14.09A6.97 6.97 0 0 1 5.48 12c0-.72.13-1.43.36-2.09V7.07H2.18A11.96 11.96 0 0 0 1 12c0 1.94.45 3.77 1.18 5.07l3.66-2.98Z" fill="#FBBC05" />
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53Z" fill="#EA4335" />
    </svg>
  );
}

function AppleIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
      <path d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.52-3.23 0-1.44.64-2.2.46-3.06-.4C3.79 16.17 4.36 9.53 8.7 9.28c1.24.06 2.1.72 2.83.76.87-.18 1.71-.9 2.89-.8 1.41.12 2.42.69 3.09 1.78-2.61 1.59-1.98 5.06.4 6.03-.57 1.49-1.31 2.92-2.86 3.23ZM12.03 9.2c-.14-2.6 2.04-4.6 4.34-4.82.34 2.82-2.5 4.93-4.34 4.82Z" />
    </svg>
  );
}

function MicrosoftIcon() {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5">
      <rect x="1" y="1" width="10" height="10" fill="#F25022" rx="1" />
      <rect x="13" y="1" width="10" height="10" fill="#7FBA00" rx="1" />
      <rect x="1" y="13" width="10" height="10" fill="#00A4EF" rx="1" />
      <rect x="13" y="13" width="10" height="10" fill="#FFB900" rx="1" />
    </svg>
  );
}

/* ── animated background ── */

function AuthBackground() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      <div className="absolute top-1/4 -left-32 w-[500px] h-[500px] bg-purple-500/8 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 -right-32 w-[400px] h-[400px] bg-violet-500/6 rounded-full blur-3xl" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/4 rounded-full blur-3xl" />
      <div className="absolute inset-0" style={{ backgroundImage: "radial-gradient(rgba(139,92,246,0.04) 1px, transparent 1px)", backgroundSize: "32px 32px" }} />
    </div>
  );
}

/* ── social button ── */

function SocialButton({ icon, label, onClick, loading }: { icon: React.ReactNode; label: string; onClick: () => void; loading: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={loading}
      className="flex items-center gap-3 w-full px-4 py-3 rounded-xl border border-white/10 bg-white/[0.02] hover:bg-white/[0.05] hover:border-white/20 transition-all disabled:opacity-50 disabled:pointer-events-none group"
    >
      <div className="shrink-0">{icon}</div>
      <span className="text-sm text-zinc-300 group-hover:text-white transition-colors">{label}</span>
    </button>
  );
}

/* ── main auth component ── */

export function AuthPage() {
  useForceDarkMode();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initialTab = searchParams.get("tab") === "register" ? "register" : "login";

  const { t } = useI18n();
  const { theme, toggleTheme } = useTheme();
  const [tab, setTab] = useState<"login" | "register">(initialTab);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loadingProvider, setLoadingProvider] = useState<string | null>(null);
  const [magicLink, setMagicLink] = useState(false);
  const [magicLinkSent, setMagicLinkSent] = useState(false);
  const [magicEmail, setMagicEmail] = useState("");
  const [magicCooldown, setMagicCooldown] = useState(0);
  const cooldownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // cleanup cooldown interval
  useEffect(() => {
    return () => { if (cooldownRef.current) clearInterval(cooldownRef.current); };
  }, []);

  const startCooldown = () => {
    setMagicCooldown(60);
    if (cooldownRef.current) clearInterval(cooldownRef.current);
    cooldownRef.current = setInterval(() => {
      setMagicCooldown((prev) => {
        if (prev <= 1) {
          if (cooldownRef.current) clearInterval(cooldownRef.current);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const [form, setForm] = useState({ name: "", email: "", password: "", confirmPassword: "" });
  const update = (key: string, val: string) => setForm((p) => ({ ...p, [key]: val }));

  const socialProviders = [
    { id: "google", label: `${t("auth.continueWith")} Google`, icon: <GoogleIcon /> },
    { id: "meta", label: `${t("auth.continueWith")} Meta`, icon: <MetaIcon /> },
    { id: "apple", label: `${t("auth.continueWith")} Apple`, icon: <AppleIcon /> },
    { id: "microsoft", label: `${t("auth.continueWith")} Microsoft`, icon: <MicrosoftIcon /> },
  ];

  const handleSocialLogin = (provider: string) => {
    setLoadingProvider(provider);
    setTimeout(() => {
      setLoadingProvider(null);
      navigate("/dashboard");
    }, 1200);
  };

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      navigate("/dashboard");
    }, 1500);
  };

  const handleMagicLinkSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!magicEmail || magicCooldown > 0) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setMagicLinkSent(true);
      startCooldown();
      // simulate auto-login after "clicking the link"
      setTimeout(() => {
        navigate("/dashboard");
      }, 4000);
    }, 1500);
  };

  const handleMagicResend = () => {
    if (magicCooldown > 0) return;
    startCooldown();
    // simulate resend - reset progress bar
    setMagicLinkSent(false);
    setTimeout(() => setMagicLinkSent(true), 300);
  };

  return (
    <div className="relative min-h-screen bg-[var(--app-bg)] text-white flex flex-col overflow-hidden">
      <AuthBackground />
      <FloatingOrbs />

      {/* Top bar */}
      <div className="liquid-glass relative z-10 flex items-center justify-between px-6 py-4">
        <button onClick={() => navigate("/")} className="flex items-center gap-2 hover:opacity-80 transition-opacity">
          <LaunchLogo size={32} />
          <span style={{ fontWeight: 700 }}>Launch OS</span>
        </button>
        <div className="flex items-center gap-2">
          <LangSwitcher />
          <button
            onClick={toggleTheme}
            aria-label={theme === "dark" ? "Switch to light theme" : "Switch to dark theme"}
            className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-500 hover:text-zinc-300 transition-all"
          >
            {theme === "dark" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Center */}
      <div className="relative z-10 flex-1 flex items-center justify-center px-4 py-8">
        <div className="w-full max-w-md">

          {/* Pulsing logo */}
          <div className="relative w-14 h-14 mx-auto mb-6">
            <motion.div animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0, 0.3] }} transition={{ duration: 2, repeat: Infinity }} className="absolute inset-0 rounded-2xl bg-purple-500/20" />
            <div className="relative w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center shadow-lg shadow-purple-500/30">
              <Rocket className="w-6 h-6 text-white" />
            </div>
          </div>

          {/* Tab switcher */}
          <div className="flex gap-1 p-1 rounded-xl bg-white/[0.03] border border-white/5 mb-6 w-fit mx-auto">
            <button onClick={() => setTab("login")} className={`px-5 py-2 rounded-lg text-sm transition-all ${tab === "login" ? "bg-purple-500/15 text-purple-400" : "text-zinc-500 hover:text-zinc-300"}`} style={{ fontWeight: tab === "login" ? 600 : 400 }}>
              {t("auth.tab.login")}
            </button>
            <button onClick={() => setTab("register")} className={`px-5 py-2 rounded-lg text-sm transition-all ${tab === "register" ? "bg-purple-500/15 text-purple-400" : "text-zinc-500 hover:text-zinc-300"}`} style={{ fontWeight: tab === "register" ? 600 : 400 }}>
              {t("auth.tab.register")}
            </button>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={tab}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
            >
              {/* Title */}
              <div className="text-center mb-6">
                <h1 className="text-2xl tracking-tight mb-1.5" style={{ fontWeight: 700 }}>
                  {tab === "login" ? t("auth.loginTitle") : t("auth.registerTitle")}
                </h1>
                <p className="text-sm text-zinc-500">
                  {tab === "login" ? t("auth.loginSub") : t("auth.registerSub")}
                </p>
              </div>

              {/* Social providers */}
              <div className="space-y-2.5 mb-6">
                {socialProviders.map((provider) => (
                  <div key={provider.id} className="relative">
                    {loadingProvider === provider.id ? (
                      <div className="flex items-center gap-3 w-full px-4 py-3 rounded-xl border border-purple-500/30 bg-purple-500/5">
                        <Loader className="w-5 h-5 text-purple-400 animate-spin" />
                        <span className="text-sm text-purple-300">{tab === "login" ? t("auth.signingIn") : t("auth.creatingAccount")}</span>
                        <motion.div initial={{ width: 0 }} animate={{ width: "100%" }} transition={{ duration: 1.2, ease: "linear" }}
                          className="absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full" />
                      </div>
                    ) : (
                      <SocialButton
                        icon={provider.icon}
                        label={provider.label}
                        onClick={() => handleSocialLogin(provider.id)}
                        loading={loadingProvider !== null}
                      />
                    )}
                  </div>
                ))}
              </div>

              {/* Divider */}
              <div className="flex items-center gap-3 mb-6">
                <div className="flex-1 h-px bg-white/5" />
                <span className="text-xs text-zinc-600">{t("auth.orEmail")}</span>
                <div className="flex-1 h-px bg-white/5" />
              </div>

              {/* Magic link toggle (login only) */}
              {tab === "login" && (
                <div className="flex gap-1 p-1 rounded-xl bg-white/[0.03] border border-white/5 mb-5 w-fit mx-auto">
                  <button onClick={() => { setMagicLink(false); setMagicLinkSent(false); }} className={`px-4 py-1.5 rounded-lg text-xs transition-all ${!magicLink ? "bg-white/[0.06] text-zinc-200" : "text-zinc-500 hover:text-zinc-300"}`} style={{ fontWeight: !magicLink ? 500 : 400 }}>
                    {t("auth.withPassword")}
                  </button>
                  <button onClick={() => { setMagicLink(true); setMagicLinkSent(false); }} className={`px-4 py-1.5 rounded-lg text-xs transition-all flex items-center gap-1.5 ${magicLink ? "bg-purple-500/15 text-purple-400" : "text-zinc-500 hover:text-zinc-300"}`} style={{ fontWeight: magicLink ? 500 : 400 }}>
                    <Sparkles className="w-3 h-3" />
                    {t("auth.magicLink")}
                  </button>
                </div>
              )}

              <AnimatePresence mode="wait">
                {/* Magic link sent state */}
                {tab === "login" && magicLink && magicLinkSent ? (
                  <motion.div key="magic-sent" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="text-center py-4">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", stiffness: 200, damping: 12 }}
                      className="w-16 h-16 mx-auto mb-5 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-green-500/10 border border-emerald-500/20 flex items-center justify-center"
                    >
                      <Mail className="w-7 h-7 text-emerald-400" />
                    </motion.div>
                    <h3 className="text-lg mb-2" style={{ fontWeight: 600 }}>{t("auth.magicLinkSentTitle")}</h3>
                    <p className="text-sm text-zinc-500 mb-1">{t("auth.magicLinkSentDesc")}</p>
                    <p className="text-sm text-zinc-300" style={{ fontWeight: 500 }}>{magicEmail}</p>
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: "100%" }}
                      transition={{ duration: 3, ease: "linear" }}
                      className="h-0.5 bg-gradient-to-r from-purple-500 to-emerald-500 rounded-full mt-6 mx-auto max-w-xs"
                    />
                    <p className="text-xs text-zinc-600 mt-3">{t("auth.magicLinkRedirect")}</p>
                    <div className="text-center mt-3">
                      {magicCooldown > 0 ? (
                        <span className="text-xs text-zinc-600">{t("auth.magicLinkResendIn")} {magicCooldown}s</span>
                      ) : (
                        <button onClick={handleMagicResend} className="text-xs text-purple-400 hover:text-purple-300 transition-colors" style={{ fontWeight: 500 }}>{t("auth.magicLinkResend")}</button>
                      )}
                    </div>
                  </motion.div>
                ) : tab === "login" && magicLink ? (
                  /* Magic link form */
                  <motion.div key="magic-form" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                    <form onSubmit={handleMagicLinkSubmit} className="space-y-4">
                      <div>
                        <label className="text-xs text-zinc-500 mb-1 block">{t("auth.email")}</label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                          <input type="email" value={magicEmail} onChange={(e) => setMagicEmail(e.target.value)} placeholder={t("auth.emailPh")} required
                            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-sm" />
                        </div>
                      </div>
                      <motion.button
                        type="submit"
                        disabled={loading || !magicEmail || magicCooldown > 0}
                        whileHover={{ scale: 1.01 }}
                        whileTap={{ scale: 0.99 }}
                        className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 disabled:opacity-50 text-white py-3 rounded-xl text-sm transition-all shadow-lg shadow-purple-500/20"
                      >
                        {loading ? (
                          <><Loader className="w-4 h-4 animate-spin" />{t("auth.magicLinkSending")}</>
                        ) : (
                          <><Sparkles className="w-4 h-4" />{t("auth.magicLinkSend")}<ArrowRight className="w-4 h-4" /></>
                        )}
                      </motion.button>
                      <p className="text-xs text-zinc-600 text-center leading-relaxed">{t("auth.magicLinkHint")}</p>
                    </form>
                  </motion.div>
                ) : (
                  /* Standard email/password form */
                  <motion.div key="password-form" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                    {/* Email form */}
                    <form onSubmit={handleEmailSubmit} className="space-y-4">
                      {tab === "register" && (
                        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}>
                          <label className="text-xs text-zinc-500 mb-1 block">{t("auth.fullName")}</label>
                          <div className="relative">
                            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                            <input value={form.name} onChange={(e) => update("name", e.target.value)} placeholder={t("auth.fullNamePh")}
                              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-sm" />
                          </div>
                        </motion.div>
                      )}

                      <div>
                        <label className="text-xs text-zinc-500 mb-1 block">{t("auth.email")}</label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                          <input type="email" value={form.email} onChange={(e) => update("email", e.target.value)} placeholder={t("auth.emailPh")}
                            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-sm" />
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-xs text-zinc-500">{t("auth.password")}</label>
                          {tab === "login" && (
                            <button type="button" onClick={() => navigate("/forgot-password")} className="text-xs text-purple-400 hover:text-purple-300 transition-colors">{t("auth.forgotPassword")}</button>
                          )}
                        </div>
                        <div className="relative">
                          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                          <input type={showPassword ? "text" : "password"} value={form.password} onChange={(e) => update("password", e.target.value)} placeholder={t("auth.passwordPh")}
                            className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-sm" />
                          <button type="button" onClick={() => setShowPassword((v) => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-zinc-400 transition-colors">
                            {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>

                      {tab === "register" && (
                        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}>
                          <label className="text-xs text-zinc-500 mb-1 block">{t("auth.confirmPassword")}</label>
                          <div className="relative">
                            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                            <input type={showPassword ? "text" : "password"} value={form.confirmPassword} onChange={(e) => update("confirmPassword", e.target.value)} placeholder={t("auth.confirmPasswordPh")}
                              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-sm" />
                          </div>
                        </motion.div>
                      )}

                      <motion.button
                        type="submit"
                        disabled={loading}
                        whileHover={{ scale: 1.01 }}
                        whileTap={{ scale: 0.99 }}
                        className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 disabled:opacity-50 text-white py-3 rounded-xl text-sm transition-all shadow-lg shadow-purple-500/20"
                      >
                        {loading ? (
                          <><Loader className="w-4 h-4 animate-spin" />{tab === "login" ? t("auth.signingIn") : t("auth.creatingAccount")}</>
                        ) : (
                          <>{tab === "login" ? t("auth.signIn") : t("auth.signUp")}<ArrowRight className="w-4 h-4" /></>
                        )}
                      </motion.button>
                    </form>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Terms */}
              {tab === "register" && (
                <p className="text-xs text-zinc-600 text-center mt-4 leading-relaxed">{t("auth.terms")}</p>
              )}

              {/* Switch tab */}
              <div className="text-center mt-6">
                <span className="text-xs text-zinc-600">
                  {tab === "login" ? t("auth.noAccount") : t("auth.haveAccount")}{" "}
                  <button onClick={() => setTab(tab === "login" ? "register" : "login")} className="text-purple-400 hover:text-purple-300 transition-colors" style={{ fontWeight: 500 }}>
                    {tab === "login" ? t("auth.register") : t("auth.login")}
                  </button>
                </span>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Footer */}
      <div className="relative z-10 text-center py-4">
        <p className="text-xs text-zinc-700">&copy; 2026 Launch OS</p>
      </div>
    </div>
  );
}