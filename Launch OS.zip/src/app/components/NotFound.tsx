import { useNavigate } from "react-router";
import { motion } from "motion/react";
import { Home, ArrowLeft, Rocket, Search } from "lucide-react";
import { useI18n } from "./i18n";

export function NotFound() {
  const navigate = useNavigate();
  const { t } = useI18n();

  return (
    <div className="min-h-screen bg-[var(--app-bg)] flex items-center justify-center p-6 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-md w-full text-center relative z-10"
      >
        {/* 404 number */}
        <div className="mb-6">
          <span
            className="text-8xl bg-gradient-to-b from-zinc-400 to-zinc-700 bg-clip-text text-transparent"
            style={{ fontWeight: 800 }}
          >
            404
          </span>
        </div>

        {/* Icon */}
        <div className="w-16 h-16 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center mx-auto mb-6">
          <Search className="w-7 h-7 text-purple-400" />
        </div>

        <h1 className="text-xl text-white mb-2" style={{ fontWeight: 700 }}>
          {t("notFound.title")}
        </h1>
        <p className="text-sm text-zinc-500 mb-8">
          {t("notFound.desc")}
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={() => navigate(-1)}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl border border-white/10 hover:border-white/20 text-sm text-zinc-300 hover:text-white transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            {t("notFound.goBack")}
          </button>
          <button
            onClick={() => navigate("/")}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl border border-white/10 hover:border-white/20 text-sm text-zinc-300 hover:text-white transition-all"
          >
            <Home className="w-4 h-4" />
            {t("notFound.home")}
          </button>
          <button
            onClick={() => navigate("/dashboard")}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-sm text-white transition-all"
          >
            <Rocket className="w-4 h-4" />
            {t("notFound.dashboard")}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
