import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Sparkles, Briefcase, DollarSign, Handshake, Workflow,
  GraduationCap, Check, Bell, ChevronUp,
  Rocket, Eye, Wand2,
  Video, FileText, BarChart3, Mail, Search as SearchIcon, Image,
  Globe, ShoppingCart,
} from "lucide-react";
import { useI18n } from "./i18n";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { toast } from "sonner";
import { ComingSoonModal, type ComingSoonFeatureId } from "./ComingSoonModal";
import { loadProgress, updateProgress } from "./user-progress";
import { fireConfetti } from "./Confetti";
import { useNavigate } from "react-router";

/* ─── Roadmap feature card ─── */
interface RoadmapFeature {
  id: string;
  icon: typeof Briefcase;
  labelKey: string;
  descKey: string;
  color: string;
  gradient: string;
  comingSoonId?: ComingSoonFeatureId;
  baseVotes: number;
}

interface PlannedFeature {
  id: string;
  icon: typeof Briefcase;
  label: string;
  desc: string;
  color: string;
  votes: number;
}

export function Roadmap() {
  const { t } = useI18n();
  useDocumentTitle(t("roadmap.title"));
  const navigate = useNavigate();

  const [notified, setNotified] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem("launchapp_roadmap_notified");
      return saved ? new Set(JSON.parse(saved)) : new Set();
    } catch { return new Set(); }
  });
  const [voted, setVoted] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem("launchapp_roadmap_voted");
      return saved ? new Set(JSON.parse(saved)) : new Set();
    } catch { return new Set(); }
  });
  const [comingSoonFeature, setComingSoonFeature] = useState<ComingSoonFeatureId | null>(null);

  /* ─── Coming Soon ─── */
  const comingSoonFeatures: RoadmapFeature[] = [
    { id: "aiContent", icon: Wand2, labelKey: "cs.aiContent.title", descKey: "cs.aiContent.desc", color: "indigo", gradient: "from-indigo-500/10 to-violet-500/5", comingSoonId: "aiContent", baseVotes: 521 },
    { id: "crm", icon: Briefcase, labelKey: "cs.crm.title", descKey: "cs.crm.desc", color: "blue", gradient: "from-blue-500/10 to-cyan-500/5", comingSoonId: "crm", baseVotes: 387 },
    { id: "finance", icon: DollarSign, labelKey: "cs.finance.title", descKey: "cs.finance.desc", color: "emerald", gradient: "from-emerald-500/10 to-teal-500/5", comingSoonId: "finance", baseVotes: 294 },
    { id: "automations", icon: Workflow, labelKey: "cs.automations.title", descKey: "cs.automations.desc", color: "orange", gradient: "from-orange-500/10 to-amber-500/5", comingSoonId: "automations", baseVotes: 456 },
    { id: "investorHub", icon: Handshake, labelKey: "cs.investorHub.title", descKey: "cs.investorHub.desc", color: "violet", gradient: "from-violet-500/10 to-purple-500/5", comingSoonId: "investorHub", baseVotes: 312 },
    { id: "training", icon: GraduationCap, labelKey: "cs.training.title", descKey: "cs.training.desc", color: "pink", gradient: "from-pink-500/10 to-rose-500/5", comingSoonId: "training", baseVotes: 248 },
  ];

  /* ─── Planned (voting) ─── */
  const [plannedFeatures] = useState<PlannedFeature[]>([
    { id: "marketplace", icon: Rocket, label: "Marketplace", desc: "Sell templates, packages & launch playbooks to other founders", color: "purple", votes: 342 },
    { id: "ai-copilot", icon: Sparkles, label: "AI Launch Copilot", desc: "Real-time AI assistant that guides you through each step", color: "cyan", votes: 289 },
    { id: "competitor", icon: Eye, label: "Competitor Tracker", desc: "Monitor competitor launches, pricing changes & positioning", color: "amber", votes: 215 },
    { id: "integrations", icon: Workflow, label: "Native Integrations", desc: "Direct posting to Reddit, Twitter, LinkedIn, Product Hunt", color: "emerald", votes: 478 },
  ]);

  const colorMap: Record<string, { bg: string; text: string; border: string }> = {
    purple: { bg: "bg-purple-500/10", text: "text-purple-400", border: "border-purple-500/15" },
    cyan: { bg: "bg-cyan-500/10", text: "text-cyan-400", border: "border-cyan-500/15" },
    emerald: { bg: "bg-emerald-500/10", text: "text-emerald-400", border: "border-emerald-500/15" },
    amber: { bg: "bg-amber-500/10", text: "text-amber-400", border: "border-amber-500/15" },
    rose: { bg: "bg-rose-500/10", text: "text-rose-400", border: "border-rose-500/15" },
    blue: { bg: "bg-blue-500/10", text: "text-blue-400", border: "border-blue-500/15" },
    violet: { bg: "bg-violet-500/10", text: "text-violet-400", border: "border-violet-500/15" },
    orange: { bg: "bg-orange-500/10", text: "text-orange-400", border: "border-orange-500/15" },
    pink: { bg: "bg-pink-500/10", text: "text-pink-400", border: "border-pink-500/15" },
    indigo: { bg: "bg-indigo-500/10", text: "text-indigo-400", border: "border-indigo-500/15" },
  };

  const handleNotify = (id: string) => {
    setNotified((prev) => new Set(prev).add(id));
    queueMicrotask(() => {
      try {
        const cur = localStorage.getItem("launchapp_roadmap_notified");
        const arr: string[] = cur ? JSON.parse(cur) : [];
        if (!arr.includes(id)) arr.push(id);
        localStorage.setItem("launchapp_roadmap_notified", JSON.stringify(arr));
      } catch {}
      toast.success(t("roadmap.notified"));
    });
  };

  /* Toggle vote: click to add, click again to remove */
  const handleVote = (id: string) => {
    const wasVoted = voted.has(id);
    setVoted((prev) => {
      const next = new Set(prev);
      if (wasVoted) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
    queueMicrotask(() => {
      try {
        const cur = localStorage.getItem("launchapp_roadmap_voted");
        let arr: string[] = cur ? JSON.parse(cur) : [];
        if (wasVoted) {
          arr = arr.filter(x => x !== id);
        } else {
          if (!arr.includes(id)) arr.push(id);
        }
        localStorage.setItem("launchapp_roadmap_voted", JSON.stringify(arr));
      } catch {}
      if (wasVoted) {
        toast.success(t("roadmap.unvoted"));
      } else {
        toast.success(t("roadmap.voted"));
      }
    });
  };

  /* ─── AI Services data ─── */
  const aiServices = [
    { key: "promoVideo", icon: Video, price: "$20", tokens: 400, color: "rose", badge: "popular" as const },
    { key: "contentPlan", icon: FileText, price: "$15", tokens: 300, color: "cyan", badge: "popular" as const },
    { key: "pitchDeck", icon: Briefcase, price: "$25", tokens: 500, color: "amber", badge: null },
    { key: "landingPage", icon: Globe, price: "$12", tokens: 240, color: "emerald", badge: null },
    { key: "competitorAnalysis", icon: BarChart3, price: "$18", tokens: 360, color: "violet", badge: "new" as const },
    { key: "emailSequence", icon: Mail, price: "$10", tokens: 200, color: "blue", badge: null },
    { key: "seoAudit", icon: SearchIcon, price: "$14", tokens: 280, color: "orange", badge: null },
    { key: "socialKit", icon: Image, price: "$22", tokens: 440, color: "pink", badge: "new" as const },
  ];

  const handleBuyService = (svc: typeof aiServices[number]) => {
    const progress = loadProgress();
    const currentBalance = progress.tokensAvailable || 0;
    if (currentBalance >= svc.tokens) {
      const newBal = currentBalance - svc.tokens;
      updateProgress({ tokensAvailable: newBal });
      fireConfetti();
      queueMicrotask(() => {
        toast.success(`${t(`aiServices.${svc.key}`)} -- processing! Ready in ~5 min`);
      });
    } else {
      const deficit = svc.tokens - currentBalance;
      queueMicrotask(() => {
        toast.error(`Need ${deficit} more tokens`);
      });
      navigate("/tokens");
    }
  };

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-8">
      <LargeTitle title={t("roadmap.title")} subtitle={t("roadmap.subtitle")} />

      {/* === COMING SOON === */}
      <div>
        <div className="mb-4">
          <h2 className="text-white" style={{ fontWeight: 600 }}>{t("roadmap.comingSoon")}</h2>
          <p className="text-xs text-zinc-500 mt-0.5">{t("roadmap.comingSoonDesc")}</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {comingSoonFeatures.map((feat, i) => {
            const c = colorMap[feat.color];
            const isNotified = notified.has(feat.id);
            const isVoted = voted.has(feat.id);
            const totalVotes = feat.baseVotes + (isVoted ? 1 : 0);
            return (
              <motion.div
                key={feat.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + i * 0.06 }}
                className={`relative p-4 rounded-xl border ${c.border} bg-gradient-to-br ${feat.gradient} cs-card overflow-hidden`}
              >
                <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
                {/* Vote counter top-right */}
                <button
                  onClick={() => handleVote(feat.id)}
                  className={`absolute top-3 right-3 flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] transition-all ${
                    isVoted
                      ? "bg-purple-500/15 border border-purple-500/25 text-purple-400"
                      : "bg-white/[0.04] border border-white/5 text-zinc-500 hover:border-purple-500/20 hover:bg-purple-500/5 hover:text-purple-400"
                  }`}
                  style={{ fontWeight: 600 }}
                  title={t("roadmap.voteForPriority")}
                >
                  <ChevronUp className={`w-3 h-3 transition-transform ${isVoted ? "text-purple-400" : ""}`} />
                  {totalVotes}
                </button>

                <div className="flex items-start gap-3 mb-3 pr-16">
                  <div className={`w-10 h-10 rounded-xl ${c.bg} flex items-center justify-center shrink-0`}>
                    <feat.icon className={`w-5 h-5 ${c.text}`} />
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-sm cs-card-title" style={{ fontWeight: 600 }}>{t(feat.labelKey)}</h3>
                    <p className="text-xs text-zinc-500 mt-0.5 line-clamp-2">{t(feat.descKey)}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  {feat.comingSoonId && (
                    <button
                      onClick={() => setComingSoonFeature(feat.comingSoonId!)}
                      className={`flex-1 inline-flex items-center justify-center gap-1.5 text-[11px] px-3 py-2 rounded-lg ${c.bg} ${c.text} hover:opacity-80 transition-all`}
                      style={{ fontWeight: 500 }}
                    >
                      <Eye className="w-3 h-3" />
                      {t("roadmap.previewBtn")}
                    </button>
                  )}
                  <button
                    onClick={() => handleNotify(feat.id)}
                    disabled={isNotified}
                    className={`flex-1 inline-flex items-center justify-center gap-1.5 text-[11px] px-3 py-2 rounded-lg border transition-all ${
                      isNotified
                        ? "border-emerald-500/20 bg-emerald-500/10 text-emerald-400"
                        : "border-white/5 bg-white/[0.03] text-zinc-400 hover:bg-white/[0.06]"
                    }`}
                    style={{ fontWeight: 500 }}
                  >
                    {isNotified ? <Check className="w-3 h-3" /> : <Bell className="w-3 h-3" />}
                    {isNotified ? t("roadmap.notified") : t("roadmap.notifyMe")}
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* === PLANNED (VOTING) === */}
      <div>
        <div className="mb-4">
          <h2 className="text-white" style={{ fontWeight: 600 }}>{t("roadmap.planned")}</h2>
          <p className="text-xs text-zinc-500 mt-0.5">{t("roadmap.plannedDesc")}</p>
        </div>
        <div className="space-y-2">
          {plannedFeatures
            .sort((a, b) => (b.votes + (voted.has(b.id) ? 1 : 0)) - (a.votes + (voted.has(a.id) ? 1 : 0)))
            .map((feat, i) => {
              const c = colorMap[feat.color];
              const isVoted = voted.has(feat.id);
              const totalVotes = feat.votes + (isVoted ? 1 : 0);
              return (
                <motion.div
                  key={feat.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + i * 0.05 }}
                  className="flex items-center gap-3 p-3 rounded-xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.03] transition-all"
                >
                  <button
                    onClick={() => handleVote(feat.id)}
                    className={`flex flex-col items-center justify-center w-12 h-12 rounded-xl shrink-0 transition-all ${
                      isVoted
                        ? "bg-purple-500/15 border border-purple-500/20"
                        : "bg-white/[0.03] border border-white/5 hover:border-purple-500/20 hover:bg-purple-500/5"
                    }`}
                  >
                    <ChevronUp className={`w-4 h-4 transition-colors ${isVoted ? "text-purple-400" : "text-zinc-500"}`} />
                    <span className={`text-xs ${isVoted ? "text-purple-400" : "text-zinc-400"}`} style={{ fontWeight: 600 }}>{totalVotes}</span>
                  </button>
                  <div className={`w-9 h-9 rounded-xl ${c.bg} flex items-center justify-center shrink-0`}>
                    <feat.icon className={`w-4 h-4 ${c.text}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm text-white" style={{ fontWeight: 500 }}>{feat.label}</h4>
                    <p className="text-xs text-zinc-500 mt-0.5">{feat.desc}</p>
                  </div>
                </motion.div>
              );
            })}
        </div>
      </div>

      {/* === AI SERVICES MARKETPLACE === */}
      <div className="pt-2">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500/10 to-purple-500/10 flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-violet-400" />
          </div>
          <div>
            <h2 className="text-white" style={{ fontWeight: 600 }}>{t("aiServices.title")}</h2>
            <p className="text-xs text-zinc-500">{t("aiServices.subtitle")}</p>
          </div>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {aiServices.map((svc, i) => (
            <motion.div
              key={svc.key}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
              className="relative p-4 rounded-xl border border-white/5 bg-white/[0.02] hover:border-white/10 hover:bg-white/[0.04] transition-all group"
            >
              {svc.badge && (
                <div className={`absolute -top-2 right-3 text-[9px] px-2 py-0.5 rounded-full text-white ${svc.badge === "popular" ? "bg-cyan-500" : "bg-violet-500"}`} style={{ fontWeight: 700 }}>
                  {svc.badge === "popular" ? t("aiServices.popular") : t("aiServices.new")}
                </div>
              )}
              <div className={`w-9 h-9 rounded-lg bg-${svc.color}-500/10 flex items-center justify-center mb-3`}>
                <svc.icon className={`w-4 h-4 text-${svc.color}-400`} />
              </div>
              <h4 className="text-sm text-white mb-0.5" style={{ fontWeight: 600 }}>{t(`aiServices.${svc.key}`)}</h4>
              <p className="text-[11px] text-zinc-500 mb-3 leading-relaxed">{t(`aiServices.${svc.key}Desc`)}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-white" style={{ fontWeight: 700 }}>{svc.price}</span>
                  <span className="text-[10px] text-zinc-600">or {svc.tokens} tokens</span>
                </div>
                <button
                  onClick={() => handleBuyService(svc)}
                  className="text-[10px] text-purple-400 bg-purple-500/10 hover:bg-purple-500/15 px-2.5 py-1 rounded-lg border border-purple-500/20 transition-all flex items-center gap-1"
                  style={{ fontWeight: 600 }}
                >
                  <ShoppingCart className="w-3 h-3" />
                  {t("aiServices.buyService")}
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Coming Soon Modal */}
      <AnimatePresence>
        {comingSoonFeature && (
          <ComingSoonModal featureId={comingSoonFeature} onClose={() => setComingSoonFeature(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}

export default Roadmap;