import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import {
  Search,
  LayoutDashboard,
  FolderPlus,
  FolderKanban,
  Zap,
  TrendingUp,
  BarChart3,
  Coins,
  Radio,
  Users,
  Settings,
  Rocket,
  ArrowRight,
  Command,
  Gift,
  Calendar,
  MessageSquare,
  CalendarDays,
} from "lucide-react";
import { useI18n } from "./i18n";

interface CmdItem {
  id: string;
  label: string;
  icon: typeof Rocket;
  action: () => void;
  group: "pages" | "actions";
  keywords: string[];
}

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const navigate = useNavigate();
  const { t } = useI18n();
  const inputRef = useRef<HTMLInputElement>(null);
  const dialogRef = useRef<HTMLDivElement>(null);

  const go = useCallback((path: string) => { navigate(path); setOpen(false); }, [navigate]);

  const items: CmdItem[] = [
    // Pages
    { id: "dashboard", label: t("sidebar.dashboard"), icon: LayoutDashboard, action: () => go("/dashboard"), group: "pages", keywords: ["dashboard", "панель", "главная", "home"] },
    { id: "projects", label: t("sidebar.projects"), icon: FolderKanban, action: () => go("/dashboard/projects"), group: "pages", keywords: ["projects", "проекты", "мои проекты", "my projects", "список"] },
    { id: "new-project", label: t("sidebar.newProject"), icon: FolderPlus, action: () => go("/dashboard/new-project"), group: "pages", keywords: ["project", "проект", "create", "создать", "new", "новый", "clarify", "прояснить"] },
    { id: "package", label: t("sidebar.package"), icon: FolderPlus, action: () => go("/dashboard/package"), group: "pages", keywords: ["package", "упаковать", "pitch", "питч", "copy", "оффер", "landing", "лендинг"] },
    { id: "launch", label: t("sidebar.launchEngine"), icon: Zap, action: () => go("/dashboard/launch"), group: "pages", keywords: ["launch", "запуск", "ai"] },
    { id: "tracker", label: t("sidebar.launchTracker"), icon: TrendingUp, action: () => go("/dashboard/tracker"), group: "pages", keywords: ["tracker", "трекер", "progress", "прогресс", "timeline", "таймлайн", "improve", "улучшить"] },
    { id: "analytics", label: t("sidebar.analytics"), icon: BarChart3, action: () => go("/dashboard/analytics"), group: "pages", keywords: ["analytics", "аналитика", "stats", "статистика"] },
    { id: "tokens", label: t("sidebar.tokens"), icon: Coins, action: () => go("/dashboard/tokens"), group: "pages", keywords: ["tokens", "токены", "buy", "купить", "store", "магазин"] },
    { id: "channels", label: t("sidebar.growth"), icon: Rocket, action: () => go("/dashboard/growth"), group: "pages", keywords: ["channels", "каналы", "connect", "подключить", "growth", "рост", "route"] },
    { id: "community", label: t("sidebar.community"), icon: Users, action: () => go("/dashboard/community"), group: "pages", keywords: ["community", "сообщество", "boost", "network", "referrals", "рефералы"] },
    { id: "messages", label: t("sidebar.messages"), icon: MessageSquare, action: () => go("/dashboard/messages"), group: "pages", keywords: ["messages", "сообщения", "chat", "чат", "dm"] },
    { id: "settings", label: t("sidebar.settings"), icon: Settings, action: () => go("/dashboard/settings"), group: "pages", keywords: ["settings", "настройки", "profile", "профиль"] },
    { id: "distribution", label: t("sidebar.distribution"), icon: Radio, action: () => go("/dashboard/distribution-live"), group: "pages", keywords: ["distribution", "дистрибуция", "live", "posting", "publish"] },
    { id: "launch-feed", label: t("sidebar.launchFeed"), icon: Users, action: () => go("/dashboard/launch-feed"), group: "pages", keywords: ["feed", "launches", "trending", "leaderboard", "social"] },
    { id: "roi", label: t("sidebar.roi"), icon: BarChart3, action: () => go("/dashboard/roi-dashboard"), group: "pages", keywords: ["roi", "revenue", "attribution", "mrr", "arr", "funnel", "cac", "ltv"] },
    { id: "talent-hub", label: t("sidebar.recruit"), icon: Users, action: () => go("/dashboard/talent-hub"), group: "pages", keywords: ["talent", "recruit", "hiring", "hr", "найм", "рекрутинг", "таланты"] },
    { id: "content-plan", label: t("sidebar.contentPlan"), icon: CalendarDays, action: () => go("/dashboard/content-plan"), group: "pages", keywords: ["content", "plan", "calendar", "контент", "план", "календарь", "schedule", "расписание", "posts"] },
    // Actions
    { id: "act-project", label: t("cmdk.createProject"), icon: FolderPlus, action: () => go("/dashboard/new-project"), group: "actions", keywords: ["create", "создать", "project", "проект"] },
    { id: "act-tokens", label: t("cmdk.buyTokens"), icon: Coins, action: () => go("/dashboard/tokens"), group: "actions", keywords: ["buy", "купить", "tokens", "токены"] },
    { id: "act-channels", label: t("cmdk.connectChannels"), icon: Radio, action: () => go("/dashboard/growth"), group: "actions", keywords: ["connect", "подключить", "channels", "каналы"] },
    { id: "act-launch", label: t("cmdk.launchEngine"), icon: Zap, action: () => go("/dashboard/launch"), group: "actions", keywords: ["launch", "запуск"] },
  ];

  const filtered = query.trim()
    ? items.filter((item) => {
        const q = query.toLowerCase();
        return item.label.toLowerCase().includes(q) || item.keywords.some((k) => k.includes(q));
      })
    : items;

  const pages = filtered.filter((i) => i.group === "pages");
  const actions = filtered.filter((i) => i.group === "actions");
  const allFiltered = [...pages, ...actions];

  // Keyboard shortcut
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setOpen((p) => !p);
        setQuery("");
        setSelectedIndex(0);
      }
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, []);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 50);
  }, [open]);

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((p) => Math.min(p + 1, allFiltered.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((p) => Math.max(p - 1, 0));
    } else if (e.key === "Enter" && allFiltered[selectedIndex]) {
      allFiltered[selectedIndex].action();
    }
  };

  // Focus trap inside dialog
  useEffect(() => {
    if (!open) return;
    const dialog = dialogRef.current;
    if (!dialog) return;
    const handleTab = (e: KeyboardEvent) => {
      if (e.key !== "Tab") return;
      const focusable = dialog.querySelectorAll<HTMLElement>(
        'input, button, [tabindex]:not([tabindex="-1"])'
      );
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", handleTab);
    return () => document.removeEventListener("keydown", handleTab);
  }, [open]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          className="fixed inset-0 z-[200] flex items-start justify-center pt-[20vh]"
          onClick={() => setOpen(false)}
          role="dialog"
          aria-modal="true"
          aria-label={t("a11y.searchCmd")}
        >
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" />
          <motion.div
            ref={dialogRef}
            initial={{ opacity: 0, scale: 0.96, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -10 }}
            transition={{ duration: 0.15 }}
            className="relative w-full max-w-lg mx-4 rounded-2xl liquid-glass-modal overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Search input */}
            <div className="flex items-center gap-3 px-4 py-3.5 border-b border-white/5">
              <Search className="w-4 h-4 text-zinc-500 shrink-0" />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={t("cmdk.placeholder")}
                className="flex-1 bg-transparent text-sm text-white placeholder:text-zinc-600 outline-none"
              />
              <kbd className="hidden sm:flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-white/5 border border-white/10 text-[10px] text-zinc-500">
                ESC
              </kbd>
            </div>

            {/* Results */}
            <div className="max-h-72 overflow-y-auto py-2">
              {allFiltered.length === 0 && (
                <div className="px-4 py-8 text-center">
                  <p className="text-xs text-zinc-600">{t("cmdk.noResults")}</p>
                </div>
              )}

              {pages.length > 0 && (
                <>
                  <div className="px-4 py-1.5">
                    <span className="text-[10px] text-zinc-600 uppercase tracking-wider" style={{ fontWeight: 600 }}>{t("cmdk.pages")}</span>
                  </div>
                  {pages.map((item) => {
                    const idx = allFiltered.indexOf(item);
                    return (
                      <button
                        key={item.id}
                        onClick={item.action}
                        onMouseEnter={() => setSelectedIndex(idx)}
                        className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors ${idx === selectedIndex ? "bg-purple-500/10 text-white" : "text-zinc-400 hover:text-zinc-300"}`}
                      >
                        <item.icon className="w-4 h-4 shrink-0" />
                        <span className="text-sm flex-1">{item.label}</span>
                        {idx === selectedIndex && <ArrowRight className="w-3 h-3 text-purple-400" />}
                      </button>
                    );
                  })}
                </>
              )}

              {actions.length > 0 && (
                <>
                  <div className="px-4 py-1.5 mt-1">
                    <span className="text-[10px] text-zinc-600 uppercase tracking-wider" style={{ fontWeight: 600 }}>{t("cmdk.actions")}</span>
                  </div>
                  {actions.map((item) => {
                    const idx = allFiltered.indexOf(item);
                    return (
                      <button
                        key={item.id}
                        onClick={item.action}
                        onMouseEnter={() => setSelectedIndex(idx)}
                        className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors ${idx === selectedIndex ? "bg-purple-500/10 text-white" : "text-zinc-400 hover:text-zinc-300"}`}
                      >
                        <item.icon className="w-4 h-4 shrink-0" />
                        <span className="text-sm flex-1">{item.label}</span>
                        {idx === selectedIndex && <ArrowRight className="w-3 h-3 text-purple-400" />}
                      </button>
                    );
                  })}
                </>
              )}
            </div>

            {/* Footer */}
            <div className="px-4 py-2.5 border-t border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3 text-[10px] text-zinc-600">
                <span className="flex items-center gap-1">Up/Down navigate</span>
                <span className="flex items-center gap-1">Enter select</span>
              </div>
              <div className="flex items-center gap-1 text-[10px] text-zinc-600">
                <Command className="w-3 h-3" />K
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}