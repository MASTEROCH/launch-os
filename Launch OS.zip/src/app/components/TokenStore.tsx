import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Coins, Zap, Crown, Check, ShoppingCart, Sparkles, Globe, Clock,
  TrendingUp, Rocket, ArrowLeft, CheckCircle, X, CreditCard, Shield,
  Gift, Copy, Star, ArrowRight,
  Download, Tag as TagIcon, Percent,
  Video, FileText, BarChart3, Mail, Search as SearchIcon, Image, Briefcase,
} from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "./i18n";
import { useNavigate } from "react-router";
import { loadProgress, updateProgress } from "./user-progress";
import { useDocumentTitle } from "./useDocumentTitle";
import { fireConfetti, dispatchBonusEvent } from "./Confetti";
import { LargeTitle } from "./LargeTitle";
import { HeroCardSkeleton, TokenCardSkeleton, CardGridSkeleton } from "./PageSkeleton";
import { usePullToRefresh } from "./usePullToRefresh";
import { PullToRefreshIndicator } from "./PullToRefreshIndicator";
import { WhyBlock } from "./WhyBlock";
import { VideoTutorial } from "./VideoTutorial";
import { copyToClipboard } from "./clipboard";
import { parseStripeReturn, clearStripeParams, getStripeTokenUrl, getStripeCheckoutUrl } from "./stripe-config";

/* ═══════════════════════════════════════════
   Types
   ═══════════════════════════════════════════ */
type PurchaseType = "tokens" | "plan";
type PaymentMethod = "card" | "crypto" | "googlepay" | "applepay" | "paypal";

interface TokenPackage {
  id: string; name: string; tokens: number; price: number;
  priceStr: string; perToken: string; icon: typeof Coins;
  color: string; popular?: boolean; savings?: string;
  features: string[];
}

interface PlanPackage {
  id: string; name: string; monthlyPrice: number; annualPrice: number;
  tokensPerMonth: number; color: string; icon: typeof Coins;
  popular?: boolean; features: string[];
}

/* ═══════════════════════════════════════════
   Promo codes (mock)
   ═══════════════════════════════════════════ */

const PROMO_CODES: Record<string, { discount: number; label: string }> = {
  LAUNCH10: { discount: 10, label: "10%" },
  STARTUP20: { discount: 20, label: "20%" },
  FOUNDER15: { discount: 15, label: "15%" },
  EARLY25: { discount: 25, label: "25%" },
};

/* ═══════════════════════════════════════════
   Receipt generator
   ═══════════════════════════════════════════ */

function generateOrderId() {
  return "LA-" + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase();
}

function downloadReceipt(data: {
  orderId: string;
  date: string;
  item: string;
  amount: string;
  method: string;
  discount?: string;
  t: (k: string) => string;
}) {
  const lines = [
    "═══════════════════════════════════════",
    `       ${data.t("purchase.receiptTitle")}`,
    "       Launch OS",
    "═══════════════════════════════════════",
    "",
    `${data.t("purchase.receiptOrderId")}:    ${data.orderId}`,
    `${data.t("purchase.receiptDate")}:       ${data.date}`,
    `${data.t("purchase.receiptItem")}:       ${data.item}`,
    ...(data.discount ? [`Discount:     ${data.discount}`] : []),
    `${data.t("purchase.receiptAmount")}:     ${data.amount}`,
    `${data.t("purchase.receiptMethod")}:     ${data.method}`,
    `${data.t("purchase.receiptStatus")}:     ${data.t("purchase.receiptPaid")}`,
    "",
    "═══════════════════════════════════════",
    `   ${data.t("purchase.receiptThankYou")}`,
    "═══════════════════════════════════════",
  ];
  const blob = new Blob([lines.join("\n")], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `receipt-${data.orderId}.txt`;
  a.click();
  URL.revokeObjectURL(url);
}

/* ══════════════════════════════════════════
   Payment Icons (inline SVG)
   ═══════════════════════════════════════════ */

function GooglePayIcon() {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1Z" fill="#4285F4" />
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23Z" fill="#34A853" />
      <path d="M5.84 14.09A6.97 6.97 0 0 1 5.48 12c0-.72.13-1.43.36-2.09V7.07H2.18A11.96 11.96 0 0 0 1 12c0 1.94.45 3.77 1.18 5.07l3.66-2.98Z" fill="#FBBC05" />
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53Z" fill="#EA4335" />
    </svg>
  );
}

function ApplePayIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-white">
      <path d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.52-3.23 0-1.44.64-2.2.46-3.06-.4C3.79 16.17 4.36 9.53 8.7 9.28c1.24.06 2.1.72 2.83.76.87-.18 1.71-.9 2.89-.8 1.41.12 2.42.69 3.09 1.78-2.61 1.59-1.98 5.06.4 6.03-.57 1.49-1.31 2.92-2.86 3.23ZM12.03 9.2c-.14-2.6 2.04-4.6 4.34-4.82.34 2.82-2.5 4.93-4.34 4.82Z" />
    </svg>
  );
}

function PayPalIcon() {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5">
      <path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944 2.23a.772.772 0 0 1 .762-.647h6.601c2.352 0 4.035.724 4.852 2.091.746 1.25.832 2.856.247 4.641-.029.089-.06.176-.094.26-.02.054-.04.108-.063.16-.516 1.226-1.48 2.248-2.86 3.024-1.331.748-3 1.127-4.964 1.127H8.08l-1.005 9.05Z" fill="#003087" />
      <path d="M23.048 7.667c-.028.18-.06.364-.104.563-.98 5.055-4.321 6.797-8.595 6.797h-2.17l-1.08 9.31a.637.637 0 0 0 .631.735h3.877a.669.669 0 0 0 .661-.566l.678-4.354a.668.668 0 0 1 .66-.565h1.529c3.802 0 6.741-1.572 7.586-6.073.376-2.009.178-3.66-.673-4.847Z" fill="#0070E0" />
    </svg>
  );
}

function UsdtIcon() {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5">
      <circle cx="12" cy="12" r="11" fill="#26A17B" />
      <path d="M13.5 13.38v-1.06c2.43-.17 4.24-.74 4.24-1.42 0-.68-1.81-1.25-4.24-1.42V7.5h3.25V5.25H7.25V7.5H10.5v1.98c-2.43.17-4.24.74-4.24 1.42 0 .68 1.81 1.25 4.24 1.42v4.93h3V13.38ZM12 12.57c-2.84 0-4.85-.64-4.85-1.15 0-.45 1.53-.99 3.85-1.12v1.78c.32.02.65.03 1 .03s.68-.01 1-.03v-1.78c2.32.13 3.85.67 3.85 1.12 0 .51-2.01 1.15-4.85 1.15Z" fill="white" />
    </svg>
  );
}

/* ═══════════════════════════════════════════
   Purchase Modal Component
   ═══════════════════════════════════════════ */

function PurchaseModal({
  type,
  tokenPkg,
  planPkg,
  initialAnnual,
  onClose,
  onSuccess,
  t,
}: {
  type: PurchaseType;
  tokenPkg?: TokenPackage;
  planPkg?: PlanPackage;
  initialAnnual?: boolean;
  onClose: () => void;
  onSuccess: (label: string, tokens?: number) => void;
  t: (key: string) => string;
}) {
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("card");
  const [annual, setAnnual] = useState(initialAnnual ?? false);
  const [processing, setProcessing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [copied, setCopied] = useState(false);

  // Card form state
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvc, setCvc] = useState("");
  const [cardHolder, setCardHolder] = useState("");

  // Promo code state
  const [promoInput, setPromoInput] = useState("");
  const [promoApplied, setPromoApplied] = useState<{ code: string; discount: number; label: string } | null>(null);
  const [promoError, setPromoError] = useState(false);

  // Receipt data (set on success)
  const [receiptData, setReceiptData] = useState<{ orderId: string; date: string } | null>(null);

  const handleApplyPromo = () => {
    const code = promoInput.trim().toUpperCase();
    const found = PROMO_CODES[code];
    if (found) {
      setPromoApplied({ code, ...found });
      setPromoError(false);
    } else {
      setPromoError(true);
      setPromoApplied(null);
      setTimeout(() => setPromoError(false), 2500);
    }
  };

  const formatCardNumber = (val: string) => {
    const digits = val.replace(/\D/g, "").slice(0, 16);
    return digits.replace(/(.{4})/g, "$1 ").trim();
  };

  const formatExpiry = (val: string) => {
    const digits = val.replace(/\D/g, "").slice(0, 4);
    if (digits.length >= 3) return digits.slice(0, 2) + " / " + digits.slice(2);
    return digits;
  };

  // Prices
  const price = type === "tokens"
    ? tokenPkg!.price
    : annual
      ? planPkg!.annualPrice
      : planPkg!.monthlyPrice;

  const priceStr = type === "tokens"
    ? tokenPkg!.priceStr
    : `$${price}`;

  const periodLabel = type === "plan"
    ? annual ? t("purchase.perYear") : t("purchase.perMonth")
    : "";

  const monthlyEquivalent = type === "plan" && annual
    ? `$${Math.round(planPkg!.annualPrice / 12)}`
    : null;

  const itemName = type === "tokens"
    ? tokenPkg!.name
    : planPkg!.name;

  const cryptoWallet = "TRX8f7vK2mE9nQp3bC6dG1hJ4kL5oR0wY";

  const handlePay = () => {
    setProcessing(true);
    const orderId = generateOrderId();
    const date = new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
    setTimeout(() => {
      setProcessing(false);
      setReceiptData({ orderId, date });
      setSuccess(true);
      setTimeout(() => {
        if (type === "tokens") {
          onSuccess(tokenPkg!.name, tokenPkg!.tokens);
        } else {
          onSuccess(planPkg!.name);
        }
      }, 4000);
    }, 2000);
  };

  const handleCopyWallet = () => {
    copyToClipboard(cryptoWallet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const paymentMethods: { id: PaymentMethod; label: string; icon: React.ReactNode; quick?: boolean }[] = [
    { id: "card", label: t("purchase.card"), icon: <CreditCard className="w-4 h-4 text-zinc-400" /> },
    { id: "crypto", label: t("purchase.crypto"), icon: <UsdtIcon /> },
    { id: "googlepay", label: t("purchase.googlePay"), icon: <GooglePayIcon />, quick: true },
    { id: "applepay", label: t("purchase.applePay"), icon: <ApplePayIcon />, quick: true },
    { id: "paypal", label: t("purchase.paypal"), icon: <PayPalIcon />, quick: true },
  ];

  // Benefits list
  const benefits = type === "tokens"
    ? [
        t("purchase.tokenUse1"),
        t("purchase.tokenUse2"),
        t("purchase.tokenUse3"),
        t("purchase.tokenUse4"),
        t("purchase.tokenUse5"),
      ]
    : [
        t("purchase.planBenefit1"),
        t("purchase.planBenefit2"),
        t("purchase.planBenefit3"),
        t("purchase.planBenefit4"),
        t("purchase.planBenefit5"),
        ...(planPkg?.id === "viral" ? [t("purchase.planBenefit6")] : []),
      ];

  if (success) {
    return (
      <>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[100]" onClick={onClose} />
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }}
          className="fixed z-[100] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90vw] max-w-md">
          <div className="rounded-2xl border border-white/10 bg-[#111113] shadow-2xl p-8 text-center">
            <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 12 }}
              className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-green-500/10 border border-emerald-500/20 flex items-center justify-center">
              <CheckCircle className="w-9 h-9 text-emerald-400" />
            </motion.div>
            <h3 className="text-xl mb-2" style={{ fontWeight: 700 }}>{t("purchase.success")}</h3>
            <p className="text-sm text-zinc-500 mb-2">{t("purchase.successSub")}</p>
            <div className="text-lg text-white mb-6" style={{ fontWeight: 600 }}>
              {itemName} -- {priceStr}{periodLabel}
            </div>
            <motion.div initial={{ width: 0 }} animate={{ width: "100%" }}
              transition={{ duration: 1.5, ease: "linear" }}
              className="h-0.5 bg-gradient-to-r from-purple-500 to-emerald-500 rounded-full mx-auto max-w-xs" />
            {receiptData && (
              <motion.button
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 }}
                onClick={() => {
                  const methodNames: Record<PaymentMethod, string> = { card: "Credit Card", crypto: "USDT (TRC-20)", googlepay: "Google Pay", applepay: "Apple Pay", paypal: "PayPal" };
                  const finalAmount = promoApplied ? `$${(price * (1 - promoApplied.discount / 100)).toFixed(2)}` : priceStr;
                  downloadReceipt({
                    orderId: receiptData.orderId,
                    date: receiptData.date,
                    item: `${itemName}${periodLabel}`,
                    amount: `${finalAmount}${periodLabel}`,
                    method: methodNames[paymentMethod],
                    discount: promoApplied ? `-${promoApplied.label} (${promoApplied.code})` : undefined,
                    t,
                  });
                }}
                className="mt-5 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm text-purple-400 bg-purple-500/10 hover:bg-purple-500/15 border border-purple-500/20 transition-all mx-auto"
              >
                <Download className="w-4 h-4" />
                {t("purchase.receipt")}
              </motion.button>
            )}
          </div>
        </motion.div>
      </>
    );
  }

  return (
    <>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[100]" onClick={onClose} />
      <motion.div initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="fixed z-[100] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[94vw] max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="rounded-2xl border border-white/10 bg-[#111113] shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="p-5 border-b border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              {type === "tokens" && tokenPkg ? (
                <motion.div layoutId={`token-icon-${tokenPkg.id}`} className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  tokenPkg.color === "purple" ? "bg-purple-500/10" : tokenPkg.color === "cyan" ? "bg-cyan-500/10" : "bg-emerald-500/10"
                }`}>
                  <tokenPkg.icon className={`w-5 h-5 ${tokenPkg.color === "purple" ? "text-purple-400" : tokenPkg.color === "cyan" ? "text-cyan-400" : "text-emerald-400"}`} />
                </motion.div>
              ) : (
                <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-purple-500/10">
                  <Star className="w-5 h-5 text-purple-400" />
                </div>
              )}
              <div>
                {type === "tokens" && tokenPkg ? (
                  <motion.h3 layoutId={`token-name-${tokenPkg.id}`} className="text-white" style={{ fontWeight: 600 }}>{t("purchase.orderSummary")}</motion.h3>
                ) : (
                  <h3 className="text-white" style={{ fontWeight: 600 }}>{t("purchase.orderSummary")}</h3>
                )}
                <p className="text-xs text-zinc-500">{type === "tokens" ? t("purchase.tokenPack") : t("purchase.plan")}: {itemName}</p>
              </div>
            </div>
            <button onClick={onClose} className="text-zinc-600 hover:text-zinc-400 transition-colors p-1.5 rounded-lg hover:bg-white/5">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-5 space-y-5">
            {/* ── Plan billing toggle ── */}
            {type === "plan" && (
              <div className="p-4 rounded-xl border border-white/5 bg-white/[0.02]">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm text-white" style={{ fontWeight: 600 }}>
                      {annual ? t("purchase.annual") : t("purchase.monthly")}
                    </div>
                    <div className="text-xs text-zinc-500 mt-0.5">
                      {annual ? t("purchase.billedAnnually") : t("purchase.billedMonthly")}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`text-xs ${!annual ? "text-white" : "text-zinc-500"}`} style={{ fontWeight: !annual ? 600 : 400 }}>
                      {t("purchase.monthly")}
                    </span>
                    <button
                      onClick={() => setAnnual(!annual)}
                      className={`relative w-12 h-6 rounded-full transition-colors ${annual ? "bg-purple-600" : "bg-zinc-700"}`}
                    >
                      <motion.div
                        animate={{ x: annual ? 24 : 2 }}
                        transition={{ type: "spring", stiffness: 500, damping: 30 }}
                        className="absolute top-1 w-4 h-4 rounded-full bg-white"
                      />
                    </button>
                    <div className="flex items-center gap-1">
                      <span className={`text-xs ${annual ? "text-white" : "text-zinc-500"}`} style={{ fontWeight: annual ? 600 : 400 }}>
                        {t("purchase.annual")}
                      </span>
                      {annual && (
                        <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded-full" style={{ fontWeight: 600 }}>
                          {t("purchase.annualSave")}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Price display */}
                <div className="mt-4 flex items-baseline gap-2">
                  <span className="text-3xl text-white" style={{ fontWeight: 700 }}>{priceStr}</span>
                  <span className="text-sm text-zinc-500">{periodLabel}</span>
                  {monthlyEquivalent && (
                    <span className="text-xs text-zinc-600 ml-2">({monthlyEquivalent}{t("purchase.perMonth")})</span>
                  )}
                </div>

                {!annual && (
                  <button onClick={() => setAnnual(true)}
                    className="mt-3 text-xs text-purple-400 hover:text-purple-300 flex items-center gap-1 transition-colors">
                    <ArrowRight className="w-3 h-3" />
                    {t("purchase.switchToAnnual")}
                  </button>
                )}
              </div>
            )}

            {/* ── Token package summary ── */}
            {type === "tokens" && (
              <div className="p-4 rounded-xl border border-white/5 bg-white/[0.02]">
                <div className="flex items-baseline justify-between">
                  <div>
                    <div className="text-sm text-white" style={{ fontWeight: 600 }}>{itemName}</div>
                    <div className="flex items-baseline gap-1.5 mt-1">
                      <span className="text-2xl text-white" style={{ fontWeight: 700 }}>{tokenPkg!.tokens.toLocaleString()}</span>
                      <span className="text-sm text-zinc-500">tokens</span>
                    </div>
                    <div className="text-xs text-zinc-600 mt-0.5">{tokenPkg!.perToken} / token</div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl text-white" style={{ fontWeight: 700 }}>{tokenPkg!.priceStr}</div>
                    {tokenPkg!.savings && (
                      <span className="text-xs text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">{tokenPkg!.savings}</span>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* ── What you get ── */}
            <div>
              <div className="text-xs text-zinc-500 mb-2.5" style={{ fontWeight: 600 }}>
                {type === "tokens" ? t("purchase.whereToUse") : t("purchase.whatYouGet")}
              </div>
              <div className="space-y-1.5">
                {benefits.map((b) => (
                  <div key={b} className="flex items-center gap-2 text-xs text-zinc-400">
                    <Check className="w-3 h-3 text-purple-400 shrink-0" />
                    {b}
                  </div>
                ))}
                {type === "plan" && (
                  <div className="flex items-center gap-2 text-xs text-zinc-400">
                    <Coins className="w-3 h-3 text-amber-400 shrink-0" />
                    {planPkg!.tokensPerMonth} tokens{t("purchase.perMonth")}
                  </div>
                )}
              </div>
            </div>

            {/* ── Payment method ── */}
            <div>
              <div className="text-xs text-zinc-500 mb-2.5" style={{ fontWeight: 600 }}>{t("purchase.paymentMethod")}</div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {paymentMethods.map((pm) => (
                  <button key={pm.id} onClick={() => setPaymentMethod(pm.id)}
                    className={`flex items-center gap-2 p-3 rounded-xl border text-xs transition-all ${
                      paymentMethod === pm.id
                        ? "border-purple-500/30 bg-purple-500/5 text-white"
                        : "border-white/5 bg-white/[0.02] text-zinc-500 hover:border-white/10 hover:text-zinc-300"
                    }`}>
                    {pm.icon}
                    <span className="truncate" style={{ fontWeight: paymentMethod === pm.id ? 500 : 400 }}>{pm.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* ── Payment form ── */}
            <AnimatePresence mode="wait">
              {paymentMethod === "card" && (
                <motion.div key="card-form" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
                  className="space-y-3">
                  <div>
                    <label className="text-xs text-zinc-500 mb-1 block">{t("purchase.cardNumber")}</label>
                    <div className="relative">
                      <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                      <input value={cardNumber} onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                        placeholder="0000 0000 0000 0000" maxLength={19}
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-sm" />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs text-zinc-500 mb-1 block">{t("purchase.expiry")}</label>
                      <input value={expiry} onChange={(e) => setExpiry(formatExpiry(e.target.value))}
                        placeholder="MM / YY" maxLength={7}
                        className="w-full px-3 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-sm" />
                    </div>
                    <div>
                      <label className="text-xs text-zinc-500 mb-1 block">{t("purchase.cvc")}</label>
                      <input value={cvc} onChange={(e) => setCvc(e.target.value.replace(/\D/g, "").slice(0, 3))}
                        placeholder="000" maxLength={3}
                        className="w-full px-3 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-sm" />
                    </div>
                    <div>
                      <label className="text-xs text-zinc-500 mb-1 block">{t("purchase.cardHolder")}</label>
                      <input value={cardHolder} onChange={(e) => setCardHolder(e.target.value)}
                        placeholder="John Doe"
                        className="w-full px-3 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-sm" />
                    </div>
                  </div>
                </motion.div>
              )}

              {paymentMethod === "crypto" && (
                <motion.div key="crypto-form" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
                  className="space-y-3">
                  <div className="p-4 rounded-xl border border-emerald-500/15 bg-emerald-500/[0.03]">
                    <div className="text-xs text-zinc-400 mb-2">{t("purchase.walletAddress")}</div>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 text-xs text-emerald-400 bg-black/30 p-2.5 rounded-lg overflow-x-auto font-mono">
                        {cryptoWallet}
                      </code>
                      <button onClick={handleCopyWallet}
                        className="shrink-0 p-2 rounded-lg border border-emerald-500/20 hover:bg-emerald-500/10 transition-all">
                        {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-emerald-400" />}
                      </button>
                    </div>
                    {copied && <p className="text-[10px] text-emerald-400 mt-1.5">{t("purchase.walletCopied")}</p>}
                    <div className="flex items-center gap-2 mt-3">
                      <div className="flex items-center gap-1.5 text-xs text-zinc-500">
                        <UsdtIcon />
                        <span>USDT (TRC-20)</span>
                      </div>
                      <span className="text-xs text-zinc-600">|</span>
                      <span className="text-xs text-white" style={{ fontWeight: 600 }}>{priceStr} USDT</span>
                    </div>
                  </div>
                  <p className="text-[11px] text-zinc-600 flex items-center gap-1.5">
                    <Clock className="w-3 h-3" />
                    {t("purchase.confirming")}
                  </p>
                </motion.div>
              )}

              {(paymentMethod === "googlepay" || paymentMethod === "applepay" || paymentMethod === "paypal") && (
                <motion.div key="quick-form" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}>
                  <div className="p-4 rounded-xl border border-white/5 bg-white/[0.02] flex items-center gap-3">
                    {paymentMethod === "googlepay" && <GooglePayIcon />}
                    {paymentMethod === "applepay" && <ApplePayIcon />}
                    {paymentMethod === "paypal" && <PayPalIcon />}
                    <div className="text-sm text-zinc-400">
                      {paymentMethod === "googlepay" && "Google Pay"}
                      {paymentMethod === "applepay" && "Apple Pay"}
                      {paymentMethod === "paypal" && "PayPal"}
                    </div>
                    <div className="ml-auto text-xs text-emerald-400 flex items-center gap-1">
                      <Zap className="w-3 h-3" />
                      Quick checkout
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* ── Security note ── */}
            <div className="flex items-center gap-2 text-[11px] text-zinc-600">
              <Shield className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              {t("purchase.securePayment")}
            </div>

            {/* ── Promo code ── */}
            <div>
              <div className="text-xs text-zinc-500 mb-2" style={{ fontWeight: 600 }}>
                <TagIcon className="w-3 h-3 inline mr-1" />
                {t("purchase.promoCode")}
              </div>
              <div className="flex gap-2">
                <input
                  value={promoInput}
                  onChange={(e) => setPromoInput(e.target.value.toUpperCase())}
                  placeholder={t("purchase.promoPlaceholder")}
                  maxLength={20}
                  disabled={!!promoApplied}
                  className="flex-1 px-3 py-2 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-sm disabled:opacity-50"
                />
                {promoApplied ? (
                  <button
                    onClick={() => { setPromoApplied(null); setPromoInput(""); }}
                    className="px-4 py-2 rounded-xl text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-1.5"
                  >
                    <Check className="w-3 h-3" />{t("purchase.promoApplied")}
                  </button>
                ) : (
                  <button
                    onClick={handleApplyPromo}
                    disabled={!promoInput.trim()}
                    className="px-4 py-2 rounded-xl text-xs text-purple-400 bg-purple-500/10 hover:bg-purple-500/15 border border-purple-500/20 transition-all disabled:opacity-40 flex items-center gap-1.5"
                  >
                    <Percent className="w-3 h-3" />{t("purchase.promoApply")}
                  </button>
                )}
              </div>
              {promoError && (
                <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-[11px] text-red-400 mt-1.5">
                  {t("purchase.promoInvalid")}
                </motion.p>
              )}
              {promoApplied && (
                <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-2 mt-2 p-2 rounded-lg bg-emerald-500/5 border border-emerald-500/10">
                  <Percent className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span className="text-xs text-emerald-400" style={{ fontWeight: 600 }}>{promoApplied.code}: -{promoApplied.label} {t("purchase.promoDiscount")}</span>
                  <span className="ml-auto text-xs text-zinc-500 line-through">{priceStr}</span>
                  <span className="text-xs text-white" style={{ fontWeight: 600 }}>${(price * (1 - promoApplied.discount / 100)).toFixed(2)}</span>
                </motion.div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="p-5 border-t border-white/5 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="flex-1">
              <div className="flex items-baseline gap-1.5">
                <span className="text-xs text-zinc-500">{t("purchase.total")}:</span>
                {promoApplied ? (
                  <>
                    <span className="text-sm text-zinc-600 line-through">{priceStr}</span>
                    <span className="text-xl text-white" style={{ fontWeight: 700 }}>${(price * (1 - promoApplied.discount / 100)).toFixed(2)}</span>
                  </>
                ) : (
                  <span className="text-xl text-white" style={{ fontWeight: 700 }}>{priceStr}</span>
                )}
                <span className="text-xs text-zinc-500">{periodLabel}</span>
              </div>
              <p className="text-[10px] text-zinc-600 mt-0.5">{t("purchase.cancelAnytime")}</p>
            </div>
            <button onClick={handlePay} disabled={processing}
              className="flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 disabled:opacity-60 text-white px-8 py-3 rounded-xl text-sm transition-all shadow-lg shadow-purple-500/20"
              style={{ fontWeight: 600 }}>
              {processing ? (
                <>{t("purchase.processing")}<motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}><Sparkles className="w-4 h-4" /></motion.div></>
              ) : (
                <><ShoppingCart className="w-4 h-4" />{type === "plan" ? t("purchase.subscribe") : t("purchase.payNow")} {priceStr}</>
              )}
            </button>
          </div>
        </div>
      </motion.div>
    </>
  );
}

/* ═══════════════════════════════════════════
   Subscription Plans Section
   ═══════════════════════════════════════════ */

function SubscriptionPlans({ t, onSelectPlan }: { t: (k: string) => string; onSelectPlan: (plan: PlanPackage, annual: boolean) => void }) {
  const [annual, setAnnual] = useState(false);

  const plans: PlanPackage[] = [
    {
      id: "free",
      name: t("pricing.free"),
      monthlyPrice: 0,
      annualPrice: 0,
      tokensPerMonth: 0,
      color: "zinc",
      icon: Globe,
      features: [t("pricing.free.f1"), t("pricing.free.f2"), t("pricing.free.f3"), t("pricing.free.f4"), t("pricing.free.f5")],
    },
    {
      id: "starter",
      name: t("pricing.starter"),
      monthlyPrice: 19,
      annualPrice: 182,
      tokensPerMonth: 50,
      color: "purple",
      icon: Zap,
      features: [t("pricing.starter.f1"), t("pricing.starter.f2"), t("pricing.starter.f3"), t("pricing.starter.f4"), t("pricing.starter.f5")],
    },
    {
      id: "growth",
      name: t("pricing.growth"),
      monthlyPrice: 49,
      annualPrice: 470,
      tokensPerMonth: 200,
      color: "cyan",
      icon: TrendingUp,
      popular: true,
      features: [t("pricing.growth.f1"), t("pricing.growth.f2"), t("pricing.growth.f3"), t("pricing.growth.f4"), t("pricing.growth.f5"), t("pricing.growth.f6")],
    },
    {
      id: "viral",
      name: t("pricing.viral"),
      monthlyPrice: 129,
      annualPrice: 1238,
      tokensPerMonth: 500,
      color: "emerald",
      icon: Crown,
      features: [t("pricing.viral.f1"), t("pricing.viral.f2"), t("pricing.viral.f3"), t("pricing.viral.f4"), t("pricing.viral.f5"), t("pricing.viral.f6"), t("pricing.viral.f7")],
    },
  ];

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg text-white" style={{ fontWeight: 600 }}>{t("pricing.title")}</h2>
        <div className="flex items-center gap-2 p-1 rounded-xl bg-white/[0.03] border border-white/5">
          <span className={`text-xs px-2.5 py-1 rounded-lg transition-all ${!annual ? "bg-purple-500/15 text-purple-400" : "text-zinc-500"}`}
            style={{ fontWeight: !annual ? 600 : 400 }}>{t("purchase.monthly")}</span>
          <button onClick={() => setAnnual(!annual)}
            className={`relative w-10 h-5 rounded-full transition-colors ${annual ? "bg-purple-600" : "bg-zinc-700"}`}>
            <motion.div animate={{ x: annual ? 20 : 2 }} transition={{ type: "spring", stiffness: 500, damping: 30 }}
              className="absolute top-0.5 w-4 h-4 rounded-full bg-white" />
          </button>
          <div className="flex items-center gap-1">
            <span className={`text-xs px-2.5 py-1 rounded-lg transition-all ${annual ? "bg-purple-500/15 text-purple-400" : "text-zinc-500"}`}
              style={{ fontWeight: annual ? 600 : 400 }}>{t("purchase.annual")}</span>
            {annual && <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded-full" style={{ fontWeight: 600 }}>{t("purchase.annualSave")}</span>}
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        {plans.map((plan, i) => {
          const isFree = plan.id === "free";
          const price = annual ? plan.annualPrice : plan.monthlyPrice;
          const monthEq = annual ? Math.round(plan.annualPrice / 12) : plan.monthlyPrice;
          return (
            <motion.div key={plan.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}
              className={`relative p-6 rounded-xl border transition-all flex flex-col ${
                plan.popular ? "border-purple-500/30 bg-purple-500/5" : isFree ? "border-white/5 bg-white/[0.01]" : "border-white/5 bg-white/[0.02] hover:border-white/10"
              }`}>
              {plan.popular && <div className="absolute -top-2.5 right-4 text-xs bg-cyan-500 text-white px-2.5 py-0.5 rounded-full" style={{ fontWeight: 600 }}>{t("pricing.popular")}</div>}
              <div className={`w-10 h-10 rounded-xl ${
                isFree ? "bg-zinc-500/10" : plan.color === "purple" ? "bg-purple-500/10" : plan.color === "cyan" ? "bg-cyan-500/10" : "bg-emerald-500/10"
              } flex items-center justify-center mb-4`}>
                <plan.icon className={`w-5 h-5 ${
                  isFree ? "text-zinc-400" : plan.color === "purple" ? "text-purple-400" : plan.color === "cyan" ? "text-cyan-400" : "text-emerald-400"
                }`} />
              </div>
              <div className="text-sm text-zinc-400 mb-1" style={{ fontWeight: 500 }}>{plan.name}</div>
              <div className="flex items-baseline gap-1 mb-1">
                <span className="text-3xl text-white" style={{ fontWeight: 700 }}>{isFree ? "$0" : `$${monthEq}`}</span>
                {!isFree && <span className="text-sm text-zinc-500">{t("purchase.perMonth")}</span>}
                {isFree && <span className="text-sm text-zinc-500">forever</span>}
              </div>
              {annual && (
                <div className="text-xs text-zinc-600 mb-3">${price}{t("purchase.perYear")} {t("purchase.billedAnnually")}</div>
              )}
              <ul className="space-y-2 mb-5 mt-3 flex-1">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-xs text-zinc-500">
                    <Check className="w-3 h-3 text-purple-400 shrink-0" />{f}
                  </li>
                ))}
              </ul>
              {isFree ? (
                <div className="w-full py-2.5 rounded-lg text-sm text-center border border-white/5 text-zinc-600 mt-auto">
                  {t("pricing.free.cta")}
                </div>
              ) : (
                <a
                  href={getStripeCheckoutUrl(plan.id, annual)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-full py-2.5 rounded-lg text-sm text-center transition-all flex items-center justify-center gap-1.5 mt-auto ${
                    plan.popular ? "bg-purple-600 text-white hover:bg-purple-500" : "border border-white/10 text-zinc-400 hover:border-white/20 hover:text-white"
                  }`}>
                  <Star className="w-3.5 h-3.5" />
                  {t("purchase.subscribe")} -- ${monthEq}/mo
                </a>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════
   Main TokenStore Component
   ═══════════════════════════════════════════ */

export function TokenStore() {
  const { t } = useI18n();
  useDocumentTitle(t("sidebar.tokens"));
  const navigate = useNavigate();
  const [selected, setSelected] = useState("growth");
  const progress = loadProgress();
  const [currentBalance, setCurrentBalance] = useState(progress.tokensAvailable);
  const [loading, setLoading] = useState(true);

  const { pullY, isRefreshing, handlers: pullHandlers } = usePullToRefresh(
    () => new Promise<void>((resolve) => setTimeout(resolve, 1200))
  );

  // ─── Stripe return handler ───
  const [stripeSuccess, setStripeSuccess] = useState(false);
  useEffect(() => {
    const result = parseStripeReturn();
    if (result && result.tokens > 0) {
      clearStripeParams();
      // Auto-credit tokens after Stripe redirect
      const newBalance = currentBalance + result.tokens;
      setCurrentBalance(newBalance);
      updateProgress({ tokensAvailable: newBalance });
      setStripeSuccess(true);
      setLoading(false);
      // Fire celebration
      setTimeout(() => {
        fireConfetti();
        dispatchBonusEvent({ message: `+${result.tokens} tokens -- ${result.plan}`, tokens: result.tokens, type: "purchase" });
        toast.success(`${result.tokens} tokens added!`, {
          icon: <CheckCircle className="w-4 h-4 text-emerald-400" />,
          duration: 5000,
        });
      }, 600);
      // Auto-dismiss after 4s
      setTimeout(() => setStripeSuccess(false), 4500);
      return;
    }
    // Normal load
    const timer = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(timer);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ─── First-visit onboarding ───
  const [onboardStep, setOnboardStep] = useState<number>(() => {
    try {
      if (localStorage.getItem("launchapp_tokens_visited")) return -1;
      return 0;
    } catch { return -1; }
  });
  const dismissOnboard = () => {
    setOnboardStep(-1);
    try { localStorage.setItem("launchapp_tokens_visited", "1"); } catch {}
  };
  const nextOnboard = () => {
    if (onboardStep < 4) setOnboardStep(onboardStep + 1);
    else dismissOnboard();
  };

  const tsTourSteps = [
    { title: t("tsTour.step1Title"), desc: t("tsTour.step1Desc") },
    { title: t("tsTour.step2Title"), desc: t("tsTour.step2Desc") },
    { title: t("tsTour.step3Title"), desc: t("tsTour.step3Desc") },
    { title: t("tsTour.step4Title"), desc: t("tsTour.step4Desc") },
    { title: t("tsTour.step5Title"), desc: t("tsTour.step5Desc") },
  ];

  // Modal state
  const [purchaseModal, setPurchaseModal] = useState<{
    type: PurchaseType;
    tokenPkg?: TokenPackage;
    planPkg?: PlanPackage;
    annual?: boolean;
  } | null>(null);

  const tokenPackages: TokenPackage[] = [
    { id: "starter", name: t("tokens.starterPack"), tokens: 200, price: 9, priceStr: "$9", perToken: "$0.045", icon: Zap, color: "purple", features: [t("tokens.extraDist"), t("tokens.aiRegen"), t("tokens.priorityQueue").replace("Priority", "Standard")] },
    { id: "growth", name: t("tokens.growthPack"), tokens: 600, price: 19, priceStr: "$19", perToken: "$0.032", icon: TrendingUp, color: "cyan", popular: true, savings: "Save 29%", features: [t("tokens.priorityQueue"), t("tokens.aiRegen"), t("tokens.boostPromo")] },
    { id: "viral", name: t("tokens.viralPack"), tokens: 1500, price: 39, priceStr: "$39", perToken: "$0.026", icon: Crown, color: "emerald", savings: "Save 42%", features: [t("tokens.extraDist"), t("tokens.priorityQueue"), t("tokens.aiRegen"), t("tokens.extraOutreach"), t("tokens.boostPromo")] },
  ];

  const tokenUses = [
    { icon: Globe, label: t("tokens.extraDist"), cost: "10-50" },
    { icon: Sparkles, label: t("tokens.aiRegen"), cost: "5" },
    { icon: Clock, label: t("tokens.priorityQueue"), cost: "25" },
    { icon: Rocket, label: t("tokens.boostPromo"), cost: "50-200" },
    { icon: TrendingUp, label: t("tokens.extraOutreach"), cost: "30" },
    { icon: Gift, label: "Gift tokens", cost: "1+" },
  ];

  const handleOpenTokenModal = (pkg: TokenPackage) => {
    setPurchaseModal({ type: "tokens", tokenPkg: pkg });
  };

  const handleOpenPlanModal = (plan: PlanPackage, annual: boolean) => {
    setPurchaseModal({ type: "plan", planPkg: plan, annual });
  };

  const handlePurchaseSuccess = (label: string, tokens?: number) => {
    if (tokens) {
      const newBalance = currentBalance + tokens;
      setCurrentBalance(newBalance);
      updateProgress({ tokensAvailable: newBalance });
      fireConfetti();
      dispatchBonusEvent({ message: `+${tokens} tokens -- ${label}`, tokens, type: "purchase" });
    } else {
      dispatchBonusEvent({ message: `${label} -- activated`, type: "purchase" });
    }
    setPurchaseModal(null);
    toast.success(`${label} -- ${t("tokens.purchased")}`, {
      icon: <CheckCircle className="w-4 h-4 text-emerald-400" />,
    });
  };

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-8" {...pullHandlers}>
      <PullToRefreshIndicator pullY={pullY} isRefreshing={isRefreshing} />
      {/* ─── Onboarding overlay ─── */}
      <AnimatePresence>
        {onboardStep >= 0 && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 z-40"
            onClick={dismissOnboard}
          />
        )}
      </AnimatePresence>

      {/* ─── 5-step tour modal ─── */}
      <AnimatePresence>
        {onboardStep >= 0 && (
          <motion.div
            key={`ts-tour-${onboardStep}`}
            initial={{ opacity: 0, y: 10, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.96 }}
            className="fixed z-[100] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90vw] max-w-sm"
          >
            <div className="p-5 rounded-2xl bg-zinc-900 border border-purple-500/30 shadow-2xl shadow-purple-500/10">
              <div className="text-xs text-purple-400 mb-2" style={{ fontWeight: 600 }}>{onboardStep + 1}/5</div>
              <div className="text-white mb-1" style={{ fontWeight: 600 }}>
                {tsTourSteps[onboardStep]?.title}
              </div>
              <p className="text-sm text-zinc-400 mb-4 leading-relaxed">
                {tsTourSteps[onboardStep]?.desc}
              </p>
              {/* Step dots */}
              <div className="flex items-center gap-1.5 mb-4">
                {[0, 1, 2, 3, 4].map((i) => (
                  <div key={i} className={`h-1 rounded-full transition-all ${i < onboardStep ? "w-5 bg-purple-500/50" : i === onboardStep ? "w-7 bg-purple-500" : "w-3 bg-white/[0.08]"}`} />
                ))}
              </div>
              <div className="flex items-center justify-between">
                <button onClick={dismissOnboard} className="text-xs text-zinc-600 hover:text-zinc-400 transition-colors">{t("tsTour.skip")}</button>
                <button onClick={nextOnboard} className="text-xs text-white bg-purple-600 hover:bg-purple-500 px-4 py-2 rounded-lg transition-colors">
                  {onboardStep < 4 ? t("tsTour.next") : t("tsTour.done")}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <LargeTitle
        title={t("tokens.title")}
        subtitle={t("tokens.subtitle")}
      />

      {/* Balance card */}
      {loading ? (
        <>
          <HeroCardSkeleton />
          <TokenCardSkeleton count={3} />
          <CardGridSkeleton count={6} cols="sm:grid-cols-2 lg:grid-cols-3" />
        </>
      ) : (
      <>
      <div className="p-6 rounded-xl border border-purple-500/20 bg-gradient-to-r from-purple-500/5 to-violet-500/5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center"><Coins className="w-6 h-6 text-purple-400" /></div>
            <div><div className="text-sm text-zinc-400">{t("tokens.balance")}</div><div className="text-3xl text-white light-force-dark" style={{ fontWeight: 700 }}>{currentBalance.toLocaleString()}</div></div>
          </div>
          <div className="flex items-center gap-3">
            {progress.projectCreated && (
              <button onClick={() => navigate("/dashboard")} className="text-xs text-purple-400 hover:text-purple-300 px-3 py-1.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/15 transition-all flex items-center gap-1">
                <ArrowLeft className="w-3 h-3" />{t("tokens.backToDash")}
              </button>
            )}
            <div className="text-right hidden sm:block"><div className="text-xs text-zinc-500">{t("tokens.monthlyBonus")}</div><div className="text-sm text-purple-400" style={{ fontWeight: 600 }}>+200 {t("tokens.onDate")}</div></div>
          </div>
        </div>
      </div>
      </>
      )}

      {/* ─── Stripe success celebration ─── */}
      <AnimatePresence>
        {stripeSuccess && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.96 }}
            className="p-5 rounded-2xl border border-emerald-500/30 bg-gradient-to-r from-emerald-500/10 to-cyan-500/5 relative overflow-hidden"
          >
            <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-emerald-400/50 to-transparent" />
            <div className="flex items-center gap-4">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
                className="w-14 h-14 rounded-2xl bg-emerald-500/15 border border-emerald-500/20 flex items-center justify-center shrink-0"
              >
                <CheckCircle className="w-7 h-7 text-emerald-400" />
              </motion.div>
              <div className="flex-1 min-w-0">
                <h3 className="text-white mb-0.5" style={{ fontWeight: 700 }}>
                  {t("tokens.paymentSuccess")}
                </h3>
                <p className="text-sm text-zinc-400">
                  {t("tokens.tokensCredited")}
                </p>
              </div>
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate("/dashboard/launch")}
                className="shrink-0 inline-flex items-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white px-5 py-2.5 rounded-xl text-sm transition-all shadow-lg shadow-purple-500/20"
                style={{ fontWeight: 600 }}
              >
                <Rocket className="w-4 h-4" />
                {t("tokens.launchNow")}
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Video tutorial */}
      <VideoTutorial title={t("tokens.videoTitle")} duration="2 min" />

      {/* ─── Demo: Quick-add tokens (for testing core loop) ─── */}
      {!stripeSuccess && currentBalance === 0 && !loading && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 rounded-xl border border-dashed border-purple-500/20 bg-purple-500/[0.03] flex flex-col sm:flex-row items-start sm:items-center gap-3"
        >
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <Sparkles className="w-4 h-4 text-purple-400 shrink-0" />
            <p className="text-xs text-zinc-400">
              {t("tokens.demoHint")}
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {[
              { label: "+100", tokens: 100 },
              { label: "+300", tokens: 300 },
              { label: "+1000", tokens: 1000 },
            ].map((demo) => (
              <button
                key={demo.tokens}
                onClick={() => {
                  const newBal = currentBalance + demo.tokens;
                  setCurrentBalance(newBal);
                  updateProgress({ tokensAvailable: newBal });
                  fireConfetti();
                  dispatchBonusEvent({ message: `+${demo.tokens} tokens (demo)`, tokens: demo.tokens, type: "purchase" });
                  toast.success(`${demo.tokens} tokens added (demo)`, {
                    icon: <CheckCircle className="w-4 h-4 text-emerald-400" />,
                  });
                }}
                className="text-xs text-purple-400 hover:text-purple-300 px-3 py-1.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/15 border border-purple-500/20 transition-all"
                style={{ fontWeight: 600 }}
              >
                {demo.label}
              </button>
            ))}
          </div>
        </motion.div>
      )}

      {/* Token packages */}
      <div>
        <h2 className="text-lg text-white mb-4" style={{ fontWeight: 600 }}>{t("tokens.buyTokens")}</h2>
        <div className="grid md:grid-cols-3 gap-4">
          {tokenPackages.map((pkg, i) => (
            <motion.button key={pkg.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }} onClick={() => setSelected(pkg.id)}
              className={`ios-press relative p-6 rounded-[14px] border text-left transition-all flex flex-col ${selected === pkg.id ? "border-purple-500/30 bg-purple-500/5" : "border-white/5 bg-white/[0.02] hover:border-white/10"}`}>
              {pkg.popular && <div className="absolute -top-2.5 right-4 text-xs bg-cyan-500 text-white px-2.5 py-0.5 rounded-full" style={{ fontWeight: 600 }}>{t("tokens.bestValue")}</div>}
              <motion.div layoutId={`token-icon-${pkg.id}`} className={`w-10 h-10 rounded-xl ${pkg.color === "purple" ? "bg-purple-500/10" : pkg.color === "cyan" ? "bg-cyan-500/10" : "bg-emerald-500/10"} flex items-center justify-center mb-4`}>
                <pkg.icon className={`w-5 h-5 ${pkg.color === "purple" ? "text-purple-400" : pkg.color === "cyan" ? "text-cyan-400" : "text-emerald-400"}`} />
              </motion.div>
              <motion.div layoutId={`token-name-${pkg.id}`} className="text-sm text-zinc-400 mb-1" style={{ fontWeight: 500 }}>{pkg.name}</motion.div>
              <div className="flex items-baseline gap-1.5 mb-1"><span className="text-3xl text-white" style={{ fontWeight: 700 }}>{pkg.tokens}</span><span className="text-sm text-zinc-500">tokens</span></div>
              <div className="flex items-center gap-2 mb-4">
                <span className="text-lg text-white" style={{ fontWeight: 600 }}>{pkg.priceStr}</span>
                <span className="text-xs text-zinc-600">({pkg.perToken}/token)</span>
                {pkg.savings && <span className="text-xs text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">{pkg.savings}</span>}
              </div>
              <ul className="space-y-2 mb-5 flex-1">{pkg.features.map((f) => <li key={f} className="flex items-center gap-2 text-xs text-zinc-500"><Check className="w-3 h-3 text-purple-400 shrink-0" />{f}</li>)}</ul>
              <a
                href={getStripeTokenUrl(pkg.id)}
                target="_blank"
                rel="noopener noreferrer"
                className={`w-full py-2.5 rounded-lg text-sm text-center transition-all flex items-center justify-center gap-1.5 mt-auto ${selected === pkg.id ? "bg-purple-600 text-white hover:bg-purple-500" : "border border-white/10 text-zinc-400 hover:border-white/20"}`}
                onClick={(e) => { e.stopPropagation(); }}>
                <ShoppingCart className="w-3.5 h-3.5" />{t("tokens.buyNow")} -- {pkg.priceStr}
              </a>
            </motion.button>
          ))}
        </div>
      </div>

      {/* What tokens are for */}
      <div>
        <h2 className="text-lg text-white mb-4" style={{ fontWeight: 600 }}>{t("tokens.whatUsedFor")}</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {tokenUses.map((u) => (
            <div key={u.label} className="flex items-center gap-3 p-4 rounded-xl border border-white/5 bg-white/[0.02]">
              <div className="w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center shrink-0"><u.icon className="w-4 h-4 text-purple-400" /></div>
              <div className="min-w-0"><div className="text-sm text-zinc-300" style={{ fontWeight: 500 }}>{u.label}</div><div className="text-xs text-zinc-600">{u.cost} tokens</div></div>
            </div>
          ))}
        </div>
      </div>

      {/* ─── Restaurant-style Token Menu ─── */}
      <div className="p-5 sm:p-6 rounded-2xl border border-purple-500/10 bg-gradient-to-br from-purple-500/[0.03] to-violet-500/[0.02]">
        <div className="flex items-center gap-3 mb-1">
          <div className="w-9 h-9 rounded-xl bg-purple-500/10 flex items-center justify-center"><Coins className="w-4 h-4 text-purple-400" /></div>
          <div>
            <h2 className="text-white" style={{ fontWeight: 600 }}>{t("tokens.menuTitle")}</h2>
            <p className="text-xs text-zinc-500 mt-0.5">{t("tokens.menuSubtitle")}</p>
          </div>
        </div>

        {/* Content Creation */}
        <div className="mt-5">
          <div className="text-[10px] text-purple-400/70 uppercase tracking-widest mb-2 px-1" style={{ fontWeight: 700 }}>{t("tokens.menuContent")}</div>
          <div className="rounded-xl border border-white/5 overflow-hidden divide-y divide-white/[0.04]">
            {[
              { label: t("tokens.menuItem1"), cost: "5" },
              { label: t("tokens.menuItem2"), cost: "10" },
              { label: t("tokens.menuItem3"), cost: "15" },
              { label: t("tokens.menuItem4"), cost: "10" },
              { label: t("tokens.menuItem5"), cost: "10" },
              { label: t("tokens.menuItem6"), cost: "10" },
              { label: t("tokens.menuItem7"), cost: "5" },
            ].map((item) => (
              <div key={item.label} className="flex items-center justify-between px-4 py-3 bg-white/[0.01] hover:bg-white/[0.03] transition-colors">
                <span className="text-sm text-zinc-300">{item.label}</span>
                <div className="flex items-center gap-1 shrink-0 ml-3">
                  <Coins className="w-3 h-3 text-amber-400/70" />
                  <span className="text-sm text-white tabular-nums" style={{ fontWeight: 600 }}>{item.cost}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Distribution */}
        <div className="mt-4">
          <div className="text-[10px] text-cyan-400/70 uppercase tracking-widest mb-2 px-1" style={{ fontWeight: 700 }}>{t("tokens.menuDistribution")}</div>
          <div className="rounded-xl border border-white/5 overflow-hidden divide-y divide-white/[0.04]">
            {[
              { label: t("tokens.menuItem8"), cost: "10" },
              { label: t("tokens.menuItem9"), cost: "15" },
              { label: t("tokens.menuItem10"), cost: "20" },
              { label: t("tokens.menuItem11"), cost: "10" },
              { label: t("tokens.menuItem12"), cost: "15" },
            ].map((item) => (
              <div key={item.label} className="flex items-center justify-between px-4 py-3 bg-white/[0.01] hover:bg-white/[0.03] transition-colors">
                <span className="text-sm text-zinc-300">{item.label}</span>
                <div className="flex items-center gap-1 shrink-0 ml-3">
                  <Coins className="w-3 h-3 text-amber-400/70" />
                  <span className="text-sm text-white tabular-nums" style={{ fontWeight: 600 }}>{item.cost}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Boosts & Extras */}
        <div className="mt-4">
          <div className="text-[10px] text-emerald-400/70 uppercase tracking-widest mb-2 px-1" style={{ fontWeight: 700 }}>{t("tokens.menuBoosts")}</div>
          <div className="rounded-xl border border-white/5 overflow-hidden divide-y divide-white/[0.04]">
            {[
              { label: t("tokens.menuItem13"), cost: "25" },
              { label: t("tokens.menuItem14"), cost: "50" },
              { label: t("tokens.menuItem15"), cost: "30" },
              { label: t("tokens.menuItem16"), cost: "40" },
              { label: t("tokens.menuItem17"), cost: "50" },
              { label: t("tokens.menuItem18"), cost: "1+" },
            ].map((item) => (
              <div key={item.label} className="flex items-center justify-between px-4 py-3 bg-white/[0.01] hover:bg-white/[0.03] transition-colors">
                <span className="text-sm text-zinc-300">{item.label}</span>
                <div className="flex items-center gap-1 shrink-0 ml-3">
                  <Coins className="w-3 h-3 text-amber-400/70" />
                  <span className="text-sm text-white tabular-nums" style={{ fontWeight: 600 }}>{item.cost}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Example callout */}
        <div className="mt-4 p-3 rounded-xl bg-purple-500/5 border border-purple-500/10 flex items-start gap-2">
          <Sparkles className="w-3.5 h-3.5 text-purple-400 shrink-0 mt-0.5" />
          <p className="text-xs text-zinc-400 leading-relaxed">{t("tokens.menuExample")}</p>
        </div>
      </div>

      {/* Subscription plans */}
      <div className="pt-4 border-t border-white/5">
        <SubscriptionPlans t={t} onSelectPlan={handleOpenPlanModal} />
      </div>

      {/* Purchase modal */}
      <AnimatePresence>
        {purchaseModal && (
          <PurchaseModal
            type={purchaseModal.type}
            tokenPkg={purchaseModal.tokenPkg}
            planPkg={purchaseModal.planPkg}
            initialAnnual={purchaseModal.annual}
            onClose={() => setPurchaseModal(null)}
            onSuccess={handlePurchaseSuccess}
            t={t}
          />
        )}
      </AnimatePresence>
    </div>
  );
}