import { useState, useCallback } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import {
  Rocket, User, Mail, Lock, Eye, EyeOff, ArrowRight, ArrowLeft,
  Globe, Users, Target, Zap, Sparkles, Check, Crown, TrendingUp, Github, Layers, SkipForward,
  Sun, Moon, HelpCircle, Package, Compass, CreditCard, Shield, Calendar,
  Bot, Cloud, Smartphone, Gamepad2, Palette,
} from "lucide-react";
import { useI18n, LangSwitcher } from "./i18n";
import { useTheme } from "./ThemeProvider";
import { FloatingOrbs } from "./FloatingOrbs";
import { updateProgress } from "./user-progress";
import { LaunchLogo } from "./LaunchLogo";
import { activateTrialSubscription, PLAN_TOKENS, PLAN_PRICES } from "./subscription";
import { useForceDarkMode } from "./useForceDarkMode";

const categories = [
  { label: "AI Tool", Icon: Bot }, { label: "SaaS", Icon: Cloud }, { label: "Mobile App", Icon: Smartphone },
  { label: "Game", Icon: Gamepad2 }, { label: "Web Platform", Icon: Globe }, { label: "Creative Product", Icon: Palette }, { label: "Startup", Icon: Rocket },
];

function ConfettiParticle({ delay, x }: { delay: number; x: number }) {
  const colors = ["#8b5cf6", "#06b6d4", "#10b981", "#f59e0b", "#ef4444", "#ec4899"];
  const color = colors[Math.floor(Math.random() * colors.length)];
  return (
    <motion.div initial={{ y: -20, x, opacity: 1, scale: 1, rotate: 0 }} animate={{ y: 600, x: x + (Math.random() - 0.5) * 200, opacity: 0, scale: 0.5, rotate: Math.random() * 720 - 360 }}
      transition={{ duration: 2.5 + Math.random(), delay, ease: "easeOut" }} className="absolute top-0 w-2 h-2 rounded-sm" style={{ backgroundColor: color, left: "50%" }} />
  );
}

function PulsingLogo() {
  return (
    <div className="relative w-14 h-14 mx-auto mb-5">
      <motion.div animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0, 0.3] }} transition={{ duration: 2, repeat: Infinity }} className="absolute inset-0 rounded-2xl bg-purple-500/20" />
      <motion.div animate={{ scale: [1, 1.15, 1], opacity: [0.5, 0, 0.5] }} transition={{ duration: 2, repeat: Infinity, delay: 0.3 }} className="absolute inset-0 rounded-2xl bg-purple-500/15" />
      <div className="relative w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center shadow-lg shadow-purple-500/30"><Rocket className="w-6 h-6 text-white" /></div>
    </div>
  );
}

function TypingDots() {
  return (
    <div className="flex items-center gap-1 px-3 py-2 justify-center">
      {[0, 1, 2].map((i) => (
        <motion.div key={i} animate={{ y: [0, -4, 0], opacity: [0.4, 1, 0.4] }} transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }} className="w-1.5 h-1.5 rounded-full bg-purple-400" />
      ))}
    </div>
  );
}

/* ─── Inline help tip ─── */
function HelpTip({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="mt-2">
      <button onClick={() => setOpen(!open)} className="flex items-center gap-1.5 text-xs text-zinc-600 hover:text-zinc-400 transition-colors">
        <HelpCircle className="w-3 h-3" />
        <span>{open ? "Hide tip" : "Need help?"}</span>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
            <div className="mt-1.5 p-3 rounded-xl bg-purple-500/5 border border-purple-500/10 text-xs text-zinc-400 leading-relaxed">
              {children}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ─── Step progress bar (mobile-optimized) ─── */
function ProgressBar({ current, total }: { current: number; total: number }) {
  return (
    <div className="flex items-center gap-1.5 w-full max-w-xs mx-auto mb-6 sm:mb-8">
      {Array.from({ length: total }).map((_, i) => (
        <div key={i} className="flex-1 h-1.5 rounded-full overflow-hidden bg-white/[0.06]">
          <motion.div
            animate={{ width: i < current ? "100%" : i === current ? "50%" : "0%" }}
            transition={{ duration: 0.4, ease: "easeOut" }}
            className={`h-full rounded-full ${i < current ? "bg-purple-500" : i === current ? "bg-purple-500/50" : ""}`}
          />
        </div>
      ))}
    </div>
  );
}

/* ─── How it works preview (shown on step 0) ─── */
function HowItWorksPreview({ t }: { t: (k: string) => string }) {
  const steps = [
    { icon: Layers, label: t("onb.howStep1"), color: "text-purple-400", bg: "bg-purple-500/10" },
    { icon: Package, label: t("onb.howStep2"), color: "text-violet-400", bg: "bg-violet-500/10" },
    { icon: Compass, label: t("onb.howStep3"), color: "text-cyan-400", bg: "bg-cyan-500/10" },
    { icon: Rocket, label: t("onb.howStep4"), color: "text-emerald-400", bg: "bg-emerald-500/10" },
    { icon: TrendingUp, label: t("onb.howStep5"), color: "text-amber-400", bg: "bg-amber-500/10" },
  ];
  return (
    <div className="mt-6 p-4 rounded-2xl border border-white/5 bg-white/[0.02]">
      <div className="text-xs text-zinc-500 mb-3 text-center" style={{ fontWeight: 600 }}>{t("onb.howTitle")}</div>
      <div className="flex items-center justify-between gap-1">
        {steps.map((s, i) => (
          <div key={i} className="flex flex-col items-center gap-1.5 flex-1 min-w-0">
            <div className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl ${s.bg} flex items-center justify-center`}>
              <s.icon className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${s.color}`} />
            </div>
            <span className="text-[9px] sm:text-[10px] text-zinc-500 text-center leading-tight">{s.label}</span>
            {i < steps.length - 1 && <div className="hidden" />}
          </div>
        ))}
      </div>
    </div>
  );
}

export function Onboarding() {
  useForceDarkMode();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [step, setStep] = useState(0);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [customCategoryOpen, setCustomCategoryOpen] = useState(false);
  const [customCategoryValue, setCustomCategoryValue] = useState("");
  const [form, setForm] = useState({ name: "", email: "", password: "", projectName: "", projectUrl: "", projectDesc: "", category: "", audience: "", goal: "", strategy: "" });
  // Card form for trial activation (step 4)
  const [cardNumber, setCardNumber] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvc, setCardCvc] = useState("");
  const [cardHolder, setCardHolder] = useState("");
  const [isActivating, setIsActivating] = useState(false);

  const formatCardNum = (v: string) => v.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();
  const formatExp = (v: string) => { const d = v.replace(/\D/g, "").slice(0, 4); return d.length >= 3 ? d.slice(0, 2) + " / " + d.slice(2) : d; };

  const totalSteps = form.strategy ? 5 : 4; // 5 steps if strategy selected (includes payment)

  const update = (key: string, val: string) => setForm((p) => ({ ...p, [key]: val }));

  const goNext = useCallback(() => {
    if (isTransitioning) return;
    setIsTransitioning(true);

    if (step < 3) {
      setStep((s) => s + 1);
    } else if (step === 3 && form.strategy) {
      // Strategy selected → go to payment step (step 4)
      setStep(4);
    } else if (step === 4) {
      // Payment step → activate trial, save everything, go to dashboard
      setIsActivating(true);
      // Save project + extended onboarding data
      updateProgress({
        projectCreated: true,
        projectName: form.projectName.trim() || "My Project",
        projectCategory: form.category || "Startup",
        projectUrl: form.projectUrl,
        projectDescription: form.projectDesc,
        tokensAvailable: PLAN_TOKENS[form.strategy] || 300,
        userName: form.name.trim(),
        userEmail: form.email.trim(),
        audience: form.audience.trim(),
        goal: form.goal.trim(),
        onboardingCompleted: true,
        lastCompletedStep: 1, // project is clarified, next is Package
        lastVisit: Date.now(),
      });
      // Activate trial subscription
      const last4 = cardNumber.replace(/\s/g, "").slice(-4) || "4242";
      const expStr = cardExpiry.replace(/\s/g, "") || "12/27";
      activateTrialSubscription(form.strategy, { last4, brand: "Visa", expiry: expStr });
      localStorage.setItem("launchapp_plan", form.strategy);

      setTimeout(() => {
        setIsActivating(false);
        setShowConfetti(true);
        setTimeout(() => navigate("/welcome"), 2500);
      }, 1500);
      return;
    } else {
      // No strategy selected → skip payment, go to welcome splash
      if (form.projectName.trim()) {
        updateProgress({
          projectCreated: true,
          projectName: form.projectName.trim(),
          projectCategory: form.category || "Startup",
          projectUrl: form.projectUrl,
          projectDescription: form.projectDesc,
          userName: form.name.trim(),
          userEmail: form.email.trim(),
          audience: form.audience.trim(),
          goal: form.goal.trim(),
          onboardingCompleted: true,
          lastCompletedStep: 1,
          lastVisit: Date.now(),
        });
      }
      setShowConfetti(true);
      setTimeout(() => navigate("/welcome"), 2500);
    }
    setTimeout(() => setIsTransitioning(false), 500);
  }, [step, isTransitioning, navigate, form, cardNumber, cardExpiry]);

  const goBack = () => { if (step > 0 && !isTransitioning) { setIsTransitioning(true); setStep((s) => s - 1); setTimeout(() => setIsTransitioning(false), 500); } };

  const skipToDashboard = () => {
    if (form.projectName.trim()) {
      updateProgress({
        projectCreated: true,
        projectName: form.projectName.trim(),
        projectCategory: form.category || "Startup",
        projectUrl: form.projectUrl,
        projectDescription: form.projectDesc,
      });
    }
    setShowConfetti(true);
    setTimeout(() => navigate("/welcome"), 2000);
  };

  const strategies = [
    { id: "starter", name: t("onb.starterLaunch"), desc: t("onb.starterLaunchDesc"), channels: "50+", tokens: 100, price: "$29", icon: Rocket, gradient: "from-purple-500/20 to-violet-500/20", border: "border-purple-500/20", iconColor: "text-purple-400" },
    { id: "growth", name: t("onb.growthLaunch"), desc: t("onb.growthLaunchDesc"), channels: "200+", tokens: 300, price: "$59", icon: TrendingUp, gradient: "from-cyan-500/20 to-blue-500/20", border: "border-cyan-500/20", iconColor: "text-cyan-400", recommended: true },
    { id: "viral", name: t("onb.viralLaunch"), desc: t("onb.viralLaunchDesc"), channels: "All", tokens: 1000, price: "$149", icon: Crown, gradient: "from-emerald-500/20 to-teal-500/20", border: "border-emerald-500/20", iconColor: "text-emerald-400" },
  ];

  const { theme, toggleTheme } = useTheme();

  /* ─── Step labels for header ─── */
  const stepLabels = [t("onb.account"), t("onb.product"), t("onb.audience"), t("onb.strategy"), ...(form.strategy ? [t("onb.paymentStep")] : [])];

  return (
    <div className="relative bg-[var(--app-bg)] text-white flex flex-col overflow-hidden" style={{ height: "100dvh" }}>
      {/* Subtle background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-1/4 -left-32 w-[400px] h-[400px] bg-purple-500/6 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 -right-32 w-[300px] h-[300px] bg-violet-500/4 rounded-full blur-3xl" />
        <div className="absolute inset-0" style={{ backgroundImage: "radial-gradient(rgba(139,92,246,0.03) 1px, transparent 1px)", backgroundSize: "32px 32px" }} />
      </div>
      <FloatingOrbs count={3} />

      {/* ─── Header (compact on mobile) ─── */}
      <div className="relative z-10 shrink-0 flex items-center justify-between px-4 sm:px-6 py-3 sm:py-4 border-b border-white/5">
        <div className="flex items-center gap-2">
          <LaunchLogo size={28} />
          <span className="text-sm sm:text-base" style={{ fontWeight: 700 }}>Launch OS</span>
        </div>
        <div className="flex items-center gap-2 sm:gap-3">
          <LangSwitcher />
          <button onClick={toggleTheme} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-500 hover:text-zinc-300 transition-all">
            {theme === "dark" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
          </button>
          <button onClick={() => navigate("/")} className="hidden sm:block text-xs text-zinc-600 hover:text-zinc-400 transition-colors">{t("nav.backToHome")}</button>
        </div>
      </div>

      {/* ─── Step label + progress ─── */}
      <div className="relative z-10 shrink-0 pt-4 sm:pt-6 px-4">
        <div className="text-center mb-2">
          <span className="text-xs text-purple-400/80 uppercase tracking-widest" style={{ fontWeight: 600 }}>
            {t("onb.stepOf").replace("{n}", String(step + 1)).replace("{total}", String(totalSteps))} — {stepLabels[step] || stepLabels[stepLabels.length - 1]}
          </span>
        </div>
        <ProgressBar current={step} total={totalSteps} />
      </div>

      {/* ─── Main content ─── */}
      <div className="relative z-10 flex-1 min-h-0 px-4 sm:px-6 pb-6 overflow-y-auto">
        <div className="w-full max-w-lg mx-auto">
          <AnimatePresence mode="wait">
            {/* ─── Step 0: Account ─── */}
            {step === 0 && (
              <motion.div key="s0" initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }} transition={{ duration: 0.35 }} className="space-y-5">
                <div className="text-center">
                  <PulsingLogo />
                  <h1 className="text-xl sm:text-2xl tracking-tight mb-2" style={{ fontWeight: 700 }}>{t("onb.welcome")}</h1>
                  <p className="text-zinc-500 text-sm max-w-sm mx-auto">{t("onb.welcomeSub")}</p>
                </div>

                <div className="space-y-4">
                  {/* Social login */}
                  <div className="grid grid-cols-2 gap-3">
                    <button className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-white/10 hover:border-white/20 hover:bg-white/[0.03] transition-all text-sm text-zinc-300 active:scale-95">
                      <Github className="w-4 h-4" />GitHub
                    </button>
                    <button className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-white/10 hover:border-white/20 hover:bg-white/[0.03] transition-all text-sm text-zinc-300 active:scale-95">
                      <Globe className="w-4 h-4" />Google
                    </button>
                  </div>
                  <div className="flex items-center gap-3"><div className="flex-1 h-px bg-white/5" /><span className="text-xs text-zinc-600">{t("onb.or")}</span><div className="flex-1 h-px bg-white/5" /></div>

                  {/* Form fields */}
                  <div>
                    <label className="text-xs text-zinc-500 mb-1.5 block">{t("onb.fullName")}</label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                      <input value={form.name} onChange={(e) => update("name", e.target.value)} placeholder={t("onb.yourName")}
                        className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-[16px] sm:text-sm" />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-zinc-500 mb-1.5 block">{t("onb.email")}</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                      <input type="email" value={form.email} onChange={(e) => update("email", e.target.value)} placeholder="you@startup.com"
                        className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-[16px] sm:text-sm" />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-zinc-500 mb-1.5 block">{t("onb.password")}</label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                      <input type={showPassword ? "text" : "password"} value={form.password} onChange={(e) => update("password", e.target.value)} placeholder={t("onb.createPassword")}
                        className="w-full pl-10 pr-10 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-[16px] sm:text-sm" />
                      <button type="button" onClick={() => setShowPassword((v) => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-zinc-400 transition-colors p-1">
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* How it works mini-preview */}
                <HowItWorksPreview t={t} />

                {/* Login link */}
                <div className="text-center">
                  <button onClick={() => navigate("/login")} className="text-xs text-zinc-600 hover:text-zinc-400 transition-colors">
                    {t("onb.alreadyHave")} <span className="text-purple-400 hover:text-purple-300">{t("onb.logIn")}</span>
                  </button>
                </div>
              </motion.div>
            )}

            {/* ─── Step 1: Product ─── */}
            {step === 1 && (
              <motion.div key="s1" initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }} transition={{ duration: 0.35 }} className="space-y-5">
                <div className="text-center">
                  <motion.div initial={{ scale: 0, rotate: -90 }} animate={{ scale: 1, rotate: 0 }} transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
                    className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/10 flex items-center justify-center">
                    <Layers className="w-6 h-6 text-cyan-400" />
                  </motion.div>
                  <h1 className="text-xl sm:text-2xl tracking-tight mb-2" style={{ fontWeight: 700 }}>{t("onb.tellProduct")}</h1>
                  <p className="text-zinc-500 text-sm max-w-sm mx-auto">{t("onb.tellProductSub")}</p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-xs text-zinc-500 mb-1.5 block">{t("onb.projectName")} *</label>
                    <input value={form.projectName} onChange={(e) => update("projectName", e.target.value)} placeholder="e.g. AI Task Manager"
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-[16px] sm:text-sm" />
                    <HelpTip>{t("onb.helpProductName")}</HelpTip>
                  </div>

                  <div>
                    <label className="text-xs text-zinc-500 mb-1.5 block">{t("onb.websiteUrl")}</label>
                    <div className="relative">
                      <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                      <input value={form.projectUrl} onChange={(e) => update("projectUrl", e.target.value)} placeholder="https://yourproduct.com"
                        className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-[16px] sm:text-sm" />
                    </div>
                    <HelpTip>{t("onb.helpUrl")}</HelpTip>
                  </div>

                  <div>
                    <label className="text-xs text-zinc-500 mb-1.5 block">{t("onb.shortDesc")} *</label>
                    <textarea value={form.projectDesc} onChange={(e) => update("projectDesc", e.target.value)} placeholder={t("onb.shortDescPh")} rows={3}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-[16px] sm:text-sm resize-none" />
                    <HelpTip>{t("onb.helpDesc")}</HelpTip>
                  </div>

                  <div>
                    <label className="text-xs text-zinc-500 mb-2 block">{t("onb.category")} *</label>
                    <div className="flex flex-wrap gap-2">
                      {categories.map((c) => (
                        <motion.button key={c.label} whileTap={{ scale: 0.95 }} onClick={() => update("category", c.label)}
                          className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-sm transition-all ${form.category === c.label ? "bg-purple-500/15 text-purple-300 border border-purple-500/30" : "bg-white/[0.03] text-zinc-500 border border-white/5 hover:border-white/10"}`}>
                          <c.Icon className="w-4 h-4" />{c.label}
                        </motion.button>
                      ))}
                      {form.category && !categories.some((c) => c.label === form.category) && (
                        <motion.button key={`custom-${form.category}`} initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
                          className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-sm bg-purple-500/15 text-purple-300 border border-purple-500/30">
                          <Sparkles className="w-4 h-4" />{form.category}
                        </motion.button>
                      )}
                      <motion.button whileTap={{ scale: 0.95 }} onClick={() => setCustomCategoryOpen(true)}
                        className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-sm bg-white/[0.03] text-zinc-500 border border-white/5 hover:border-white/10">
                        <span>+</span>{t("onb.custom")}
                      </motion.button>
                    </div>
                    {customCategoryOpen && (
                      <div className="mt-2 flex gap-2">
                        <input value={customCategoryValue} onChange={(e) => setCustomCategoryValue(e.target.value)} placeholder={t("onb.customCategoryPh")}
                          className="flex-1 px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-[16px] sm:text-sm" />
                        <button disabled={!customCategoryValue.trim()} onClick={() => { if (customCategoryValue.trim()) { update("category", customCategoryValue.trim()); setCustomCategoryOpen(false); setCustomCategoryValue(""); } }}
                          className="px-4 py-3 rounded-xl bg-purple-600 text-white text-sm transition-all disabled:opacity-40 shrink-0 active:scale-95">
                          {t("onb.addCategory")}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Step 2: Audience ─── */}
            {step === 2 && (
              <motion.div key="s2" initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }} transition={{ duration: 0.35 }} className="space-y-5">
                <div className="text-center">
                  <motion.div initial={{ scale: 0, rotate: 90 }} animate={{ scale: 1, rotate: 0 }} transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
                    className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/10 flex items-center justify-center">
                    <Target className="w-6 h-6 text-emerald-400" />
                  </motion.div>
                  <h1 className="text-xl sm:text-2xl tracking-tight mb-2" style={{ fontWeight: 700 }}>{t("onb.whoFor")}</h1>
                  <p className="text-zinc-500 text-sm max-w-sm mx-auto">{t("onb.whoForSub")}</p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-xs text-zinc-500 mb-1.5 block">
                      <Users className="w-3.5 h-3.5 inline mr-1 -mt-0.5" />{t("onb.targetAudience")} *
                    </label>
                    <input value={form.audience} onChange={(e) => update("audience", e.target.value)} placeholder={t("onb.targetAudiencePh")}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-[16px] sm:text-sm" />
                    <HelpTip>{t("onb.helpAudience")}</HelpTip>
                  </div>

                  <div>
                    <label className="text-xs text-zinc-500 mb-1.5 block">
                      <Target className="w-3.5 h-3.5 inline mr-1 -mt-0.5" />{t("onb.launchGoal")} *
                    </label>
                    <textarea value={form.goal} onChange={(e) => update("goal", e.target.value)} placeholder={t("onb.launchGoalPh")} rows={3}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-[16px] sm:text-sm resize-none" />
                    <HelpTip>{t("onb.helpGoal")}</HelpTip>
                  </div>

                  <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
                    className="flex items-start gap-3 p-4 rounded-xl bg-purple-500/5 border border-purple-500/10">
                    <Sparkles className="w-4 h-4 text-purple-400 mt-0.5 shrink-0" />
                    <div>
                      <div className="text-xs text-purple-300" style={{ fontWeight: 600 }}>{t("onb.aiFindChannels")}</div>
                      <p className="text-xs text-zinc-500 mt-0.5 leading-relaxed">{t("onb.aiFindChannelsSub")}</p>
                    </div>
                  </motion.div>
                </div>
              </motion.div>
            )}

            {/* ─── Step 3: Strategy ─── */}
            {step === 3 && (
              <motion.div key="s3" initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }} transition={{ duration: 0.35 }} className="space-y-5">
                <div className="text-center">
                  <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
                    className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-amber-500/20 to-orange-500/20 border border-amber-500/10 flex items-center justify-center">
                    <Zap className="w-6 h-6 text-amber-400" />
                  </motion.div>
                  <h1 className="text-xl sm:text-2xl tracking-tight mb-2" style={{ fontWeight: 700 }}>{t("onb.choosePower")}</h1>
                  <p className="text-zinc-500 text-sm max-w-sm mx-auto">{t("onb.choosePowerSub")}</p>
                </div>

                <HelpTip>{t("onb.helpStrategy")}</HelpTip>

                <div className="space-y-3">
                  {strategies.map((s, i) => (
                    <motion.button key={s.id} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 + i * 0.08 }}
                      onClick={() => update("strategy", s.id)}
                      className={`relative w-full p-4 sm:p-5 rounded-2xl border text-left transition-all active:scale-[0.98] ${form.strategy === s.id ? `${s.border} bg-gradient-to-r ${s.gradient}` : "border-white/5 bg-white/[0.02] hover:border-white/10"}`}>
                      {s.recommended && <div className="absolute -top-2.5 right-4 text-[10px] bg-cyan-500 text-white px-2.5 py-0.5 rounded-full" style={{ fontWeight: 700 }}>{t("onb.recommended")}</div>}
                      <div className="flex items-start gap-3 sm:gap-4">
                        <div className={`w-4 h-4 mt-1 shrink-0 rounded-full border-2 transition-all flex items-center justify-center ${form.strategy === s.id ? "border-purple-500 bg-purple-500" : "border-zinc-600"}`}>
                          {form.strategy === s.id && <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}><Check className="w-2.5 h-2.5 text-white" /></motion.div>}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2 mb-1">
                            <div className="flex items-center gap-2">
                              <s.icon className={`w-4 h-4 ${s.iconColor}`} />
                              <span className="text-white text-sm" style={{ fontWeight: 600 }}>{s.name}</span>
                            </div>
                            <span className="text-sm text-white shrink-0" style={{ fontWeight: 700 }}>{s.price}<span className="text-xs text-zinc-500">/mo</span></span>
                          </div>
                          <p className="text-xs text-zinc-500 leading-relaxed mb-2">{s.desc}</p>
                          <div className="flex items-center gap-3 text-xs text-zinc-600">
                            <span className="flex items-center gap-1"><Globe className="w-3 h-3" />{s.channels}</span>
                            <span className="flex items-center gap-1"><Sparkles className="w-3 h-3" />{s.tokens} tokens</span>
                          </div>
                        </div>
                      </div>
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            )}

            {/* ─── Step 4: Payment / Trial Activation ─── */}
            {step === 4 && (
              <motion.div key="s4" initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }} transition={{ duration: 0.35 }} className="space-y-5">
                <div className="text-center">
                  <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
                    className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 border border-emerald-500/10 flex items-center justify-center">
                    <CreditCard className="w-6 h-6 text-emerald-400" />
                  </motion.div>
                  <h1 className="text-xl sm:text-2xl tracking-tight mb-2" style={{ fontWeight: 700 }}>{t("onb.trialTitle")}</h1>
                  <p className="text-zinc-500 text-sm max-w-sm mx-auto">{t("onb.trialSub")}</p>
                </div>

                {/* Selected plan summary */}
                {form.strategy && (() => {
                  const s = strategies.find((x) => x.id === form.strategy);
                  if (!s) return null;
                  return (
                    <div className={`p-4 rounded-xl border ${s.border} bg-gradient-to-r ${s.gradient}`}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <s.icon className={`w-4 h-4 ${s.iconColor}`} />
                          <span className="text-white text-sm" style={{ fontWeight: 600 }}>{s.name}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-white text-sm" style={{ fontWeight: 700 }}>{s.price}/mo</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 mt-2 text-xs text-zinc-400">
                        <span className="flex items-center gap-1"><Sparkles className="w-3 h-3" />{s.tokens} tokens</span>
                        <span className="flex items-center gap-1"><Globe className="w-3 h-3" />{s.channels}</span>
                      </div>
                    </div>
                  );
                })()}

                {/* Trial benefits */}
                <div className="space-y-2">
                  {[
                    { icon: Calendar, text: `${t("onb.trialInfo1")} $${PLAN_PRICES[form.strategy] || 59}/mo`, color: "text-emerald-400" },
                    { icon: Shield, text: t("onb.trialInfo2"), color: "text-cyan-400" },
                    { icon: Sparkles, text: t("onb.trialInfo3"), color: "text-purple-400" },
                  ].map((item, i) => (
                    <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 + i * 0.1 }}
                      className="flex items-center gap-3 p-3 rounded-xl bg-white/[0.02] border border-white/5">
                      <item.icon className={`w-4 h-4 ${item.color} shrink-0`} />
                      <span className="text-sm text-zinc-300">{item.text}</span>
                    </motion.div>
                  ))}
                </div>

                {/* Card form */}
                <div className="space-y-3">
                  <div>
                    <label className="text-xs text-zinc-500 mb-1.5 block">{t("onb.cardNumber")}</label>
                    <div className="relative">
                      <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                      <input value={cardNumber} onChange={(e) => setCardNumber(formatCardNum(e.target.value))}
                        placeholder="0000 0000 0000 0000" maxLength={19}
                        className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-[16px] sm:text-sm" />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs text-zinc-500 mb-1.5 block">{t("onb.expiry")}</label>
                      <input value={cardExpiry} onChange={(e) => setCardExpiry(formatExp(e.target.value))}
                        placeholder="MM / YY" maxLength={7}
                        className="w-full px-3 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-[16px] sm:text-sm" />
                    </div>
                    <div>
                      <label className="text-xs text-zinc-500 mb-1.5 block">{t("onb.cvc")}</label>
                      <input value={cardCvc} onChange={(e) => setCardCvc(e.target.value.replace(/\D/g, "").slice(0, 3))}
                        placeholder="000" maxLength={3}
                        className="w-full px-3 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-[16px] sm:text-sm" />
                    </div>
                    <div>
                      <label className="text-xs text-zinc-500 mb-1.5 block">{t("onb.cardHolder")}</label>
                      <input value={cardHolder} onChange={(e) => setCardHolder(e.target.value)}
                        placeholder="John Doe"
                        className="w-full px-3 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-zinc-600 focus:border-purple-500/50 focus:outline-none transition-colors text-[16px] sm:text-sm" />
                    </div>
                  </div>
                </div>

                {/* Security */}
                <div className="flex items-center gap-2 text-[11px] text-zinc-600">
                  <Shield className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  {t("purchase.securePayment")}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* ─── Bottom navigation ─── */}
      <div className="relative z-10 shrink-0 bg-[var(--app-bg-90)] backdrop-blur-md border-t border-white/5 px-4 sm:px-6 py-3 sm:py-4" style={{ paddingBottom: "max(12px, env(safe-area-inset-bottom))" }}>
        <div className="max-w-lg mx-auto">
          <div className="flex items-center justify-between gap-3">
            {/* Back button */}
            <button onClick={goBack} disabled={step === 0}
              className={`flex items-center gap-1.5 text-sm py-3 px-4 rounded-xl transition-all ${step === 0 ? "text-zinc-700 cursor-not-allowed" : "text-zinc-400 hover:text-zinc-200 active:bg-white/5"}`}>
              <ArrowLeft className="w-4 h-4" /><span className="hidden sm:inline">{t("onb.back")}</span>
            </button>

            <div className="flex items-center gap-2">
              {/* Skip (hidden on payment step) */}
              {step !== 4 && (
                <button onClick={step < 3 ? goNext : skipToDashboard}
                  className="text-xs text-zinc-600 hover:text-zinc-400 transition-colors px-3 py-3 rounded-xl hover:bg-white/[0.03] flex items-center gap-1.5">
                  <SkipForward className="w-3.5 h-3.5" /><span className="hidden sm:inline">{t("onb.skip")}</span>
                </button>
              )}

              {/* Continue button (big, easy to tap) */}
              <motion.button whileTap={{ scale: 0.95 }} onClick={goNext} disabled={isActivating}
                className={`inline-flex items-center gap-2 text-white px-6 sm:px-8 py-3 sm:py-3.5 rounded-xl text-sm transition-all shadow-lg disabled:opacity-60 ${
                  step === 4
                    ? "bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 shadow-emerald-500/20"
                    : step === 3 && form.strategy
                    ? "bg-gradient-to-r from-emerald-600 to-purple-600 hover:from-emerald-500 hover:to-purple-500 shadow-emerald-500/20"
                    : "bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 shadow-purple-500/20"
                }`}>
                {step === 4 ? (
                  isActivating
                    ? <><motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}><Sparkles className="w-4 h-4" /></motion.div>{t("onb.activating")}</>
                    : <><CreditCard className="w-4 h-4" />{t("onb.activateTrial")}</>
                ) : step < 3 ? (
                  <>{t("onb.continue")}<ArrowRight className="w-4 h-4" /></>
                ) : form.strategy ? (
                  <><Zap className="w-4 h-4" />{t("onb.proceedToPayment")}<ArrowRight className="w-4 h-4" /></>
                ) : (
                  <><Sparkles className="w-4 h-4" />{t("onb.startLaunching")}</>
                )}
              </motion.button>
            </div>
          </div>

          {/* Skip all (only from step 1+, hidden on payment step) */}
          {step > 0 && step !== 4 && (
            <div className="text-center mt-2">
              <button onClick={skipToDashboard} className="text-xs text-zinc-600 hover:text-purple-400 transition-colors flex items-center gap-1 mx-auto">
                <SkipForward className="w-3 h-3" />{t("onb.skipAll")}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Confetti */}
      <AnimatePresence>
        {showConfetti && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 z-[100] flex items-center justify-center bg-[var(--app-bg-80)] backdrop-blur-sm">
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              {Array.from({ length: 40 }).map((_, i) => <ConfettiParticle key={i} delay={Math.random() * 0.5} x={(Math.random() - 0.5) * 600} />)}
            </div>
            <motion.div initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: "spring", stiffness: 200, delay: 0.2 }} className="text-center relative z-10 px-6">
              <motion.div animate={{ rotate: [0, 10, -10, 0] }} transition={{ duration: 0.5, delay: 0.4 }} className="mb-6 flex justify-center"><Rocket className="w-16 h-16 text-purple-400" /></motion.div>
              <h2 className="text-2xl sm:text-3xl tracking-tight mb-3" style={{ fontWeight: 700 }}>{t("onb.allSet")}</h2>
              <p className="text-zinc-400 text-sm mb-2 max-w-sm mx-auto">
                {step === 4 || (form.strategy && step >= 3)
                  ? (t("onb.trialActivatedSub"))
                  : t("onb.allSetSub")
                }
              </p>
              <TypingDots />
              <p className="text-xs text-zinc-600 mt-2">{t("onb.redirecting")}</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}