import { useState, useEffect, useMemo, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Eye, Users, TrendingUp, MousePointerClick, MessageSquare, Target, ArrowUpRight, ArrowDownRight, Rocket, BarChart3, Repeat, Trophy, Download, FileText, FileSpreadsheet, Sparkles, Lightbulb, Clock, Copy, Check, ChevronRight } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, LineChart, Line } from "recharts";
import { useI18n } from "./i18n";
import { CountUp } from "./CountUp";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { StatsSkeleton, ChartSkeleton, RadarChartSkeleton, BarChartSkeleton } from "./PageSkeleton";
import { usePullToRefresh } from "./usePullToRefresh";
import { PullToRefreshIndicator } from "./PullToRefreshIndicator";
import { loadProgress } from "./user-progress";
import { useNavigate } from "react-router";
import { WhyBlock } from "./WhyBlock";
import { VideoTutorial } from "./VideoTutorial";
import { MetricTooltip } from "./MetricTooltip";
import { toast } from "sonner";
import jsPDF from "jspdf";

const timelineData = [
  { date: "Mar 1", reach: 120, clicks: 45, engagement: 23 },
  { date: "Mar 2", reach: 450, clicks: 128, engagement: 67 },
  { date: "Mar 3", reach: 890, clicks: 234, engagement: 112 },
  { date: "Mar 4", reach: 1420, clicks: 412, engagement: 198 },
  { date: "Mar 5", reach: 2100, clicks: 567, engagement: 245 },
  { date: "Mar 6", reach: 3200, clicks: 789, engagement: 378 },
  { date: "Mar 7", reach: 4800, clicks: 1023, engagement: 456 },
];
const platformComparison = [
  { platform: "Reddit", reach: 12400, clicks: 890, engagement: 234 },
  { platform: "Twitter", reach: 8900, clicks: 567, engagement: 189 },
  { platform: "LinkedIn", reach: 5600, clicks: 345, engagement: 123 },
  { platform: "PH", reach: 3200, clicks: 456, engagement: 178 },
  { platform: "Forums", reach: 2100, clicks: 234, engagement: 89 },
];
const engagementRadar = [
  { subject: "Upvotes", A: 85 }, { subject: "Comments", A: 72 }, { subject: "Shares", A: 58 },
  { subject: "Clicks", A: 90 }, { subject: "Saves", A: 45 }, { subject: "Follows", A: 62 },
];

const colorMap: Record<string, string> = {
  purple: "bg-purple-500/10 text-purple-400", cyan: "bg-cyan-500/10 text-cyan-400",
  emerald: "bg-emerald-500/10 text-emerald-400", amber: "bg-amber-500/10 text-amber-400",
  rose: "bg-rose-500/10 text-rose-400", violet: "bg-violet-500/10 text-violet-400",
};

export function AnalyticsDashboard() {
  const { t } = useI18n();
  useDocumentTitle(t("sidebar.analytics"));
  const [loading, setLoading] = useState(true);
  const [showDetailedCharts, setShowDetailedCharts] = useState(false);
  const progress = loadProgress();
  const navigate = useNavigate();

  const { pullY, isRefreshing, handlers: pullHandlers } = usePullToRefresh(
    () => new Promise<void>((resolve) => setTimeout(resolve, 1200))
  );

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 700);
    return () => clearTimeout(timer);
  }, []);

  const metrics = [
    { id: "reach", icon: Eye, label: t("analytics.totalReach"), value: "32.2K", change: "+18.4%", up: true, color: "purple", tip: t("analytics.tipReach") },
    { id: "eng", icon: Users, label: t("analytics.communityEng"), value: "1,813", change: "+24.1%", up: true, color: "cyan", tip: t("analytics.tipEng") },
    { id: "traffic", icon: TrendingUp, label: t("analytics.trafficGen"), value: "4,823", change: "+31.2%", up: true, color: "emerald", tip: t("analytics.tipTraffic") },
    { id: "click", icon: MousePointerClick, label: t("analytics.clickRate"), value: "3.8%", change: "+0.6%", up: true, color: "amber", tip: t("analytics.tipClick") },
    { id: "mentions", icon: MessageSquare, label: t("analytics.mentions"), value: "89", change: "+12", up: true, color: "rose", tip: t("analytics.tipMentions") },
    { id: "conv", icon: Target, label: t("analytics.convSignals"), value: "142", change: "-3.2%", up: false, color: "violet", tip: t("analytics.tipConv") },
  ];

  if (loading) {
    return (
      <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-4 sm:space-y-6">
        <LargeTitle title={t("analytics.title")} subtitle={t("analytics.subtitle")} />
        <StatsSkeleton count={6} />
        <div className="grid lg:grid-cols-3 gap-6">
          <ChartSkeleton className="lg:col-span-2" />
          <RadarChartSkeleton />
        </div>
        <BarChartSkeleton bars={8} height={240} />
      </div>
    );
  }

  // Guide user if they haven't launched yet
  if (!progress.launched) {
    return (
      <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6">
        <LargeTitle title={t("analytics.title")} subtitle={t("analytics.subtitle")} />
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-8 sm:p-12 rounded-2xl border border-dashed border-white/5 bg-white/[0.01] flex flex-col items-center justify-center text-center"
        >
          <div className="w-16 h-16 rounded-2xl bg-purple-500/10 border border-purple-500/10 flex items-center justify-center mb-4">
            <BarChart3 className="w-7 h-7 text-purple-500/40" />
          </div>
          <h3 className="text-zinc-400 text-sm" style={{ fontWeight: 600 }}>
            {t("analytics.emptyTitle")}
          </h3>
          <p className="text-xs text-zinc-600 mt-1 max-w-sm">
            {t("analytics.emptyDesc")}
          </p>
          <button
            onClick={() => navigate(progress.projectCreated ? "/dashboard/launch" : "/dashboard/new-project")}
            className="mt-5 inline-flex items-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white px-5 py-2.5 rounded-xl text-sm transition-all shadow-lg shadow-purple-500/20"
          >
            <Rocket className="w-4 h-4" />
            {progress.projectCreated
              ? t("analytics.goToLaunch")
              : t("analytics.createProject")}
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-4 sm:space-y-6" {...pullHandlers}>
      <PullToRefreshIndicator pullY={pullY} isRefreshing={isRefreshing} />
      <LargeTitle title={t("analytics.title")} subtitle={t("analytics.subtitle")} />

      {/* ROI Dashboard link */}
      <button
        onClick={() => navigate("/dashboard/roi-dashboard")}
        className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-emerald-500/20 bg-emerald-500/[0.04] hover:bg-emerald-500/[0.08] text-sm text-emerald-400 transition-all"
        style={{ fontWeight: 500 }}
      >
        <Target className="w-4 h-4" />
        {t("sidebar.roi")} Dashboard — Revenue Attribution & Funnels
        <ArrowUpRight className="w-3.5 h-3.5 ml-1" />
      </button>

      {/* Beginner explanation */}
      <WhyBlock label={t("analytics.whyLabel")} color="purple" variant="collapsible">
        {t("analytics.whyExplain")}
      </WhyBlock>

      {/* Video tutorial */}
      <VideoTutorial title={t("analytics.videoTitle")} duration="2 min" />

      {/* ─── Narrative Analytics: Story-like summary ─── */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden p-5 sm:p-6 rounded-2xl border border-purple-500/15 bg-gradient-to-br from-purple-500/[0.06] via-transparent to-cyan-500/[0.04]"
      >
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-purple-400/30 to-transparent" />
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center">
            <TrendingUp className="w-4 h-4 text-purple-400" />
          </div>
          <div>
            <h3 className="text-white" style={{ fontWeight: 600 }}>{t("narrative.weekSummary")}</h3>
          </div>
          <div className="ml-auto px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/15">
            <span className="text-[11px] text-emerald-400" style={{ fontWeight: 600 }}>{t("narrative.great")}</span>
          </div>
        </div>

        <div className="space-y-3">
          {/* People saw */}
          <div className="flex items-start gap-3 p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]">
            <div className="w-7 h-7 rounded-lg bg-purple-500/10 flex items-center justify-center shrink-0 mt-0.5">
              <Eye className="w-3.5 h-3.5 text-purple-400" />
            </div>
            <div>
              <p className="text-sm text-white">{t("narrative.peopleSaw").replace("{count}", "32,200")}</p>
              <p className="text-xs text-emerald-400 mt-0.5">{t("narrative.peopleSawCompare").replace("{pct}", "18")}</p>
            </div>
          </div>

          {/* People clicked */}
          <div className="flex items-start gap-3 p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]">
            <div className="w-7 h-7 rounded-lg bg-cyan-500/10 flex items-center justify-center shrink-0 mt-0.5">
              <MousePointerClick className="w-3.5 h-3.5 text-cyan-400" />
            </div>
            <div>
              <p className="text-sm text-white">{t("narrative.peopleClicked").replace("{count}", "4,823")}</p>
              <p className="text-xs text-zinc-500 mt-0.5">3.8% click rate</p>
            </div>
          </div>

          {/* Engagement */}
          <div className="flex items-start gap-3 p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 flex items-center justify-center shrink-0 mt-0.5">
              <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div>
              <p className="text-sm text-white">{t("narrative.peopleEngaged").replace("{count}", "1,813")}</p>
            </div>
          </div>

          {/* Best platform */}
          <div className="flex items-start gap-3 p-3 rounded-xl bg-amber-500/[0.04] border border-amber-500/10">
            <div className="w-7 h-7 rounded-lg bg-amber-500/10 flex items-center justify-center shrink-0 mt-0.5">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <div>
              <p className="text-sm text-white">{t("narrative.bestPlatform")} <span className="text-amber-400" style={{ fontWeight: 600 }}>Reddit</span> (12,400 reach)</p>
            </div>
          </div>

          {/* Recommendation */}
          <div className="flex items-start gap-3 p-4 rounded-xl bg-violet-500/[0.05] border border-violet-500/15">
            <div className="w-7 h-7 rounded-lg bg-violet-500/10 flex items-center justify-center shrink-0 mt-0.5">
              <Lightbulb className="w-3.5 h-3.5 text-violet-400" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-violet-300 uppercase tracking-wider mb-1" style={{ fontWeight: 600 }}>{t("narrative.recommendation")}</p>
              <p className="text-sm text-zinc-300">{t("narrative.recAddLinkedIn")}</p>
              <button
                onClick={() => navigate("/dashboard/content-plan")}
                className="mt-2.5 inline-flex items-center gap-1.5 text-xs text-violet-400 hover:text-violet-300 px-3 py-1.5 rounded-lg bg-violet-500/10 hover:bg-violet-500/15 transition-all"
              >
                <Sparkles className="w-3 h-3" />
                {t("narrative.actionBtn")}
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>

        {/* Toggle detailed charts */}
        <button
          type="button"
          onClick={() => setShowDetailedCharts((prev) => !prev)}
          className="mt-4 w-full flex items-center justify-center gap-1.5 text-xs text-zinc-500 hover:text-zinc-400 py-2 rounded-xl border border-white/[0.04] hover:border-white/[0.08] bg-white/[0.01] transition-all"
        >
          {showDetailedCharts ? t("narrative.hideDetails") : t("narrative.showDetails")}
          <ChevronRight className={`w-3 h-3 transition-transform ${showDetailedCharts ? "rotate-90" : ""}`} />
        </button>
      </motion.div>

      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {metrics.map((m, i) => (
          <motion.div key={m.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="p-4 rounded-xl border border-white/5 bg-white/[0.02]">
            <div className="flex items-center justify-between mb-3">
              <div className={`w-8 h-8 rounded-lg ${colorMap[m.color]} flex items-center justify-center`}><m.icon className="w-4 h-4" /></div>
              <MetricTooltip text={m.tip} color={m.color as any} />
            </div>
            <div className="text-xl text-white" style={{ fontWeight: 700 }}><CountUp value={m.value} /></div>
            <div className="text-xs text-zinc-500 mt-0.5">{m.label}</div>
            <div className={`text-xs mt-1 flex items-center gap-0.5 ${m.up ? "text-emerald-400" : "text-rose-400"}`}>{m.up ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}{m.change}</div>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
      {showDetailedCharts && (
      <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
      <div className="grid lg:grid-cols-3 gap-6">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="lg:col-span-2 p-6 rounded-xl border border-white/5 bg-white/[0.02]">
          <h3 className="text-white mb-1" style={{ fontWeight: 600 }}>{t("analytics.trafficTimeline")}</h3>
          <p className="text-xs text-zinc-500 mb-6">{t("analytics.trafficTimelineSub")}</p>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={timelineData}>
              <defs>
                <linearGradient id="gReach" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.3} /><stop offset="100%" stopColor="#8b5cf6" stopOpacity={0} /></linearGradient>
                <linearGradient id="gClicks" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#06b6d4" stopOpacity={0.3} /><stop offset="100%" stopColor="#06b6d4" stopOpacity={0} /></linearGradient>
                <linearGradient id="gEng" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#10b981" stopOpacity={0.3} /><stop offset="100%" stopColor="#10b981" stopOpacity={0} /></linearGradient>
              </defs>
              <CartesianGrid key="grid" stroke="rgba(255,255,255,0.03)" strokeDasharray="3 3" />
              <XAxis key="xaxis" dataKey="date" axisLine={false} tickLine={false} tick={{ fill: "#52525b", fontSize: 12 }} />
              <YAxis key="yaxis" axisLine={false} tickLine={false} tick={{ fill: "#52525b", fontSize: 12 }} />
              <Tooltip key="tooltip" contentStyle={{ background: "#18181b", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", fontSize: "12px" }} />
              <Area key="area-reach" type="monotone" dataKey="reach" stroke="#8b5cf6" fill="url(#gReach)" strokeWidth={2} />
              <Area key="area-clicks" type="monotone" dataKey="clicks" stroke="#06b6d4" fill="url(#gClicks)" strokeWidth={2} />
              <Area key="area-engagement" type="monotone" dataKey="engagement" stroke="#10b981" fill="url(#gEng)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
          <div className="flex items-center gap-6 mt-4 text-xs">
            <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-purple-500" /><span className="text-zinc-500">{t("analytics.reach")}</span></div>
            <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-cyan-500" /><span className="text-zinc-500">{t("analytics.clicks")}</span></div>
            <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-emerald-500" /><span className="text-zinc-500">{t("analytics.engagement")}</span></div>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="p-6 rounded-xl border border-white/5 bg-white/[0.02]">
          <h3 className="text-white mb-1" style={{ fontWeight: 600 }}>{t("analytics.engHeatmap")}</h3>
          <p className="text-xs text-zinc-500 mb-6">{t("analytics.engHeatmapSub")}</p>
          <ResponsiveContainer width="100%" height={280}>
            <RadarChart data={engagementRadar}>
              <PolarGrid key="polar-grid" stroke="rgba(255,255,255,0.06)" />
              <PolarAngleAxis key="polar-angle" dataKey="subject" tick={{ fill: "#71717a", fontSize: 11 }} />
              <PolarRadiusAxis key="polar-radius" tick={false} axisLine={false} />
              <Radar key="radar-a" dataKey="A" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.15} strokeWidth={2} />
            </RadarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="p-6 rounded-xl border border-white/5 bg-white/[0.02]">
        <h3 className="text-white mb-1" style={{ fontWeight: 600 }}>{t("analytics.platformPerf")}</h3>
        <p className="text-xs text-zinc-500 mb-6">{t("analytics.platformPerfSub")}</p>
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={platformComparison}>
            <CartesianGrid key="bar-grid" stroke="rgba(255,255,255,0.03)" strokeDasharray="3 3" />
            <XAxis key="bar-xaxis" dataKey="platform" axisLine={false} tickLine={false} tick={{ fill: "#a1a1aa", fontSize: 12 }} />
            <YAxis key="bar-yaxis" axisLine={false} tickLine={false} tick={{ fill: "#52525b", fontSize: 12 }} />
            <Tooltip key="bar-tooltip" contentStyle={{ background: "#18181b", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", fontSize: "12px" }} />
            <Bar key="bar-reach" dataKey="reach" fill="#8b5cf6" radius={[4, 4, 0, 0]} barSize={16} name={t("analytics.reach")} />
            <Bar key="bar-clicks" dataKey="clicks" fill="#06b6d4" radius={[4, 4, 0, 0]} barSize={16} name={t("analytics.clicks")} />
            <Bar key="bar-engagement" dataKey="engagement" fill="#10b981" radius={[4, 4, 0, 0]} barSize={16} name={t("analytics.engagement")} />
          </BarChart>
        </ResponsiveContainer>
      </motion.div>
      </motion.div>
      )}
      </AnimatePresence>

      {/* ─── A/B Test Results ─── */}
      {showDetailedCharts && <ABTestResultsSection t={t} />}
    </div>
  );
}

/* ═══ A/B Test Results integrated from Content Plan ═══ */
interface ABTest { a: string; b: string; aClicks: number; bClicks: number }
type ABTab = "results" | "timeline" | "ai";

/* Mock weekly history data generator */
function generateWeeklyHistory(entries: [string, ABTest][]): { week: string; convA: number; convB: number; lift: number }[] {
  const weeks = ["W1", "W2", "W3", "W4", "W5", "W6"];
  return weeks.map((w, i) => {
    const base = 2.2 + i * 0.4;
    const aConv = +(base + Math.sin(i * 1.2) * 0.8 + Math.random() * 0.5).toFixed(1);
    const bConv = +(base + 0.3 + Math.cos(i * 0.9) * 0.6 + Math.random() * 0.5).toFixed(1);
    return { week: w, convA: aConv, convB: bConv, lift: +((Math.abs(bConv - aConv) / Math.min(aConv, bConv)) * 100).toFixed(1) };
  });
}

/* AI headline recommendation patterns */
const AI_PATTERNS = [
  { type: "numbers", en: "Add specific numbers", ru: "Добавить конкретные числа", transform: (h: string) => h.replace(/many|several|some/gi, "47").replace(/fast|quick/gi, "3x faster") },
  { type: "question", en: "Convert to question", ru: "Переформулировать как вопрос", transform: (h: string) => `What if ${h.toLowerCase().replace(/^(we |our |the )/i, "you could ")}?` },
  { type: "urgency", en: "Add urgency", ru: "Добавить срочность", transform: (h: string) => `${h} (limited spots available)` },
  { type: "social_proof", en: "Add social proof", ru: "Добавить соц. доказательство", transform: (h: string) => `Join 2,000+ teams using ${h.split(" ").slice(-2).join(" ")}` },
  { type: "benefit", en: "Lead with benefit", ru: "Начать с выгоды", transform: (h: string) => `Save 15 hours/week — ${h}` },
  { type: "contrast", en: "Before/After contrast", ru: "Контраст до/после", transform: (h: string) => `From manual chaos to autopilot: ${h}` },
  { type: "curiosity", en: "Curiosity gap", ru: "Разрыв любопытства", transform: (h: string) => `The surprising reason why ${h.toLowerCase()}` },
  { type: "power_word", en: "Power words", ru: "Усилить формулировку", transform: (h: string) => h.replace(/good|nice|great/gi, "revolutionary").replace(/help|assist/gi, "supercharge") },
];

function ABTestResultsSection({ t }: { t: (k: string) => string }) {
  const [abTests, setAbTests] = useState<Record<string, ABTest>>({});
  const [activeTab, setActiveTab] = useState<ABTab>("results");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiRecs, setAiRecs] = useState<{ testId: string; original: string; suggestions: { label: string; text: string; score: number }[] }[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    const load = () => {
      try {
        const raw = localStorage.getItem("launchapp_ab_tests");
        if (raw) setAbTests(JSON.parse(raw));
      } catch {}
    };
    load();
    const handler = () => load();
    window.addEventListener("storage", handler);
    const interval = setInterval(load, 3000);
    return () => { window.removeEventListener("storage", handler); clearInterval(interval); };
  }, []);

  const entries = useMemo(() => Object.entries(abTests), [abTests]);
  const weeklyData = useMemo(() => generateWeeklyHistory(entries), [entries]);

  const totalA = entries.reduce((s, [, v]) => s + v.aClicks, 0);
  const totalB = entries.reduce((s, [, v]) => s + v.bClicks, 0);
  const avgLift = entries.length > 0 ? entries.reduce((s, [, v]) => {
    const mn = Math.min(v.aClicks, v.bClicks);
    return s + (mn > 0 ? ((Math.max(v.aClicks, v.bClicks) - mn) / mn) * 100 : 0);
  }, 0) / entries.length : 0;

  /* ── Export CSV ── */
  const exportCSV = useCallback(() => {
    const header = "Test ID,Variant A,Variant B,A Clicks,B Clicks,Winner,Lift %\n";
    const rows = entries.map(([id, test]) => {
      const aW = test.aClicks >= test.bClicks;
      const mn = Math.min(test.aClicks, test.bClicks);
      const lift = mn > 0 ? ((Math.max(test.aClicks, test.bClicks) - mn) / mn * 100).toFixed(1) : "0";
      return `"${id}","${test.a.replace(/"/g, '""')}","${test.b.replace(/"/g, '""')}",${test.aClicks},${test.bClicks},${aW ? "A" : "B"},${lift}`;
    }).join("\n");
    const blob = new Blob([header + rows], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `ab-test-results-${new Date().toISOString().split("T")[0]}.csv`;
    a.click(); URL.revokeObjectURL(url);
    toast.success(t("analytics.abExportCSVDone"));
  }, [entries, t]);

  /* ── Export PDF ── */
  const exportPDF = useCallback(() => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text("A/B Test Results — Launch OS", 14, 20);
    doc.setFontSize(10);
    doc.setTextColor(120);
    doc.text(`Generated: ${new Date().toLocaleDateString()} · ${entries.length} tests · Avg lift: ${avgLift.toFixed(1)}%`, 14, 28);
    let y = 40;
    entries.forEach(([id, test], i) => {
      if (y > 260) { doc.addPage(); y = 20; }
      const aW = test.aClicks >= test.bClicks;
      const mn = Math.min(test.aClicks, test.bClicks);
      const lift = mn > 0 ? ((Math.max(test.aClicks, test.bClicks) - mn) / mn * 100).toFixed(1) : "0";
      doc.setFontSize(11); doc.setTextColor(40);
      doc.text(`Test #${i + 1}`, 14, y);
      doc.setFontSize(9); doc.setTextColor(80);
      doc.text(`Winner: Variant ${aW ? "A" : "B"} · Lift: +${lift}%`, 50, y);
      y += 7;
      doc.setTextColor(60);
      const aLines = doc.splitTextToSize(`[A] ${test.a}`, 170);
      doc.text(aLines, 18, y); y += aLines.length * 4.5;
      const bLines = doc.splitTextToSize(`[B] ${test.b}`, 170);
      doc.text(bLines, 18, y); y += bLines.length * 4.5;
      doc.text(`Clicks: A=${test.aClicks}, B=${test.bClicks}`, 18, y);
      y += 10;
    });
    doc.save(`ab-test-results-${new Date().toISOString().split("T")[0]}.pdf`);
    toast.success(t("analytics.abExportPDFDone"));
  }, [entries, avgLift, t]);

  /* ── AI recommendations ── */
  const generateAIRecs = useCallback(() => {
    setAiLoading(true);
    setTimeout(() => {
      const recs = entries.map(([id, test]) => {
        const winner = test.aClicks >= test.bClicks ? test.a : test.b;
        const shuffled = [...AI_PATTERNS].sort(() => Math.random() - 0.5).slice(0, 4);
        const suggestions = shuffled.map((p) => ({
          label: p.en,
          text: p.transform(winner),
          score: +(70 + Math.random() * 25).toFixed(0),
        }));
        suggestions.sort((a, b) => b.score - a.score);
        return { testId: id, original: winner, suggestions };
      });
      setAiRecs(recs);
      setAiLoading(false);
      toast.success(t("analytics.abAIDone"));
    }, 1800);
  }, [entries, t]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    toast.success("Copied!");
    setTimeout(() => setCopiedId(null), 2000);
  };

  /* ── Empty state ── */
  if (entries.length === 0) {
    return (
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}
        className="p-6 rounded-xl border border-dashed border-white/5 bg-white/[0.01]"
      >
        <div className="flex items-center gap-3 mb-2">
          <div className="w-9 h-9 rounded-xl bg-orange-500/10 flex items-center justify-center">
            <Repeat className="w-4 h-4 text-orange-400" />
          </div>
          <div>
            <h3 className="text-white text-sm" style={{ fontWeight: 600 }}>{t("analytics.abTestTitle")}</h3>
            <p className="text-xs text-zinc-500">{t("analytics.abTestEmpty")}</p>
          </div>
        </div>
      </motion.div>
    );
  }

  const tabs: { id: ABTab; label: string; icon: typeof Repeat }[] = [
    { id: "results", label: t("analytics.abTabResults"), icon: Trophy },
    { id: "timeline", label: t("analytics.abTabTimeline"), icon: Clock },
    { id: "ai", label: t("analytics.abTabAI"), icon: Sparkles },
  ];

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}
      className="rounded-xl border border-white/5 bg-white/[0.02] overflow-hidden"
    >
      {/* Header */}
      <div className="px-5 pt-5 pb-0">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-orange-500/10 flex items-center justify-center">
              <Repeat className="w-4 h-4 text-orange-400" />
            </div>
            <div>
              <h3 className="text-white text-sm" style={{ fontWeight: 600 }}>{t("analytics.abTestTitle")}</h3>
              <p className="text-xs text-zinc-500">{entries.length} {t("analytics.abTestActive")} · {t("analytics.abTestAvgLift")} {avgLift.toFixed(1)}%</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={exportCSV} className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-white/5 bg-white/[0.02] hover:bg-white/[0.06] text-[11px] text-zinc-400 transition-all" title="Export CSV">
              <FileSpreadsheet className="w-3 h-3" /> CSV
            </button>
            <button onClick={exportPDF} className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-white/5 bg-white/[0.02] hover:bg-white/[0.06] text-[11px] text-zinc-400 transition-all" title="Export PDF">
              <FileText className="w-3 h-3" /> PDF
            </button>
            <div className="text-center ml-2">
              <div className="text-sm text-white" style={{ fontWeight: 700 }}>{totalA + totalB}</div>
              <div className="text-[10px] text-zinc-600">{t("analytics.abTestTotalClicks")}</div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 border-b border-white/5 -mx-5 px-5">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`inline-flex items-center gap-1.5 px-3 py-2.5 text-xs transition-all border-b-2 -mb-px ${activeTab === tab.id ? "border-orange-500 text-white" : "border-transparent text-zinc-500 hover:text-zinc-300"}`}
              style={{ fontWeight: activeTab === tab.id ? 600 : 400 }}
            >
              <tab.icon className="w-3 h-3" /> {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab content */}
      <div className="p-5">
        <AnimatePresence mode="wait">
          {/* ── Results tab ── */}
          {activeTab === "results" && (
            <motion.div key="results" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="space-y-3">
              {entries.map(([id, test]) => {
                const aWins = test.aClicks >= test.bClicks;
                const mn = Math.min(test.aClicks, test.bClicks);
                const lift = mn > 0 ? ((Math.max(test.aClicks, test.bClicks) - mn) / mn * 100) : 0;
                const total = test.aClicks + test.bClicks;
                const aPct = total > 0 ? (test.aClicks / total) * 100 : 50;
                const confidence = Math.min(95, 50 + Math.abs(test.aClicks - test.bClicks) * 2);
                return (
                  <div key={id} className="p-3 rounded-xl bg-white/[0.02] border border-white/5">
                    <div className="grid grid-cols-2 gap-3 mb-2">
                      <div className={`p-2.5 rounded-lg border ${aWins ? "border-emerald-500/20 bg-emerald-500/[0.04]" : "border-white/5 bg-white/[0.01]"}`}>
                        <div className="flex items-center gap-1.5 mb-1">
                          <span className={`text-[10px] px-1.5 py-0.5 rounded ${aWins ? "bg-emerald-500/20 text-emerald-400" : "bg-white/5 text-zinc-500"}`} style={{ fontWeight: 600 }}>A{aWins ? " W" : ""}</span>
                          <span className="text-xs text-zinc-400" style={{ fontWeight: 600 }}>{test.aClicks} clicks</span>
                        </div>
                        <p className="text-xs text-zinc-300 line-clamp-2">{test.a}</p>
                      </div>
                      <div className={`p-2.5 rounded-lg border ${!aWins ? "border-emerald-500/20 bg-emerald-500/[0.04]" : "border-white/5 bg-white/[0.01]"}`}>
                        <div className="flex items-center gap-1.5 mb-1">
                          <span className={`text-[10px] px-1.5 py-0.5 rounded ${!aWins ? "bg-emerald-500/20 text-emerald-400" : "bg-white/5 text-zinc-500"}`} style={{ fontWeight: 600 }}>B{!aWins ? " W" : ""}</span>
                          <span className="text-xs text-zinc-400" style={{ fontWeight: 600 }}>{test.bClicks} clicks</span>
                        </div>
                        <p className="text-xs text-zinc-300 line-clamp-2">{test.b}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-2 rounded-full bg-white/5 overflow-hidden flex">
                        <div className={`h-full ${aWins ? "bg-emerald-500" : "bg-zinc-600"} transition-all`} style={{ width: `${aPct}%` }} />
                        <div className={`h-full ${!aWins ? "bg-emerald-500" : "bg-zinc-600"} transition-all`} style={{ width: `${100 - aPct}%` }} />
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <Trophy className="w-3 h-3 text-emerald-400" />
                        <span className="text-[10px] text-emerald-400" style={{ fontWeight: 600 }}>+{lift.toFixed(0)}%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/5">
                      <span className="text-[10px] text-zinc-600">{t("analytics.abConfidence")}: {confidence.toFixed(0)}%</span>
                      <span className="text-[10px] text-zinc-600">{t("analytics.abSampleSize")}: {total}</span>
                    </div>
                  </div>
                );
              })}
            </motion.div>
          )}

          {/* ── Timeline tab ── */}
          {activeTab === "timeline" && (
            <motion.div key="timeline" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
              <div className="mb-3">
                <h4 className="text-sm text-white" style={{ fontWeight: 600 }}>{t("analytics.abTimelineTitle")}</h4>
                <p className="text-xs text-zinc-500">{t("analytics.abTimelineSub")}</p>
              </div>
              <ResponsiveContainer width="100%" height={240}>
                <LineChart data={weeklyData}>
                  <defs>
                    <linearGradient id="gConvA" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#f97316" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="#f97316" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gConvB" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke="rgba(255,255,255,0.03)" strokeDasharray="3 3" />
                  <XAxis dataKey="week" axisLine={false} tickLine={false} tick={{ fill: "#52525b", fontSize: 11 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: "#52525b", fontSize: 11 }} unit="%" />
                  <Tooltip contentStyle={{ background: "#18181b", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", fontSize: "12px" }} formatter={(v: number) => `${v}%`} />
                  <Line type="monotone" dataKey="convA" stroke="#f97316" strokeWidth={2} dot={{ fill: "#f97316", r: 3 }} name="Variant A CTR" />
                  <Line type="monotone" dataKey="convB" stroke="#8b5cf6" strokeWidth={2} dot={{ fill: "#8b5cf6", r: 3 }} name="Variant B CTR" />
                </LineChart>
              </ResponsiveContainer>
              <div className="flex items-center gap-6 mt-3 text-xs">
                <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-orange-500" /><span className="text-zinc-500">Variant A CTR</span></div>
                <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-purple-500" /><span className="text-zinc-500">Variant B CTR</span></div>
              </div>

              {/* Lift over time */}
              <div className="mt-5 pt-4 border-t border-white/5">
                <h4 className="text-sm text-white mb-3" style={{ fontWeight: 600 }}>{t("analytics.abLiftOverTime")}</h4>
                <ResponsiveContainer width="100%" height={140}>
                  <BarChart data={weeklyData}>
                    <CartesianGrid stroke="rgba(255,255,255,0.03)" strokeDasharray="3 3" />
                    <XAxis dataKey="week" axisLine={false} tickLine={false} tick={{ fill: "#52525b", fontSize: 11 }} />
                    <YAxis axisLine={false} tickLine={false} tick={{ fill: "#52525b", fontSize: 11 }} unit="%" />
                    <Tooltip contentStyle={{ background: "#18181b", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", fontSize: "12px" }} formatter={(v: number) => `${v}%`} />
                    <Bar dataKey="lift" fill="#10b981" radius={[4, 4, 0, 0]} barSize={24} name="Lift %" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Weekly summary table */}
              <div className="mt-4 overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-white/5">
                      <th className="text-left py-2 text-zinc-500" style={{ fontWeight: 500 }}>{t("analytics.abWeek")}</th>
                      <th className="text-right py-2 text-zinc-500" style={{ fontWeight: 500 }}>A CTR</th>
                      <th className="text-right py-2 text-zinc-500" style={{ fontWeight: 500 }}>B CTR</th>
                      <th className="text-right py-2 text-zinc-500" style={{ fontWeight: 500 }}>Lift</th>
                      <th className="text-right py-2 text-zinc-500" style={{ fontWeight: 500 }}>{t("analytics.abWinner")}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {weeklyData.map((w) => (
                      <tr key={w.week} className="border-b border-white/[0.03]">
                        <td className="py-2 text-zinc-300">{w.week}</td>
                        <td className="py-2 text-right text-orange-400">{w.convA}%</td>
                        <td className="py-2 text-right text-purple-400">{w.convB}%</td>
                        <td className="py-2 text-right text-emerald-400">+{w.lift}%</td>
                        <td className="py-2 text-right">
                          <span className={`px-1.5 py-0.5 rounded text-[10px] ${w.convB > w.convA ? "bg-purple-500/15 text-purple-400" : "bg-orange-500/15 text-orange-400"}`} style={{ fontWeight: 600 }}>
                            {w.convB > w.convA ? "B" : "A"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {/* ── AI Insights tab ── */}
          {activeTab === "ai" && (
            <motion.div key="ai" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h4 className="text-sm text-white" style={{ fontWeight: 600 }}>{t("analytics.abAITitle")}</h4>
                  <p className="text-xs text-zinc-500">{t("analytics.abAISub")}</p>
                </div>
                <button
                  onClick={generateAIRecs}
                  disabled={aiLoading}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 disabled:opacity-50 text-white text-xs transition-all"
                  style={{ fontWeight: 500 }}
                >
                  {aiLoading ? (
                    <><motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}><Sparkles className="w-3 h-3" /></motion.div> {t("analytics.abAIGenerating")}</>
                  ) : (
                    <><Sparkles className="w-3 h-3" /> {t("analytics.abAIGenerate")}</>
                  )}
                </button>
              </div>

              {aiRecs.length === 0 && !aiLoading && (
                <div className="p-8 rounded-xl border border-dashed border-white/5 bg-white/[0.01] text-center">
                  <Lightbulb className="w-8 h-8 text-amber-500/30 mx-auto mb-3" />
                  <p className="text-xs text-zinc-500">{t("analytics.abAIEmptyHint")}</p>
                </div>
              )}

              {aiLoading && (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="p-4 rounded-xl bg-white/[0.02] border border-white/5 animate-pulse">
                      <div className="h-3 w-1/3 rounded bg-white/5 mb-3" />
                      <div className="space-y-2">
                        <div className="h-2.5 w-full rounded bg-white/[0.03]" />
                        <div className="h-2.5 w-2/3 rounded bg-white/[0.03]" />
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {!aiLoading && aiRecs.length > 0 && (
                <div className="space-y-4">
                  {aiRecs.map((rec) => (
                    <div key={rec.testId} className="p-4 rounded-xl bg-white/[0.02] border border-white/5">
                      <div className="flex items-center gap-2 mb-3">
                        <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
                        <span className="text-xs text-zinc-400" style={{ fontWeight: 500 }}>{t("analytics.abAIBased")}</span>
                      </div>
                      <p className="text-xs text-zinc-500 mb-3 pl-5">"{rec.original}"</p>
                      <div className="space-y-2">
                        {rec.suggestions.map((s, si) => (
                          <div key={si} className="flex items-start gap-2 p-2.5 rounded-lg bg-white/[0.02] border border-white/5 hover:bg-white/[0.04] transition-all group">
                            <div className="shrink-0 mt-0.5">
                              <div className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] ${s.score >= 85 ? "bg-emerald-500/15 text-emerald-400" : s.score >= 75 ? "bg-amber-500/15 text-amber-400" : "bg-zinc-500/15 text-zinc-400"}`} style={{ fontWeight: 700 }}>
                                {s.score}
                              </div>
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-[10px] text-zinc-500 mb-0.5" style={{ fontWeight: 500 }}>{s.label}</div>
                              <p className="text-xs text-zinc-200">{s.text}</p>
                            </div>
                            <button
                              onClick={() => copyToClipboard(s.text, `${rec.testId}-${si}`)}
                              className="shrink-0 p-1.5 rounded-lg hover:bg-white/5 text-zinc-600 hover:text-zinc-300 opacity-0 group-hover:opacity-100 transition-all"
                              title="Copy"
                            >
                              {copiedId === `${rec.testId}-${si}` ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                            </button>
                          </div>
                        ))}
                      </div>
                      <div className="mt-3 pt-2 border-t border-white/5 flex items-center gap-1.5 text-[10px] text-zinc-600">
                        <Sparkles className="w-3 h-3" /> {t("analytics.abAIDisclaimer")}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}