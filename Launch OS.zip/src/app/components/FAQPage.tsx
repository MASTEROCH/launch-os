import { useState, useMemo, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  HelpCircle, Search, ChevronDown, ChevronRight,
  Sparkles, Package, Compass, Zap, TrendingUp,
  Mail, MessageCircle, ArrowRight, ExternalLink,
  CalendarDays, BarChart3, Users, Map as MapIcon,
} from "lucide-react";
import { useNavigate } from "react-router";
import { useI18n } from "./i18n";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { toast } from "sonner";

/* ─── Types ─── */
interface FAQItem {
  id: string;
  qKey: string;
  aKey: string;
  category: string;
}

/* ─── Core Steps data (moved from Roadmap) ─── */
const CORE_STEPS = [
  { step: 1, labelKey: "sidebar.newProject", descKey: "roadmap.stepCreate", icon: Sparkles, color: "purple", path: "/dashboard/new-project" },
  { step: 2, labelKey: "sidebar.package", descKey: "roadmap.stepPackage", icon: Package, color: "violet", path: "/dashboard/package" },
  { step: 3, labelKey: "sidebar.growth", descKey: "roadmap.stepGrowth", icon: Compass, color: "cyan", path: "/dashboard/growth" },
  { step: 4, labelKey: "sidebar.launchEngine", descKey: "roadmap.stepLaunch", icon: Zap, color: "emerald", path: "/dashboard/launch" },
  { step: 5, labelKey: "sidebar.launchTracker", descKey: "roadmap.stepTrack", icon: TrendingUp, color: "amber", path: "/dashboard/tracker" },
];

const COLOR_MAP: Record<string, { bg: string; text: string; border: string }> = {
  purple: { bg: "bg-purple-500/10", text: "text-purple-400", border: "border-purple-500/15" },
  violet: { bg: "bg-violet-500/10", text: "text-violet-400", border: "border-violet-500/15" },
  cyan: { bg: "bg-cyan-500/10", text: "text-cyan-400", border: "border-cyan-500/15" },
  emerald: { bg: "bg-emerald-500/10", text: "text-emerald-400", border: "border-emerald-500/15" },
  amber: { bg: "bg-amber-500/10", text: "text-amber-400", border: "border-amber-500/15" },
};

const TOOL_LINKS = [
  { icon: CalendarDays, labelKey: "sidebar.contentPlan", descKey: "dash.coreLoop.toolContentPlanDesc", color: "purple", path: "/dashboard/content-plan" },
  { icon: BarChart3, labelKey: "sidebar.analytics", descKey: "dash.coreLoop.toolAnalyticsDesc", color: "cyan", path: "/dashboard/analytics" },
  { icon: Users, labelKey: "sidebar.community", descKey: "dash.coreLoop.toolCommunityDesc", color: "emerald", path: "/dashboard/community" },
];

/* ─── FAQ items ─── */
const FAQ_ITEMS: FAQItem[] = [
  { id: "1", qKey: "faq.q1", aKey: "faq.a1", category: "general" },
  { id: "2", qKey: "faq.q2", aKey: "faq.a2", category: "general" },
  { id: "3", qKey: "faq.q3", aKey: "faq.a3", category: "launch" },
  { id: "4", qKey: "faq.q4", aKey: "faq.a4", category: "launch" },
  { id: "5", qKey: "faq.q5", aKey: "faq.a5", category: "billing" },
  { id: "6", qKey: "faq.q6", aKey: "faq.a6", category: "tools" },
  { id: "7", qKey: "faq.q7", aKey: "faq.a7", category: "tools" },
  { id: "8", qKey: "faq.q8", aKey: "faq.a8", category: "billing" },
  { id: "9", qKey: "faq.q9", aKey: "faq.a9", category: "tools" },
  { id: "10", qKey: "faq.q10", aKey: "faq.a10", category: "general" },
  { id: "11", qKey: "faq.q11", aKey: "faq.a11", category: "tools" },
  { id: "12", qKey: "faq.q12", aKey: "faq.a12", category: "tools" },
  { id: "13", qKey: "faq.q13", aKey: "faq.a13", category: "launch" },
];

const CATEGORIES = ["all", "general", "launch", "billing", "tools"] as const;

export function FAQPage() {
  const navigate = useNavigate();
  const { t } = useI18n();
  useDocumentTitle(t("faq.title"));

  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [openIds, setOpenIds] = useState<Set<string>>(new Set());

  const toggleOpen = useCallback((id: string) => {
    setOpenIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }, []);

  const filteredFAQ = useMemo(() => {
    return FAQ_ITEMS.filter((item) => {
      if (activeCategory !== "all" && item.category !== activeCategory) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        const question = t(item.qKey).toLowerCase();
        const answer = t(item.aKey).toLowerCase();
        if (!question.includes(q) && !answer.includes(q)) return false;
      }
      return true;
    });
  }, [search, activeCategory, t]);

  const catLabels: Record<string, string> = {
    all: t("faq.cat.all"),
    general: t("faq.cat.general"),
    launch: t("faq.cat.launch"),
    billing: t("faq.cat.billing"),
    tools: t("faq.cat.tools"),
  };

  const handleContact = useCallback(() => {
    toast.success(t("faq.contactSent"));
  }, [t]);

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-8">
      <LargeTitle title={t("faq.title")} subtitle={t("faq.subtitle")} />

      {/* ═══ HOW LAUNCH OS WORKS (moved from Roadmap) ═══ */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative p-5 sm:p-6 rounded-2xl border border-purple-500/15 bg-gradient-to-br from-purple-500/[0.06] via-transparent to-cyan-500/[0.04] overflow-hidden"
      >
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-purple-400/30 to-transparent" />
        <div className="flex items-center gap-2 mb-5">
          <div className="w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center">
            <HelpCircle className="w-4 h-4 text-purple-400" />
          </div>
          <div>
            <h3 className="text-white" style={{ fontWeight: 600 }}>{t("faq.howTitle")}</h3>
            <p className="text-xs text-zinc-500">{t("faq.howDesc")}</p>
          </div>
        </div>

        {/* 5 Steps Visual Pipeline */}
        <div className="space-y-2">
          {CORE_STEPS.map((step, i) => {
            const c = COLOR_MAP[step.color];
            return (
              <motion.button
                key={step.step}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.07 }}
                onClick={() => navigate(step.path)}
                className="w-full flex items-center gap-3 p-3 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:border-white/[0.08] hover:bg-white/[0.04] transition-all group text-left"
              >
                <div className={`w-9 h-9 rounded-xl ${c.bg} flex items-center justify-center shrink-0`}>
                  <span className={`text-sm ${c.text}`} style={{ fontWeight: 700 }}>{step.step}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-white" style={{ fontWeight: 500 }}>{t(step.labelKey)}</p>
                  <p className="text-xs text-zinc-500">{t(step.descKey)}</p>
                </div>
                <step.icon className={`w-4 h-4 ${c.text} opacity-40 group-hover:opacity-100 transition-opacity shrink-0`} />
                {i < CORE_STEPS.length - 1 && (
                  <ArrowRight className="w-3 h-3 text-zinc-700 shrink-0 hidden sm:block" />
                )}
              </motion.button>
            );
          })}
        </div>

        {/* Arrow to Tools */}
        <div className="flex items-center gap-2 mt-4 ml-3">
          <div className="w-px h-4 bg-zinc-700" />
          <span className="text-[11px] text-zinc-500" style={{ fontWeight: 500 }}>{t("roadmap.thenTools")}</span>
          <ArrowRight className="w-3 h-3 text-zinc-600" />
        </div>

        {/* Current Tools */}
        <div className="grid sm:grid-cols-3 gap-2 mt-2">
          {TOOL_LINKS.map((tool) => {
            const c = COLOR_MAP[tool.color];
            return (
              <button
                key={tool.path}
                onClick={() => navigate(tool.path)}
                className={`flex items-center gap-2.5 p-3 rounded-xl border ${c.border} bg-white/[0.01] hover:bg-white/[0.04] transition-all text-left`}
              >
                <div className={`w-7 h-7 rounded-lg ${c.bg} flex items-center justify-center shrink-0`}>
                  <tool.icon className={`w-3.5 h-3.5 ${c.text}`} />
                </div>
                <div className="min-w-0">
                  <p className="text-xs text-white" style={{ fontWeight: 500 }}>{t(tool.labelKey)}</p>
                  <p className="text-[10px] text-zinc-600 truncate">{t(tool.descKey)}</p>
                </div>
              </button>
            );
          })}
        </div>
      </motion.div>

      {/* ═══ SEARCH & FILTERS ═══ */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t("faq.searchPlaceholder")}
            className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/[0.03] border border-white/5 text-sm text-white placeholder-zinc-600 focus:outline-none focus:border-purple-500/30 transition-colors"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${
                activeCategory === cat
                  ? "bg-purple-500/10 border-purple-500/20 text-purple-400"
                  : "border-white/5 text-zinc-500 hover:text-zinc-300 hover:bg-white/[0.03]"
              }`}
              style={{ fontWeight: activeCategory === cat ? 600 : 400 }}
            >
              {catLabels[cat]}
            </button>
          ))}
        </div>
      </div>

      {/* ═══ FAQ ACCORDION ═══ */}
      <div className="space-y-2">
        {filteredFAQ.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="p-8 rounded-2xl border border-white/5 bg-white/[0.02] text-center"
          >
            <HelpCircle className="w-10 h-10 text-zinc-700 mx-auto mb-3" />
            <p className="text-sm text-zinc-500">{t("faq.contactTitle")}</p>
            <button
              onClick={handleContact}
              className="mt-3 inline-flex items-center gap-1.5 text-sm text-purple-400 hover:text-purple-300 px-4 py-2 rounded-xl bg-purple-500/10 transition-all"
            >
              <Mail className="w-3.5 h-3.5" />
              {t("faq.contactBtn")}
            </button>
          </motion.div>
        ) : (
          filteredFAQ.map((item, i) => {
            const isOpen = openIds.has(item.id);
            const catColor =
              item.category === "general" ? "text-purple-400 bg-purple-500/10" :
              item.category === "launch" ? "text-cyan-400 bg-cyan-500/10" :
              item.category === "billing" ? "text-amber-400 bg-amber-500/10" :
              "text-emerald-400 bg-emerald-500/10";

            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.03 }}
                className={`rounded-xl border transition-all ${isOpen ? "border-purple-500/20 bg-purple-500/[0.03]" : "border-white/5 bg-white/[0.02] hover:border-white/10"}`}
              >
                <button
                  onClick={() => toggleOpen(item.id)}
                  className="w-full flex items-center gap-3 p-4 text-left"
                >
                  <div className="shrink-0">
                    {isOpen
                      ? <ChevronDown className="w-4 h-4 text-purple-400" />
                      : <ChevronRight className="w-4 h-4 text-zinc-600" />}
                  </div>
                  <span className="flex-1 text-sm text-white" style={{ fontWeight: 500 }}>
                    {t(item.qKey)}
                  </span>
                  <span className={`text-[9px] px-1.5 py-0.5 rounded-full shrink-0 ${catColor}`}>
                    {catLabels[item.category]}
                  </span>
                </button>
                <AnimatePresence>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden"
                    >
                      <div className="px-4 pb-4 pl-11">
                        <p className="text-sm text-zinc-400 leading-relaxed">{t(item.aKey)}</p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })
        )}
      </div>

      {/* ═══ CONTACT US BLOCK ═══ */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="relative p-6 rounded-2xl border border-white/5 bg-gradient-to-br from-purple-500/[0.04] via-transparent to-cyan-500/[0.03] overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center shrink-0">
            <MessageCircle className="w-5 h-5 text-purple-400" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-white" style={{ fontWeight: 600 }}>{t("faq.contactTitle")}</h3>
            <p className="text-xs text-zinc-500 mt-0.5">{t("faq.contactDesc")}</p>
          </div>
          <button
            onClick={handleContact}
            className="inline-flex items-center gap-2 bg-purple-600 hover:bg-purple-500 text-white px-5 py-2.5 rounded-xl text-sm transition-all active:scale-[0.97] shrink-0"
          >
            <Mail className="w-4 h-4" />
            {t("faq.contactBtn")}
            <ExternalLink className="w-3 h-3 opacity-50" />
          </button>
        </div>
      </motion.div>

      {/* ═══ LINK TO ROADMAP ═══ */}
      <div className="flex justify-center">
        <button
          onClick={() => navigate("/dashboard/roadmap")}
          className="inline-flex items-center gap-2 text-xs text-zinc-500 hover:text-purple-400 transition-colors py-2"
        >
          <MapIcon className="w-3.5 h-3.5" />
          {t("faq.backToRoadmap")}
          <ArrowRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
}

export default FAQPage;