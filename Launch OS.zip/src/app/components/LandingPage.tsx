import React, { useState, useEffect, useRef, useCallback } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import {
  Rocket, Zap, BarChart3, Globe, Users, MessageSquare,
  ArrowRight, Check, Sparkles, Target, TrendingUp, Radio,
  ChevronRight, ChevronDown, Menu, X, Sun, Moon, Package,
  Shield, Star, Twitter, Linkedin, Github, ChevronUp, Flame, Mail,
} from "lucide-react";
import { useI18n, LangSwitcher } from "./i18n";
import { loadProgress } from "./user-progress";
import { useTheme } from "./ThemeProvider";
import { FloatingOrbs } from "./FloatingOrbs";
import { AVATAR_URLS } from "./avatars";
import { LaunchLogo } from "./LaunchLogo";
import { HeroNetwork } from "./HeroNetwork";
import { STRIPE_PLANS } from "./stripe-config";
import { HeroPipeline } from "./HeroPipeline";
import { useForceDarkMode } from "./useForceDarkMode";

/* ─── useInView hook ─── */
function useInViewOnce(ref: React.RefObject<HTMLElement | null>) {
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([entry]) => { if (entry.isIntersecting) { setInView(true); obs.disconnect(); } }, { threshold: 0.3 });
    obs.observe(el);
    return () => obs.disconnect();
  }, [ref]);
  return inView;
}

/* ─── Animated Counter ─── */
function AnimatedCounter({ value, suffix = "" }: { value: string; suffix?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInViewOnce(ref);
  const numericPart = value.replace(/[^0-9.]/g, "");
  const prefix = value.replace(/[0-9.+KM]/g, "");
  const suffixPart = value.replace(/[0-9.]/g, "").replace(prefix, "");
  const target = parseFloat(numericPart) || 0;
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!isInView) return;
    let frame: number;
    const duration = 1600;
    const start = performance.now();
    const step = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 4);
      setCount(eased * target);
      if (progress < 1) frame = requestAnimationFrame(step);
    };
    frame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(frame);
  }, [isInView, target]);

  const display = target >= 100
    ? Math.round(count).toLocaleString()
    : count.toFixed(1);

  return (
    <div ref={ref} className="text-2xl text-white" style={{ fontWeight: 700 }}>
      {prefix}{display}{suffixPart}{suffix}
    </div>
  );
}

/* ─── Typing effect hook ─── */
function useTypingEffect(text: string, speed = 40, startDelay = 300) {
  const [displayed, setDisplayed] = useState("");
  const [done, setDone] = useState(false);
  useEffect(() => {
    setDisplayed("");
    setDone(false);
    const timeout = setTimeout(() => {
      let i = 0;
      const interval = setInterval(() => {
        setDisplayed(text.slice(0, i + 1));
        i++;
        if (i >= text.length) { clearInterval(interval); setDone(true); }
      }, speed);
      return () => clearInterval(interval);
    }, startDelay);
    return () => clearTimeout(timeout);
  }, [text, speed, startDelay]);
  return { displayed, done };
}

/* ─── FAQ Accordion Item ─── */
function FaqItem({ question, answer }: { question: string; answer: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="vision-card rounded-2xl overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between p-5 md:p-6 text-left"
      >
        <span className="text-white pr-4" style={{ fontWeight: 500 }}>{question}</span>
        <motion.div animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown className="w-5 h-5 text-zinc-500 shrink-0" />
        </motion.div>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 md:px-6 md:pb-6 text-sm text-zinc-400 leading-relaxed">{answer}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ─── Section wrapper with consistent animation ─── */
function Section({ id, children, className = "" }: { id?: string; children: React.ReactNode; className?: string }) {
  return (
    <section id={id} className={`py-16 md:py-24 lg:py-32 relative ${className}`}>
      {children}
    </section>
  );
}

function SectionHeader({ label, labelColor = "text-purple-400", title, subtitle }: {
  label: string; labelColor?: string; title: React.ReactNode; subtitle: string;
}) {
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-10 md:mb-16 px-1">
      <div className={`text-xs md:text-sm ${labelColor} mb-3 tracking-wide`} style={{ fontWeight: 600 }}>{label}</div>
      <h2 className="text-2xl md:text-3xl lg:text-4xl tracking-tight mb-3 md:mb-4" style={{ fontWeight: 700 }}>{title}</h2>
      <p className="text-sm md:text-base text-zinc-500 max-w-xl mx-auto" style={{ lineHeight: 1.7 }}>{subtitle.replace(/--/g, "->")}</p>
    </motion.div>
  );
}

export function LandingPage() {
  useForceDarkMode();
  const navigate = useNavigate();
  const { t, lang } = useI18n();
  const { theme, toggleTheme } = useTheme();
  const [activeStep, setActiveStep] = useState(0);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [demoStep, setDemoStep] = useState(0);
  const [isAnnual, setIsAnnual] = useState(false);
  const [showFeatures, setShowFeatures] = useState(false);
  const [showSticky, setShowSticky] = useState(false);
  const [ctaEmail, setCtaEmail] = useState("");
  const [showBackToTop, setShowBackToTop] = useState(false);
  const [scrollY, setScrollY] = useState(0);
  const [liveProof, setLiveProof] = useState<{ name: string; action: string; time: string } | null>(null);
  const isReturningUser = loadProgress().projectCreated;

  useEffect(() => {
    const interval = setInterval(() => setActiveStep((s) => (s + 1) % 5), 3000);
    return () => clearInterval(interval);
  }, []);

  // Sticky CTA on mobile
  useEffect(() => {
    const handler = () => {
      setShowSticky(window.scrollY > 600);
      setShowBackToTop(window.scrollY > 1200);
      setScrollY(window.scrollY);
    };
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  // Live social proof notifications
  useEffect(() => {
    const proofs = [
      { name: "Alex K.", action: t("live.justLaunched"), time: "2m" },
      { name: "Sarah C.", action: t("live.signupsToday47"), time: "5m" },
      { name: "Marcus J.", action: t("live.upvotes2h"), time: "8m" },
      { name: "Elena P.", action: t("live.justLaunchedF"), time: "12m" },
      { name: "James L.", action: t("live.signupsToday89"), time: "15m" },
    ];
    let idx = 0;
    const show = () => {
      setLiveProof(proofs[idx % proofs.length]);
      idx++;
      setTimeout(() => setLiveProof(null), 4000);
    };
    const firstTimer = setTimeout(show, 8000);
    const interval = setInterval(show, 18000);
    return () => { clearTimeout(firstTimer); clearInterval(interval); };
  }, [lang]);

  const steps = [
    { icon: Sparkles, title: t("how.step1.title"), desc: t("how.step1.desc") },
    { icon: Package, title: t("how.step2.title"), desc: t("how.step2.desc") },
    { icon: Globe, title: t("how.step3.title"), desc: t("how.step3.desc") },
    { icon: Rocket, title: t("how.step4.title"), desc: t("how.step4.desc") },
    { icon: BarChart3, title: t("how.step5.title"), desc: t("how.step5.desc") },
  ];

  const channelsData = [
    { icon: Users, label: t("channels.startup"), count: "200+", examples: ["YC, Indie Hackers, BetaList, SaaSHub"] },
    { icon: MessageSquare, label: t("channels.dev"), count: "150+", examples: ["Reddit, HN, Dev.to, StackOverflow"] },
    { icon: Target, label: t("channels.discovery"), count: "50+", examples: ["Product Hunt, AlternativeTo, G2"] },
    { icon: Globe, label: t("channels.social"), count: "10+", examples: ["Twitter, LinkedIn, Facebook, TikTok"] },
    { icon: Radio, label: t("channels.founder"), count: "80+", examples: ["Slack, Discord, Telegram, Meetup"] },
  ];

  const plans = [
    {
      name: t("pricing.starter"), monthlyPrice: 29, annualPrice: 23,
      features: [t("pricing.starter.f1"), t("pricing.starter.f2"), t("pricing.starter.f3"), t("pricing.starter.f4"), t("pricing.starter.f5")],
      cta: t("pricing.starter.cta"), popular: false, trial: false,
      stripeMonthly: STRIPE_PLANS.starter.stripeMonthlyUrl,
      stripeAnnual:  STRIPE_PLANS.starter.stripeAnnualUrl,
    },
    {
      name: t("pricing.growth"), monthlyPrice: 59, annualPrice: 47,
      features: [t("pricing.growth.f1"), t("pricing.growth.f2"), t("pricing.growth.f3"), t("pricing.growth.f4"), t("pricing.growth.f5"), t("pricing.growth.f6")],
      cta: t("pricing.growth.cta"), popular: true, trial: true,
      stripeMonthly: STRIPE_PLANS.growth.stripeMonthlyUrl,
      stripeAnnual:  STRIPE_PLANS.growth.stripeAnnualUrl,
    },
    {
      name: t("pricing.viral"), monthlyPrice: 149, annualPrice: 119,
      features: [t("pricing.viral.f1"), t("pricing.viral.f2"), t("pricing.viral.f3"), t("pricing.viral.f4"), t("pricing.viral.f5"), t("pricing.viral.f6"), t("pricing.viral.f7")],
      cta: t("pricing.viral.cta"), popular: false, trial: false,
      stripeMonthly: STRIPE_PLANS.viral.stripeMonthlyUrl,
      stripeAnnual:  STRIPE_PLANS.viral.stripeAnnualUrl,
    },
  ];

  const testimonials = [
    { name: t("social.t1.name"), role: t("social.t1.role"), text: t("social.t1.text"), avatar: AVATAR_URLS.f2, stars: 5 },
    { name: t("social.t2.name"), role: t("social.t2.role"), text: t("social.t2.text"), avatar: AVATAR_URLS.f1, stars: 5 },
    { name: t("social.t3.name"), role: t("social.t3.role"), text: t("social.t3.text"), avatar: AVATAR_URLS.f4, stars: 5 },
    { name: t("social.t4.name"), role: t("social.t4.role"), text: t("social.t4.text"), avatar: AVATAR_URLS.f5, stars: 5 },
  ];

  const whyCards = [
    { icon: Target, title: t("why.find.title"), desc: t("why.find.desc") },
    { icon: Zap, title: t("why.publish.title"), desc: t("why.publish.desc") },
    { icon: TrendingUp, title: t("why.track.title"), desc: t("why.track.desc") },
  ];

  const featureComparison = [
    { label: t("features.projects"), s: "1", g: "5", v: t("pricing.unlimited") },
    { label: t("features.tokens"), s: "100", g: "300", v: "1,000" },
    { label: t("features.channelsCount"), s: "50", g: "All", v: "All" },
    { label: t("features.analytics"), s: t("features.basic"), g: t("features.advanced"), v: t("features.full") },
    { label: t("features.abtest"), s: "—", g: t("compare.yes"), v: t("compare.yes") },
    { label: t("features.api"), s: "—", g: "—", v: t("compare.yes") },
    { label: t("features.support"), s: t("features.email"), g: t("features.priority"), v: t("features.dedicated") },
  ];

  return (
    <div className="min-h-screen bg-[var(--app-bg)] text-white">
      <FloatingOrbs count={5} />

      {/* ═══════ Navbar ═══════ */}
      <nav className="liquid-glass fixed top-0 left-0 right-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <LaunchLogo size={32} forceColor="white" />
            <span className="tracking-tight" style={{ fontSize: "1.125rem", fontWeight: 700 }}>Launch OS</span>
          </div>
          <div className="hidden md:flex items-center absolute left-1/2 -translate-x-1/2 gap-8">
            {[
              { href: "#how-it-works", label: t("nav.howItWorks") },
              { href: "#demo", label: t("demo.label") },
              { href: "#channels", label: t("nav.channels") },
              { href: "#pricing", label: t("nav.pricing") },
            ].map(l => (
              null
            ))}
          </div>
          <div className="hidden md:flex items-center gap-3">
            <LangSwitcher />
            <button onClick={toggleTheme} aria-label="Toggle theme"
              className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 text-zinc-500 hover:text-zinc-300 transition-all">
              {theme === "dark" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </button>
            <button onClick={() => navigate("/login")} className="text-sm text-zinc-400 hover:text-white transition-colors px-4 py-2">
              {t("nav.logIn")}
            </button>
            <button onClick={() => navigate("/onboarding")} className="text-sm bg-purple-600 hover:bg-purple-500 text-white px-5 py-2 rounded-xl transition-colors">
              {t("nav.startLaunching")}
            </button>
          </div>
          <div className="flex md:hidden items-center gap-1">
            <LangSwitcher />
            <button onClick={toggleTheme} aria-label="Toggle theme"
              className="w-10 h-10 flex items-center justify-center rounded-xl text-zinc-400 hover:text-white hover:bg-white/5 transition-all">
              {theme === "dark" ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
            </button>
            <button onClick={() => setMobileMenu(true)} className="w-10 h-10 flex items-center justify-center rounded-xl text-zinc-400 hover:text-white hover:bg-white/5 transition-all">
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileMenu && (
          <>
            <motion.div key="backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm" onClick={() => setMobileMenu(false)} />
            <motion.div key="drawer" initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="fixed top-0 right-0 bottom-0 z-[70] w-72 liquid-glass-sidebar flex flex-col">
              <div className="flex items-center justify-between px-5 h-16 border-b border-white/5">
                <div className="flex items-center gap-2">
                  <LaunchLogo size={28} forceColor="white" />
                  <span className="text-sm" style={{ fontWeight: 700 }}>Launch OS</span>
                </div>
                <button onClick={() => setMobileMenu(false)} className="p-1.5 rounded-lg text-zinc-500 hover:text-white hover:bg-white/5 transition-all">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 px-4 py-6 space-y-1">
                {[
                  { href: "#how-it-works", label: t("nav.howItWorks") },
                  { href: "#demo", label: t("demo.label") },
                  { href: "#channels", label: t("nav.channels") },
                  { href: "#pricing", label: t("nav.pricing") },
                ].map(link => (
                  <a key={link.href} href={link.href} onClick={() => setMobileMenu(false)}
                    className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-zinc-400 hover:text-white hover:bg-white/5 transition-all">
                    <ChevronRight className="w-4 h-4 text-zinc-600" />{link.label}
                  </a>
                ))}
              </div>
              <div className="px-4 pb-6 space-y-3 border-t border-white/5 pt-4">
                <button onClick={() => { setMobileMenu(false); navigate("/login"); }}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border border-white/10 text-sm text-zinc-300 hover:text-white hover:border-white/20 transition-all">
                  {t("nav.logIn")}
                </button>
                <button onClick={() => { setMobileMenu(false); navigate("/onboarding"); }}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-sm text-white transition-colors">
                  <Rocket className="w-4 h-4" />{t("nav.startLaunching")}
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ═══════ Hero ═══════ */}
      <section className="relative min-h-screen flex items-center justify-center pt-16">
        {/* Network constellation background — information spreading */}
        <HeroNetwork scrollY={scrollY} />
        {/* Ambient color blobs — whisper subtle */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-purple-500/[0.070] rounded-full blur-[140px]" style={{ transform: `translateY(${scrollY * 0.08}px)` }} />
          <div className="absolute top-1/3 right-1/4 w-[400px] h-[400px] bg-cyan-500/[0.044] rounded-full blur-[120px]" style={{ transform: `translateY(${scrollY * -0.05}px)` }} />
          <div className="absolute bottom-1/4 left-1/3 w-[350px] h-[350px] bg-violet-500/[0.053] rounded-full blur-[120px]" style={{ transform: `translateY(${scrollY * 0.06}px)` }} />
        </div>
        <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            {/* Hero Logo — large Liquid Glass with sparkles */}
            

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-purple-500/20 bg-purple-500/10 text-purple-300 text-sm mt-8 mb-6"
            >
              <Zap className="w-3.5 h-3.5" />
              {t("hero.badge")}
            </motion.div>
            <h1 className="mb-6 tracking-tight bg-gradient-to-b from-white to-zinc-400 bg-clip-text text-transparent"
              style={{ fontSize: "clamp(2.5rem, 6vw, 4.5rem)", fontWeight: 800, lineHeight: 1.1 }}>
              {t("hero.title1")}<br />{t("hero.title2")}
            </h1>
            <p className="text-zinc-400 max-w-2xl mx-auto mb-8 md:mb-10 px-2" style={{ fontSize: "clamp(0.938rem, 2.5vw, 1.125rem)", lineHeight: 1.7 }}>
              {t("hero.subtitle")}
            </p>
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center px-4 sm:px-0">
              <button onClick={() => navigate("/onboarding")}
                className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white px-8 py-3.5 rounded-2xl transition-all shadow-lg shadow-purple-500/25 active:scale-[0.98]">
                <Rocket className="w-4 h-4" />{t("hero.cta")}<ArrowRight className="w-4 h-4" />
              </button>
              <a href="#how-it-works"
                className="inline-flex items-center justify-center gap-2 border border-white/10 hover:border-white/20 text-zinc-300 hover:text-white px-8 py-3.5 rounded-2xl transition-all active:scale-[0.98]">
                {t("hero.seeHow")}
              </a>
            </div>
          </motion.div>

          {/* Trusted by founders — avatar stack */}
          

          {/* Hero stats with animated counters */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5, duration: 0.6 }}
            className="grid grid-cols-3 gap-8 mt-10 max-w-lg mx-auto">
            {[
              { value: "10", suffix: "K+", label: t("hero.stat1") },
              { value: "100s", suffix: "", label: t("hero.stat2") },
              { value: "2.1", suffix: "M", label: t("hero.stat3") },
            ].map(s => (
              <div key={s.label}>
                <AnimatedCounter value={s.value} suffix={s.suffix} />
                <div className="text-xs text-zinc-500 mt-1">{s.label}</div>
              </div>
            ))}
          </motion.div>

          {/* Urgency counter */}
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7, duration: 0.5 }}
            className="flex items-center justify-center gap-2 mt-6">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs text-zinc-500">
              <span className="text-emerald-400" style={{ fontWeight: 600 }}>47</span> {t("hero.launchedThisWeek")}
            </span>
          </motion.div>

          {/* Product Mockup — animated pipeline widget */}
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.8, duration: 0.7 }}
            className="mt-12 md:mt-16 max-w-3xl mx-auto">
            <HeroPipeline />
          </motion.div>
        </div>
      </section>

      {/* ═══════ How It Works ═══════ */}
      <Section id="how-it-works">
        <div className="max-w-6xl mx-auto px-6">
          <SectionHeader label={t("how.label")} title={t("how.title")} subtitle={t("how.subtitle")} />
          {/* Mobile: horizontal scroll carousel */}
          <div className="md:hidden -mx-6 px-6">
            <div className="flex gap-4 overflow-x-auto scrollbar-hide snap-x snap-mandatory pb-4" style={{ WebkitOverflowScrolling: "touch" }}>
              {steps.map((step, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}
                  className={`vision-card relative p-5 rounded-2xl transition-all duration-500 snap-center shrink-0 ${activeStep === i ? "!border-purple-500/30 !shadow-[0_0_40px_-8px_rgba(139,92,246,0.15)]" : ""}`}
                  style={{ width: "75vw", maxWidth: "280px" }}>
                  <div className="flex items-center gap-3 mb-3">
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors shrink-0 ${activeStep === i ? "bg-purple-500/20 text-purple-400" : "bg-white/5 text-zinc-500"}`}>
                      <step.icon className="w-4.5 h-4.5" />
                    </div>
                    <div className="text-[10px] text-zinc-600" style={{ fontWeight: 600 }}>STEP {i + 1}</div>
                  </div>
                  <h3 className="text-white text-sm mb-1.5" style={{ fontWeight: 600 }}>{step.title}</h3>
                  <p className="text-xs text-zinc-500 leading-relaxed">{step.desc}</p>
                  {activeStep === i && <div className="absolute bottom-0 left-5 right-5 h-0.5 bg-gradient-to-r from-purple-500 to-violet-500 rounded-full" />}
                </motion.div>
              ))}
            </div>
            {/* Scroll indicators */}
            <div className="flex justify-center gap-1.5 mt-2">
              {steps.map((_, i) => (
                <div key={i} className={`h-1 rounded-full transition-all duration-300 ${activeStep === i ? "w-5 bg-purple-500" : "w-1.5 bg-white/10"}`} />
              ))}
            </div>
          </div>
          {/* Desktop: grid */}
          <div className="hidden md:grid md:grid-cols-5 gap-4">
            {steps.map((step, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                className={`vision-card relative p-6 rounded-2xl transition-all duration-500 ${activeStep === i ? "!border-purple-500/30 !shadow-[0_0_40px_-8px_rgba(139,92,246,0.15)]" : ""}`}>
                <div className="text-xs text-zinc-600 mb-4" style={{ fontWeight: 600 }}>STEP {i + 1}</div>
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 transition-colors ${activeStep === i ? "bg-purple-500/20 text-purple-400" : "bg-white/5 text-zinc-500"}`}>
                  <step.icon className="w-5 h-5" />
                </div>
                <h3 className="text-white mb-2" style={{ fontWeight: 600 }}>{step.title}</h3>
                <p className="text-sm text-zinc-500 leading-relaxed">{step.desc}</p>
                {activeStep === i && <div className="absolute bottom-0 left-6 right-6 h-0.5 bg-gradient-to-r from-purple-500 to-violet-500 rounded-full" />}
              </motion.div>
            ))}
          </div>
        </div>
      </Section>

      {/* ═══════ Why Different ═══════ */}
      <Section>
        <div className="max-w-6xl mx-auto px-6">
          <SectionHeader label={t("why.label")} labelColor="text-emerald-400"
            title={<>{t("why.title1")}<br />{t("why.title2")}</>} subtitle={t("why.subtitle")} />
          <div className="grid gap-4 md:grid-cols-3 md:gap-6">
            {whyCards.map((f, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                className="vision-card p-6 md:p-8 rounded-2xl hover:!border-emerald-500/20">
                <div className="flex md:block items-center gap-4">
                  <div className="w-11 h-11 md:w-12 md:h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center shrink-0 md:mb-5">
                    <f.icon className="w-5 h-5 md:w-6 md:h-6 text-emerald-400" />
                  </div>
                  <div>
                    <h3 className="text-white mb-1 md:mb-2" style={{ fontWeight: 600 }}>{f.title}</h3>
                    <p className="text-sm text-zinc-500 leading-relaxed">{f.desc}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </Section>

      {/* ═══════ Social Proof — Testimonials ═══════ */}
      <Section>
        <div className="max-w-6xl mx-auto px-6">
          <SectionHeader label={t("social.label")} labelColor="text-amber-400"
            title={t("social.title")} subtitle={t("social.subtitle")} />
          {/* Mobile: horizontal scroll */}
          <div className="md:hidden -mx-6 px-6">
            <div className="flex gap-4 overflow-x-auto scrollbar-hide snap-x snap-mandatory pb-2" style={{ WebkitOverflowScrolling: "touch" as any }}>
              {testimonials.map((tm, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                  className="vision-card p-5 rounded-2xl flex flex-col snap-center shrink-0" style={{ width: "85vw", maxWidth: "340px" }}>
                  <div className="flex gap-1 mb-3">
                    {Array.from({ length: tm.stars }).map((_, s) => (
                      <Star key={s} className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                    ))}
                  </div>
                  <p className="text-sm text-zinc-300 leading-relaxed flex-1 mb-4" style={{ fontStyle: "italic" }}>
                    "{tm.text}"
                  </p>
                  <div className="flex items-center gap-3">
                    <img src={tm.avatar} alt={tm.name} className="w-9 h-9 rounded-full object-cover" />
                    <div>
                      <div className="text-sm text-white" style={{ fontWeight: 600 }}>{tm.name}</div>
                      <div className="text-xs text-zinc-500">{tm.role}</div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
          {/* Desktop: grid */}
          <div className="hidden md:grid md:grid-cols-2 gap-6">
            {testimonials.map((tm, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                className="vision-card p-6 rounded-2xl flex flex-col">
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: tm.stars }).map((_, s) => (
                    <Star key={s} className="w-4 h-4 text-amber-400 fill-amber-400" />
                  ))}
                </div>
                <p className="text-sm text-zinc-300 leading-relaxed flex-1 mb-5" style={{ fontStyle: "italic" }}>
                  "{tm.text}"
                </p>
                <div className="flex items-center gap-3">
                  <img src={tm.avatar} alt={tm.name} className="w-10 h-10 rounded-full object-cover" />
                  <div>
                    <div className="text-sm text-white" style={{ fontWeight: 600 }}>{tm.name}</div>
                    <div className="text-xs text-zinc-500">{tm.role}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </Section>

      {/* ═══════ Logo Bar — As Seen On (infinite marquee) ═══════ */}
      <div className="py-10 md:py-14 border-t border-b border-white/[0.03] overflow-hidden">
        <div className="max-w-5xl mx-auto px-6 mb-6">
          <div className="text-center text-[10px] md:text-xs text-zinc-600 tracking-widest" style={{ fontWeight: 500 }}>
            {t("logos.seenOn").toUpperCase()}
          </div>
        </div>
        <div className="relative">
          <div className="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-[#09090b] to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-[#09090b] to-transparent z-10 pointer-events-none" />
          <div className="flex gap-10 md:gap-14" style={{ animation: "marquee 25s linear infinite", width: "max-content" }}>
            {[...Array(2)].flatMap((_, rep) =>
              ["Product Hunt", "Reddit", "Hacker News", "Indie Hackers", "BetaList", "Twitter/X", "LinkedIn", "Dev.to", "SaaSHub", "AlternativeTo"].map((name, i) => (
                <span key={`${name}-${rep}-${i}`} className="text-xs md:text-sm text-zinc-500 whitespace-nowrap opacity-40 hover:opacity-70 transition-opacity shrink-0" style={{ fontWeight: 600 }}>{name}</span>
              ))
            )}
          </div>
        </div>
      </div>

      {/* ═══════ Case Study – 7 Day Results ═══════ */}
      <Section>
        <div className="absolute inset-0"><div className="absolute top-1/2 left-1/3 w-[500px] h-[500px] bg-emerald-500/5 rounded-full blur-3xl" /></div>
        <div className="max-w-4xl mx-auto px-6 relative z-10">
          <SectionHeader label={t("case.label")} labelColor="text-emerald-400"
            title={t("case.title")} subtitle={t("case.subtitle")} />
          <div className="grid gap-4 md:gap-0 md:grid-cols-3 relative">
            {/* Connecting line (desktop) */}
            <div className="hidden md:block absolute top-10 left-[16.7%] right-[16.7%] h-0.5 bg-gradient-to-r from-purple-500/20 via-cyan-500/20 to-emerald-500/20" />
            {[
              { day: t("case.day1"), title: t("case.day1.title"), desc: t("case.day1.desc"), color: "purple", icon: Sparkles },
              { day: t("case.day3"), title: t("case.day3.title"), desc: t("case.day3.desc"), color: "cyan", icon: Globe },
              { day: t("case.day7"), title: t("case.day7.title"), desc: t("case.day7.desc"), color: "emerald", icon: TrendingUp },
            ].map((step, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.15 }}
                className="relative flex flex-col items-center text-center px-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 relative z-10 ${
                  step.color === "purple" ? "bg-purple-500/15 text-purple-400" :
                  step.color === "cyan" ? "bg-cyan-500/15 text-cyan-400" :
                  "bg-emerald-500/15 text-emerald-400"
                }`}>
                  <step.icon className="w-5 h-5" />
                </div>
                <div className={`text-xs mb-2 ${
                  step.color === "purple" ? "text-purple-400" :
                  step.color === "cyan" ? "text-cyan-400" :
                  "text-emerald-400"
                }`} style={{ fontWeight: 600 }}>{step.day}</div>
                <h3 className="text-white text-sm mb-1.5" style={{ fontWeight: 600 }}>{step.title}</h3>
                <p className="text-xs text-zinc-500 leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </div>
          {/* Result highlight */}
          <motion.div initial={{ opacity: 0, y: 15 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="mt-8 vision-card p-5 rounded-2xl flex flex-col sm:flex-row items-center justify-center gap-6 sm:gap-10">
            {[
              { val: "2,100+", label: t("demo.visitors"), color: "text-purple-400" },
              { val: "89", label: t("demo.signups"), color: "text-cyan-400" },
              { val: "$1,140", label: "MRR", color: "text-emerald-400" },
            ].map(r => (
              <div key={r.label} className="text-center">
                <div className={`text-2xl ${r.color}`} style={{ fontWeight: 700 }}>{r.val}</div>
                <div className="text-xs text-zinc-500 mt-0.5">{r.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </Section>

      {/* ═══════ Channels with hover previews ═══════ */}
      <Section id="channels">
        <div className="absolute inset-0"><div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-purple-500/5 rounded-full blur-3xl" /></div>
        <div className="max-w-6xl mx-auto px-6 relative z-10">
          <SectionHeader label={t("channels.label")} labelColor="text-cyan-400"
            title={t("channels.title")} subtitle={t("channels.subtitle")} />
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3 md:gap-4">
            {channelsData.map((ch, i) => (
              <motion.div key={i} initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                className={`group vision-card p-4 md:p-5 rounded-2xl text-center cursor-default relative overflow-hidden ${i === channelsData.length - 1 ? "col-span-2 md:col-span-1" : ""}`}>
                <ch.icon className="w-5 h-5 md:w-6 md:h-6 text-purple-400 mx-auto mb-2 md:mb-3" />
                <div className="text-sm text-white mb-0.5 md:mb-1" style={{ fontWeight: 500 }}>{ch.label}</div>
                <div className="text-xs text-zinc-500">{ch.count} {t("channels.count")}</div>
                {/* Mobile: show examples inline */}
                <div className="md:hidden text-[10px] text-zinc-600 mt-2 leading-relaxed">{ch.examples[0]}</div>
                {/* Desktop: hover preview */}
                <div className="hidden md:flex absolute inset-0 bg-[#0c0c0f]/95 backdrop-blur-sm items-center justify-center p-3 opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl">
                  <div className="text-[10px] text-zinc-400 text-center leading-relaxed">{ch.examples[0]}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </Section>

      {/* ═══════ Comparison Table ═══════ */}
      <Section>
        <div className="absolute inset-0"><div className="absolute top-1/2 right-1/3 w-[500px] h-[500px] bg-orange-500/5 rounded-full blur-3xl" /></div>
        <div className="max-w-5xl mx-auto px-6 relative z-10">
          <SectionHeader label={t("compare.label")} labelColor="text-orange-400"
            title={t("compare.title")} subtitle={t("compare.subtitle")} />
          {/* Mobile scroll hint */}
          <div className="md:hidden flex items-center justify-center gap-2 mb-3 text-xs text-zinc-600">
            <ArrowRight className="w-3 h-3" />
            <span>{t("demo.scrollRight")}</span>
          </div>
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="vision-card rounded-2xl overflow-x-auto scrollbar-hide">
            <div className="grid grid-cols-4 gap-0 min-w-[580px]">
              <div className="p-4 md:p-5" />
              <div className="p-4 md:p-5 bg-purple-500/10 border-x border-purple-500/10 text-center">
                <div className="flex items-center justify-center gap-2 mb-1">
                  <LaunchLogo size={24} forceColor="white" />
                  <span className="text-white text-sm" style={{ fontWeight: 700 }}>{t("compare.launchOS")}</span>
                </div>
                <div className="text-xs text-purple-300" style={{ fontWeight: 500 }}>$59{t("demo.perMonth")}</div>
              </div>
              <div className="p-5 text-center">
                <div className="text-sm text-zinc-400 mb-1" style={{ fontWeight: 600 }}>{t("compare.freelancer")}</div>
                <div className="text-xs text-zinc-600" style={{ fontWeight: 500 }}>{t("compare.cost.freelancer")}</div>
              </div>
              <div className="p-5 text-center">
                <div className="text-sm text-zinc-400 mb-1" style={{ fontWeight: 600 }}>{t("compare.agency")}</div>
                <div className="text-xs text-zinc-600" style={{ fontWeight: 500 }}>{t("compare.cost.agency")}</div>
              </div>
            </div>
            {[
              { label: t("compare.channels"), os: t("compare.channels.os"), free: t("compare.channels.freelancer"), agency: t("compare.channels.agency") },
              { label: t("compare.speed"), os: t("compare.speed.os"), free: t("compare.speed.freelancer"), agency: t("compare.speed.agency") },
              { label: t("compare.aiContent"), os: t("compare.yes"), free: t("compare.no"), agency: t("compare.limited") },
              { label: t("compare.analytics"), os: t("compare.yes"), free: t("compare.limited"), agency: t("compare.limited") },
              { label: t("compare.availability"), os: t("compare.availability.os"), free: t("compare.availability.freelancer"), agency: t("compare.availability.agency") },
            ].map((row, i) => (
              <div key={i} className="grid grid-cols-4 gap-0 border-t border-white/5 min-w-[600px]">
                <div className="p-4 text-sm text-zinc-400" style={{ fontWeight: 500 }}>{row.label}</div>
                <div className="p-4 bg-purple-500/5 border-x border-purple-500/10 text-center">
                  <span className="text-sm text-emerald-400" style={{ fontWeight: 600 }}>
                    {row.os === t("compare.yes") ? <Check className="w-4 h-4 text-emerald-400 mx-auto" /> : row.os}
                  </span>
                </div>
                <div className="p-4 text-center">
                  <span className={`text-sm ${row.free === t("compare.no") ? "text-red-400/60" : "text-zinc-500"}`}>
                    {row.free === t("compare.no") ? <X className="w-4 h-4 text-red-400/60 mx-auto" /> : row.free}
                  </span>
                </div>
                <div className="p-4 text-center"><span className="text-sm text-zinc-500">{row.agency}</span></div>
              </div>
            ))}
          </motion.div>
        </div>
      </Section>

      {/* ═══════ Interactive Demo ═══════ */}
      <Section id="demo">
        <div className="absolute inset-0"><div className="absolute top-1/3 right-1/4 w-[500px] h-[500px] bg-violet-500/5 rounded-full blur-3xl" /></div>
        <div className="max-w-6xl mx-auto px-6 relative z-10">
          <SectionHeader label={t("demo.label")} labelColor="text-violet-400"
            title={t("demo.title")} subtitle={t("demo.subtitle")} />
          {/* Mobile: compact icon tab bar */}
          <div className="md:hidden flex gap-2 mb-5 overflow-x-auto scrollbar-hide pb-1">
            {steps.map((s, i) => (
              <button key={i} onClick={() => setDemoStep(i)}
                className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl shrink-0 transition-all text-xs ${
                  demoStep === i ? "bg-purple-500/15 border border-purple-500/25 text-purple-300" : "bg-white/[0.03] border border-white/5 text-zinc-500"
                }`} style={{ fontWeight: 500 }}>
                <s.icon className="w-4 h-4" />
                <span className="hidden xs:inline">{i + 1}</span>
                {i < demoStep && <Check className="w-3 h-3 text-emerald-400" />}
              </button>
            ))}
          </div>
          <div className="grid md:grid-cols-[280px_1fr] gap-8">
            {/* Desktop: step sidebar */}
            <div className="hidden md:block space-y-2">
              {steps.map((s, i) => (
                <button key={i} onClick={() => setDemoStep(i)}
                  className={`w-full flex items-center gap-3 p-4 rounded-xl text-left transition-all ${
                    demoStep === i ? "bg-purple-500/10 border border-purple-500/25" : "bg-white/[0.02] border border-white/5 hover:border-white/10"
                  }`}>
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${demoStep === i ? "bg-purple-500/20 text-purple-400" : "bg-white/5 text-zinc-600"}`}>
                    <s.icon className="w-4.5 h-4.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-[10px] text-zinc-600 uppercase tracking-wider" style={{ fontWeight: 600 }}>{t("demo.stepLabel")} {i + 1}</div>
                    <div className={`text-sm truncate ${demoStep === i ? "text-white" : "text-zinc-400"}`} style={{ fontWeight: 500 }}>{s.title}</div>
                  </div>
                  {i < demoStep && <Check className="w-4 h-4 text-emerald-400 shrink-0 ml-auto" />}
                </button>
              ))}
            </div>
            <div className="relative">
              <AnimatePresence mode="wait">
                <motion.div key={demoStep} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }}
                  className="vision-card p-5 md:p-8 rounded-2xl min-h-[280px] md:min-h-[320px] flex flex-col">
                  <div className="flex items-center gap-2 mb-6">
                    <div className="flex gap-1.5">
                      <div className="w-3 h-3 rounded-full bg-red-500/40" /><div className="w-3 h-3 rounded-full bg-yellow-500/40" /><div className="w-3 h-3 rounded-full bg-green-500/40" />
                    </div>
                    <div className="flex-1 h-6 rounded-lg bg-white/[0.03] mx-4" />
                  </div>
                  <div className="flex-1 flex flex-col justify-center">
                    {demoStep === 0 && (
                      <div className="space-y-4">
                        <div className="flex items-center gap-2 text-sm text-zinc-400"><Sparkles className="w-4 h-4 text-purple-400" />{t("demo.yourProduct")}</div>
                        <div className="p-4 rounded-xl bg-purple-500/5 border border-purple-500/15"><p className="text-white" style={{ fontWeight: 500 }}>{t("demo.clarify.example")}</p></div>
                        <div className="flex flex-wrap gap-2">{["SaaS", "B2B", "AI", "Remote Teams"].map(tag => <span key={tag} className="px-3 py-1 rounded-full text-xs bg-purple-500/10 text-purple-300 border border-purple-500/15">{tag}</span>)}</div>
                      </div>
                    )}
                    {demoStep === 1 && (
                      <div className="space-y-4">
                        <div className="flex items-center gap-2 text-sm text-zinc-400"><Package className="w-4 h-4 text-violet-400" />{t("demo.aiGeneration")}</div>
                        <div className="p-4 rounded-xl bg-violet-500/5 border border-violet-500/15"><p className="text-white italic" style={{ fontWeight: 500 }}>{t("demo.package.example")}</p></div>
                        <div className="flex gap-1.5 md:gap-2 flex-wrap">{["One-liner", "Pitch", "Landing", "FAQ", "Posts"].map((item, i) => <div key={item} className={`flex-1 min-w-[60px] p-1.5 md:p-2 rounded-lg text-center text-[11px] md:text-xs ${i < 3 ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/15" : "bg-white/[0.03] text-zinc-600 border border-white/5"}`}>{i < 3 && <Check className="w-3 h-3 mx-auto mb-0.5" />}{item}</div>)}</div>
                      </div>
                    )}
                    {demoStep === 2 && (
                      <div className="space-y-4">
                        <div className="flex items-center gap-2 text-sm text-zinc-400"><Globe className="w-4 h-4 text-cyan-400" />{t("demo.channelsFound")}</div>
                        <div className="p-4 rounded-xl bg-cyan-500/5 border border-cyan-500/15"><p className="text-white" style={{ fontWeight: 500 }}>{t("demo.route.example")}</p></div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">{["Reddit", "PH", "HN", "LinkedIn"].map(ch => <div key={ch} className="p-2 md:p-2.5 rounded-lg bg-white/[0.03] border border-white/5 text-center"><div className="text-xs text-white" style={{ fontWeight: 600 }}>{ch}</div><div className="text-[10px] text-emerald-400 mt-0.5">Connected</div></div>)}</div>
                      </div>
                    )}
                    {demoStep === 3 && (
                      <div className="space-y-4">
                        <div className="flex items-center gap-2 text-sm text-zinc-400"><Rocket className="w-4 h-4 text-emerald-400" />{t("demo.launchStatus")}</div>
                        <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/15"><p className="text-white" style={{ fontWeight: 500 }}>{t("demo.launch.example")}</p></div>
                        <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-sm flex items-center justify-center gap-2"><Rocket className="w-4 h-4" />{t("demo.launchBtn")}</motion.button>
                      </div>
                    )}
                    {demoStep === 4 && (
                      <div className="space-y-4">
                        <div className="flex items-center gap-2 text-sm text-zinc-400"><BarChart3 className="w-4 h-4 text-amber-400" />{t("demo.resultsLabel")}</div>
                        <div className="p-4 rounded-xl bg-amber-500/5 border border-amber-500/15"><p className="text-white" style={{ fontWeight: 500 }}>{t("demo.improve.example")}</p></div>
                        <div className="grid grid-cols-3 gap-3">{[
                          { label: t("demo.reach"), value: "2.1K", color: "text-purple-400" },
                          { label: t("demo.clicks"), value: "89", color: "text-cyan-400" },
                          { label: t("demo.registrations"), value: "12", color: "text-emerald-400" },
                        ].map(m => <div key={m.label} className="p-3 rounded-lg bg-white/[0.03] border border-white/5 text-center"><div className={`text-xl ${m.color}`} style={{ fontWeight: 700 }}>{m.value}</div><div className="text-xs text-zinc-500 mt-0.5">{m.label}</div></div>)}</div>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center justify-between mt-6 pt-4 border-t border-white/5">
                    <button onClick={() => setDemoStep(Math.max(0, demoStep - 1))} disabled={demoStep === 0} className="text-xs text-zinc-600 hover:text-zinc-400 disabled:opacity-30 transition-colors">&larr; {t("demo.back")}</button>
                    <div className="flex gap-1.5">{[0, 1, 2, 3, 4].map(i => <button key={i} onClick={() => setDemoStep(i)} className={`w-2 h-2 rounded-full transition-all ${i === demoStep ? "bg-purple-500 w-5" : i < demoStep ? "bg-emerald-500/50" : "bg-white/10"}`} />)}</div>
                    {demoStep < 4 ? (
                      <button onClick={() => setDemoStep(demoStep + 1)} className="text-xs text-purple-400 hover:text-purple-300 transition-colors">{t("demo.next")} &rarr;</button>
                    ) : (
                      <button onClick={() => navigate("/onboarding")} className="text-xs text-emerald-400 hover:text-emerald-300 transition-colors flex items-center gap-1">{t("demo.cta")} <ArrowRight className="w-3 h-3" /></button>
                    )}
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>
      </Section>

      {/* ═══════ Pricing ═══════ */}
      <Section id="pricing">
        <div className="max-w-5xl mx-auto px-6">
          <SectionHeader label={t("pricing.label")} title={t("pricing.title")} subtitle={t("pricing.subtitle")} />

          {/* Monthly / Annual toggle */}
          <div className="flex items-center justify-center gap-3 mb-12">
            <span className={`text-sm transition-colors ${!isAnnual ? "text-white" : "text-zinc-500"}`} style={{ fontWeight: 500 }}>{t("pricing.monthly")}</span>
            <button onClick={() => setIsAnnual(!isAnnual)} className={`relative w-14 h-7 rounded-full transition-colors ${isAnnual ? "bg-purple-600" : "bg-white/10"}`}>
              <motion.div className="absolute top-1 w-5 h-5 rounded-full bg-white shadow-md" animate={{ left: isAnnual ? 32 : 4 }} transition={{ type: "spring", stiffness: 500, damping: 30 }} />
            </button>
            <span className={`text-sm transition-colors ${isAnnual ? "text-white" : "text-zinc-500"}`} style={{ fontWeight: 500 }}>{t("pricing.annual")}</span>
            {isAnnual && (
              <motion.span initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }}
                className="ml-1 px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 text-xs border border-emerald-500/20" style={{ fontWeight: 600 }}>
                {t("pricing.save")}
              </motion.span>
            )}
          </div>

          <div className="grid gap-5 md:grid-cols-3 md:gap-6">
            {plans.map((plan, i) => {
              const displayPrice = isAnnual ? plan.annualPrice : plan.monthlyPrice;
              return (
                <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                  className={`relative p-6 md:p-8 rounded-2xl flex flex-col ${plan.popular ? "vision-card-popular -order-1 md:order-none" : "vision-card"}`}>
                  {plan.popular && <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-purple-600 text-xs text-white z-10" style={{ fontWeight: 600 }}>{t("pricing.popular")}</div>}
                  <div className="text-sm text-zinc-400 mb-1" style={{ fontWeight: 500 }}>{plan.name}</div>
                  <div className="flex items-baseline gap-1 mb-1">
                    <span className="text-4xl text-white" style={{ fontWeight: 700 }}>${displayPrice}</span>
                    <span className="text-zinc-500 text-sm">/mo</span>
                  </div>
                  {isAnnual ? (
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs text-zinc-600 line-through">${plan.monthlyPrice}/mo</span>
                      <span className="text-xs text-emerald-400" style={{ fontWeight: 500 }}>{t("pricing.annualBilled")}</span>
                    </div>
                  ) : <div className="mb-1" />}
                  <div className="text-[10px] text-zinc-600 mb-4 italic">
                    {i === 0 ? t("pricing.anchor.starter") : i === 1 ? t("pricing.anchor.growth") : t("pricing.anchor.viral")}
                  </div>
                  {plan.trial && (
                    <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/15 mb-5">
                      <Shield className="w-4 h-4 text-emerald-400 shrink-0" />
                      <div>
                        <div className="text-xs text-emerald-400" style={{ fontWeight: 600 }}>{t("pricing.trial")}</div>
                        <div className="text-[10px] text-emerald-400/60">{t("pricing.trialDesc")}</div>
                      </div>
                    </div>
                  )}
                  <ul className="space-y-3 mb-8 flex-1">
                    {plan.features.map(f => <li key={f} className="flex items-center gap-2.5 text-sm text-zinc-400"><Check className="w-4 h-4 text-purple-400 shrink-0" />{f}</li>)}
                  </ul>
                  <a
                    href={isAnnual ? plan.stripeAnnual : plan.stripeMonthly}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`w-full py-3 rounded-xl text-sm transition-all text-center block ${plan.popular ? "bg-purple-600 hover:bg-purple-500 text-white" : "border border-white/10 hover:border-white/20 text-zinc-300 hover:text-white"}`}
                    style={{ fontWeight: 500 }}
                  >
                    {plan.cta}
                  </a>
                </motion.div>
              );
            })}
          </div>

          {/* Money-back guarantee */}
          <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}
            className="flex items-center justify-center gap-2 mt-8 text-sm text-zinc-600">
            <Shield className="w-4 h-4 text-emerald-500/60" />
            <span>{t("moneyback")}</span>
          </motion.div>

          {/* Feature comparison toggle */}
          <div className="mt-10 text-center">
            <button onClick={() => setShowFeatures(!showFeatures)}
              className="inline-flex items-center gap-2 text-sm text-purple-400 hover:text-purple-300 transition-colors">
              {t("features.compare")}
              <motion.div animate={{ rotate: showFeatures ? 180 : 0 }}><ChevronDown className="w-4 h-4" /></motion.div>
            </button>
          </div>
          <AnimatePresence>
            {showFeatures && (
              <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden mt-6">
                <div className="vision-card rounded-2xl overflow-x-auto scrollbar-hide">
                  <div className="grid grid-cols-4 gap-0 min-w-[480px]">
                    <div className="p-4" />
                    {[t("pricing.starter"), t("pricing.growth"), t("pricing.viral")].map(n => (
                      <div key={n} className="p-4 text-center text-sm text-zinc-400" style={{ fontWeight: 600 }}>{n}</div>
                    ))}
                  </div>
                  {featureComparison.map((row, i) => (
                    <div key={i} className="grid grid-cols-4 gap-0 border-t border-white/5 min-w-[500px]">
                      <div className="p-3 text-sm text-zinc-500" style={{ fontWeight: 500 }}>{row.label}</div>
                      {[row.s, row.g, row.v].map((val, j) => (
                        <div key={j} className={`p-3 text-center text-sm ${j === 1 ? "bg-purple-500/5 border-x border-purple-500/10" : ""} ${val === t("compare.yes") ? "text-emerald-400" : "text-zinc-400"}`}>
                          {val === t("compare.yes") ? <Check className="w-4 h-4 text-emerald-400 mx-auto" /> : val === "—" ? <span className="text-zinc-700">—</span> : val}
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </Section>

      {/* ═══════ FAQ ═══════ */}
      <Section>
        <div className="max-w-3xl mx-auto px-6">
          <SectionHeader label={t("faq.label")} labelColor="text-sky-400"
            title={t("landing.faq.title")} subtitle="" />
          <div className="space-y-3">
            {[1, 2, 3, 4, 5, 6].map(n => (
              <FaqItem key={n} question={t(`landing.faq.q${n}` as any)} answer={t(`landing.faq.a${n}` as any)} />
            ))}
          </div>
        </div>
      </Section>

      {/* ═══════ CTA ═══════ */}
      <Section>
        <div className="max-w-3xl mx-auto px-6 text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            {/* CTA Logo */}
            <div className="flex justify-center mb-6">
              <LaunchLogo size={56} forceColor="white" />
            </div>
            <h2 className="text-3xl md:text-4xl tracking-tight mb-4" style={{ fontWeight: 700 }}>{t("cta.title")}</h2>
            <p className="text-zinc-400 mb-8 max-w-lg mx-auto">{t("cta.subtitle")}</p>
            {/* Email capture */}
            <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto mb-4">
              <div className="flex-1 relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                <input
                  type="email"
                  value={ctaEmail}
                  onChange={(e) => setCtaEmail(e.target.value)}
                  placeholder={t("cta.emailPlaceholder")}
                  className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-white/[0.04] border border-white/10 text-sm text-white placeholder-zinc-600 focus:border-purple-500/40 focus:outline-none focus:ring-1 focus:ring-purple-500/20 transition-all"
                />
              </div>
              <button onClick={() => navigate("/onboarding")}
                className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white px-6 py-3.5 rounded-2xl transition-all shadow-lg shadow-purple-500/25 shrink-0">
                <Rocket className="w-4 h-4" />{t("cta.emailButton")}
              </button>
            </div>
            <p className="text-xs text-zinc-600">{t("sticky.trial")}</p>
          </motion.div>
        </div>
      </Section>

      {/* ═══════ Talent Hub teaser — subtle ═══════ */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex flex-col sm:flex-row items-center gap-4 p-4 sm:p-5 rounded-2xl border border-white/5 bg-white/[0.02]">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500/15 to-purple-500/15 flex items-center justify-center shrink-0">
            <Users className="w-5 h-5 text-violet-400" />
          </div>
          <div className="flex-1 text-center sm:text-left">
            <h4 className="text-sm text-white" style={{ fontWeight: 600 }}>{t("talent.landingTitle")}</h4>
            <p className="text-xs text-zinc-500 mt-0.5">{t("talent.landingDesc")}</p>
          </div>
          <button
            onClick={() => navigate("/onboarding")}
            className="shrink-0 text-xs text-purple-400 hover:text-purple-300 px-4 py-2 rounded-xl bg-purple-500/10 hover:bg-purple-500/15 border border-purple-500/15 transition-all"
            style={{ fontWeight: 500 }}
          >
            {t("talent.landingCta")} <ArrowRight className="w-3 h-3 inline ml-1" />
          </button>
        </div>
      </div>

      {/* ═══════ Extended Footer ═══════ */}
      <footer className="border-t border-white/5 py-12 md:py-16 pb-28 md:pb-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6 md:gap-8 mb-10 md:mb-12">
            {/* Brand */}
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center gap-2 mb-3">
                <LaunchLogo size={28} forceColor="white" />
                <span className="text-sm" style={{ fontWeight: 700 }}>Launch OS</span>
              </div>
              <p className="text-xs text-zinc-600 leading-relaxed mb-4">
                {t("footer.tagline")}
              </p>
              <div className="flex gap-3">
                <a href="#" className="text-zinc-600 hover:text-zinc-400 transition-colors"><Twitter className="w-4 h-4" /></a>
                <a href="#" className="text-zinc-600 hover:text-zinc-400 transition-colors"><Linkedin className="w-4 h-4" /></a>
                <a href="#" className="text-zinc-600 hover:text-zinc-400 transition-colors"><Github className="w-4 h-4" /></a>
              </div>
            </div>
            {/* Links */}
            {[
              { title: t("footer.product"), links: [t("footer.features"), t("footer.pricing"), t("footer.changelog"), t("footer.docs")] },
              { title: t("footer.company"), links: [t("footer.about"), t("footer.blog"), t("footer.careers"), t("footer.contact")] },
              { title: t("footer.legal"), links: [t("footer.privacy"), t("footer.terms"), t("footer.cookies")] },
            ].map(col => (
              <div key={col.title}>
                <div className="text-xs text-zinc-500 mb-3 tracking-wide" style={{ fontWeight: 600 }}>{col.title}</div>
                <div className="space-y-2">
                  {col.links.map(link => (
                    <a key={link} href="#" className="block text-sm text-zinc-600 hover:text-zinc-400 transition-colors">{link}</a>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-sm text-zinc-700">&copy; 2026 Launch OS. {t("footer.rights")}</div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs text-zinc-600">{t("footer.allSystems")}</span>
            </div>
          </div>
        </div>
      </footer>

      {/* ═══════ Sticky Mobile CTA ═══════ */}
      <AnimatePresence>
        {showSticky && (
          <motion.div
            initial={{ y: 100 }} animate={{ y: 0 }} exit={{ y: 100 }}
            className="fixed bottom-0 left-0 right-0 z-50 md:hidden ios-tab-glass px-4 pt-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]"
          >
            <button onClick={() => navigate("/onboarding")}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white text-sm transition-colors active:scale-[0.98]">
              <Rocket className="w-4 h-4" />{t("sticky.cta")}
            </button>
            <p className="text-center text-[10px] text-zinc-500 mt-1">{t("sticky.trial")}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══════ Back to Top ═══════ */}
      <AnimatePresence>
        {showBackToTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="fixed bottom-6 right-6 z-40 w-10 h-10 rounded-full vision-card hidden md:flex items-center justify-center hover:!border-purple-500/30 transition-all"
            aria-label="Back to top"
          >
            <ChevronUp className="w-4 h-4 text-zinc-400" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* ═══════ Live Social Proof Toast ═══════ */}
      <AnimatePresence>
        {liveProof && (
          <motion.div
            initial={{ opacity: 0, x: -80, y: 10 }}
            animate={{ opacity: 1, x: 0, y: 0 }}
            exit={{ opacity: 0, x: -80 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed bottom-6 left-6 z-40 hidden md:flex items-center gap-3 px-4 py-3 rounded-2xl vision-card max-w-xs"
          >
            <div className="w-8 h-8 rounded-full bg-purple-500/15 flex items-center justify-center shrink-0">
              <Rocket className="w-4 h-4 text-purple-400" />
            </div>
            <div className="min-w-0">
              <div className="text-xs text-white truncate" style={{ fontWeight: 600 }}>{liveProof.name}</div>
              <div className="text-[10px] text-zinc-500 truncate">{liveProof.action}</div>
            </div>
            <span className="text-[10px] text-zinc-600 shrink-0">{liveProof.time}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}