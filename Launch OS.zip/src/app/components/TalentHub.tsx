import { useState } from "react";
import { motion } from "motion/react";
import {
  UserSearch, Users, Clock, TrendingUp, Star, Check, Crown,
  Globe, Code, Palette, BarChart3, Briefcase, Zap, ChevronRight,
  Shield, Building, Mail, Award, BadgeCheck, ExternalLink,
} from "lucide-react";
import { useI18n } from "./i18n";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { usePullToRefresh } from "./usePullToRefresh";
import { PullToRefreshIndicator } from "./PullToRefreshIndicator";
import { AVATAR_URLS } from "./avatars";
import { toast } from "sonner";
import { RECRUITER_PLAN } from "./subscription";

/* ─── Mock talent profiles ─── */
interface TalentProfile {
  name: string;
  avatar: string;
  title: string;
  skills: string[];
  launches: number;
  score: number;
  location: string;
  openToOffers: boolean;
  verified: boolean;
}

const MOCK_TALENT: TalentProfile[] = [
  { name: "Sarah Chen", avatar: AVATAR_URLS.f2, title: "Full-Stack Engineer", skills: ["React", "Node.js", "AI/ML"], launches: 3, score: 847, location: "San Francisco", openToOffers: true, verified: true },
  { name: "Marc Dubois", avatar: AVATAR_URLS.f1, title: "Product Designer", skills: ["Figma", "UX Research", "Design Systems"], launches: 5, score: 912, location: "Paris", openToOffers: true, verified: true },
  { name: "Aisha Williams", avatar: AVATAR_URLS.f6, title: "Growth Lead", skills: ["SEO", "Content Marketing", "Analytics"], launches: 2, score: 634, location: "London", openToOffers: false, verified: true },
  { name: "James Park", avatar: AVATAR_URLS.f5, title: "Backend Engineer", skills: ["Python", "AWS", "PostgreSQL"], launches: 4, score: 778, location: "Seoul", openToOffers: true, verified: false },
  { name: "Elena Popova", avatar: AVATAR_URLS.f4, title: "Founding CEO", skills: ["Strategy", "Fundraising", "Operations"], launches: 6, score: 956, location: "Berlin", openToOffers: false, verified: true },
  { name: "David Kim", avatar: AVATAR_URLS.f3, title: "ML Engineer", skills: ["PyTorch", "NLP", "Computer Vision"], launches: 1, score: 445, location: "Toronto", openToOffers: true, verified: false },
  { name: "Priya Sharma", avatar: AVATAR_URLS.f8, title: "DevOps / SRE", skills: ["Kubernetes", "Terraform", "CI/CD"], launches: 2, score: 567, location: "Bangalore", openToOffers: true, verified: true },
  { name: "Alex Turner", avatar: AVATAR_URLS.f7, title: "Marketing Lead", skills: ["Paid Ads", "Copy", "Viral Growth"], launches: 3, score: 712, location: "Austin", openToOffers: true, verified: false },
];

export function TalentHub() {
  const { t } = useI18n();
  useDocumentTitle(t("recruit.title"));
  const [activeTab, setActiveTab] = useState<"recruiters" | "founders">("recruiters");
  const [founderDiscoverable, setFounderDiscoverable] = useState(true);
  const [openToOffers, setOpenToOffers] = useState(false);

  const { pullY, isRefreshing, handlers: pullHandlers } = usePullToRefresh(
    () => new Promise<void>((r) => setTimeout(r, 800))
  );

  const stats = [
    { label: t("recruit.activeProfiles"), value: "15,247", icon: Users, color: "purple" },
    { label: t("recruit.avgResponseTime"), value: "< 2h", icon: Clock, color: "cyan" },
    { label: t("recruit.hireRate"), value: "34%", icon: TrendingUp, color: "emerald" },
  ];

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6" {...pullHandlers}>
      <PullToRefreshIndicator pullY={pullY} isRefreshing={isRefreshing} />
      <LargeTitle title={t("recruit.title")} subtitle={t("recruit.subtitle")} />

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className="p-4 rounded-xl border border-white/5 bg-white/[0.02] text-center"
          >
            <stat.icon className={`w-5 h-5 text-${stat.color}-400 mx-auto mb-2`} />
            <div className="text-xl text-white" style={{ fontWeight: 700 }}>{stat.value}</div>
            <div className="text-[10px] text-zinc-500 mt-0.5">{stat.label}</div>
          </motion.div>
        ))}
      </div>

      {/* Tab switcher */}
      <div className="flex items-center gap-1 border-b border-white/5 pb-0.5">
        {(["recruiters", "founders"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex items-center gap-1.5 px-4 py-2 text-sm transition-all border-b-2 ${
              activeTab === tab ? "text-white border-purple-500" : "text-zinc-500 border-transparent hover:text-zinc-300"
            }`}
            style={{ fontWeight: activeTab === tab ? 600 : 400 }}
          >
            {tab === "recruiters" ? <Building className="w-3.5 h-3.5" /> : <UserSearch className="w-3.5 h-3.5" />}
            {tab === "recruiters" ? t("recruit.forRecruiters") : t("recruit.forFounders")}
          </button>
        ))}
      </div>

      {activeTab === "recruiters" ? (
        /* ═══ Recruiter Section ═══ */
        <div className="space-y-6">
          {/* Pricing cards */}
          <div className="grid md:grid-cols-2 gap-4">
            {/* Annual */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative p-6 rounded-xl border border-purple-500/30 bg-gradient-to-br from-purple-500/[0.06] to-violet-500/[0.03]"
            >
              <div className="absolute -top-2.5 right-4 text-xs bg-purple-500 text-white px-2.5 py-0.5 rounded-full" style={{ fontWeight: 600 }}>
                Best Value
              </div>
              <Crown className="w-8 h-8 text-purple-400 mb-3" />
              <h3 className="text-lg text-white mb-1" style={{ fontWeight: 700 }}>{t("recruit.annualPlan")}</h3>
              <div className="flex items-baseline gap-1 mb-4">
                <span className="text-3xl text-white" style={{ fontWeight: 700 }}>${RECRUITER_PLAN.annual.toLocaleString()}</span>
                <span className="text-sm text-zinc-500">{t("recruit.perYear")}</span>
              </div>
              <p className="text-sm text-zinc-400 mb-5">
                ${Math.round(RECRUITER_PLAN.annual / 12)}/mo — Save $998 vs monthly
              </p>
              <ul className="space-y-2 mb-6">
                {RECRUITER_PLAN.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-xs text-zinc-400">
                    <Check className="w-3 h-3 text-purple-400 shrink-0" />{f}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => toast.success("Demo: Sales team will contact you within 24h")}
                className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-purple-500/20"
                style={{ fontWeight: 600 }}
              >
                <Mail className="w-4 h-4" />
                {t("recruit.contactSales")}
              </button>
            </motion.div>

            {/* Monthly */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="p-6 rounded-xl border border-white/5 bg-white/[0.02]"
            >
              <Briefcase className="w-8 h-8 text-zinc-400 mb-3" />
              <h3 className="text-lg text-white mb-1" style={{ fontWeight: 700 }}>{t("recruit.monthlyPlan")}</h3>
              <div className="flex items-baseline gap-1 mb-4">
                <span className="text-3xl text-white" style={{ fontWeight: 700 }}>${RECRUITER_PLAN.monthly}</span>
                <span className="text-sm text-zinc-500">{t("recruit.perMonth")}</span>
              </div>
              <p className="text-sm text-zinc-400 mb-5">
                Flexible month-to-month access
              </p>
              <ul className="space-y-2 mb-6">
                {RECRUITER_PLAN.features.slice(0, 4).map((f) => (
                  <li key={f} className="flex items-center gap-2 text-xs text-zinc-400">
                    <Check className="w-3 h-3 text-zinc-500 shrink-0" />{f}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => toast.success("Demo: Redirecting to checkout…")}
                className="w-full py-3 rounded-xl border border-white/10 text-zinc-400 hover:text-white hover:border-white/20 text-sm transition-all flex items-center justify-center gap-2"
                style={{ fontWeight: 600 }}
              >
                {t("recruit.requestDemo")}
              </button>
            </motion.div>
          </div>

          {/* Sample talent preview (blurred for non-subscribers) */}
          <div>
            <h3 className="text-sm text-white mb-3" style={{ fontWeight: 700 }}>Sample Talent Directory</h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {MOCK_TALENT.slice(0, 4).map((talent, i) => (
                <motion.div
                  key={talent.name}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + i * 0.05 }}
                  className="relative p-4 rounded-xl border border-white/5 bg-white/[0.02] overflow-hidden"
                >
                  {/* Blur overlay for non-subscribers */}
                  <div className="absolute inset-0 backdrop-blur-sm bg-black/20 z-10 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <span className="text-xs text-zinc-300 bg-black/60 px-3 py-1.5 rounded-lg flex items-center gap-1.5">
                      <Shield className="w-3 h-3" /> Subscribe to access
                    </span>
                  </div>
                  <div className="flex items-center gap-3 mb-3">
                    <img src={talent.avatar} alt="" className="w-10 h-10 rounded-xl object-cover border border-white/10" />
                    <div>
                      <div className="flex items-center gap-1">
                        <span className="text-[13px] text-white" style={{ fontWeight: 600 }}>{talent.name}</span>
                        {talent.verified && <BadgeCheck className="w-3 h-3 text-purple-400" />}
                      </div>
                      <span className="text-[11px] text-zinc-500">{talent.title}</span>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1 mb-2">
                    {talent.skills.map((s) => (
                      <span key={s} className="text-[9px] text-zinc-400 bg-white/[0.04] px-1.5 py-0.5 rounded">{s}</span>
                    ))}
                  </div>
                  <div className="flex items-center gap-3 text-[10px] text-zinc-600">
                    <span className="flex items-center gap-0.5"><Star className="w-3 h-3" />{talent.score}</span>
                    <span className="flex items-center gap-0.5"><Zap className="w-3 h-3" />{talent.launches} launches</span>
                    <span className="flex items-center gap-0.5"><Globe className="w-3 h-3" />{talent.location}</span>
                  </div>
                  {talent.openToOffers && (
                    <div className="mt-2 text-[9px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full inline-flex items-center gap-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      Open to offers
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        /* ═══ Founder Section ═══ */
        <div className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-6 rounded-xl border border-purple-500/20 bg-gradient-to-br from-purple-500/[0.05] to-violet-500/[0.03]"
          >
            <h3 className="text-lg text-white mb-2" style={{ fontWeight: 700 }}>{t("recruit.forFounders")}</h3>
            <p className="text-sm text-zinc-400 mb-6">{t("recruit.forFoundersDesc")}</p>

            {/* Profile strength */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-zinc-400">{t("recruit.profileStrength")}</span>
                <span className="text-xs text-purple-400" style={{ fontWeight: 600 }}>72%</span>
              </div>
              <div className="h-2 rounded-full bg-white/[0.04] overflow-hidden">
                <motion.div
                  className="h-full rounded-full bg-gradient-to-r from-purple-500 to-violet-500"
                  initial={{ width: 0 }}
                  animate={{ width: "72%" }}
                  transition={{ delay: 0.3, type: "spring", stiffness: 80 }}
                />
              </div>
              <p className="text-[10px] text-zinc-600 mt-1">Add skills and a bio to reach 100%</p>
            </div>

            {/* Toggle settings */}
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-xl border border-white/5 bg-white/[0.02]">
                <div>
                  <div className="text-sm text-white" style={{ fontWeight: 500 }}>{t("recruit.makeDiscoverable")}</div>
                  <div className="text-[11px] text-zinc-500">Let recruiters find your profile</div>
                </div>
                <button
                  onClick={() => setFounderDiscoverable(!founderDiscoverable)}
                  className={`relative w-12 h-6 rounded-full transition-colors ${founderDiscoverable ? "bg-purple-600" : "bg-zinc-700"}`}
                >
                  <motion.div
                    animate={{ x: founderDiscoverable ? 24 : 2 }}
                    transition={{ type: "spring", stiffness: 500, damping: 30 }}
                    className="absolute top-1 w-4 h-4 rounded-full bg-white"
                  />
                </button>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl border border-white/5 bg-white/[0.02]">
                <div>
                  <div className="text-sm text-white" style={{ fontWeight: 500 }}>{t("recruit.openToOffers")}</div>
                  <div className="text-[11px] text-zinc-500">Show "Open to offers" badge</div>
                </div>
                <button
                  onClick={() => { setOpenToOffers(!openToOffers); if (!openToOffers) toast.success("Badge activated!"); }}
                  className={`relative w-12 h-6 rounded-full transition-colors ${openToOffers ? "bg-emerald-600" : "bg-zinc-700"}`}
                >
                  <motion.div
                    animate={{ x: openToOffers ? 24 : 2 }}
                    transition={{ type: "spring", stiffness: 500, damping: 30 }}
                    className="absolute top-1 w-4 h-4 rounded-full bg-white"
                  />
                </button>
              </div>
            </div>
          </motion.div>

          {/* Badges section */}
          <div>
            <h3 className="text-sm text-white mb-3" style={{ fontWeight: 700 }}>{t("badges.title")}</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { key: "earlyAdopter", icon: Award, color: "purple", earned: true },
                { key: "viralPost", icon: Zap, color: "amber", earned: true },
                { key: "networkBuilder", icon: Users, color: "cyan", earned: false },
                { key: "first1k", icon: TrendingUp, color: "emerald", earned: false },
                { key: "topProduct", icon: Crown, color: "amber", earned: false },
                { key: "globalTeam", icon: Globe, color: "blue", earned: false },
                { key: "launchStreak", icon: Star, color: "violet", earned: true },
                { key: "communityChamp", icon: Award, color: "rose", earned: false },
              ].map((badge, i) => (
                <motion.div
                  key={badge.key}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.2 + i * 0.04 }}
                  className={`p-3 rounded-xl border text-center transition-all ${
                    badge.earned
                      ? "border-purple-500/20 bg-purple-500/[0.04]"
                      : "border-white/[0.03] bg-white/[0.01] opacity-50"
                  }`}
                >
                  <div className={`w-10 h-10 rounded-xl mx-auto mb-2 flex items-center justify-center ${
                    badge.earned ? `bg-${badge.color}-500/15` : "bg-white/[0.03]"
                  }`}>
                    <badge.icon className={`w-5 h-5 ${badge.earned ? `text-${badge.color}-400` : "text-zinc-700"}`} />
                  </div>
                  <div className="text-[11px] text-white mb-0.5" style={{ fontWeight: 600 }}>
                    {t(`badges.${badge.key}`)}
                  </div>
                  <div className="text-[9px] text-zinc-600">
                    {badge.earned ? t("badges.earned") : t("badges.locked")}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default TalentHub;
