import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { PlayCircle, ChevronDown, Video } from "lucide-react";
import { useI18n } from "./i18n";

interface VideoTutorialProps {
  /** YouTube video ID (e.g. "dQw4w9WgXcQ") */
  videoId?: string;
  /** Full external embed URL (e.g. veed.io) */
  embedUrl?: string;
  /** Custom title override */
  title?: string;
  /** Duration label */
  duration?: string;
  /** Placeholder text when no video ID */
  placeholderText?: string;
}

const DEFAULT_EMBED_URL =
  "https://player.veed.io/396d7eb4-33ca-4a85-83f8-e3de8e713574";

/**
 * Collapsible video tutorial embed.
 * Shows a "Watch tutorial" bar that expands into a 16:9 iframe.
 * Supports YouTube videoId, custom embedUrl, or falls back to default veed.io demo.
 */
export function VideoTutorial({
  videoId,
  embedUrl,
  title,
  duration = "2 min",
  placeholderText,
}: VideoTutorialProps) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const displayTitle = title || t("tutorial.title");

  return (
    <div className="rounded-xl border border-white/5 bg-white/[0.02] overflow-hidden">
      {/* Toggle bar */}
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-3 px-4 py-3 hover:bg-white/[0.02] transition-colors"
      >
        <div className="w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center shrink-0">
          <Video className="w-4 h-4 text-purple-400" />
        </div>
        <div className="flex-1 text-left min-w-0">
          <span className="text-sm text-zinc-300" style={{ fontWeight: 500 }}>{displayTitle}</span>
          <span className="text-xs text-zinc-600 ml-2">{duration}</span>
        </div>
        <motion.div animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown className="w-4 h-4 text-zinc-600" />
        </motion.div>
      </button>

      {/* Video area */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4">
              {(() => {
                const src = videoId
                  ? `https://www.youtube.com/embed/${videoId}?rel=0&modestbranding=1`
                  : embedUrl || DEFAULT_EMBED_URL;
                return (
                  <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-black">
                    <iframe
                      src={src}
                      title={displayTitle}
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                      allowFullScreen
                      className="absolute inset-0 w-full h-full"
                    />
                  </div>
                );
              })()}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}