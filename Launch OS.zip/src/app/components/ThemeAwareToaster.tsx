import { Toaster } from "sonner";
import { useTheme } from "./ThemeProvider";

export function ThemeAwareToaster() {
  const { theme } = useTheme();

  return (
    <Toaster
      position="bottom-right"
      theme={theme}
      toastOptions={{
        style:
          theme === "dark"
            ? {
                background: "#18181b",
                border: "1px solid rgba(255,255,255,0.1)",
                color: "#fff",
                fontSize: "13px",
              }
            : {
                background: "#ffffff",
                border: "1px solid rgba(0,0,0,0.08)",
                color: "#09090b",
                fontSize: "13px",
                boxShadow: "0 4px 24px rgba(0,0,0,0.08)",
              },
      }}
    />
  );
}
