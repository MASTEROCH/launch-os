import React from "react";
import { useTheme } from "./ThemeProvider";
import logoDark from "figma:asset/e4fc5f75f08583a9902e54f9390039a95f06b694.png";
import logoLight from "figma:asset/c58d6ef2264956b1d3d384018f90959e6a2b3acb.png";

interface LaunchLogoProps {
  /** Overall container size in px */
  size?: number;
  /** Force logo color regardless of theme */
  forceColor?: "white" | "black";
}

export function LaunchLogo({ size = 32, forceColor }: LaunchLogoProps) {
  const { theme } = useTheme();
  const useWhite = forceColor === "white" || (!forceColor && theme === "dark");
  const logoSrc = logoDark;
  const cornerRadius = size * 0.45;
  const br = `0px ${cornerRadius}px 0px 0px`;
  const isLarge = size >= 48;
  const isHero = size >= 72;
  const isDark = theme === "dark";

  return (
    <div
      className="logo-root relative shrink-0 flex items-center justify-center"
      style={{ width: size, height: size }}
    >
      {/* ── 1. Ambient glow (soft, distant) ── */}
      

      {/* ── 2. Rotating liquid-glass border ── */}
      <div
        className="absolute logo-border-rotate"
        style={{
          inset: -1.5,
          borderRadius: br,
          padding: 1,
          background: isDark
            ? `conic-gradient(
                from var(--ll-angle, 0deg),
                rgba(255,255,255,0.5),
                rgba(255,255,255,0.15),
                rgba(200,200,210,0.4),
                rgba(255,255,255,0.1),
                rgba(220,220,230,0.35),
                rgba(255,255,255,0.2),
                rgba(255,255,255,0.5)
              )`
            : `conic-gradient(
                from var(--ll-angle, 0deg),
                rgba(0,0,0,0.35),
                rgba(60,60,70,0.2),
                rgba(0,0,0,0.3),
                rgba(80,80,90,0.15),
                rgba(0,0,0,0.25),
                rgba(40,40,50,0.2),
                rgba(0,0,0,0.35)
              )`,
          WebkitMask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
          WebkitMaskComposite: "xor" as any,
          maskComposite: "exclude" as any,
        }}
      />

      {/* ── 3. Frosted glass body ── */}
      <div
        className="absolute inset-0 overflow-hidden"
        style={{ borderRadius: br }}
      >
        {/* Base: theme-adaptive glass */}
        <div
          className="absolute inset-0"
          style={{
            background: isDark
              ? `linear-gradient(
                  145deg,
                  rgba(255,255,255,0.18) 0%,
                  rgba(220,220,230,0.22) 35%,
                  rgba(200,200,210,0.25) 65%,
                  rgba(240,240,245,0.2) 100%
                )`
              : `linear-gradient(
                  145deg,
                  rgba(30,30,35,0.82) 0%,
                  rgba(20,20,25,0.88) 35%,
                  rgba(15,15,20,0.92) 65%,
                  rgba(25,25,30,0.85) 100%
                )`,
            backdropFilter: "blur(16px)",
            WebkitBackdropFilter: "blur(16px)",
          }}
        />

        {/* Frosted noise layer (simulated) */}
        <div
          className="absolute inset-0"
          style={{
            background: isDark
              ? `radial-gradient(
                  ellipse at 35% 25%,
                  rgba(255,255,255,0.15) 0%,
                  rgba(255,255,255,0.05) 40%,
                  transparent 70%
                )`
              : `radial-gradient(
                  ellipse at 35% 25%,
                  rgba(255,255,255,0.08) 0%,
                  rgba(255,255,255,0.02) 40%,
                  transparent 70%
                )`,
          }}
        />

        {/* Liquid color refraction — slow moving */}
        <div
          className="absolute inset-0 logo-liquid-move"
          style={{
            background: isDark
              ? `radial-gradient(
                  circle at var(--ll-refract-x, 30%) var(--ll-refract-y, 25%),
                  rgba(255,255,255,0.12) 0%,
                  rgba(220,220,230,0.06) 40%,
                  transparent 70%
                )`
              : `radial-gradient(
                  circle at var(--ll-refract-x, 30%) var(--ll-refract-y, 25%),
                  rgba(255,255,255,0.06) 0%,
                  rgba(200,200,210,0.03) 40%,
                  transparent 70%
                )`,
            mixBlendMode: "screen",
          }}
        />

        {/* Depth: inner shadow at bottom-right */}
        <div
          className="absolute inset-0"
          style={{
            background: `linear-gradient(
              315deg,
              rgba(0,0,0,${isDark ? 0.15 : 0.3}) 0%,
              transparent 50%
            )`,
          }}
        />
      </div>

      {/* ── 4. Glass specular highlight (top) ── */}
      <div
        className="absolute overflow-hidden"
        style={{
          top: 0,
          left: 0,
          right: 0,
          height: "48%",
          borderRadius: br,
        }}
      >
        <div
          style={{
            width: "100%",
            height: "100%",
            background: isDark
              ? `linear-gradient(
                  172deg,
                  rgba(255,255,255,0.35) 0%,
                  rgba(255,255,255,0.12) 35%,
                  rgba(255,255,255,0.03) 60%,
                  transparent 100%
                )`
              : `linear-gradient(
                  172deg,
                  rgba(255,255,255,0.18) 0%,
                  rgba(255,255,255,0.06) 35%,
                  rgba(255,255,255,0.01) 60%,
                  transparent 100%
                )`,
          }}
        />
      </div>

      {/* ── 5. Shimmer sweep ── */}
      <div
        className="absolute inset-0 overflow-hidden"
        style={{ borderRadius: br }}
      >
        <div
          className="absolute logo-glass-shimmer"
          style={{
            top: 0,
            left: "-140%",
            width: "50%",
            height: "200%",
            background: `linear-gradient(
              105deg,
              transparent 30%,
              rgba(255,255,255,0.2) 46%,
              rgba(255,255,255,0.35) 50%,
              rgba(255,255,255,0.2) 54%,
              transparent 70%
            )`,
            transform: "skewX(-18deg)",
          }}
        />
      </div>

      {/* ── 6. Logo image ── */}
      <img
        src={logoSrc}
        alt="Launch OS"
        className="relative z-10 object-contain"
        style={{
          width: size * 0.62,
          height: size * 0.62,
          filter: "drop-shadow(0 1px 3px rgba(0,0,0,0.3))",
        }}
      />

      {/* ── 7. Floating sparkles for large sizes ── */}
      {isLarge && (
        null
      )}

      {/* ── 8. Outer glass rim ── */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          borderRadius: br,
          boxShadow: isDark
            ? `
              inset 0 0.5px 0 rgba(255,255,255,0.35),
              inset 0 -0.5px 0 rgba(0,0,0,0.12),
              0 1px ${Math.max(4, size * 0.12)}px rgba(255,255,255,0.08),
              0 ${Math.max(2, size * 0.06)}px ${Math.max(8, size * 0.25)}px rgba(0,0,0,0.15)
            `
            : `
              inset 0 0.5px 0 rgba(255,255,255,0.15),
              inset 0 -0.5px 0 rgba(0,0,0,0.25),
              0 1px ${Math.max(4, size * 0.12)}px rgba(0,0,0,0.12),
              0 ${Math.max(2, size * 0.06)}px ${Math.max(8, size * 0.25)}px rgba(0,0,0,0.25)
            `,
        }}
      />

      {/* ── Keyframes ── */}
      <style>{`
        @property --ll-angle {
          syntax: "<angle>";
          initial-value: 0deg;
          inherits: false;
        }

        @property --ll-refract-x {
          syntax: "<percentage>";
          initial-value: 30%;
          inherits: false;
        }

        @property --ll-refract-y {
          syntax: "<percentage>";
          initial-value: 25%;
          inherits: false;
        }

        @keyframes llBorderRotate {
          from { --ll-angle: 0deg; }
          to { --ll-angle: 360deg; }
        }

        @keyframes llAmbientPulse {
          0%, 100% { opacity: 0.5; transform: scale(1); }
          50% { opacity: 0.85; transform: scale(1.08); }
        }

        @keyframes llLiquidMove {
          0% { --ll-refract-x: 30%; --ll-refract-y: 25%; }
          33% { --ll-refract-x: 65%; --ll-refract-y: 35%; }
          66% { --ll-refract-x: 45%; --ll-refract-y: 70%; }
          100% { --ll-refract-x: 30%; --ll-refract-y: 25%; }
        }

        @keyframes llGlassShimmer {
          0%, 70% { left: -140%; }
          100% { left: 200%; }
        }

        @keyframes llSparkleFloat {
          0%, 100% {
            opacity: 0;
            transform: translate(-50%, -50%) scale(0.3);
          }
          20% {
            opacity: 1;
            transform: translate(-50%, -50%) scale(1);
          }
          80% {
            opacity: 0.6;
            transform: translate(-50%, calc(-50% - 4px)) scale(0.7);
          }
        }

        .logo-border-rotate {
          animation: llBorderRotate 6s linear infinite;
        }

        .logo-ambient-pulse {
          animation: llAmbientPulse 4s ease-in-out infinite;
        }

        .logo-liquid-move {
          animation: llLiquidMove 8s ease-in-out infinite;
        }

        .logo-glass-shimmer {
          animation: llGlassShimmer 5s ease-in-out 2s infinite;
        }

        .logo-sparkle-float {
          animation: llSparkleFloat 3s ease-in-out infinite;
        }

        @media (prefers-reduced-motion: reduce) {
          .logo-border-rotate,
          .logo-ambient-pulse,
          .logo-liquid-move,
          .logo-glass-shimmer,
          .logo-sparkle-float {
            animation: none !important;
          }
        }
      `}</style>
    </div>
  );
}