import { useState, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import confetti from "canvas-confetti";
import {
  Link2,
  Copy,
  Check,
  Users,
  Coins,
  Gift,
  ChevronRight,
  ChevronDown,
  Share2,
  Mail,
  Send,
  Sparkles,
  Trophy,
  Layers,
  UserPlus,
  Twitter,
  Linkedin,
  MessageCircle,
  Network,
  Plus,
  Minus,
} from "lucide-react";
import { toast as sonnerToast } from "sonner";
import { useI18n } from "./i18n";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { loadProgress, updateProgress } from "./user-progress";
import { copyToClipboard } from "./clipboard";

/* ─── Referral tree node ─── */
interface ReferralNode {
  id: string;
  name: string;
  avatar: string;
  joinedDaysAgo: number;
  tokensEarned: number;
  level: number;
  children: ReferralNode[];
}

/* ─── Mock referral tree data ─── */
const MOCK_TREE: ReferralNode[] = [
  {
    id: "r1",
    name: "Alex Chen",
    avatar: "AC",
    joinedDaysAgo: 12,
    tokensEarned: 100,
    level: 1,
    children: [
      {
        id: "r1a",
        name: "Maria Santos",
        avatar: "MS",
        joinedDaysAgo: 8,
        tokensEarned: 100,
        level: 2,
        children: [
          {
            id: "r1a1",
            name: "James Wilson",
            avatar: "JW",
            joinedDaysAgo: 5,
            tokensEarned: 100,
            level: 3,
            children: [
              {
                id: "r1a1a",
                name: "Yuki Tanaka",
                avatar: "YT",
                joinedDaysAgo: 2,
                tokensEarned: 100,
                level: 4,
                children: [
                  {
                    id: "r1a1a1",
                    name: "Priya Patel",
                    avatar: "PP",
                    joinedDaysAgo: 1,
                    tokensEarned: 100,
                    level: 5,
                    children: [],
                  },
                ],
              },
            ],
          },
          {
            id: "r1a2",
            name: "Li Wei",
            avatar: "LW",
            joinedDaysAgo: 4,
            tokensEarned: 100,
            level: 3,
            children: [],
          },
        ],
      },
      {
        id: "r1b",
        name: "David Kim",
        avatar: "DK",
        joinedDaysAgo: 6,
        tokensEarned: 100,
        level: 2,
        children: [
          {
            id: "r1b1",
            name: "Sofia Rodriguez",
            avatar: "SR",
            joinedDaysAgo: 3,
            tokensEarned: 100,
            level: 3,
            children: [],
          },
        ],
      },
    ],
  },
  {
    id: "r2",
    name: "Emma Thompson",
    avatar: "ET",
    joinedDaysAgo: 10,
    tokensEarned: 100,
    level: 1,
    children: [
      {
        id: "r2a",
        name: "Nikolai Petrov",
        avatar: "NP",
        joinedDaysAgo: 7,
        tokensEarned: 100,
        level: 2,
        children: [
          {
            id: "r2a1",
            name: "Anna Müller",
            avatar: "AM",
            joinedDaysAgo: 3,
            tokensEarned: 100,
            level: 3,
            children: [],
          },
        ],
      },
    ],
  },
  {
    id: "r3",
    name: "Omar Hassan",
    avatar: "OH",
    joinedDaysAgo: 5,
    tokensEarned: 100,
    level: 1,
    children: [],
  },
];

/* ─── Pending invites ─── */
interface PendingInvite {
  id: string;
  email: string;
  sentDaysAgo: number;
  status: "pending" | "accepted";
}

const MOCK_PENDING: PendingInvite[] = [
  { id: "p1", email: "kate@startup.io", sentDaysAgo: 3, status: "pending" },
  { id: "p2", email: "max@devtools.co", sentDaysAgo: 1, status: "pending" },
];

/* ─── Helpers ─── */
function countNodes(nodes: ReferralNode[]): number {
  let c = 0;
  for (const n of nodes) c += 1 + countNodes(n.children);
  return c;
}

function maxDepth(nodes: ReferralNode[]): number {
  if (nodes.length === 0) return 0;
  return Math.max(...nodes.map((n) => (n.children.length > 0 ? maxDepth(n.children) : n.level)));
}

function calcTokensFromTree(nodes: ReferralNode[]): number {
  let total = 0;
  for (const n of nodes) {
    if (n.level === 1) total += 100;
    else if (n.level === 2) total += 50;
    else if (n.level === 3) total += 25;
    else total += 10;
    total += calcTokensFromTree(n.children);
  }
  return total;
}

const levelColors: Record<number, { bg: string; text: string; border: string; line: string }> = {
  1: { bg: "bg-purple-500/10", text: "text-purple-400", border: "border-purple-500/20", line: "bg-purple-500/30" },
  2: { bg: "bg-cyan-500/10", text: "text-cyan-400", border: "border-cyan-500/20", line: "bg-cyan-500/30" },
  3: { bg: "bg-amber-500/10", text: "text-amber-400", border: "border-amber-500/20", line: "bg-amber-500/30" },
  4: { bg: "bg-emerald-500/10", text: "text-emerald-400", border: "border-emerald-500/20", line: "bg-emerald-500/30" },
  5: { bg: "bg-pink-500/10", text: "text-pink-400", border: "border-pink-500/20", line: "bg-pink-500/30" },
};
function getLevelColor(level: number) {
  return levelColors[level] || levelColors[((level - 1) % 5) + 1];
}

function bonusForLevel(level: number): number {
  if (level === 1) return 100;
  if (level === 2) return 50;
  if (level === 3) return 25;
  return 10;
}

const RANDOM_NAMES = [
  "Ava Mitchell", "Leo Garcia", "Mia Johnson", "Ethan Brown",
  "Zara Ali", "Finn O'Brien", "Luna Park", "Noah Schmidt",
  "Isla Chen", "Max Ivanov", "Ruby Singh", "Sam Nakamura",
  "Clara Fischer", "Dante Rossi", "Eva Larsson", "Hugo Fernandez",
];

/* ─── Confetti burst ─── */
function fireConfetti() {
  const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };
  confetti({ ...defaults, particleCount: 50, origin: { x: 0.5, y: 0.45 } });
  setTimeout(() => {
    confetti({ ...defaults, particleCount: 30, origin: { x: 0.3, y: 0.5 } });
    confetti({ ...defaults, particleCount: 30, origin: { x: 0.7, y: 0.5 } });
  }, 200);
}

/* ─── Dispatch notification event to Layout ─── */
function dispatchReferralNotification(name: string, level: number, tokens: number, parentName?: string) {
  document.dispatchEvent(
    new CustomEvent("launchapp:referral", {
      detail: { name, level, tokens, parentName },
    })
  );
}

/* ─── Add child to node in tree (recursive, immutable) ─── */
function addChildToNodeInTree(
  nodes: ReferralNode[],
  parentId: string,
  child: ReferralNode
): ReferralNode[] {
  return nodes.map((n) => {
    if (n.id === parentId) {
      return { ...n, children: [child, ...n.children] };
    }
    if (n.children.length > 0) {
      return { ...n, children: addChildToNodeInTree(n.children, parentId, child) };
    }
    return n;
  });
}

/* ═══════════════════════════════════════════════
   Context-Aware Skeleton
   ═══════════════════════════════════════════════ */
function ReferralSkeleton() {
  return (
    <div className="space-y-6">
      {/* Stats grid skeleton */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.05, duration: 0.3 }}
            className="p-4 rounded-xl border border-white/5 bg-white/[0.02]"
          >
            <div className="flex items-center gap-2 mb-2">
              <div className="w-4 h-4 rounded bg-white/[0.05] skeleton-shimmer" />
              <div className="h-2.5 w-20 rounded bg-white/[0.04] skeleton-shimmer" />
            </div>
            <div className="h-7 w-12 rounded bg-white/[0.06] skeleton-shimmer" />
          </motion.div>
        ))}
      </div>

      {/* Link + Share cards skeleton */}
      <div className="grid md:grid-cols-2 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, duration: 0.3 }}
          className="p-5 rounded-xl border border-white/5 bg-white/[0.02]"
        >
          <div className="flex items-center gap-2 mb-3">
            <div className="w-4 h-4 rounded bg-purple-500/10 skeleton-shimmer" />
            <div className="h-3.5 w-24 rounded bg-white/[0.06] skeleton-shimmer" />
          </div>
          <div className="flex items-center gap-2">
            <div className="flex-1 h-10 rounded-lg bg-white/[0.04] skeleton-shimmer" />
            <div className="w-20 h-10 rounded-lg bg-white/[0.05] skeleton-shimmer" />
          </div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.3 }}
          className="p-5 rounded-xl border border-white/5 bg-white/[0.02]"
        >
          <div className="flex items-center gap-2 mb-3">
            <div className="w-4 h-4 rounded bg-cyan-500/10 skeleton-shimmer" />
            <div className="h-3.5 w-28 rounded bg-white/[0.06] skeleton-shimmer" />
          </div>
          <div className="h-10 rounded-lg bg-white/[0.04] skeleton-shimmer mb-3" />
          <div className="flex gap-2">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="w-10 h-10 rounded-xl bg-white/[0.04] skeleton-shimmer" />
            ))}
          </div>
        </motion.div>
      </div>

      {/* Tree skeleton */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.35, duration: 0.3 }}
        className="p-5 rounded-xl border border-white/5 bg-white/[0.02]"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-purple-500/10 skeleton-shimmer" />
            <div className="h-3.5 w-32 rounded bg-white/[0.06] skeleton-shimmer" />
          </div>
          <div className="flex gap-2">
            <div className="w-16 h-7 rounded-lg bg-white/[0.04] skeleton-shimmer" />
            <div className="w-16 h-7 rounded-lg bg-white/[0.04] skeleton-shimmer" />
            <div className="w-28 h-7 rounded-lg bg-white/[0.04] skeleton-shimmer" />
          </div>
        </div>

        {/* Tree node skeletons */}
        <div className="pl-0 space-y-2">
          {[1, 2, 3].map((i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 + i * 0.08, duration: 0.3 }}
            >
              <div className="flex items-center gap-3 p-3 rounded-xl border border-purple-500/10 bg-white/[0.01]">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-500/10 to-purple-500/5 skeleton-shimmer shrink-0" />
                <div className="flex-1 space-y-1.5">
                  <div className="h-3.5 w-28 rounded bg-white/[0.06] skeleton-shimmer" />
                  <div className="h-2.5 w-40 rounded bg-white/[0.03] skeleton-shimmer" />
                </div>
                <div className="h-5 w-16 rounded-full bg-purple-500/5 skeleton-shimmer" />
              </div>
              {/* Nested child */}
              {i <= 2 && (
                <div className="ml-10 mt-1.5 space-y-1.5">
                  <div className="flex items-center gap-3 p-3 rounded-xl border border-cyan-500/10 bg-white/[0.01]">
                    <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500/10 to-cyan-500/5 skeleton-shimmer shrink-0" />
                    <div className="flex-1 space-y-1.5">
                      <div className="h-3.5 w-24 rounded bg-white/[0.06] skeleton-shimmer" />
                      <div className="h-2.5 w-36 rounded bg-white/[0.03] skeleton-shimmer" />
                    </div>
                    <div className="h-5 w-14 rounded-full bg-cyan-500/5 skeleton-shimmer" />
                  </div>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}

/* ═══════════════════════════════════════════════
   Tree Node Component (recursive, infinite depth)
   ═══════════════════════════════════════════════ */
function TreeNode({
  node,
  expandedIds,
  toggleExpand,
  onAddChild,
  t,
  isLast,
}: {
  node: ReferralNode;
  expandedIds: Set<string>;
  toggleExpand: (id: string) => void;
  onAddChild: (parentId: string, parentName: string, parentLevel: number) => void;
  t: (key: string) => string;
  isLast: boolean;
}) {
  const hasChildren = node.children.length > 0;
  const isExpanded = expandedIds.has(node.id);
  const lc = getLevelColor(node.level);
  const bonus = bonusForLevel(node.level);

  return (
    <div className="relative">
      <div className="flex items-start gap-0">
        {/* Tree connector */}
        <div className="relative w-6 shrink-0 flex flex-col items-center">
          <div className={`w-px h-5 ${lc.line}`} />
          <div className={`w-3 h-px ${lc.line} self-end`} />
          {!isLast && (
            <div
              className={`w-px flex-1 ${lc.line} absolute top-5 left-1/2 -translate-x-1/2`}
              style={{ bottom: 0 }}
            />
          )}
        </div>

        {/* Node card */}
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.2 }}
          className="flex-1 mb-1.5"
        >
          <div
            className={`w-full flex items-center gap-3 p-3 rounded-xl border transition-all text-left group ${lc.border} bg-white/[0.01] hover:bg-white/[0.03]`}
          >
            {/* Avatar — click to expand/collapse */}
            <button
              onClick={() => hasChildren && toggleExpand(node.id)}
              className={`w-9 h-9 rounded-full ${lc.bg} flex items-center justify-center text-xs shrink-0 ${lc.text} ${hasChildren ? "cursor-pointer" : "cursor-default"}`}
              style={{ fontWeight: 700 }}
              title={hasChildren ? "Expand/collapse" : undefined}
            >
              {node.avatar}
            </button>

            {/* Info */}
            <button
              onClick={() => hasChildren && toggleExpand(node.id)}
              className={`flex-1 min-w-0 text-left ${hasChildren ? "cursor-pointer" : "cursor-default"}`}
            >
              <div className="flex items-center gap-2">
                <span className="text-sm text-white truncate" style={{ fontWeight: 600 }}>
                  {node.name}
                </span>
                <span
                  className={`text-[9px] px-1.5 py-0.5 rounded-full ${lc.bg} ${lc.text} border ${lc.border}`}
                  style={{ fontWeight: 600 }}
                >
                  L{node.level}
                </span>
              </div>
              <div className="flex items-center gap-3 mt-0.5">
                <span className="text-[11px] text-zinc-600">
                  {node.joinedDaysAgo === 0
                    ? t("ref.today")
                    : `${node.joinedDaysAgo} ${t("ref.daysAgo")}`}
                </span>
                <span className="text-[11px] text-zinc-600 flex items-center gap-0.5">
                  <Coins className="w-2.5 h-2.5" />+{bonus}
                </span>
                {hasChildren && (
                  <span className="text-[11px] text-zinc-600 flex items-center gap-0.5">
                    <Users className="w-2.5 h-2.5" />
                    {countNodes(node.children)} {t("ref.friends")}
                  </span>
                )}
              </div>
            </button>

            {/* Add child referral button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAddChild(node.id, node.name, node.level);
              }}
              className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 ${lc.bg} hover:scale-110`}
              title={t("ref.addChildHint")}
            >
              <UserPlus className={`w-3 h-3 ${lc.text}`} />
            </button>

            {/* Expand toggle */}
            {hasChildren && (
              <button
                onClick={() => toggleExpand(node.id)}
                className={`w-6 h-6 rounded-md flex items-center justify-center transition-colors ${lc.bg}`}
              >
                {isExpanded ? (
                  <ChevronDown className={`w-3.5 h-3.5 ${lc.text}`} />
                ) : (
                  <ChevronRight className={`w-3.5 h-3.5 ${lc.text}`} />
                )}
              </button>
            )}
          </div>

          {/* Children (recursive) */}
          <AnimatePresence>
            {hasChildren && isExpanded && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.25 }}
                className="overflow-hidden ml-4"
              >
                {node.children.map((child, i) => (
                  <TreeNode
                    key={child.id}
                    node={child}
                    expandedIds={expandedIds}
                    toggleExpand={toggleExpand}
                    onAddChild={onAddChild}
                    t={t}
                    isLast={i === node.children.length - 1}
                  />
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════
   Main Referral Program Component
   ═══════════════════════════════════════════════ */
export function ReferralProgram() {
  const { t } = useI18n();
  useDocumentTitle(t("sidebar.referrals"));
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 550);
    return () => clearTimeout(timer);
  }, []);

  const [tree, setTree] = useState<ReferralNode[]>(() => {
    try {
      const saved = localStorage.getItem("launchapp_referral_tree");
      if (saved) return JSON.parse(saved);
    } catch {}
    return MOCK_TREE;
  });

  const [pending, setPending] = useState<PendingInvite[]>(MOCK_PENDING);
  const [copied, setCopied] = useState(false);
  const [emailInput, setEmailInput] = useState("");
  const [emailSent, setEmailSent] = useState(false);
  const [expandedIds, setExpandedIds] = useState<Set<string>>(() => {
    const ids = new Set<string>();
    tree.forEach((n) => ids.add(n.id));
    return ids;
  });
  const [simulating, setSimulating] = useState(false);

  // Persist tree
  useEffect(() => {
    localStorage.setItem("launchapp_referral_tree", JSON.stringify(tree));
  }, [tree]);

  const referralCode = "ROMAN-LA7X";
  const referralLink = `https://launchos.ai/signup?ref=${referralCode}`;

  // Stats
  const directFriends = tree.length;
  const totalNetwork = countNodes(tree);
  const tokensEarned = calcTokensFromTree(tree);
  const deepest = tree.length > 0 ? maxDepth(tree) : 0;

  const handleCopy = useCallback(() => {
    copyToClipboard(referralLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [referralLink]);

  const toggleExpand = useCallback((id: string) => {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const getAllIds = useCallback((nodes: ReferralNode[]): string[] => {
    const ids: string[] = [];
    for (const n of nodes) {
      if (n.children.length > 0) {
        ids.push(n.id);
        ids.push(...getAllIds(n.children));
      }
    }
    return ids;
  }, []);

  const expandAll = () => setExpandedIds(new Set(getAllIds(tree)));
  const collapseAll = () => setExpandedIds(new Set());

  const handleSendInvite = () => {
    if (!emailInput.trim() || !emailInput.includes("@")) return;
    setPending((p) => [
      ...p,
      { id: `p${Date.now()}`, email: emailInput.trim(), sentDaysAgo: 0, status: "pending" },
    ]);
    setEmailInput("");
    setEmailSent(true);
    sonnerToast.success(t("ref.inviteSent"));
    setTimeout(() => setEmailSent(false), 2000);
  };

  /* ── Simulate a direct (Level 1) referral ── */
  const simulateReferral = () => {
    setSimulating(true);
    setTimeout(() => {
      const name = RANDOM_NAMES[Math.floor(Math.random() * RANDOM_NAMES.length)];
      const initials = name.split(" ").map((w) => w[0]).join("");
      const newNode: ReferralNode = {
        id: `sim-${Date.now()}`,
        name,
        avatar: initials,
        joinedDaysAgo: 0,
        tokensEarned: 100,
        level: 1,
        children: [],
      };
      setTree((prev) => [newNode, ...prev]);

      const tokens = 100;
      const currentTokens = loadProgress().tokensAvailable || 0;
      updateProgress({ tokensAvailable: currentTokens + tokens });

      // Confetti!
      fireConfetti();

      // Notify Layout bell
      dispatchReferralNotification(name, 1, tokens);

      setSimulating(false);
      sonnerToast.success(`${name} — +${tokens} ${t("ref.tokensAwarded")}`);
    }, 1500);
  };

  /* ── Add child referral to any node (tree grows deeper) ── */
  const handleAddChild = useCallback(
    (parentId: string, parentName: string, parentLevel: number) => {
      const name = RANDOM_NAMES[Math.floor(Math.random() * RANDOM_NAMES.length)];
      const initials = name.split(" ").map((w) => w[0]).join("");
      const childLevel = parentLevel + 1;
      const newChild: ReferralNode = {
        id: `deep-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        name,
        avatar: initials,
        joinedDaysAgo: 0,
        tokensEarned: 100,
        level: childLevel,
        children: [],
      };

      setTree((prev) => addChildToNodeInTree(prev, parentId, newChild));

      // Auto-expand parent so user sees the new child
      setExpandedIds((prev) => new Set([...prev, parentId]));

      // Award tokens based on depth
      const tokens = bonusForLevel(childLevel);
      const currentTokens = loadProgress().tokensAvailable || 0;
      updateProgress({ tokensAvailable: currentTokens + tokens });

      // Confetti!
      fireConfetti();

      // Notify Layout bell
      dispatchReferralNotification(name, childLevel, tokens, parentName);

      sonnerToast.success(`${name} — L${childLevel} via ${parentName} — +${tokens} ${t("ref.tokensAwarded")}`);
    },
    [t]
  );

  // Share URLs
  const shareText = `Join me on Launch OS — AI distribution for startups! Sign up with my link and we both get 100 bonus tokens: ${referralLink}`;
  const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}`;
  const linkedinUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(referralLink)}`;
  const telegramUrl = `https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent(shareText)}`;

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-6">
      {/* Header — iOS Large Title */}
      <LargeTitle
        title={t("ref.title")}
        subtitle={t("ref.subtitle")}
        badge={
          <span className="text-xs bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full" style={{ fontWeight: 600 }}>
            ∞ levels
          </span>
        }
      />

      {loading ? (
        <ReferralSkeleton />
      ) : (
      <>
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: t("ref.directFriends"), value: directFriends, icon: Users, color: "text-purple-400" },
          { label: t("ref.totalNetwork"), value: totalNetwork, icon: Network, color: "text-cyan-400" },
          { label: t("ref.tokensEarned"), value: tokensEarned, icon: Coins, color: "text-amber-400" },
          { label: t("ref.deepestLevel"), value: deepest, icon: Layers, color: "text-emerald-400" },
        ].map((s) => (
          <motion.div
            key={s.label}
            layout
            className="p-4 rounded-xl border border-white/5 bg-white/[0.02]"
          >
            <div className="flex items-center gap-2 mb-2">
              <s.icon className={`w-4 h-4 ${s.color}`} />
              <span className="text-xs text-zinc-500">{s.label}</span>
            </div>
            <motion.div
              key={s.value}
              initial={{ scale: 1.15, color: "#a78bfa" }}
              animate={{ scale: 1, color: "#ffffff" }}
              transition={{ duration: 0.4 }}
              className="text-2xl"
              style={{ fontWeight: 700 }}
            >
              {s.value}
            </motion.div>
          </motion.div>
        ))}
      </div>

      {/* Referral Link + Share */}
      <div className="grid md:grid-cols-2 gap-4">
        <div className="p-5 rounded-xl border border-white/5 bg-white/[0.02]">
          <div className="flex items-center gap-2 mb-3">
            <Link2 className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-white" style={{ fontWeight: 600 }}>
              {t("ref.yourLink")}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex-1 bg-white/[0.04] border border-white/10 rounded-lg px-3 py-2.5 text-xs text-zinc-300 truncate select-all">
              {referralLink}
            </div>
            <button
              onClick={handleCopy}
              className={`shrink-0 inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-xs transition-all ${
                copied
                  ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30"
                  : "bg-purple-600 hover:bg-purple-500 text-white"
              }`}
            >
              {copied ? (
                <>
                  <Check className="w-3 h-3" />
                  {t("ref.copied")}
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  {t("ref.copyLink")}
                </>
              )}
            </button>
          </div>
          <div className="mt-4">
            <span className="text-[11px] text-zinc-600 uppercase tracking-wider" style={{ fontWeight: 600 }}>
              {t("ref.shareTitle")}
            </span>
            <div className="flex items-center gap-2 mt-2">
              <a href={twitterUrl} target="_blank" rel="noopener noreferrer" className="w-9 h-9 rounded-lg bg-white/[0.04] border border-white/5 hover:border-white/10 hover:bg-white/[0.06] flex items-center justify-center transition-all">
                <Twitter className="w-3.5 h-3.5 text-zinc-400" />
              </a>
              <a href={linkedinUrl} target="_blank" rel="noopener noreferrer" className="w-9 h-9 rounded-lg bg-white/[0.04] border border-white/5 hover:border-white/10 hover:bg-white/[0.06] flex items-center justify-center transition-all">
                <Linkedin className="w-3.5 h-3.5 text-zinc-400" />
              </a>
              <a href={telegramUrl} target="_blank" rel="noopener noreferrer" className="w-9 h-9 rounded-lg bg-white/[0.04] border border-white/5 hover:border-white/10 hover:bg-white/[0.06] flex items-center justify-center transition-all">
                <MessageCircle className="w-3.5 h-3.5 text-zinc-400" />
              </a>
            </div>
          </div>
        </div>

        <div className="p-5 rounded-xl border border-white/5 bg-white/[0.02]">
          <div className="flex items-center gap-2 mb-3">
            <Mail className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-white" style={{ fontWeight: 600 }}>
              {t("ref.inviteByEmail")}
            </span>
          </div>
          <div className="flex items-center gap-2 mb-4">
            <input
              type="email"
              value={emailInput}
              onChange={(e) => setEmailInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSendInvite()}
              placeholder={t("ref.emailPlaceholder")}
              className="flex-1 bg-white/[0.04] border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder:text-zinc-600 outline-none focus:border-purple-500/40 transition-colors"
            />
            <button
              onClick={handleSendInvite}
              disabled={!emailInput.trim()}
              className="shrink-0 inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-xs bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white transition-all"
            >
              <Send className="w-3 h-3" />
              {t("ref.sendInvite")}
            </button>
          </div>
          {pending.length > 0 && (
            <>
              <span className="text-[11px] text-zinc-600 uppercase tracking-wider" style={{ fontWeight: 600 }}>
                {t("ref.pendingInvites")}
              </span>
              <div className="mt-2 space-y-1.5 max-h-32 overflow-y-auto">
                {pending.map((inv) => (
                  <div key={inv.id} className="flex items-center justify-between px-3 py-2 rounded-lg bg-white/[0.02] border border-white/5">
                    <span className="text-xs text-zinc-400 truncate">{inv.email}</span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full ${
                        inv.status === "accepted" ? "bg-emerald-500/10 text-emerald-400" : "bg-amber-500/10 text-amber-400"
                      }`}
                      style={{ fontWeight: 500 }}
                    >
                      {inv.status === "accepted" ? t("ref.accepted") : t("ref.pending")}
                    </span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* How it Works + Bonus table */}
      <div className="grid md:grid-cols-2 gap-4">
        <div className="p-5 rounded-xl border border-white/5 bg-white/[0.02]">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-white" style={{ fontWeight: 600 }}>
              {t("ref.howItWorks")}
            </span>
          </div>
          <div className="space-y-3">
            {[
              { step: 1, text: t("ref.step1"), icon: Share2 },
              { step: 2, text: t("ref.step2"), icon: UserPlus },
              { step: 3, text: t("ref.step3"), icon: Gift },
              { step: 4, text: t("ref.step4"), icon: Network },
            ].map((s) => (
              <div key={s.step} className="flex items-start gap-3">
                <div className="w-7 h-7 rounded-full bg-purple-500/10 border border-purple-500/20 flex items-center justify-center shrink-0">
                  <span className="text-[10px] text-purple-400" style={{ fontWeight: 700 }}>
                    {s.step}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 leading-relaxed pt-1">{s.text}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="p-5 rounded-xl border border-white/5 bg-white/[0.02]">
          <div className="flex items-center gap-2 mb-4">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span className="text-sm text-white" style={{ fontWeight: 600 }}>
              {t("ref.bonusPerLevel")}
            </span>
          </div>
          <div className="space-y-2">
            {[
              { level: 1, text: t("ref.level1Bonus"), tokens: 100, color: getLevelColor(1) },
              { level: 2, text: t("ref.level2Bonus"), tokens: 50, color: getLevelColor(2) },
              { level: 3, text: t("ref.level3Bonus"), tokens: 25, color: getLevelColor(3) },
              { level: "4+", text: t("ref.deeperBonus"), tokens: 10, color: getLevelColor(4) },
            ].map((b) => (
              <div key={b.level} className={`flex items-center justify-between px-3 py-2.5 rounded-lg border ${b.color.border} ${b.color.bg}`}>
                <div className="flex items-center gap-2">
                  <span className={`text-xs ${b.color.text}`} style={{ fontWeight: 600 }}>
                    L{b.level}
                  </span>
                  <span className="text-xs text-zinc-400">{b.text}</span>
                </div>
                <span className={`text-xs ${b.color.text} flex items-center gap-1`} style={{ fontWeight: 700 }}>
                  <Coins className="w-3 h-3" />+{b.tokens}
                </span>
              </div>
            ))}
          </div>

          {/* Simulate button */}
          <div className="mt-4 pt-4 border-t border-white/5">
            <button
              onClick={simulateReferral}
              disabled={simulating}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 disabled:opacity-50 text-white transition-all shadow-lg shadow-purple-500/10"
            >
              {simulating ? (
                <>
                  <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                    <Sparkles className="w-3.5 h-3.5" />
                  </motion.div>
                  {t("ref.simulate")}...
                </>
              ) : (
                <>
                  <UserPlus className="w-3.5 h-3.5" />
                  {t("ref.simulate")}
                </>
              )}
            </button>
            <p className="text-[10px] text-zinc-600 text-center mt-1.5">{t("ref.simulateHint")}</p>
          </div>
        </div>
      </div>

      {/* Referral Tree */}
      <div className="p-5 rounded-xl border border-white/5 bg-white/[0.02]">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <Network className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-white" style={{ fontWeight: 600 }}>
              {t("ref.tree")}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={expandAll} className="text-[11px] text-zinc-500 hover:text-zinc-300 flex items-center gap-1 transition-colors">
              <Plus className="w-3 h-3" />
              {t("ref.expandAll")}
            </button>
            <span className="text-zinc-700">|</span>
            <button onClick={collapseAll} className="text-[11px] text-zinc-500 hover:text-zinc-300 flex items-center gap-1 transition-colors">
              <Minus className="w-3 h-3" />
              {t("ref.collapseAll")}
            </button>
          </div>
        </div>
        <p className="text-[11px] text-zinc-600 mb-4">{t("ref.treeHint")}</p>

        {tree.length === 0 ? (
          <div className="p-8 text-center">
            <div className="w-14 h-14 rounded-2xl bg-purple-500/10 border border-purple-500/15 flex items-center justify-center mx-auto mb-3">
              <Users className="w-6 h-6 text-purple-400/50" />
            </div>
            <p className="text-xs text-zinc-500">{t("ref.noReferrals")}</p>
          </div>
        ) : (
          <div>
            {/* Root: You */}
            <div className="flex items-center gap-3 p-3 rounded-xl border border-purple-500/20 bg-purple-500/[0.06] mb-2">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center text-sm text-white shrink-0" style={{ fontWeight: 700 }}>
                R
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-white" style={{ fontWeight: 600 }}>
                    Roman ({t("ref.you")})
                  </span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/30" style={{ fontWeight: 600 }}>
                    ROOT
                  </span>
                </div>
                <div className="flex items-center gap-3 mt-0.5">
                  <span className="text-[11px] text-zinc-500 flex items-center gap-1">
                    <Users className="w-2.5 h-2.5" />
                    {directFriends} direct
                  </span>
                  <span className="text-[11px] text-zinc-500 flex items-center gap-1">
                    <Network className="w-2.5 h-2.5" />
                    {totalNetwork} total
                  </span>
                  <span className="text-[11px] text-purple-400 flex items-center gap-1">
                    <Coins className="w-2.5 h-2.5" />+{tokensEarned}
                  </span>
                </div>
              </div>
            </div>

            {/* Tree nodes */}
            <div className="ml-2">
              {tree.map((node, i) => (
                <TreeNode
                  key={node.id}
                  node={node}
                  expandedIds={expandedIds}
                  toggleExpand={toggleExpand}
                  onAddChild={handleAddChild}
                  t={t}
                  isLast={i === tree.length - 1}
                />
              ))}
            </div>
          </div>
        )}
      </div>
      </>
      )}
    </div>
  );
}