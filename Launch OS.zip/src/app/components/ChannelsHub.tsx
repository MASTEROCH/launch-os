import React, { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Link2, Unlink, Check, ChevronRight, Sparkles,
  Copy, Shield, Key, Gift, ExternalLink, Lock, ArrowRight,
  Zap, Radio, RefreshCw, Eye, MessageSquare,
  CheckCircle2, AlertCircle, X, Send,
} from "lucide-react";
import { toast as sonnerToast } from "sonner";
import confetti from "canvas-confetti";
import { useI18n } from "./i18n";
import { loadProgress, updateProgress, LS_KEYS } from "./user-progress";
import { useDocumentTitle } from "./useDocumentTitle";
import { LargeTitle } from "./LargeTitle";
import { StatsSkeleton, CardGridSkeleton } from "./PageSkeleton";
import { useNavigate } from "react-router";
import { WhyBlock } from "./WhyBlock";
import { VideoTutorial } from "./VideoTutorial";

/* ─── Types ─── */
type ChannelStatus = "connected" | "disconnected" | "connecting" | "active" | "pending";
type ChannelTier = "auto" | "assisted" | "managed";

interface Channel {
  id: string;
  name: string;
  tier: ChannelTier;
  icon: string;
  color: string;
  bgColor: string;
  borderColor: string;
  status: ChannelStatus;
  description: string;
  stats?: { posts: number; reach: number; engagement: number };
  features: string[];
  devPortalUrl?: string;
}

/* ─── Developer portal URLs ─── */
const DEV_PORTALS: Record<string, string> = {
  twitter: "https://developer.twitter.com/en/portal/dashboard",
  linkedin: "https://www.linkedin.com/developers/apps",
  facebook: "https://developers.facebook.com/apps/",
  instagram: "https://developers.facebook.com/apps/",
  producthunt: "https://www.producthunt.com/v2/oauth/applications",
  youtube: "https://console.cloud.google.com/apis/credentials",
  reddit: "https://www.reddit.com/prefs/apps",
  hackernews: "https://news.ycombinator.com/",
  indiehackers: "https://www.indiehackers.com/",
  telegram: "https://my.telegram.org/apps",
  devto: "https://dev.to/settings/extensions",
};

/* ─── API key validation patterns per platform ─── */
const API_KEY_PATTERNS: Record<string, { regex: RegExp; hint: string }> = {
  twitter: { regex: /^[A-Za-z0-9]{20,50}$/, hint: "20-50 alphanumeric chars" },
  linkedin: { regex: /^[A-Za-z0-9]{10,30}$/, hint: "10-30 alphanumeric chars" },
  facebook: { regex: /^[0-9]{10,20}\|[A-Za-z0-9_-]{20,40}$/, hint: "App ID|Secret format" },
  instagram: { regex: /^[0-9]{10,20}\|[A-Za-z0-9_-]{20,40}$/, hint: "App ID|Secret format" },
  producthunt: { regex: /^[A-Za-z0-9_-]{30,80}$/, hint: "30-80 chars token" },
  youtube: { regex: /^AIza[A-Za-z0-9_-]{30,40}$/, hint: "Starts with AIza..." },
  reddit: { regex: /^[A-Za-z0-9_-]{14,30}$/, hint: "14-30 chars" },
  hackernews: { regex: /^.{4,}$/, hint: "Min 4 chars" },
  indiehackers: { regex: /^.{4,}$/, hint: "Min 4 chars" },
  telegram: { regex: /^[0-9]+:[A-Za-z0-9_-]{30,50}$/, hint: "Bot token: 123456:ABC..." },
  devto: { regex: /^[A-Za-z0-9]{20,60}$/, hint: "20-60 alphanumeric chars" },
};

/* ─── Channel data ─── */
const initialChannels: Channel[] = [
  // Tier 1 -- Auto-Post (OAuth)
  {
    id: "twitter",
    name: "Twitter / X",
    tier: "auto",
    icon: "X",
    color: "text-white",
    bgColor: "bg-zinc-800",
    borderColor: "border-zinc-600/30",
    status: "disconnected",
    description: "Auto-post threads, announcements, and engage with tech community",
    features: ["Thread generation", "Optimal timing", "Hashtag optimization"],
  },
  {
    id: "linkedin",
    name: "LinkedIn",
    tier: "auto",
    icon: "in",
    color: "text-[#0A66C2]",
    bgColor: "bg-[#0A66C2]/10",
    borderColor: "border-[#0A66C2]/20",
    status: "disconnected",
    description: "Professional announcements, founder stories, and B2B outreach",
    features: ["Post & articles", "Company page", "Network targeting"],
  },
  {
    id: "facebook",
    name: "Facebook",
    tier: "auto",
    icon: "f",
    color: "text-[#1877F2]",
    bgColor: "bg-[#1877F2]/10",
    borderColor: "border-[#1877F2]/20",
    status: "disconnected",
    description: "Reach audiences through pages, groups, and targeted content",
    features: ["Page posts", "Group sharing", "Event promotion"],
  },
  {
    id: "instagram",
    name: "Instagram",
    tier: "auto",
    icon: "IG",
    color: "text-[#E4405F]",
    bgColor: "bg-[#E4405F]/10",
    borderColor: "border-[#E4405F]/20",
    status: "disconnected",
    description: "Visual storytelling with carousels, reels, and stories",
    features: ["Carousel posts", "Story sequences", "Bio link optimization"],
  },
  {
    id: "producthunt",
    name: "Product Hunt",
    tier: "auto",
    icon: "PH",
    color: "text-[#DA552F]",
    bgColor: "bg-[#DA552F]/10",
    borderColor: "border-[#DA552F]/20",
    status: "disconnected",
    description: "Schedule and optimize your Product Hunt launch for maximum upvotes",
    features: ["Launch scheduling", "Maker comment", "Hunter outreach"],
  },
  {
    id: "youtube",
    name: "YouTube",
    tier: "auto",
    icon: "YT",
    color: "text-[#FF0000]",
    bgColor: "bg-[#FF0000]/10",
    borderColor: "border-[#FF0000]/20",
    status: "disconnected",
    description: "Publish demo videos, tutorials, and product walkthroughs",
    features: ["Shorts", "Community posts", "Video SEO"],
  },
  // Tier 2 -- Assisted (Copy & Post)
  {
    id: "reddit",
    name: "Reddit",
    tier: "assisted",
    icon: "R",
    color: "text-[#FF4500]",
    bgColor: "bg-[#FF4500]/10",
    borderColor: "border-[#FF4500]/20",
    status: "disconnected",
    description: "AI crafts authentic posts for relevant subreddits -- you publish",
    features: ["Subreddit matching", "Tone adaptation", "Upvote optimization"],
  },
  {
    id: "hackernews",
    name: "Hacker News",
    tier: "assisted",
    icon: "Y",
    color: "text-[#FF6600]",
    bgColor: "bg-[#FF6600]/10",
    borderColor: "border-[#FF6600]/20",
    status: "disconnected",
    description: "Perfectly crafted Show HN posts optimized for the HN audience",
    features: ["Show HN format", "Technical angle", "Timing optimization"],
  },
  {
    id: "indiehackers",
    name: "Indie Hackers",
    tier: "assisted",
    icon: "IH",
    color: "text-[#1F6FEB]",
    bgColor: "bg-[#1F6FEB]/10",
    borderColor: "border-[#1F6FEB]/20",
    status: "disconnected",
    description: "Share your journey with the indie maker community",
    features: ["Milestone posts", "Revenue updates", "AMA prep"],
  },
  {
    id: "telegram",
    name: "Telegram",
    tier: "assisted",
    icon: "TG",
    color: "text-[#26A5E4]",
    bgColor: "bg-[#26A5E4]/10",
    borderColor: "border-[#26A5E4]/20",
    status: "disconnected",
    description: "Post to startup channels and relevant groups",
    features: ["Channel posts", "Group messages", "Bot integration"],
  },
  {
    id: "devto",
    name: "Dev.to",
    tier: "assisted",
    icon: "DEV",
    color: "text-white",
    bgColor: "bg-zinc-800",
    borderColor: "border-zinc-600/30",
    status: "disconnected",
    description: "Technical articles and tutorials for developer audience",
    features: ["Technical blog", "Code snippets", "Tag optimization"],
  },
  // Tier 3 -- Launch OS-Managed
  {
    id: "email-pr",
    name: "Email PR & Outreach",
    tier: "managed",
    icon: "PR",
    color: "text-purple-400",
    bgColor: "bg-purple-500/10",
    borderColor: "border-purple-500/20",
    status: "active",
    description: "AI-crafted pitch emails to journalists, bloggers, and influencers",
    features: ["500+ press contacts", "Personalized pitches", "Follow-up sequences"],
    stats: { posts: 48, reach: 12400, engagement: 340 },
  },
  {
    id: "catalogs",
    name: "Startup Catalogs",
    tier: "managed",
    icon: "SC",
    color: "text-cyan-400",
    bgColor: "bg-cyan-500/10",
    borderColor: "border-cyan-500/20",
    status: "active",
    description: "Auto-submit to BetaList, SaaSHub, AlternativeTo, and 80+ directories",
    features: ["80+ directories", "Auto-fill forms", "Listing optimization"],
    stats: { posts: 34, reach: 8900, engagement: 210 },
  },
  {
    id: "seo",
    name: "SEO Engine",
    tier: "managed",
    icon: "SEO",
    color: "text-emerald-400",
    bgColor: "bg-emerald-500/10",
    borderColor: "border-emerald-500/20",
    status: "active",
    description: "Auto-generate landing pages, blog posts, and backlink outreach",
    features: ["Keyword research", "Content generation", "Backlink building"],
    stats: { posts: 12, reach: 23100, engagement: 890 },
  },
  {
    id: "newsletters",
    name: "Newsletter Mentions",
    tier: "managed",
    icon: "NL",
    color: "text-amber-400",
    bgColor: "bg-amber-500/10",
    borderColor: "border-amber-500/20",
    status: "active",
    description: "Get featured in popular startup and tech newsletters",
    features: ["200+ newsletters", "Sponsorship matching", "Feature requests"],
    stats: { posts: 8, reach: 45200, engagement: 1200 },
  },
  {
    id: "forums",
    name: "Niche Forums & Communities",
    tier: "managed",
    icon: "NF",
    color: "text-rose-400",
    bgColor: "bg-rose-500/10",
    borderColor: "border-rose-500/20",
    status: "active",
    description: "AI discovers and posts to 300+ niche forums relevant to your product",
    features: ["Forum discovery", "Tone matching", "Community rules compliance"],
    stats: { posts: 67, reach: 18700, engagement: 520 },
  },
];

/* ─── Saved channels state ─── */
function loadChannelState(): Record<string, ChannelStatus> {
  try {
    const raw = localStorage.getItem(LS_KEYS.channels);
    if (raw) return JSON.parse(raw);
  } catch {}
  return {};
}
function saveChannelState(state: Record<string, ChannelStatus>) {
  localStorage.setItem(LS_KEYS.channels, JSON.stringify(state));
}

/* ─── API key state ─── */
function loadApiKeyState(): Record<string, boolean> {
  try {
    const raw = localStorage.getItem(LS_KEYS.apiKeys);
    if (raw) return JSON.parse(raw);
  } catch {}
  return {};
}
function saveApiKeyState(state: Record<string, boolean>) {
  localStorage.setItem(LS_KEYS.apiKeys, JSON.stringify(state));
}

/* ─── Token rewards state ─── */
function loadRewardedChannels(): string[] {
  try {
    const raw = localStorage.getItem(LS_KEYS.channelRewards);
    if (raw) return JSON.parse(raw);
  } catch {}
  return [];
}
function saveRewardedChannels(ids: string[]) {
  localStorage.setItem(LS_KEYS.channelRewards, JSON.stringify(ids));
}

/* ─── Setup level helper ─── */
function getSetupLevel(channelId: string, status: ChannelStatus, apiKeys: Record<string, boolean>, tier: ChannelTier): number {
  if (tier === "managed") return 2; // managed channels are always fully set up
  const accountConnected = status === "connected" || status === "active";
  const hasKey = !!apiKeys[channelId];
  if (accountConnected && hasKey) return 2;
  if (accountConnected) return 1;
  return 0;
}

/* ─── Component ─── */
export function ChannelsHub() {
  const { t } = useI18n();
  useDocumentTitle(t("sidebar.channels"));
  const [loading, setLoading] = useState(true);
  const [channels, setChannels] = useState<Channel[]>(() => {
    const saved = loadChannelState();
    return initialChannels.map((ch) => ({
      ...ch,
      status: saved[ch.id] || ch.status,
    }));
  });
  const [apiKeys, setApiKeys] = useState<Record<string, boolean>>(loadApiKeyState);
  const [rewardedChannels, setRewardedChannels] = useState<string[]>(loadRewardedChannels);
  const [selectedChannel, setSelectedChannel] = useState<Channel | null>(null);
  const [apiKeyModalChannel, setApiKeyModalChannel] = useState<Channel | null>(null);
  const [activeFilter, setActiveFilter] = useState<"all" | ChannelTier>("all");
  const [connectingId, setConnectingId] = useState<string | null>(null);
  const navigate = useNavigate();

  // ─── Guided Tour ───
  const [chTourStep, setChTourStep] = useState(-1);
  const chTourDone = (() => { try { return !!localStorage.getItem("launchapp_ch_tour_done"); } catch { return false; } })();

  useEffect(() => {
    if (!chTourDone && !loading) {
      const timer = setTimeout(() => setChTourStep(0), 600);
      return () => clearTimeout(timer);
    }
  }, [loading, chTourDone]);

  const closeChTour = () => {
    setChTourStep(-1);
    try { localStorage.setItem("launchapp_ch_tour_done", "1"); } catch {}
  };
  const nextChTour = () => {
    if (chTourStep < 2) setChTourStep(chTourStep + 1);
    else closeChTour();
  };

  const chTourSteps = [
    { title: t("chTour.step1Title"), desc: t("chTour.step1Desc") },
    { title: t("chTour.step2Title"), desc: t("chTour.step2Desc") },
    { title: t("chTour.step3Title"), desc: t("chTour.step3Desc") },
  ];

  // Simulate initial load
  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 600);
    return () => clearTimeout(timer);
  }, []);

  // Persist channel states
  useEffect(() => {
    const state: Record<string, ChannelStatus> = {};
    channels.forEach((ch) => { state[ch.id] = ch.status; });
    saveChannelState(state);
    const connectedCount = channels.filter((ch) => ch.status === "connected" || ch.status === "active").length;
    updateProgress({ channelsConnected: connectedCount } as any);
  }, [channels]);

  // Persist API key state
  useEffect(() => {
    saveApiKeyState(apiKeys);
  }, [apiKeys]);

  // Confetti burst for +10 token reward
  const fireRewardConfetti = useCallback(() => {
    const duration = 1500;
    const end = Date.now() + duration;
    const colors = ["#a855f7", "#38bdf8", "#facc15", "#34d399", "#f472b6"];

    const frame = () => {
      confetti({
        particleCount: 3,
        angle: 60,
        spread: 55,
        origin: { x: 0, y: 0.7 },
        colors,
        zIndex: 9999,
      });
      confetti({
        particleCount: 3,
        angle: 120,
        spread: 55,
        origin: { x: 1, y: 0.7 },
        colors,
        zIndex: 9999,
      });
      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();

    // Center burst
    confetti({
      particleCount: 80,
      spread: 100,
      origin: { x: 0.5, y: 0.4 },
      colors,
      zIndex: 9999,
      scalar: 1.2,
    });
  }, []);

  // Check for new rewards when apiKeys or channels change
  const checkAndAwardTokens = useCallback((channelId: string) => {
    const ch = channels.find(c => c.id === channelId);
    if (!ch || ch.tier === "managed") return;
    const level = getSetupLevel(channelId, ch.status, apiKeys, ch.tier);
    if (level === 2 && !rewardedChannels.includes(channelId)) {
      const newRewarded = [...rewardedChannels, channelId];
      setRewardedChannels(newRewarded);
      queueMicrotask(() => {
        saveRewardedChannels(newRewarded);
        // Integrate with global token balance via user-progress
        const progress = loadProgress();
        updateProgress({ tokensAvailable: (progress.tokensAvailable || 0) + 10 });
        sonnerToast.success(t("ch.channelComplete"), {
          description: `${ch.name}: +10 tokens`,
          duration: 4000,
        });
        // Fire confetti celebration
        fireRewardConfetti();
      });
    }
  }, [channels, apiKeys, rewardedChannels, t]);

  const handleConnect = (id: string) => {
    setConnectingId(id);
    setChannels((prev) => prev.map((ch) => ch.id === id ? { ...ch, status: "connecting" as ChannelStatus } : ch));
    // Simulate OAuth flow
    setTimeout(() => {
      setChannels((prev) => prev.map((ch) => ch.id === id ? {
        ...ch,
        status: "connected" as ChannelStatus,
        stats: { posts: 0, reach: 0, engagement: 0 },
      } : ch));
      setConnectingId(null);
      queueMicrotask(() => {
        sonnerToast.success(t("ch.connectSuccess"));
      });
    }, 2200);
  };

  const handleDisconnect = (id: string) => {
    setChannels((prev) => prev.map((ch) => ch.id === id ? { ...ch, status: "disconnected" as ChannelStatus, stats: undefined } : ch));
    if (selectedChannel?.id === id) setSelectedChannel(null);
    // Also remove API key
    setApiKeys(prev => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    queueMicrotask(() => {
      sonnerToast.success(t("ch.disconnectSuccess"));
    });
  };

  const handleApiKeySaved = (channelId: string) => {
    setApiKeys(prev => ({ ...prev, [channelId]: true }));
    setApiKeyModalChannel(null);
    // Check rewards after state update via effect
    queueMicrotask(() => {
      sonnerToast.success(t("ch.apiKeySuccess"));
    });
  };

  // Award tokens after api key or channel state changes
  useEffect(() => {
    channels.forEach(ch => {
      if (ch.tier !== "managed" && (ch.status === "connected" || ch.status === "active") && apiKeys[ch.id] && !rewardedChannels.includes(ch.id)) {
        checkAndAwardTokens(ch.id);
      }
    });
  }, [channels, apiKeys]); // eslint-disable-line react-hooks/exhaustive-deps

  const connectedCount = channels.filter((ch) => ch.status === "connected" || ch.status === "active").length;
  const totalChannels = channels.length;
  const nonManagedChannels = channels.filter(ch => ch.tier !== "managed");
  const fullySetupCount = nonManagedChannels.filter(ch => getSetupLevel(ch.id, ch.status, apiKeys, ch.tier) === 2).length;
  const autoChannels = channels.filter((ch) => ch.tier === "auto");
  const assistedChannels = channels.filter((ch) => ch.tier === "assisted");
  const managedChannels = channels.filter((ch) => ch.tier === "managed");

  const filteredChannels = activeFilter === "all"
    ? channels
    : channels.filter((ch) => ch.tier === activeFilter);

  const tierConfig = {
    auto: {
      title: t("ch.tierAuto"),
      subtitle: t("ch.tierAutoSub"),
      icon: Zap,
      color: "text-purple-400",
      bg: "bg-purple-500/10",
      border: "border-purple-500/20",
      badge: t("ch.oauthBadge"),
    },
    assisted: {
      title: t("ch.tierAssisted"),
      subtitle: t("ch.tierAssistedSub"),
      icon: Copy,
      color: "text-amber-400",
      bg: "bg-amber-500/10",
      border: "border-amber-500/20",
      badge: t("ch.copyBadge"),
    },
    managed: {
      title: t("ch.tierManaged"),
      subtitle: t("ch.tierManagedSub"),
      icon: Shield,
      color: "text-emerald-400",
      bg: "bg-emerald-500/10",
      border: "border-emerald-500/20",
      badge: t("ch.autoBadge"),
    },
  };

  const earnedTokens = rewardedChannels.length * 10;
  const maxTokens = nonManagedChannels.length * 10;

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6">
      {/* Tour overlay backdrop */}
      <AnimatePresence>
        {chTourStep >= 0 && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 z-40"
            onClick={closeChTour}
          />
        )}
      </AnimatePresence>

      {/* Header */}
      <LargeTitle
        title={t("ch.title")}
        subtitle={t("ch.subtitle")}
        badge={
          <span className="text-xs bg-purple-500/10 text-purple-400 px-2.5 py-0.5 rounded-full" style={{ fontWeight: 600 }}>
            {connectedCount}/{totalChannels} {t("ch.active")}
          </span>
        }
        actions={
          <div className="relative">
            <button
              onClick={() => {
                const disconnected = channels.filter((ch) => ch.tier === "auto" && ch.status === "disconnected");
                if (disconnected.length > 0) handleConnect(disconnected[0].id);
              }}
              className={`inline-flex items-center gap-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white px-5 py-2.5 rounded-xl text-sm transition-all shadow-lg shadow-purple-500/20 ${chTourStep === 0 ? "relative z-50 ring-2 ring-purple-400/50 ring-offset-2 ring-offset-zinc-950" : ""}`}
            >
              <Link2 className="w-4 h-4" />
              {t("ch.connectNew")}
            </button>
            <AnimatePresence>
              {chTourStep === 0 && (
                <ChTourTooltip step={0} total={3} title={chTourSteps[0].title} desc={chTourSteps[0].desc} onNext={nextChTour} onSkip={closeChTour} t={t} />
              )}
            </AnimatePresence>
          </div>
        }
      />

      {/* Summary Stats */}
      {loading ? (
        <>
          <StatsSkeleton count={4} cols="grid-cols-2 md:grid-cols-4" />
          <CardGridSkeleton count={6} />
        </>
      ) : (
        <>
          {/* Beginner explanation */}
          <WhyBlock label={t("why.channelsLabel")} color="cyan" variant="collapsible">
            {t("why.channels")}
          </WhyBlock>

          {/* Video tutorial */}
          <VideoTutorial title={t("ch.videoTitle")} duration="3 min" />

          {/* --- Token Reward Banner --- */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 sm:p-5 rounded-2xl border border-amber-500/20 bg-gradient-to-br from-amber-500/[0.06] to-orange-500/[0.03] overflow-hidden relative"
          >
            <div className="absolute top-0 right-0 w-48 h-48 bg-amber-500/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3" />
            <div className="relative">
              <div className="flex items-start gap-3 mb-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/15 flex items-center justify-center shrink-0">
                  <Gift className="w-5 h-5 text-amber-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm text-white" style={{ fontWeight: 600 }}>{t("ch.rewardBannerTitle")}</div>
                  <p className="text-xs text-zinc-400 mt-0.5">{t("ch.rewardBannerDesc")}</p>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-lg text-amber-400" style={{ fontWeight: 700 }}>+{earnedTokens}</div>
                  <div className="text-[10px] text-zinc-500">{t("ch.rewardEarned")}</div>
                </div>
              </div>
              {/* Progress bar */}
              <div className="relative">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] text-zinc-500">
                    {fullySetupCount} {t("ch.rewardOf")} {nonManagedChannels.length} {t("ch.rewardPossible")}
                  </span>
                  <span className="text-[11px] text-amber-400" style={{ fontWeight: 600 }}>
                    {earnedTokens} / {maxTokens}
                  </span>
                </div>
                <div className="h-2 rounded-full bg-white/[0.05] overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${nonManagedChannels.length > 0 ? (fullySetupCount / nonManagedChannels.length) * 100 : 0}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className="h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-500"
                  />
                </div>
                {/* Mini channel dots */}
                <div className="flex items-center gap-1 mt-2 flex-wrap">
                  {nonManagedChannels.map(ch => {
                    const level = getSetupLevel(ch.id, ch.status, apiKeys, ch.tier);
                    return (
                      <div
                        key={ch.id}
                        className={`w-6 h-6 rounded-md flex items-center justify-center text-[9px] transition-all ${
                          level === 2
                            ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                            : level === 1
                            ? "bg-purple-500/15 text-purple-400 border border-purple-500/20"
                            : "bg-white/[0.03] text-zinc-700 border border-white/5"
                        }`}
                        style={{ fontWeight: 700 }}
                        title={`${ch.name}: ${level}/2`}
                      >
                        {ch.icon.slice(0, 2)}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
            {[
              { label: t("ch.totalChannels"), value: `${totalChannels}`, sub: t("ch.configured"), icon: Radio, iconBg: "bg-purple-500/10", iconColor: "text-purple-400" },
              { label: t("ch.connected"), value: `${connectedCount}`, sub: t("ch.readyToPost"), icon: CheckCircle2, iconBg: "bg-emerald-500/10", iconColor: "text-emerald-400" },
              { label: t("ch.totalReach"), value: "108K+", sub: t("ch.potentialAudience"), icon: Eye, iconBg: "bg-cyan-500/10", iconColor: "text-cyan-400" },
              { label: t("ch.contentPieces"), value: "169", sub: t("ch.generated"), icon: Send, iconBg: "bg-amber-500/10", iconColor: "text-amber-400" },
            ].map((stat) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="ios-press p-4 rounded-[14px] border border-white/5 bg-white/[0.02]"
              >
                <div className={`w-8 h-8 rounded-[10px] ${stat.iconBg} flex items-center justify-center mb-3`}>
                  <stat.icon className={`w-4 h-4 ${stat.iconColor}`} />
                </div>
                <div className="text-lg text-white" style={{ fontWeight: 700 }}>{stat.value}</div>
                <div className="text-xs text-zinc-500 truncate">{stat.label}</div>
                <div className="text-xs text-zinc-600 mt-0.5 truncate">{stat.sub}</div>
              </motion.div>
            ))}
          </div>
        </>
      )}

      {/* Filter Tabs */}
      <div className={`relative flex flex-wrap gap-1 p-1 rounded-xl bg-white/[0.02] border border-white/5 w-fit ${chTourStep === 1 ? "relative z-50 ring-2 ring-purple-400/50 ring-offset-2 ring-offset-zinc-950" : ""}`}>
        {[
          { key: "all" as const, label: t("ch.filterAll"), count: totalChannels },
          { key: "auto" as const, label: t("ch.filterAuto"), count: autoChannels.length },
          { key: "assisted" as const, label: t("ch.filterAssisted"), count: assistedChannels.length },
          { key: "managed" as const, label: t("ch.filterManaged"), count: managedChannels.length },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveFilter(tab.key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm transition-all ${
              activeFilter === tab.key
                ? "bg-purple-500/10 text-purple-400"
                : "text-zinc-500 hover:text-zinc-300"
            }`}
          >
            <span>{tab.label}</span>
            <span className={`text-xs px-1.5 py-0.5 rounded-full ${
              activeFilter === tab.key ? "bg-purple-500/20 text-purple-300" : "bg-white/5 text-zinc-600"
            }`}>{tab.count}</span>
          </button>
        ))}
        <AnimatePresence>
          {chTourStep === 1 && (
            <ChTourTooltip step={1} total={3} title={chTourSteps[1].title} desc={chTourSteps[1].desc} onNext={nextChTour} onSkip={closeChTour} t={t} />
          )}
        </AnimatePresence>
      </div>

      {/* Channel Tiers */}
      {(activeFilter === "all" ? ["auto", "assisted", "managed"] as ChannelTier[] : [activeFilter]).map((tier) => {
        const config = tierConfig[tier];
        const tierChannels = filteredChannels.filter((ch) => ch.tier === tier);
        if (tierChannels.length === 0) return null;

        return (
          <motion.div
            key={tier}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            {/* Tier header */}
            <div className="flex items-center gap-3">
              <div className={`w-9 h-9 rounded-xl ${config.bg} flex items-center justify-center`}>
                <config.icon className={`w-4.5 h-4.5 ${config.color}`} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h2 className="text-white" style={{ fontWeight: 600 }}>{config.title}</h2>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full ${config.bg} ${config.color} ${config.border} border`} style={{ fontWeight: 600 }}>
                    {config.badge}
                  </span>
                </div>
                <p className="text-xs text-zinc-500">{config.subtitle}</p>
              </div>
            </div>

            {/* Channel cards grid */}
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {tierChannels.map((channel, i) => {
                const setupLevel = getSetupLevel(channel.id, channel.status, apiKeys, channel.tier);
                const isFullySetup = setupLevel === 2;
                const isAccountConnected = channel.status === "connected" || channel.status === "active";
                const hasApiKeySet = !!apiKeys[channel.id];

                return (
                  <motion.div
                    key={channel.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.04 }}
                    onClick={() => setSelectedChannel(channel)}
                    className={`ios-press group p-4 rounded-[14px] border transition-all cursor-pointer ${
                      isFullySetup && tier !== "managed"
                        ? "border-emerald-500/30 bg-emerald-500/[0.03] hover:bg-emerald-500/[0.05]"
                        : channel.status === "connected" || channel.status === "active"
                        ? `${channel.borderColor} bg-white/[0.02] hover:bg-white/[0.04]`
                        : channel.status === "connecting"
                        ? "border-purple-500/30 bg-purple-500/[0.03]"
                        : "border-white/5 bg-white/[0.01] hover:border-white/10 hover:bg-white/[0.02]"
                    }`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <motion.div layoutId={`channel-icon-${channel.id}`} className={`w-10 h-10 rounded-xl ${channel.bgColor} flex items-center justify-center text-sm ${channel.color} shrink-0`} style={{ fontWeight: 800 }}>
                          {channel.icon}
                        </motion.div>
                        <div>
                          <motion.div layoutId={`channel-name-${channel.id}`} className="text-sm text-white" style={{ fontWeight: 600 }}>{channel.name}</motion.div>
                          <div className="text-[11px] text-zinc-600 mt-0.5">
                            {tier === "auto" ? t("ch.autoLabel") : tier === "assisted" ? t("ch.assistedLabel") : t("ch.managedLabel")}
                          </div>
                        </div>
                      </div>
                      {/* Setup counter badge (for non-managed) */}
                      {tier !== "managed" ? (
                        <SetupBadge level={setupLevel} t={t} />
                      ) : (
                        <StatusBadge status={channel.status} t={t} />
                      )}
                    </div>

                    {/* Fully ready banner */}
                    {isFullySetup && tier !== "managed" && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        className="flex items-center gap-2 px-3 py-2 rounded-lg bg-emerald-500/10 border border-emerald-500/15 mb-3"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span className="text-[11px] text-emerald-400" style={{ fontWeight: 500 }}>{t("ch.fullyReady")}</span>
                      </motion.div>
                    )}

                    {/* Two-step progress indicator (for non-managed) */}
                    {tier !== "managed" && channel.status !== "disconnected" && channel.status !== "connecting" && (
                      <div className="flex items-center gap-2 mb-3">
                        <SetupStep
                          done={isAccountConnected}
                          label={t("ch.step1Account")}
                          icon={<Link2 className="w-3 h-3" />}
                        />
                        <div className="w-4 h-px bg-white/10 shrink-0" />
                        <SetupStep
                          done={hasApiKeySet}
                          label={t("ch.step2ApiKey")}
                          icon={<Key className="w-3 h-3" />}
                        />
                      </div>
                    )}

                    <p className="text-xs text-zinc-500 mb-3 line-clamp-2">{channel.description}</p>

                    {/* Features pills */}
                    <div className="flex flex-wrap gap-1.5 mb-3">
                      {channel.features.slice(0, 3).map((f) => (
                        <span key={f} className="text-[10px] text-zinc-600 px-2 py-0.5 rounded-full bg-white/[0.03] border border-white/5">
                          {f}
                        </span>
                      ))}
                    </div>

                    {/* Stats row (for connected/active channels) */}
                    {channel.stats && (
                      <div className="flex items-center gap-4 pt-3 border-t border-white/5">
                        <div className="text-[11px]">
                          <span className="text-zinc-600">{t("ch.statPosts")}</span>{" "}
                          <span className="text-zinc-400" style={{ fontWeight: 600 }}>{channel.stats.posts}</span>
                        </div>
                        <div className="text-[11px]">
                          <span className="text-zinc-600">{t("ch.statReach")}</span>{" "}
                          <span className="text-zinc-400" style={{ fontWeight: 600 }}>{channel.stats.reach.toLocaleString()}</span>
                        </div>
                        <div className="text-[11px]">
                          <span className="text-zinc-600">{t("ch.statEng")}</span>{" "}
                          <span className="text-zinc-400" style={{ fontWeight: 600 }}>{channel.stats.engagement}</span>
                        </div>
                      </div>
                    )}

                    {/* Action buttons */}
                    <div className="mt-3">
                      {channel.status === "disconnected" && tier !== "managed" && (
                        <button
                          onClick={(e) => { e.stopPropagation(); handleConnect(channel.id); }}
                          className="w-full flex items-center justify-center gap-2 py-2 rounded-lg text-xs text-purple-400 bg-purple-500/10 hover:bg-purple-500/15 border border-purple-500/20 transition-all"
                        >
                          <Link2 className="w-3.5 h-3.5" />
                          {tier === "auto" ? t("ch.connectOAuth") : t("ch.enable")}
                        </button>
                      )}
                      {channel.status === "connecting" && (
                        <div className="w-full flex items-center justify-center gap-2 py-2 rounded-lg text-xs text-purple-400 bg-purple-500/5 border border-purple-500/15">
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          {t("ch.connecting")}
                        </div>
                      )}
                      {isAccountConnected && tier !== "managed" && (
                        <div className="flex gap-2">
                          <button
                            onClick={(e) => { e.stopPropagation(); handleDisconnect(channel.id); }}
                            className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs text-zinc-500 hover:text-red-400 bg-white/[0.02] hover:bg-red-500/5 border border-white/5 hover:border-red-500/20 transition-all"
                          >
                            <Unlink className="w-3 h-3" />
                            {t("ch.disconnect")}
                          </button>
                          {!hasApiKeySet ? (
                            <button
                              onClick={(e) => { e.stopPropagation(); setApiKeyModalChannel(channel); }}
                              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs text-amber-400 bg-amber-500/10 hover:bg-amber-500/15 border border-amber-500/20 transition-all"
                            >
                              <Key className="w-3 h-3" />
                              {t("ch.addApiKey")}
                            </button>
                          ) : (
                            <button
                              onClick={(e) => e.stopPropagation()}
                              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 transition-all"
                            >
                              <Check className="w-3 h-3" />
                              {t("ch.apiKeyAdded")}
                            </button>
                          )}
                        </div>
                      )}
                      {channel.status === "active" && (
                        <div className="w-full flex items-center justify-center gap-2 py-2 rounded-lg text-xs text-emerald-400 bg-emerald-500/5 border border-emerald-500/15">
                          <Radio className="w-3.5 h-3.5" />
                          {t("ch.activeRunning")}
                        </div>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        );
      })}

      {/* How It Works Banner */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className={`p-6 rounded-2xl border border-purple-500/15 bg-gradient-to-br from-purple-500/[0.04] to-violet-500/[0.02] overflow-hidden relative ${chTourStep === 2 ? "z-50 ring-2 ring-purple-400/50 ring-offset-2 ring-offset-zinc-950" : ""}`}
      >
        <div className="absolute top-0 right-0 w-72 h-72 bg-purple-500/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3" />
        <div className="relative">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-5 h-5 text-purple-400" />
            <h3 className="text-white" style={{ fontWeight: 600 }}>{t("ch.howTitle")}</h3>
          </div>
          <div className="grid sm:grid-cols-3 gap-6 mt-4">
            {[
              { step: "01", title: t("ch.howStep1"), desc: t("ch.howStep1Desc"), stepBg: "bg-purple-500/10", stepColor: "text-purple-400" },
              { step: "02", title: t("ch.howStep2"), desc: t("ch.howStep2Desc"), stepBg: "bg-cyan-500/10", stepColor: "text-cyan-400" },
              { step: "03", title: t("ch.howStep3"), desc: t("ch.howStep3Desc"), stepBg: "bg-emerald-500/10", stepColor: "text-emerald-400" },
            ].map((s) => (
              <div key={s.step} className="flex gap-3">
                <div className={`w-8 h-8 rounded-lg ${s.stepBg} flex items-center justify-center shrink-0`}>
                  <span className={`text-xs ${s.stepColor}`} style={{ fontWeight: 700 }}>{s.step}</span>
                </div>
                <div>
                  <div className="text-sm text-white" style={{ fontWeight: 600 }}>{s.title}</div>
                  <p className="text-xs text-zinc-500 mt-1">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        <AnimatePresence>
          {chTourStep === 2 && (
            <ChTourTooltip step={2} total={3} title={chTourSteps[2].title} desc={chTourSteps[2].desc} onNext={nextChTour} onSkip={closeChTour} t={t} />
          )}
        </AnimatePresence>
      </motion.div>

      {/* Security notice */}
      <div className="flex items-start gap-3 p-4 rounded-xl border border-white/5 bg-white/[0.01]">
        <Shield className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
        <div>
          <div className="text-sm text-white" style={{ fontWeight: 500 }}>{t("ch.securityTitle")}</div>
          <p className="text-xs text-zinc-500 mt-0.5">{t("ch.securityDesc")}</p>
        </div>
      </div>

      {/* Channel Detail Modal */}
      <AnimatePresence>
        {selectedChannel && (
          <ChannelDetailModal
            channel={selectedChannel}
            t={t}
            apiKeys={apiKeys}
            onClose={() => setSelectedChannel(null)}
            onConnect={() => { handleConnect(selectedChannel.id); setSelectedChannel(null); }}
            onDisconnect={() => { handleDisconnect(selectedChannel.id); setSelectedChannel(null); }}
            onAddApiKey={() => { setApiKeyModalChannel(selectedChannel); setSelectedChannel(null); }}
          />
        )}
      </AnimatePresence>

      {/* API Key Setup Modal */}
      <AnimatePresence>
        {apiKeyModalChannel && (
          <ApiKeySetupModal
            channel={apiKeyModalChannel}
            t={t}
            onClose={() => setApiKeyModalChannel(null)}
            onSave={(id) => handleApiKeySaved(id)}
          />
        )}
      </AnimatePresence>

      {/* Next step prompt when channels are connected */}
      {connectedCount >= 2 && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-5 rounded-2xl border border-emerald-500/20 bg-gradient-to-br from-emerald-500/10 to-teal-500/10"
        >
          <div className="flex items-start gap-4">
            <div className="w-11 h-11 rounded-xl bg-emerald-500/15 flex items-center justify-center shrink-0">
              <Zap className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="flex-1">
              <h3 className="text-sm text-white" style={{ fontWeight: 600 }}>
                {connectedCount} {t("ch.connected")}! {t("ch.readyToLaunch")}
              </h3>
              <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
                {t("ch.channelsConnectedDesc")}
              </p>
              <button
                onClick={() => navigate("/dashboard/launch")}
                className="mt-3 inline-flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white px-4 py-2 rounded-xl text-sm transition-all"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {t("ch.reviewAndLaunch")}
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}

/* ─── Setup Step Indicator ─── */
function SetupStep({ done, label, icon }: { done: boolean; label: string; icon: React.ReactNode }) {
  return (
    <div className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-[10px] transition-all ${
      done
        ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/15"
        : "bg-white/[0.02] text-zinc-600 border border-white/5"
    }`}>
      {done ? <Check className="w-3 h-3" /> : icon}
      <span style={{ fontWeight: 500 }}>{label}</span>
    </div>
  );
}

/* ─── Setup Badge (0/2, 1/2, 2/2) ─── */
function SetupBadge({ level, t }: { level: number; t: (k: string) => string }) {
  const configs = [
    { className: "bg-white/5 text-zinc-600 border-white/5" },
    { className: "bg-amber-500/10 text-amber-400 border-amber-500/20" },
    { className: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" },
  ];
  const c = configs[level];
  return (
    <span className={`text-[10px] px-2 py-0.5 rounded-full border shrink-0 flex items-center gap-1 ${c.className}`} style={{ fontWeight: 600 }}>
      {level === 2 && <CheckCircle2 className="w-3 h-3" />}
      {level === 1 && <Key className="w-3 h-3" />}
      {level}/2
    </span>
  );
}

/* ─── Status Badge ─── */
function StatusBadge({ status, t }: { status: ChannelStatus; t: (k: string) => string }) {
  const config: Record<ChannelStatus, { label: string; className: string }> = {
    connected: { label: t("ch.statusConnected"), className: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" },
    disconnected: { label: t("ch.statusOffline"), className: "bg-white/5 text-zinc-600 border-white/5" },
    connecting: { label: t("ch.statusConnecting"), className: "bg-purple-500/10 text-purple-400 border-purple-500/20" },
    active: { label: t("ch.statusActive"), className: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" },
    pending: { label: t("ch.statusPending"), className: "bg-amber-500/10 text-amber-400 border-amber-500/20" },
  };
  const c = config[status];
  return (
    <span className={`text-[10px] px-2 py-0.5 rounded-full border shrink-0 ${c.className}`} style={{ fontWeight: 600 }}>
      {c.label}
    </span>
  );
}

/* ─── Channel Detail Modal ─── */
function ChannelDetailModal({
  channel, t, apiKeys, onClose, onConnect, onDisconnect, onAddApiKey,
}: {
  channel: Channel;
  t: (k: string) => string;
  apiKeys: Record<string, boolean>;
  onClose: () => void;
  onConnect: () => void;
  onDisconnect: () => void;
  onAddApiKey: () => void;
}) {
  const isConnected = channel.status === "connected" || channel.status === "active";
  const hasKey = !!apiKeys[channel.id];
  const setupLevel = getSetupLevel(channel.id, channel.status, apiKeys, channel.tier);

  return (
    <>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100]"
        onClick={onClose}
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="fixed z-[100] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90vw] max-w-lg max-h-[85vh] overflow-y-auto"
      >
        <div className="liquid-glass-modal rounded-2xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="p-6 border-b border-white/5">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <motion.div layoutId={`channel-icon-${channel.id}`} className={`w-12 h-12 rounded-xl ${channel.bgColor} flex items-center justify-center text-base ${channel.color}`} style={{ fontWeight: 800 }}>
                  {channel.icon}
                </motion.div>
                <div>
                  <motion.h3 layoutId={`channel-name-${channel.id}`} className="text-white" style={{ fontWeight: 600 }}>{channel.name}</motion.h3>
                  <div className="flex items-center gap-2 mt-0.5">
                    {channel.tier !== "managed" ? (
                      <SetupBadge level={setupLevel} t={t} />
                    ) : (
                      <StatusBadge status={channel.status} t={t} />
                    )}
                    <span className="text-[10px] text-zinc-600">
                      {channel.tier === "auto" ? t("ch.autoLabel") : channel.tier === "assisted" ? t("ch.assistedLabel") : t("ch.managedLabel")}
                    </span>
                  </div>
                </div>
              </div>
              <button onClick={onClose} className="text-zinc-600 hover:text-zinc-400 transition-colors p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Body */}
          <div className="p-6 space-y-5">
            <p className="text-sm text-zinc-400">{channel.description}</p>

            {/* Setup progress for non-managed */}
            {channel.tier !== "managed" && (
              <div className="space-y-2">
                <div className="text-xs text-zinc-500" style={{ fontWeight: 600 }}>{t("ch.setupProgress")}</div>
                <div className="flex items-center gap-3">
                  <SetupStep done={isConnected} label={t("ch.step1Account")} icon={<Link2 className="w-3 h-3" />} />
                  <ArrowRight className="w-3 h-3 text-zinc-700 shrink-0" />
                  <SetupStep done={hasKey} label={t("ch.step2ApiKey")} icon={<Key className="w-3 h-3" />} />
                  <ArrowRight className="w-3 h-3 text-zinc-700 shrink-0" />
                  <div className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-[10px] border ${
                    setupLevel === 2
                      ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/15"
                      : "bg-white/[0.02] text-zinc-600 border-white/5"
                  }`}>
                    {setupLevel === 2 ? <CheckCircle2 className="w-3 h-3" /> : <Gift className="w-3 h-3" />}
                    <span style={{ fontWeight: 500 }}>+10</span>
                  </div>
                </div>
              </div>
            )}

            {/* Features */}
            <div>
              <div className="text-xs text-zinc-500 mb-2" style={{ fontWeight: 600 }}>{t("ch.features")}</div>
              <div className="space-y-1.5">
                {channel.features.map((f) => (
                  <div key={f} className="flex items-center gap-2 text-xs text-zinc-400">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    {f}
                  </div>
                ))}
              </div>
            </div>

            {/* Stats (if available) */}
            {channel.stats && (
              <div>
                <div className="text-xs text-zinc-500 mb-2" style={{ fontWeight: 600 }}>{t("ch.performance")}</div>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: t("ch.statPosts"), value: channel.stats.posts, icon: Send },
                    { label: t("ch.statReach"), value: channel.stats.reach.toLocaleString(), icon: Eye },
                    { label: t("ch.statEng"), value: channel.stats.engagement, icon: MessageSquare },
                  ].map((s) => (
                    <div key={s.label} className="p-3 rounded-xl bg-white/[0.02] border border-white/5 text-center">
                      <s.icon className="w-3.5 h-3.5 text-zinc-600 mx-auto mb-1.5" />
                      <div className="text-sm text-white" style={{ fontWeight: 600 }}>{s.value}</div>
                      <div className="text-[10px] text-zinc-600">{s.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Security note for OAuth channels */}
            {channel.tier === "auto" && (
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/10">
                <Shield className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <p className="text-[11px] text-zinc-400">{t("ch.oauthSecurity")}</p>
              </div>
            )}

            {/* Assisted explanation */}
            {channel.tier === "assisted" && (
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-amber-500/5 border border-amber-500/10">
                <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <p className="text-[11px] text-zinc-400">{t("ch.assistedSecurity")}</p>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-white/5 flex items-center justify-end gap-3 flex-wrap">
            <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm text-zinc-400 hover:text-zinc-300 border border-white/5 hover:border-white/10 transition-all">
              {t("ch.close")}
            </button>
            {channel.status === "disconnected" && channel.tier !== "managed" && (
              <button onClick={onConnect} className="px-5 py-2 rounded-lg text-sm text-white bg-purple-600 hover:bg-purple-500 transition-colors flex items-center gap-2">
                <Link2 className="w-4 h-4" />
                {channel.tier === "auto" ? t("ch.connectOAuth") : t("ch.enable")}
              </button>
            )}
            {isConnected && channel.tier !== "managed" && !hasKey && (
              <button onClick={onAddApiKey} className="px-5 py-2 rounded-lg text-sm text-white bg-amber-600 hover:bg-amber-500 transition-colors flex items-center gap-2">
                <Key className="w-4 h-4" />
                {t("ch.addApiKey")}
              </button>
            )}
            {isConnected && channel.tier !== "managed" && (
              <button onClick={onDisconnect} className="px-5 py-2 rounded-lg text-sm text-red-400 hover:text-red-300 border border-red-500/20 hover:border-red-500/30 hover:bg-red-500/5 transition-all flex items-center gap-2">
                <Unlink className="w-4 h-4" />
                {t("ch.disconnect")}
              </button>
            )}
          </div>
        </div>
      </motion.div>
    </>
  );
}

/* ─── API Key Setup Modal (animated 3-step instruction) ─── */
function ApiKeySetupModal({
  channel, t, onClose, onSave,
}: {
  channel: Channel;
  t: (k: string) => string;
  onClose: () => void;
  onSave: (channelId: string) => void;
}) {
  const [currentStep, setCurrentStep] = useState(0);
  const [apiKey, setApiKey] = useState("");
  const [apiSecret, setApiSecret] = useState("");
  const [verifying, setVerifying] = useState(false);
  const [verified, setVerified] = useState(false);
  const [validationError, setValidationError] = useState("");

  const portalUrl = DEV_PORTALS[channel.id] || "#";
  const keyPattern = API_KEY_PATTERNS[channel.id];

  const steps = [
    {
      title: t("ch.apiStep1Title"),
      desc: t("ch.apiStep1Desc").replace("{platform}", channel.name),
      icon: ExternalLink,
      color: "text-purple-400",
      bg: "bg-purple-500/15",
    },
    {
      title: t("ch.apiStep2Title"),
      desc: t("ch.apiStep2Desc"),
      icon: Copy,
      color: "text-cyan-400",
      bg: "bg-cyan-500/15",
    },
    {
      title: t("ch.apiStep3Title"),
      desc: t("ch.apiStep3Desc"),
      icon: Key,
      color: "text-emerald-400",
      bg: "bg-emerald-500/15",
    },
  ];

  const handleVerify = () => {
    if (!apiKey.trim()) return;
    setValidationError("");
    // Validate format if pattern exists (skip strict validation in demo -- accept any non-empty key)
    if (keyPattern && !keyPattern.regex.test(apiKey.trim())) {
      // In demo mode, warn but still proceed
      setValidationError(`Format hint: ${keyPattern.hint}`);
    }
    setVerifying(true);
    setTimeout(() => {
      setVerifying(false);
      setVerified(true);
      setValidationError("");
      setTimeout(() => {
        onSave(channel.id);
      }, 800);
    }, 1800);
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[110]"
        onClick={onClose}
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.92, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.92, y: 30 }}
        transition={{ type: "spring", damping: 25, stiffness: 300 }}
        className="fixed z-[110] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[92vw] max-w-md max-h-[90vh] overflow-y-auto"
      >
        <div className="liquid-glass-modal rounded-2xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="p-5 border-b border-white/5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl ${channel.bgColor} flex items-center justify-center text-sm ${channel.color}`} style={{ fontWeight: 800 }}>
                  {channel.icon}
                </div>
                <div>
                  <div className="text-sm text-white" style={{ fontWeight: 600 }}>{t("ch.apiModalTitle")}</div>
                  <div className="text-[11px] text-zinc-500">{channel.name}</div>
                </div>
              </div>
              <button onClick={onClose} className="text-zinc-600 hover:text-zinc-400 transition-colors p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-zinc-400 mt-3">{t("ch.apiModalSub")}</p>
          </div>

          {/* Steps */}
          <div className="p-5 space-y-4">
            {/* Step progress dots */}
            <div className="flex items-center justify-center gap-2 mb-2">
              {steps.map((_, i) => (
                <button
                  key={i}
                  onClick={() => !verified && setCurrentStep(i)}
                  className={`h-1.5 rounded-full transition-all cursor-pointer ${
                    i === currentStep ? "w-8 bg-purple-500" : i < currentStep ? "w-4 bg-purple-500/50" : "w-4 bg-white/10"
                  }`}
                />
              ))}
            </div>

            {/* Animated step card */}
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="p-4 rounded-xl border border-white/5 bg-white/[0.02]"
              >
                <div className="flex items-start gap-3 mb-3">
                  <div className={`w-9 h-9 rounded-lg ${steps[currentStep].bg} flex items-center justify-center shrink-0`}>
                    {(() => { const Icon = steps[currentStep].icon; return <Icon className={`w-4 h-4 ${steps[currentStep].color}`} />; })()}
                  </div>
                  <div>
                    <div className="text-xs text-zinc-500 mb-0.5" style={{ fontWeight: 600 }}>
                      {currentStep + 1}/3
                    </div>
                    <div className="text-sm text-white" style={{ fontWeight: 600 }}>
                      {steps[currentStep].title}
                    </div>
                    <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
                      {steps[currentStep].desc}
                    </p>
                  </div>
                </div>

                {/* Step 1: Open developer portal button */}
                {currentStep === 0 && (
                  <motion.a
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.15 }}
                    href={portalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => setTimeout(() => setCurrentStep(1), 300)}
                    className="mt-2 w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs text-purple-400 bg-purple-500/10 hover:bg-purple-500/15 border border-purple-500/20 transition-all"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    {t("ch.openPortal")}
                  </motion.a>
                )}

                {/* Step 2: Visual copy hint */}
                {currentStep === 1 && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.15 }}
                    className="mt-2 p-3 rounded-lg bg-zinc-900 border border-white/5"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <Lock className="w-3 h-3 text-zinc-600" />
                      <span className="text-[10px] text-zinc-600" style={{ fontWeight: 500 }}>API Key</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-7 rounded bg-white/[0.03] border border-white/5 px-2 flex items-center">
                        <span className="text-[11px] text-zinc-500 font-mono">sk-****************************</span>
                      </div>
                      <button
                        onClick={() => setCurrentStep(2)}
                        className="px-3 py-1.5 rounded bg-cyan-500/10 text-cyan-400 text-[10px] border border-cyan-500/20 hover:bg-cyan-500/15 transition-all flex items-center gap-1"
                      >
                        <Copy className="w-3 h-3" />
                        Copy
                      </button>
                    </div>
                  </motion.div>
                )}

                {/* Step 3: Input fields */}
                {currentStep === 2 && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.15 }}
                    className="mt-3 space-y-3"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[10px] text-zinc-500" style={{ fontWeight: 500 }}>API Key</label>
                        {keyPattern && (
                          <span className="text-[9px] text-zinc-600">{keyPattern.hint}</span>
                        )}
                      </div>
                      <input
                        type="password"
                        value={apiKey}
                        onChange={(e) => { setApiKey(e.target.value); setValidationError(""); }}
                        placeholder={t("ch.apiKeyPlaceholder")}
                        className="w-full px-3 py-2.5 rounded-lg bg-white/[0.03] border border-white/5 text-sm text-white placeholder-zinc-700 focus:outline-none focus:border-purple-500/30 focus:ring-1 focus:ring-purple-500/20 transition-all font-mono"
                      />
                      {validationError && (
                        <div className="text-[10px] text-amber-400 mt-1">{validationError}</div>
                      )}
                    </div>
                    <div>
                      <label className="text-[10px] text-zinc-500 mb-1 block" style={{ fontWeight: 500 }}>API Secret</label>
                      <input
                        type="password"
                        value={apiSecret}
                        onChange={(e) => setApiSecret(e.target.value)}
                        placeholder={t("ch.apiSecretPlaceholder")}
                        className="w-full px-3 py-2.5 rounded-lg bg-white/[0.03] border border-white/5 text-sm text-white placeholder-zinc-700 focus:outline-none focus:border-purple-500/30 focus:ring-1 focus:ring-purple-500/20 transition-all font-mono"
                      />
                    </div>
                  </motion.div>
                )}
              </motion.div>
            </AnimatePresence>

            {/* Navigation */}
            <div className="flex items-center justify-between">
              <button
                onClick={() => currentStep > 0 ? setCurrentStep(currentStep - 1) : onClose()}
                className="text-xs text-zinc-500 hover:text-zinc-300 transition-colors"
              >
                {currentStep > 0 ? "Back" : t("ch.close")}
              </button>

              {currentStep < 2 ? (
                <button
                  onClick={() => setCurrentStep(currentStep + 1)}
                  className="text-xs text-white bg-purple-600 hover:bg-purple-500 px-4 py-2 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  Next
                  <ArrowRight className="w-3 h-3" />
                </button>
              ) : (
                <button
                  onClick={handleVerify}
                  disabled={!apiKey.trim() || verifying || verified}
                  className={`text-xs px-5 py-2.5 rounded-lg transition-all flex items-center gap-2 ${
                    verified
                      ? "bg-emerald-600 text-white"
                      : verifying
                      ? "bg-purple-600/50 text-purple-300"
                      : apiKey.trim()
                      ? "bg-purple-600 hover:bg-purple-500 text-white"
                      : "bg-white/5 text-zinc-600 cursor-not-allowed"
                  }`}
                >
                  {verified ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      OK
                    </>
                  ) : verifying ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      {t("ch.verifying")}
                    </>
                  ) : (
                    <>
                      <Shield className="w-3.5 h-3.5" />
                      {t("ch.verifyAndSave")}
                    </>
                  )}
                </button>
              )}
            </div>

            {/* Security note */}
            <div className="flex items-start gap-2 p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/10">
              <Lock className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
              <p className="text-[10px] text-zinc-500 leading-relaxed">{t("ch.apiKeySecurityNote")}</p>
            </div>
          </div>
        </div>
      </motion.div>
    </>
  );
}

/* ─── Guided Tour Tooltip ─── */
function ChTourTooltip({
  step, total, title, desc, onNext, onSkip, t,
}: {
  step: number;
  total: number;
  title: string;
  desc: string;
  onNext: () => void;
  onSkip: () => void;
  t: (k: string) => string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -10, scale: 0.96 }}
      className="fixed z-[100] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90vw] max-w-sm"
    >
      <div className="relative p-5 rounded-2xl bg-zinc-900 border border-purple-500/30 shadow-2xl shadow-purple-500/10">
        <button onClick={onSkip} className="absolute top-3 right-3 text-zinc-600 hover:text-zinc-400 transition-colors">
          <X className="w-3.5 h-3.5" />
        </button>
        <div className="text-xs text-purple-400 mb-2" style={{ fontWeight: 600 }}>{step + 1}/{total}</div>
        <div className="text-sm text-white mb-1" style={{ fontWeight: 600 }}>{title}</div>
        <p className="text-xs text-zinc-400 mb-4 leading-relaxed">{desc}</p>
        <div className="flex items-center gap-1.5 mb-4">
          {Array.from({ length: total }).map((_, i) => (
            <div key={i} className={`h-1 rounded-full transition-all ${i < step ? "w-5 bg-purple-500/50" : i === step ? "w-7 bg-purple-500" : "w-3 bg-white/[0.08]"}`} />
          ))}
        </div>
        <div className="flex items-center justify-between">
          <button onClick={onSkip} className="text-xs text-zinc-600 hover:text-zinc-400 transition-colors">{t("chTour.skip")}</button>
          <button onClick={onNext} className="text-xs text-white bg-purple-600 hover:bg-purple-500 px-4 py-2 rounded-lg transition-colors">
            {step < total - 1 ? t("chTour.next") : t("chTour.done")}
          </button>
        </div>
      </div>
    </motion.div>
  );
}
