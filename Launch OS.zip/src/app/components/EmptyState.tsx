import { motion } from "motion/react";
import { type LucideIcon } from "lucide-react";

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description: string;
  ctaLabel?: string;
  onCta?: () => void;
  color?: "purple" | "cyan" | "emerald" | "amber" | "violet";
}

const colorMap = {
  purple: { iconBg: "bg-purple-500/10", iconText: "text-purple-400", btn: "bg-purple-600 hover:bg-purple-500" },
  cyan: { iconBg: "bg-cyan-500/10", iconText: "text-cyan-400", btn: "bg-cyan-600 hover:bg-cyan-500" },
  emerald: { iconBg: "bg-emerald-500/10", iconText: "text-emerald-400", btn: "bg-emerald-600 hover:bg-emerald-500" },
  amber: { iconBg: "bg-amber-500/10", iconText: "text-amber-400", btn: "bg-amber-600 hover:bg-amber-500" },
  violet: { iconBg: "bg-violet-500/10", iconText: "text-violet-400", btn: "bg-violet-600 hover:bg-violet-500" },
};

export function EmptyState({ icon: Icon, title, description, ctaLabel, onCta, color = "purple" }: EmptyStateProps) {
  const c = colorMap[color];
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="flex flex-col items-center justify-center text-center py-16 px-6"
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", stiffness: 300, damping: 20, delay: 0.1 }}
        className={`w-16 h-16 rounded-2xl ${c.iconBg} flex items-center justify-center mb-5`}
      >
        <Icon className={`w-7 h-7 ${c.iconText}`} />
      </motion.div>
      <h3 className="text-white mb-2" style={{ fontWeight: 600 }}>{title}</h3>
      <p className="text-sm text-zinc-500 max-w-sm leading-relaxed mb-6">{description}</p>
      {ctaLabel && onCta && (
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={onCta}
          className={`flex items-center gap-2 px-6 py-2.5 rounded-xl ${c.btn} text-white text-sm transition-colors`}
          style={{ fontWeight: 500 }}
        >
          {ctaLabel}
        </motion.button>
      )}
    </motion.div>
  );
}
